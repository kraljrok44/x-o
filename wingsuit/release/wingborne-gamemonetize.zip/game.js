/* Wingborne: BASE Flight. Includes three.js (MIT, (c) 2010-2024 three.js authors) */
(()=>{var ie={name:typeof window<"u"&&window.__PLATFORM__||"none",adsAllowed:typeof window<"u"&&window.__ADS__===!0,cg:null,env:"disabled",inGameplay:!1,adblock:!1,muteFromSdk:!1,onMute:null,onPause:null,user:null,onUser:null,locale:typeof navigator<"u"&&navigator.language||"en"},Pt=(s,e)=>{try{return s()}catch{return e}},qe={get name(){return ie.name},get adsEnabled(){return ie.adsAllowed&&!ie.adblock&&(ie.name==="gamemonetize"||ie.name==="crazygames"&&ie.env!=="disabled")},get rewardedAvailable(){return ie.name==="crazygames"&&this.adsEnabled},get user(){return ie.user},get userAvailable(){return ie.name==="crazygames"&&ie.env!=="disabled"&&Pt(()=>ie.cg.user.isUserAccountAvailable,!1)},get locale(){return ie.locale},set onMute(s){ie.onMute=s,s&&s(ie.muteFromSdk)},set onUser(s){ie.onUser=s},set onPause(s){ie.onPause=s},async init(){if(ie.name==="crazygames"&&window.CrazyGames&&window.CrazyGames.SDK)try{if(ie.cg=window.CrazyGames.SDK,await ie.cg.init(),ie.env=ie.cg.environment,ie.env==="disabled")return;let s=ie.cg.game.settings||{};if(ie.muteFromSdk=!!s.muteAudio,ie.cg.game.addSettingsChangeListener(e=>{ie.muteFromSdk=!!e.muteAudio,ie.onMute&&ie.onMute(ie.muteFromSdk)}),ie.locale=Pt(()=>ie.cg.user.systemInfo.locale,ie.locale)||ie.locale,ie.adsAllowed)try{ie.adblock=await ie.cg.ad.hasAdblock()}catch{ie.adblock=!1}try{ie.cg.user.isUserAccountAvailable&&(ie.user=await ie.cg.user.getUser(),ie.cg.user.addAuthListener(e=>{ie.user=e,ie.onUser&&ie.onUser(e)}))}catch{ie.user=null}}catch{ie.env="disabled"}else ie.name==="gamemonetize"&&(ie.env="gamemonetize",window.__gmEvent=s=>{if(s==="SDK_GAME_PAUSE"&&(ie._gmPaused=!0,ie.onPause&&ie.onPause(!0)),s==="SDK_GAME_START"&&(ie._gmPaused=!1,ie.onPause&&ie.onPause(!1),ie._gmResolve)){let e=ie._gmResolve;ie._gmResolve=null,e()}})},loadingStart(){ie.name==="crazygames"&&ie.env!=="disabled"&&Pt(()=>ie.cg.game.loadingStart())},loadingStop(){ie.name==="crazygames"&&ie.env!=="disabled"&&Pt(()=>ie.cg.game.loadingStop())},gameplayStart(){ie.inGameplay||(ie.inGameplay=!0,ie.name==="crazygames"&&ie.env!=="disabled"&&Pt(()=>ie.cg.game.gameplayStart()))},gameplayStop(){ie.inGameplay&&(ie.inGameplay=!1,ie.name==="crazygames"&&ie.env!=="disabled"&&Pt(()=>ie.cg.game.gameplayStop()))},happytime(){ie.name==="crazygames"&&ie.env!=="disabled"&&Pt(()=>ie.cg.game.happytime())},progress(s){ie.name==="crazygames"&&ie.env!=="disabled"&&Pt(()=>ie.cg.game.reportGameCompletedPercentage&&ie.cg.game.reportGameCompletedPercentage(Math.round(s)))},setContext(s){ie.name==="crazygames"&&ie.env!=="disabled"&&Pt(()=>ie.cg.game.setGameContext&&ie.cg.game.setGameContext(s))},showAuthPrompt(){this.userAvailable&&Pt(()=>ie.cg.user.showAuthPrompt().then(s=>{ie.user=s,ie.onUser&&ie.onUser(s)}).catch(()=>{}))},midgame(s={}){return new Promise(e=>{if(!this.adsEnabled)return e(!1);if(ie.name==="crazygames")try{ie.cg.ad.requestAd("midgame",{adStarted:()=>s.started&&s.started(),adFinished:()=>e(!0),adError:()=>e(!1)})}catch{e(!1)}else if(ie.name==="gamemonetize"){if(typeof window.sdk>"u"||!window.sdk.showBanner)return e(!1);ie._gmResolve=()=>e(!0);let t=!1,i=ie.onPause;ie.onPause=n=>{n&&!t&&(t=!0,s.started&&s.started()),i&&i(n)},Pt(()=>window.sdk.showBanner()),setTimeout(()=>{!t&&ie._gmResolve&&(ie._gmResolve=null,ie.onPause=i,e(!1))},1800),setTimeout(()=>{ie._gmResolve&&(ie._gmResolve=null,e(!1)),ie.onPause=i},45e3)}else e(!1)})},rewarded(s={}){return new Promise(e=>{if(!this.rewardedAvailable)return e(!1);try{ie.cg.ad.requestAd("rewarded",{adStarted:()=>s.started&&s.started(),adFinished:()=>e(!0),adError:()=>e(!1)})}catch{e(!1)}})},getItem(s){if(ie.name==="crazygames"&&ie.env!=="disabled"){let e=Pt(()=>ie.cg.data.getItem(s),null);if(e!=null)return e}return Pt(()=>window.localStorage.getItem(s),null)},setItem(s,e){ie.name==="crazygames"&&ie.env!=="disabled"&&Pt(()=>(ie.cg.data.setItem(s,e),!0),!1)||Pt(()=>window.localStorage.setItem(s,e))}};var de=(s,e,t)=>s<e?e:s>t?t:s,fe=(s,e,t)=>s+(e-s)*t,Ye=(s,e,t)=>{let i=de((t-s)/(e-s),0,1);return i*i*(3-2*i)},Je=(s,e,t,i)=>fe(s,e,1-Math.exp(-t*i)),Lf=Math.PI*2;function Qi(s){let e=s>>>0;return function(){e|=0,e=e+1831565813|0;let t=Math.imul(e^e>>>15,1|e);return t=t+Math.imul(t^t>>>7,61|t)^t,((t^t>>>14)>>>0)/4294967296}}var yd=.5*(Math.sqrt(3)-1),xs=(3-Math.sqrt(3))/6,Mo=[[1,1],[-1,1],[1,-1],[-1,-1],[1,0],[-1,0],[0,1],[0,-1]];function Ht(s){let e=Qi(s),t=new Uint8Array(256);for(let o=0;o<256;o++)t[o]=o;for(let o=255;o>0;o--){let l=Math.floor(e()*(o+1)),c=t[o];t[o]=t[l],t[l]=c}let i=new Uint8Array(512);for(let o=0;o<512;o++)i[o]=t[o&255];function n(o,l){let c=(o+l)*yd,h=Math.floor(o+c),d=Math.floor(l+c),u=(h+d)*xs,p=o-(h-u),m=l-(d-u),v=p>m?1:0,f=p>m?0:1,g=p-v+xs,y=m-f+xs,x=p-1+2*xs,_=m-1+2*xs,b=h&255,S=d&255,R=0,P=0,C=0,B=.5-p*p-m*m;if(B>0){let F=Mo[i[b+i[S]]&7];B*=B,R=B*B*(F[0]*p+F[1]*m)}let z=.5-g*g-y*y;if(z>0){let F=Mo[i[b+v+i[S+f]]&7];z*=z,P=z*z*(F[0]*g+F[1]*y)}let D=.5-x*x-_*_;if(D>0){let F=Mo[i[b+1+i[S+1]]&7];D*=D,C=D*D*(F[0]*x+F[1]*_)}return 70*(R+P+C)}function r(o,l,c=5,h=2,d=.5){let u=1,p=1,m=0,v=0;for(let f=0;f<c;f++)m+=u*n(o*p,l*p),v+=u,u*=d,p*=h;return m/v}function a(o,l,c=5,h=2.05,d=.5){let u=1,p=1,m=0,v=0,f=1;for(let g=0;g<c;g++){let y=1-Math.abs(n(o*p,l*p));y*=y,y*=f,f=de(y*1.6,0,1),m+=u*y,v+=u,u*=d,p*=h}return m/v}return{n2:n,fbm:r,ridged:a}}var fr=class{constructor(e){this.p=e,this.len=[0];for(let t=1;t<e.length;t++){let i=e[t].x-e[t-1].x,n=e[t].z-e[t-1].z;this.len.push(this.len[t-1]+Math.hypot(i,n))}this.total=this.len[this.len.length-1],this.cell=120,this.grid=new Map;for(let t=0;t<e.length-1;t++){let i=e[t],n=e[t+1],r=Math.floor((Math.min(i.x,n.x)-400)/this.cell),a=Math.floor((Math.max(i.x,n.x)+400)/this.cell),o=Math.floor((Math.min(i.z,n.z)-400)/this.cell),l=Math.floor((Math.max(i.z,n.z)+400)/this.cell);for(let c=r;c<=a;c++)for(let h=o;h<=l;h++){let d=c*73856093^h*19349663,u=this.grid.get(d);u||(u=[],this.grid.set(d,u)),u.push(t)}}}nearest(e,t,i={d:0,s:0}){let n=Math.floor(e/this.cell)*73856093^Math.floor(t/this.cell)*19349663,r=this.grid.get(n),a=1e9,o=0,l=this.p,c=h=>{let d=l[h],u=l[h+1],p=u.x-d.x,m=u.z-d.z,v=p*p+m*m||1,f=((e-d.x)*p+(t-d.z)*m)/v;f=f<0?0:f>1?1:f;let g=d.x+p*f-e,y=d.z+m*f-t,x=g*g+y*y;x<a&&(a=x,o=this.len[h]+f*(this.len[h+1]-this.len[h]))};if(r)for(let h of r)c(h);else return i.d=1e4,i.s=0,i;return i.d=Math.sqrt(a),i.s=o,i}at(e,t={x:0,z:0,dx:0,dz:1}){e=de(e,0,this.total);let i=1;for(;i<this.len.length-1&&this.len[i]<e;)i++;let n=this.p[i-1],r=this.p[i],a=this.len[i]-this.len[i-1]||1,o=(e-this.len[i-1])/a;return t.x=fe(n.x,r.x,o),t.z=fe(n.z,r.z,o),t.dx=(r.x-n.x)/a,t.dz=(r.z-n.z)/a,t}};function xh(s,e=20){let t=[],i=r=>s[de(r,0,s.length-1)];for(let r=0;r<s.length-1;r++){let a=i(r-1),o=i(r),l=i(r+1),c=i(r+2),h=Math.hypot(l[0]-o[0],l[1]-o[1]),d=Math.max(2,Math.ceil(h/e));for(let u=0;u<d;u++){let p=u/d,m=p*p,v=m*p,f=(g,y,x,_)=>.5*(2*y+(-g+x)*p+(2*g-5*y+4*x-_)*m+(-g+3*y-3*x+_)*v);t.push({x:f(a[0],o[0],l[0],c[0]),z:f(a[1],o[1],l[1],c[1])})}}let n=s[s.length-1];return t.push({x:n[0],z:n[1]}),t}function zt(s){let e=Math.floor(s/60),t=s-e*60;return`${e}:${t<10?"0":""}${t.toFixed(1)}`}var _h=[["pitchDown","Pitch down / dive"],["pitchUp","Pitch up"],["left","Turn left"],["right","Turn right"],["rollL","Roll left"],["rollR","Roll right"],["stab","Stabilize / Jump"],["tuck","Tuck posture (speed)"],["spread","Spread posture (glide)"],["chute","Deploy parachute"],["camera","Change camera"],["restart","Restart flight"],["pause","Pause"]],_s={pitchDown:"KeyW",pitchUp:"KeyS",left:"KeyA",right:"KeyD",rollL:"KeyQ",rollR:"KeyE",stab:"Space",tuck:"ShiftLeft",spread:"KeyX",chute:"KeyF",camera:"KeyC",restart:"KeyR",pause:"KeyP"},gr={pitchDown:["ArrowUp"],pitchUp:["ArrowDown"],left:["ArrowLeft"],right:["ArrowRight"],tuck:["ShiftRight"],stab:["Enter"]},Ms={stab:0,chute:1,restart:2,camera:3,rollL:4,rollR:5,tuck:6,spread:7,pause:9},yr=["A / Cross","B / Circle","X / Square","Y / Triangle","LB / L1","RB / R1","LT / L2","RT / R2","Back","Start","L3","R3","D-Up","D-Down","D-Left","D-Right"],Mh=new Set(["Escape","ControlLeft","ControlRight","MetaLeft","MetaRight","Tab","F5","F11","F12","AltLeft","AltRight"]),vr=class{constructor(e){this.keys=new Set,this.bind={..._s},this.pad={...Ms},this.queue=[],this.lookDX=0,this.lookDY=0,this.ax={pitch:0,turn:0,roll:0},this.invert=!1,this.smoothing=1,this.touch={x:0,y:0,active:!1,btn:{}},this.padPrev=[],this.padActive=!1,this.layout=null,this.onAnyKey=null,this.lastDevice="kb",window.addEventListener("keydown",o=>{if(this.onAnyKey){o.preventDefault(),this.onAnyKey(o.code);return}if(["Space","ArrowUp","ArrowDown","ArrowLeft","ArrowRight"].includes(o.code)&&o.preventDefault(),this.lastDevice="kb",!o.repeat)for(let l of this._actionsFor(o.code))this.queue.push(l);this.keys.add(o.code)}),window.addEventListener("keyup",o=>this.keys.delete(o.code)),window.addEventListener("blur",()=>this.keys.clear());let t=!1,i=0,n=0,r=null;e.addEventListener("pointerdown",o=>{if(o.pointerType!=="touch"){t=!0,i=o.clientX,n=o.clientY,r=o.pointerId,this.lastDevice="kb";try{e.setPointerCapture(r)}catch{}}}),e.addEventListener("pointermove",o=>{!t||o.pointerId!==r||(this.lookDX+=(o.clientX-i)*.006,this.lookDY+=(o.clientY-n)*.006,i=o.clientX,n=o.clientY)});let a=()=>{t=!1};e.addEventListener("pointerup",a),e.addEventListener("pointercancel",a),e.addEventListener("contextmenu",o=>o.preventDefault()),navigator.keyboard&&navigator.keyboard.getLayoutMap&&navigator.keyboard.getLayoutMap().then(o=>{this.layout=o}).catch(()=>{})}_actionsFor(e){let t=[];for(let i in this.bind)(this.bind[i]===e||gr[i]&&gr[i].includes(e))&&t.push(i);return t}down(e){if(this.keys.has(this.bind[e]))return!0;if(gr[e]){for(let t of gr[e])if(this.keys.has(t))return!0}return!!(this.touch.btn[e]||this._padBtn(this.pad[e]))}keyLabel(e){let t=this.bind[e];return t?this.layout&&this.layout.get(t)?this.layout.get(t).toUpperCase():bo(t):"\u2014"}_pads(){return navigator.getGamepads?Array.from(navigator.getGamepads()).filter(Boolean):[]}_padBtn(e){if(e==null)return!1;for(let t of this._pads()){let i=t.buttons[e];if(i&&(i.pressed||i.value>.5))return!0}return!1}poll(e){let t=this._pads(),i=0,n=0,r=0,a=0;for(let u of t){let p=m=>Math.abs(m)<.15?0:(m-Math.sign(m)*.15)/.85;i+=p(u.axes[0]||0),n+=p(u.axes[1]||0),r+=p(u.axes[2]||0),a+=p(u.axes[3]||0),u.buttons.forEach((m,v)=>{let f=m.pressed||m.value>.5,g=u.index+":"+v;if(f&&!this.padPrev[g]){this.padActive=!0,this.lastDevice="pad";for(let y in this.pad)this.pad[y]===v&&this.queue.push(y);this.queue.push("pad:"+v)}this.padPrev[g]=f}),Math.abs(i)+Math.abs(n)>.3&&(this.lastDevice="pad")}Math.abs(r)+Math.abs(a)>0&&(this.lookDX+=r*e*2.5,this.lookDY+=a*e*2);let o=(u,p)=>(this.down(u)?1:0)-(this.down(p)?1:0),l=o("pitchDown","pitchUp"),c=o("right","left"),h=o("rollR","rollL");this.touch.active&&(l+=-this.touch.y,c+=this.touch.x),l+=-n,c+=i,this.invert&&(l=-l);let d=7/Math.max(.3,this.smoothing);this.ax.pitch=Je(this.ax.pitch,de(l,-1,1),d,e),this.ax.turn=Je(this.ax.turn,de(c,-1,1),d,e),this.ax.roll=Je(this.ax.roll,de(h,-1,1),d*1.3,e)}state(){return{pitch:this.ax.pitch,turn:this.ax.turn,roll:this.ax.roll,stab:this.down("stab"),tuck:this.down("tuck"),spread:this.down("spread")}}takeLook(){let e=[this.lookDX,this.lookDY];return this.lookDX=this.lookDY=0,e}consume(){let e=this.queue;return this.queue=[],e}};function bo(s){return s?s.startsWith("Key")?s.slice(3):s.startsWith("Digit")?s.slice(5):{Space:"SPACE",ShiftLeft:"L-SHIFT",ShiftRight:"R-SHIFT",Enter:"ENTER",ArrowUp:"\u2191",ArrowDown:"\u2193",ArrowLeft:"\u2190",ArrowRight:"\u2192",Backspace:"BKSP"}[s]||s.replace("Numpad","NUM "):"\u2014"}var bh="wingborne_save_v1",So={quality:"auto",shadows:!0,speedFx:!0,motionBlur:!0,shake:1,fov:70,hudRoute:!0,master:.8,music:.5,sfx:.8,invert:!1,smoothing:1,view:"chase",warn:{subtle:30,strong:15,critical:5},keys:{..._s},pad:{...Ms},autoSpread:!0};function xr(){return{v:1,coins:0,flights:0,tutorialDone:!1,owned:{suit:["ember"],helmet:["white"],chute:["sunset"],trail:["none"]},equip:{suit:"ember",helmet:"white",chute:"sunset",trail:"none"},missions:{},records:{},archive:[],settings:JSON.parse(JSON.stringify(So)),stats:{flightTime:0,maxSpeed:0,landings:0,crashes:0,gates:0}}}var He={data:xr(),load(){try{let s=qe.getItem(bh);if(s){let e=JSON.parse(s),t=xr();this.data={...t,...e,owned:{...t.owned,...e.owned||{}},equip:{...t.equip,...e.equip||{}},stats:{...t.stats,...e.stats||{}}},this.data.settings={...t.settings,...e.settings||{},warn:{...t.settings.warn,...(e.settings||{}).warn||{}},keys:{...t.settings.keys,...(e.settings||{}).keys||{}},pad:{...t.settings.pad,...(e.settings||{}).pad||{}}},this.isNew=!1;return}}catch{}this.data=xr(),this.isNew=!0},write(){try{let s=JSON.stringify(this.data);for(;s.length>6e5&&this.data.archive.length;)this.data.archive.pop(),s=JSON.stringify(this.data);qe.setItem(bh,s)}catch{}},reset(){let s=this.data.settings;this.data=xr(),this.data.settings=s,this.write()}};var al="170";var Ou=2;var xd=0,Uc=1,Xt=2;var Oa=2;var ln=100,_d=101,Md=102;var bd=200,Sd=201,wd=202,Ed=203,ol=204,ll=205,Td=206,Ad=207,Rd=208,Cd=209,Ld=210,Pd=211,Id=212,Dd=213,Ud=214,Nd=0,Od=1,zd=2,kd=3,Fd=4,Bd=5,Hd=6,Vd=7;var zu=4;var ku=300,Xn=301,qn=302,cl=303,hl=304,za=306,Fs=1e3,Bs=1001,ul=1002,ii=1003,Gd=1004;var _r=1005;var Ti=1006,wo=1007;var Bn=1008;var Vi=1009,Fu=1010,Bu=1011,Hs=1012,Nc=1013,un=1014,pi=1015,vn=1016,Oc=1017,zc=1018,jn=1020,Hu=35902,Vu=1021,Gu=1022,mi=1023,Wu=1024,Xu=1025,Vs=1026,Yn=1027,kc=1028,Fc=1029,qu=1030,Bc=1031;var Hc=1033,ia=33776,na=33777,sa=33778,ra=33779,dl=35840,pl=35841,ml=35842,fl=35843,gl=36196,vl=37492,yl=37496,xl=37808,_l=37809,Ml=37810,bl=37811,Sl=37812,wl=37813,El=37814,Tl=37815,Al=37816,Rl=37817,Cl=37818,Ll=37819,Pl=37820,Il=37821,aa=36492,Dl=36494,Ul=36495,ju=36283,Nl=36284,Ol=36285,zl=36286;var oa=2300,kl=2301,Eo=2302,Sh=2400,wh=2401,Eh=2402;var Bi="",wt="srgb",os="srgb-linear",ka="linear",et="srgb";var bn=7680;var Wd=512,Xd=513,qd=514,jd=515,Yd=516,$d=517,Zd=518,Jd=519,Fl=35044;var Th="300 es",$n=2e3,la=2001,Gi=class{addEventListener(e,t){this._listeners===void 0&&(this._listeners={});let i=this._listeners;i[e]===void 0&&(i[e]=[]),i[e].indexOf(t)===-1&&i[e].push(t)}hasEventListener(e,t){if(this._listeners===void 0)return!1;let i=this._listeners;return i[e]!==void 0&&i[e].indexOf(t)!==-1}removeEventListener(e,t){if(this._listeners===void 0)return;let i=this._listeners[e];if(i!==void 0){let n=i.indexOf(t);n!==-1&&i.splice(n,1)}}dispatchEvent(e){if(this._listeners===void 0)return;let t=this._listeners[e.type];if(t!==void 0){e.target=this;let i=t.slice(0);for(let n=0,r=i.length;n<r;n++)i[n].call(this,e);e.target=null}}},At=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],Ah=1234567,Vn=Math.PI/180,Gs=180/Math.PI;function fi(){let s=4294967295*Math.random()|0,e=4294967295*Math.random()|0,t=4294967295*Math.random()|0,i=4294967295*Math.random()|0;return(At[255&s]+At[s>>8&255]+At[s>>16&255]+At[s>>24&255]+"-"+At[255&e]+At[e>>8&255]+"-"+At[e>>16&15|64]+At[e>>24&255]+"-"+At[63&t|128]+At[t>>8&255]+"-"+At[t>>16&255]+At[t>>24&255]+At[255&i]+At[i>>8&255]+At[i>>16&255]+At[i>>24&255]).toLowerCase()}function _t(s,e,t){return Math.max(e,Math.min(t,s))}function Bl(s,e){return(s%e+e)%e}function Ns(s,e,t){return(1-t)*s+t*e}function ti(s,e){switch(e.constructor){case Float32Array:return s;case Uint32Array:return s/4294967295;case Uint16Array:return s/65535;case Uint8Array:return s/255;case Int32Array:return Math.max(s/2147483647,-1);case Int16Array:return Math.max(s/32767,-1);case Int8Array:return Math.max(s/127,-1);default:throw new Error("Invalid component type.")}}function Ke(s,e){switch(e.constructor){case Float32Array:return s;case Uint32Array:return Math.round(4294967295*s);case Uint16Array:return Math.round(65535*s);case Uint8Array:return Math.round(255*s);case Int32Array:return Math.round(2147483647*s);case Int16Array:return Math.round(32767*s);case Int8Array:return Math.round(127*s);default:throw new Error("Invalid component type.")}}var Vc={DEG2RAD:Vn,RAD2DEG:Gs,generateUUID:fi,clamp:_t,euclideanModulo:Bl,mapLinear:function(s,e,t,i,n){return i+(s-e)*(n-i)/(t-e)},inverseLerp:function(s,e,t){return s!==e?(t-s)/(e-s):0},lerp:Ns,damp:function(s,e,t,i){return Ns(s,e,1-Math.exp(-t*i))},pingpong:function(s,e=1){return e-Math.abs(Bl(s,2*e)-e)},smoothstep:function(s,e,t){return s<=e?0:s>=t?1:(s=(s-e)/(t-e))*s*(3-2*s)},smootherstep:function(s,e,t){return s<=e?0:s>=t?1:(s=(s-e)/(t-e))*s*s*(s*(6*s-15)+10)},randInt:function(s,e){return s+Math.floor(Math.random()*(e-s+1))},randFloat:function(s,e){return s+Math.random()*(e-s)},randFloatSpread:function(s){return s*(.5-Math.random())},seededRandom:function(s){s!==void 0&&(Ah=s);let e=Ah+=1831565813;return e=Math.imul(e^e>>>15,1|e),e^=e+Math.imul(e^e>>>7,61|e),((e^e>>>14)>>>0)/4294967296},degToRad:function(s){return s*Vn},radToDeg:function(s){return s*Gs},isPowerOfTwo:function(s){return!(s&s-1)&&s!==0},ceilPowerOfTwo:function(s){return Math.pow(2,Math.ceil(Math.log(s)/Math.LN2))},floorPowerOfTwo:function(s){return Math.pow(2,Math.floor(Math.log(s)/Math.LN2))},setQuaternionFromProperEuler:function(s,e,t,i,n){let r=Math.cos,a=Math.sin,o=r(t/2),l=a(t/2),c=r((e+i)/2),h=a((e+i)/2),d=r((e-i)/2),u=a((e-i)/2),p=r((i-e)/2),m=a((i-e)/2);switch(n){case"XYX":s.set(o*h,l*d,l*u,o*c);break;case"YZY":s.set(l*u,o*h,l*d,o*c);break;case"ZXZ":s.set(l*d,l*u,o*h,o*c);break;case"XZX":s.set(o*h,l*m,l*p,o*c);break;case"YXY":s.set(l*p,o*h,l*m,o*c);break;case"ZYZ":s.set(l*m,l*p,o*h,o*c);break;default:console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+n)}},normalize:Ke,denormalize:ti},oe=class s{constructor(e=0,t=0){s.prototype.isVector2=!0,this.x=e,this.y=t}get width(){return this.x}set width(e){this.x=e}get height(){return this.y}set height(e){this.y=e}set(e,t){return this.x=e,this.y=t,this}setScalar(e){return this.x=e,this.y=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y)}copy(e){return this.x=e.x,this.y=e.y,this}add(e){return this.x+=e.x,this.y+=e.y,this}addScalar(e){return this.x+=e,this.y+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this}subScalar(e){return this.x-=e,this.y-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this}multiply(e){return this.x*=e.x,this.y*=e.y,this}multiplyScalar(e){return this.x*=e,this.y*=e,this}divide(e){return this.x/=e.x,this.y/=e.y,this}divideScalar(e){return this.multiplyScalar(1/e)}applyMatrix3(e){let t=this.x,i=this.y,n=e.elements;return this.x=n[0]*t+n[3]*i+n[6],this.y=n[1]*t+n[4]*i+n[7],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this}clampLength(e,t){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this}negate(){return this.x=-this.x,this.y=-this.y,this}dot(e){return this.x*e.x+this.y*e.y}cross(e){return this.x*e.y-this.y*e.x}lengthSq(){return this.x*this.x+this.y*this.y}length(){return Math.sqrt(this.x*this.x+this.y*this.y)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)}normalize(){return this.divideScalar(this.length()||1)}angle(){return Math.atan2(-this.y,-this.x)+Math.PI}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let i=this.dot(e)/t;return Math.acos(_t(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,i=this.y-e.y;return t*t+i*i}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this}equals(e){return e.x===this.x&&e.y===this.y}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this}rotateAround(e,t){let i=Math.cos(t),n=Math.sin(t),r=this.x-e.x,a=this.y-e.y;return this.x=r*i-a*n+e.x,this.y=r*n+a*i+e.y,this}random(){return this.x=Math.random(),this.y=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y}},De=class s{constructor(e,t,i,n,r,a,o,l,c){s.prototype.isMatrix3=!0,this.elements=[1,0,0,0,1,0,0,0,1],e!==void 0&&this.set(e,t,i,n,r,a,o,l,c)}set(e,t,i,n,r,a,o,l,c){let h=this.elements;return h[0]=e,h[1]=n,h[2]=o,h[3]=t,h[4]=r,h[5]=l,h[6]=i,h[7]=a,h[8]=c,this}identity(){return this.set(1,0,0,0,1,0,0,0,1),this}copy(e){let t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],this}extractBasis(e,t,i){return e.setFromMatrix3Column(this,0),t.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this}setFromMatrix4(e){let t=e.elements;return this.set(t[0],t[4],t[8],t[1],t[5],t[9],t[2],t[6],t[10]),this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let i=e.elements,n=t.elements,r=this.elements,a=i[0],o=i[3],l=i[6],c=i[1],h=i[4],d=i[7],u=i[2],p=i[5],m=i[8],v=n[0],f=n[3],g=n[6],y=n[1],x=n[4],_=n[7],b=n[2],S=n[5],R=n[8];return r[0]=a*v+o*y+l*b,r[3]=a*f+o*x+l*S,r[6]=a*g+o*_+l*R,r[1]=c*v+h*y+d*b,r[4]=c*f+h*x+d*S,r[7]=c*g+h*_+d*R,r[2]=u*v+p*y+m*b,r[5]=u*f+p*x+m*S,r[8]=u*g+p*_+m*R,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[3]*=e,t[6]*=e,t[1]*=e,t[4]*=e,t[7]*=e,t[2]*=e,t[5]*=e,t[8]*=e,this}determinant(){let e=this.elements,t=e[0],i=e[1],n=e[2],r=e[3],a=e[4],o=e[5],l=e[6],c=e[7],h=e[8];return t*a*h-t*o*c-i*r*h+i*o*l+n*r*c-n*a*l}invert(){let e=this.elements,t=e[0],i=e[1],n=e[2],r=e[3],a=e[4],o=e[5],l=e[6],c=e[7],h=e[8],d=h*a-o*c,u=o*l-h*r,p=c*r-a*l,m=t*d+i*u+n*p;if(m===0)return this.set(0,0,0,0,0,0,0,0,0);let v=1/m;return e[0]=d*v,e[1]=(n*c-h*i)*v,e[2]=(o*i-n*a)*v,e[3]=u*v,e[4]=(h*t-n*l)*v,e[5]=(n*r-o*t)*v,e[6]=p*v,e[7]=(i*l-c*t)*v,e[8]=(a*t-i*r)*v,this}transpose(){let e,t=this.elements;return e=t[1],t[1]=t[3],t[3]=e,e=t[2],t[2]=t[6],t[6]=e,e=t[5],t[5]=t[7],t[7]=e,this}getNormalMatrix(e){return this.setFromMatrix4(e).invert().transpose()}transposeIntoArray(e){let t=this.elements;return e[0]=t[0],e[1]=t[3],e[2]=t[6],e[3]=t[1],e[4]=t[4],e[5]=t[7],e[6]=t[2],e[7]=t[5],e[8]=t[8],this}setUvTransform(e,t,i,n,r,a,o){let l=Math.cos(r),c=Math.sin(r);return this.set(i*l,i*c,-i*(l*a+c*o)+a+e,-n*c,n*l,-n*(-c*a+l*o)+o+t,0,0,1),this}scale(e,t){return this.premultiply(To.makeScale(e,t)),this}rotate(e){return this.premultiply(To.makeRotation(-e)),this}translate(e,t){return this.premultiply(To.makeTranslation(e,t)),this}makeTranslation(e,t){return e.isVector2?this.set(1,0,e.x,0,1,e.y,0,0,1):this.set(1,0,e,0,1,t,0,0,1),this}makeRotation(e){let t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,i,t,0,0,0,1),this}makeScale(e,t){return this.set(e,0,0,0,t,0,0,0,1),this}equals(e){let t=this.elements,i=e.elements;for(let n=0;n<9;n++)if(t[n]!==i[n])return!1;return!0}fromArray(e,t=0){for(let i=0;i<9;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){let i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e}clone(){return new this.constructor().fromArray(this.elements)}},To=new De;function Yu(s){for(let e=s.length-1;e>=0;--e)if(s[e]>=65535)return!0;return!1}function ca(s){return document.createElementNS("http://www.w3.org/1999/xhtml",s)}function Kd(){let s=ca("canvas");return s.style.display="block",s}var Rh={};function Us(s){s in Rh||(Rh[s]=!0,console.warn(s))}var je={enabled:!0,workingColorSpace:os,spaces:{},convert:function(s,e,t){return this.enabled!==!1&&e!==t&&e&&t&&(this.spaces[e].transfer===et&&(s.r=Ai(s.r),s.g=Ai(s.g),s.b=Ai(s.b)),this.spaces[e].primaries!==this.spaces[t].primaries&&(s.applyMatrix3(this.spaces[e].toXYZ),s.applyMatrix3(this.spaces[t].fromXYZ)),this.spaces[t].transfer===et&&(s.r=Gn(s.r),s.g=Gn(s.g),s.b=Gn(s.b))),s},fromWorkingColorSpace:function(s,e){return this.convert(s,this.workingColorSpace,e)},toWorkingColorSpace:function(s,e){return this.convert(s,e,this.workingColorSpace)},getPrimaries:function(s){return this.spaces[s].primaries},getTransfer:function(s){return s===Bi?ka:this.spaces[s].transfer},getLuminanceCoefficients:function(s,e=this.workingColorSpace){return s.fromArray(this.spaces[e].luminanceCoefficients)},define:function(s){Object.assign(this.spaces,s)},_getMatrix:function(s,e,t){return s.copy(this.spaces[e].toXYZ).multiply(this.spaces[t].fromXYZ)},_getDrawingBufferColorSpace:function(s){return this.spaces[s].outputColorSpaceConfig.drawingBufferColorSpace},_getUnpackColorSpace:function(s=this.workingColorSpace){return this.spaces[s].workingColorSpaceConfig.unpackColorSpace}};function Ai(s){return s<.04045?.0773993808*s:Math.pow(.9478672986*s+.0521327014,2.4)}function Gn(s){return s<.0031308?12.92*s:1.055*Math.pow(s,.41666)-.055}var Ch=[.64,.33,.3,.6,.15,.06],Lh=[.2126,.7152,.0722],Ph=[.3127,.329],Ih=new De().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),Dh=new De().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715),Sn;je.define({[os]:{primaries:Ch,whitePoint:Ph,transfer:ka,toXYZ:Ih,fromXYZ:Dh,luminanceCoefficients:Lh,workingColorSpaceConfig:{unpackColorSpace:wt},outputColorSpaceConfig:{drawingBufferColorSpace:wt}},[wt]:{primaries:Ch,whitePoint:Ph,transfer:et,toXYZ:Ih,fromXYZ:Dh,luminanceCoefficients:Lh,outputColorSpaceConfig:{drawingBufferColorSpace:wt}}});var Hl=class{static getDataURL(e){if(/^data:/i.test(e.src)||typeof HTMLCanvasElement>"u")return e.src;let t;if(e instanceof HTMLCanvasElement)t=e;else{Sn===void 0&&(Sn=ca("canvas")),Sn.width=e.width,Sn.height=e.height;let i=Sn.getContext("2d");e instanceof ImageData?i.putImageData(e,0,0):i.drawImage(e,0,0,e.width,e.height),t=Sn}return t.width>2048||t.height>2048?(console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons",e),t.toDataURL("image/jpeg",.6)):t.toDataURL("image/png")}static sRGBToLinear(e){if(typeof HTMLImageElement<"u"&&e instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&e instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&e instanceof ImageBitmap){let t=ca("canvas");t.width=e.width,t.height=e.height;let i=t.getContext("2d");i.drawImage(e,0,0,e.width,e.height);let n=i.getImageData(0,0,e.width,e.height),r=n.data;for(let a=0;a<r.length;a++)r[a]=255*Ai(r[a]/255);return i.putImageData(n,0,0),t}if(e.data){let t=e.data.slice(0);for(let i=0;i<t.length;i++)t instanceof Uint8Array||t instanceof Uint8ClampedArray?t[i]=Math.floor(255*Ai(t[i]/255)):t[i]=Ai(t[i]);return{data:t,width:e.width,height:e.height}}return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),e}},Qd=0,ha=class{constructor(e=null){this.isSource=!0,Object.defineProperty(this,"id",{value:Qd++}),this.uuid=fi(),this.data=e,this.dataReady=!0,this.version=0}set needsUpdate(e){e===!0&&this.version++}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.images[this.uuid]!==void 0)return e.images[this.uuid];let i={uuid:this.uuid,url:""},n=this.data;if(n!==null){let r;if(Array.isArray(n)){r=[];for(let a=0,o=n.length;a<o;a++)n[a].isDataTexture?r.push(Ao(n[a].image)):r.push(Ao(n[a]))}else r=Ao(n);i.url=r}return t||(e.images[this.uuid]=i),i}};function Ao(s){return typeof HTMLImageElement<"u"&&s instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&s instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&s instanceof ImageBitmap?Hl.getDataURL(s):s.data?{data:Array.from(s.data),width:s.width,height:s.height,type:s.data.constructor.name}:(console.warn("THREE.Texture: Unable to serialize Texture."),{})}var ep=0,Nt=class s extends Gi{constructor(e=s.DEFAULT_IMAGE,t=s.DEFAULT_MAPPING,i=1001,n=1001,r=1006,a=1008,o=1023,l=1009,c=s.DEFAULT_ANISOTROPY,h=""){super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:ep++}),this.uuid=fi(),this.name="",this.source=new ha(e),this.mipmaps=[],this.mapping=t,this.channel=0,this.wrapS=i,this.wrapT=n,this.magFilter=r,this.minFilter=a,this.anisotropy=c,this.format=o,this.internalFormat=null,this.type=l,this.offset=new oe(0,0),this.repeat=new oe(1,1),this.center=new oe(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new De,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=h,this.userData={},this.version=0,this.onUpdate=null,this.isRenderTargetTexture=!1,this.pmremVersion=0}get image(){return this.source.data}set image(e=null){this.source.data=e}updateMatrix(){this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)}clone(){return new this.constructor().copy(this)}copy(e){return this.name=e.name,this.source=e.source,this.mipmaps=e.mipmaps.slice(0),this.mapping=e.mapping,this.channel=e.channel,this.wrapS=e.wrapS,this.wrapT=e.wrapT,this.magFilter=e.magFilter,this.minFilter=e.minFilter,this.anisotropy=e.anisotropy,this.format=e.format,this.internalFormat=e.internalFormat,this.type=e.type,this.offset.copy(e.offset),this.repeat.copy(e.repeat),this.center.copy(e.center),this.rotation=e.rotation,this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrix.copy(e.matrix),this.generateMipmaps=e.generateMipmaps,this.premultiplyAlpha=e.premultiplyAlpha,this.flipY=e.flipY,this.unpackAlignment=e.unpackAlignment,this.colorSpace=e.colorSpace,this.userData=JSON.parse(JSON.stringify(e.userData)),this.needsUpdate=!0,this}toJSON(e){let t=e===void 0||typeof e=="string";if(!t&&e.textures[this.uuid]!==void 0)return e.textures[this.uuid];let i={metadata:{version:4.6,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(e).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};return Object.keys(this.userData).length>0&&(i.userData=this.userData),t||(e.textures[this.uuid]=i),i}dispose(){this.dispatchEvent({type:"dispose"})}transformUv(e){if(this.mapping!==ku)return e;if(e.applyMatrix3(this.matrix),e.x<0||e.x>1)switch(this.wrapS){case Fs:e.x=e.x-Math.floor(e.x);break;case Bs:e.x=e.x<0?0:1;break;case ul:Math.abs(Math.floor(e.x)%2)===1?e.x=Math.ceil(e.x)-e.x:e.x=e.x-Math.floor(e.x)}if(e.y<0||e.y>1)switch(this.wrapT){case Fs:e.y=e.y-Math.floor(e.y);break;case Bs:e.y=e.y<0?0:1;break;case ul:Math.abs(Math.floor(e.y)%2)===1?e.y=Math.ceil(e.y)-e.y:e.y=e.y-Math.floor(e.y)}return this.flipY&&(e.y=1-e.y),e}set needsUpdate(e){e===!0&&(this.version++,this.source.needsUpdate=!0)}set needsPMREMUpdate(e){e===!0&&this.pmremVersion++}};Nt.DEFAULT_IMAGE=null,Nt.DEFAULT_MAPPING=ku,Nt.DEFAULT_ANISOTROPY=1;var ct=class s{constructor(e=0,t=0,i=0,n=1){s.prototype.isVector4=!0,this.x=e,this.y=t,this.z=i,this.w=n}get width(){return this.z}set width(e){this.z=e}get height(){return this.w}set height(e){this.w=e}set(e,t,i,n){return this.x=e,this.y=t,this.z=i,this.w=n,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this.w=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setW(e){return this.w=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;case 3:this.w=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;case 3:return this.w;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z,this.w)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this.w=e.w!==void 0?e.w:1,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this.w+=e.w,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this.w+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this.w=e.w+t.w,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this.w+=e.w*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this.w-=e.w,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this.w-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this.w=e.w-t.w,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this.w*=e.w,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this.w*=e,this}applyMatrix4(e){let t=this.x,i=this.y,n=this.z,r=this.w,a=e.elements;return this.x=a[0]*t+a[4]*i+a[8]*n+a[12]*r,this.y=a[1]*t+a[5]*i+a[9]*n+a[13]*r,this.z=a[2]*t+a[6]*i+a[10]*n+a[14]*r,this.w=a[3]*t+a[7]*i+a[11]*n+a[15]*r,this}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this.w/=e.w,this}divideScalar(e){return this.multiplyScalar(1/e)}setAxisAngleFromQuaternion(e){this.w=2*Math.acos(e.w);let t=Math.sqrt(1-e.w*e.w);return t<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=e.x/t,this.y=e.y/t,this.z=e.z/t),this}setAxisAngleFromRotationMatrix(e){let t,i,n,r,l=e.elements,c=l[0],h=l[4],d=l[8],u=l[1],p=l[5],m=l[9],v=l[2],f=l[6],g=l[10];if(Math.abs(h-u)<.01&&Math.abs(d-v)<.01&&Math.abs(m-f)<.01){if(Math.abs(h+u)<.1&&Math.abs(d+v)<.1&&Math.abs(m+f)<.1&&Math.abs(c+p+g-3)<.1)return this.set(1,0,0,0),this;t=Math.PI;let x=(c+1)/2,_=(p+1)/2,b=(g+1)/2,S=(h+u)/4,R=(d+v)/4,P=(m+f)/4;return x>_&&x>b?x<.01?(i=0,n=.707106781,r=.707106781):(i=Math.sqrt(x),n=S/i,r=R/i):_>b?_<.01?(i=.707106781,n=0,r=.707106781):(n=Math.sqrt(_),i=S/n,r=P/n):b<.01?(i=.707106781,n=.707106781,r=0):(r=Math.sqrt(b),i=R/r,n=P/r),this.set(i,n,r,t),this}let y=Math.sqrt((f-m)*(f-m)+(d-v)*(d-v)+(u-h)*(u-h));return Math.abs(y)<.001&&(y=1),this.x=(f-m)/y,this.y=(d-v)/y,this.z=(u-h)/y,this.w=Math.acos((c+p+g-1)/2),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this.w=t[15],this}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this.w=Math.min(this.w,e.w),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this.w=Math.max(this.w,e.w),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this.w=Math.max(e.w,Math.min(t.w,this.w)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this.w=Math.max(e,Math.min(t,this.w)),this}clampLength(e,t){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z+this.w*e.w}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this.w+=(e.w-this.w)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this.w=e.w+(t.w-e.w)*i,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z&&e.w===this.w}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this.w=e[t+3],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e[t+3]=this.w,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this.w=e.getW(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z,yield this.w}},Vl=class extends Gi{constructor(e=1,t=1,i={}){super(),this.isRenderTarget=!0,this.width=e,this.height=t,this.depth=1,this.scissor=new ct(0,0,e,t),this.scissorTest=!1,this.viewport=new ct(0,0,e,t);let n={width:e,height:t,depth:1};i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:Ti,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1},i);let r=new Nt(n,i.mapping,i.wrapS,i.wrapT,i.magFilter,i.minFilter,i.format,i.type,i.anisotropy,i.colorSpace);r.flipY=!1,r.generateMipmaps=i.generateMipmaps,r.internalFormat=i.internalFormat,this.textures=[];let a=i.count;for(let o=0;o<a;o++)this.textures[o]=r.clone(),this.textures[o].isRenderTargetTexture=!0;this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.resolveDepthBuffer=i.resolveDepthBuffer,this.resolveStencilBuffer=i.resolveStencilBuffer,this.depthTexture=i.depthTexture,this.samples=i.samples}get texture(){return this.textures[0]}set texture(e){this.textures[0]=e}setSize(e,t,i=1){if(this.width!==e||this.height!==t||this.depth!==i){this.width=e,this.height=t,this.depth=i;for(let n=0,r=this.textures.length;n<r;n++)this.textures[n].image.width=e,this.textures[n].image.height=t,this.textures[n].image.depth=i;this.dispose()}this.viewport.set(0,0,e,t),this.scissor.set(0,0,e,t)}clone(){return new this.constructor().copy(this)}copy(e){this.width=e.width,this.height=e.height,this.depth=e.depth,this.scissor.copy(e.scissor),this.scissorTest=e.scissorTest,this.viewport.copy(e.viewport),this.textures.length=0;for(let i=0,n=e.textures.length;i<n;i++)this.textures[i]=e.textures[i].clone(),this.textures[i].isRenderTargetTexture=!0;let t=Object.assign({},e.texture.image);return this.texture.source=new ha(t),this.depthBuffer=e.depthBuffer,this.stencilBuffer=e.stencilBuffer,this.resolveDepthBuffer=e.resolveDepthBuffer,this.resolveStencilBuffer=e.resolveStencilBuffer,e.depthTexture!==null&&(this.depthTexture=e.depthTexture.clone()),this.samples=e.samples,this}dispose(){this.dispatchEvent({type:"dispose"})}},si=class extends Vl{constructor(e=1,t=1,i={}){super(e,t,i),this.isWebGLRenderTarget=!0}},ua=class extends Nt{constructor(e=null,t=1,i=1,n=1){super(null),this.isDataArrayTexture=!0,this.image={data:e,width:t,height:i,depth:n},this.magFilter=ii,this.minFilter=ii,this.wrapR=Bs,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set}addLayerUpdate(e){this.layerUpdates.add(e)}clearLayerUpdates(){this.layerUpdates.clear()}};var Gl=class extends Nt{constructor(e=null,t=1,i=1,n=1){super(null),this.isData3DTexture=!0,this.image={data:e,width:t,height:i,depth:n},this.magFilter=ii,this.minFilter=ii,this.wrapR=Bs,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}};var $e=class{constructor(e=0,t=0,i=0,n=1){this.isQuaternion=!0,this._x=e,this._y=t,this._z=i,this._w=n}static slerpFlat(e,t,i,n,r,a,o){let l=i[n+0],c=i[n+1],h=i[n+2],d=i[n+3],u=r[a+0],p=r[a+1],m=r[a+2],v=r[a+3];if(o===0)return e[t+0]=l,e[t+1]=c,e[t+2]=h,void(e[t+3]=d);if(o===1)return e[t+0]=u,e[t+1]=p,e[t+2]=m,void(e[t+3]=v);if(d!==v||l!==u||c!==p||h!==m){let f=1-o,g=l*u+c*p+h*m+d*v,y=g>=0?1:-1,x=1-g*g;if(x>Number.EPSILON){let b=Math.sqrt(x),S=Math.atan2(b,g*y);f=Math.sin(f*S)/b,o=Math.sin(o*S)/b}let _=o*y;if(l=l*f+u*_,c=c*f+p*_,h=h*f+m*_,d=d*f+v*_,f===1-o){let b=1/Math.sqrt(l*l+c*c+h*h+d*d);l*=b,c*=b,h*=b,d*=b}}e[t]=l,e[t+1]=c,e[t+2]=h,e[t+3]=d}static multiplyQuaternionsFlat(e,t,i,n,r,a){let o=i[n],l=i[n+1],c=i[n+2],h=i[n+3],d=r[a],u=r[a+1],p=r[a+2],m=r[a+3];return e[t]=o*m+h*d+l*p-c*u,e[t+1]=l*m+h*u+c*d-o*p,e[t+2]=c*m+h*p+o*u-l*d,e[t+3]=h*m-o*d-l*u-c*p,e}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get w(){return this._w}set w(e){this._w=e,this._onChangeCallback()}set(e,t,i,n){return this._x=e,this._y=t,this._z=i,this._w=n,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._w)}copy(e){return this._x=e.x,this._y=e.y,this._z=e.z,this._w=e.w,this._onChangeCallback(),this}setFromEuler(e,t=!0){let i=e._x,n=e._y,r=e._z,a=e._order,o=Math.cos,l=Math.sin,c=o(i/2),h=o(n/2),d=o(r/2),u=l(i/2),p=l(n/2),m=l(r/2);switch(a){case"XYZ":this._x=u*h*d+c*p*m,this._y=c*p*d-u*h*m,this._z=c*h*m+u*p*d,this._w=c*h*d-u*p*m;break;case"YXZ":this._x=u*h*d+c*p*m,this._y=c*p*d-u*h*m,this._z=c*h*m-u*p*d,this._w=c*h*d+u*p*m;break;case"ZXY":this._x=u*h*d-c*p*m,this._y=c*p*d+u*h*m,this._z=c*h*m+u*p*d,this._w=c*h*d-u*p*m;break;case"ZYX":this._x=u*h*d-c*p*m,this._y=c*p*d+u*h*m,this._z=c*h*m-u*p*d,this._w=c*h*d+u*p*m;break;case"YZX":this._x=u*h*d+c*p*m,this._y=c*p*d+u*h*m,this._z=c*h*m-u*p*d,this._w=c*h*d-u*p*m;break;case"XZY":this._x=u*h*d-c*p*m,this._y=c*p*d-u*h*m,this._z=c*h*m+u*p*d,this._w=c*h*d+u*p*m;break;default:console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: "+a)}return t===!0&&this._onChangeCallback(),this}setFromAxisAngle(e,t){let i=t/2,n=Math.sin(i);return this._x=e.x*n,this._y=e.y*n,this._z=e.z*n,this._w=Math.cos(i),this._onChangeCallback(),this}setFromRotationMatrix(e){let t=e.elements,i=t[0],n=t[4],r=t[8],a=t[1],o=t[5],l=t[9],c=t[2],h=t[6],d=t[10],u=i+o+d;if(u>0){let p=.5/Math.sqrt(u+1);this._w=.25/p,this._x=(h-l)*p,this._y=(r-c)*p,this._z=(a-n)*p}else if(i>o&&i>d){let p=2*Math.sqrt(1+i-o-d);this._w=(h-l)/p,this._x=.25*p,this._y=(n+a)/p,this._z=(r+c)/p}else if(o>d){let p=2*Math.sqrt(1+o-i-d);this._w=(r-c)/p,this._x=(n+a)/p,this._y=.25*p,this._z=(l+h)/p}else{let p=2*Math.sqrt(1+d-i-o);this._w=(a-n)/p,this._x=(r+c)/p,this._y=(l+h)/p,this._z=.25*p}return this._onChangeCallback(),this}setFromUnitVectors(e,t){let i=e.dot(t)+1;return i<Number.EPSILON?(i=0,Math.abs(e.x)>Math.abs(e.z)?(this._x=-e.y,this._y=e.x,this._z=0,this._w=i):(this._x=0,this._y=-e.z,this._z=e.y,this._w=i)):(this._x=e.y*t.z-e.z*t.y,this._y=e.z*t.x-e.x*t.z,this._z=e.x*t.y-e.y*t.x,this._w=i),this.normalize()}angleTo(e){return 2*Math.acos(Math.abs(_t(this.dot(e),-1,1)))}rotateTowards(e,t){let i=this.angleTo(e);if(i===0)return this;let n=Math.min(1,t/i);return this.slerp(e,n),this}identity(){return this.set(0,0,0,1)}invert(){return this.conjugate()}conjugate(){return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this}dot(e){return this._x*e._x+this._y*e._y+this._z*e._z+this._w*e._w}lengthSq(){return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w}length(){return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)}normalize(){let e=this.length();return e===0?(this._x=0,this._y=0,this._z=0,this._w=1):(e=1/e,this._x=this._x*e,this._y=this._y*e,this._z=this._z*e,this._w=this._w*e),this._onChangeCallback(),this}multiply(e){return this.multiplyQuaternions(this,e)}premultiply(e){return this.multiplyQuaternions(e,this)}multiplyQuaternions(e,t){let i=e._x,n=e._y,r=e._z,a=e._w,o=t._x,l=t._y,c=t._z,h=t._w;return this._x=i*h+a*o+n*c-r*l,this._y=n*h+a*l+r*o-i*c,this._z=r*h+a*c+i*l-n*o,this._w=a*h-i*o-n*l-r*c,this._onChangeCallback(),this}slerp(e,t){if(t===0)return this;if(t===1)return this.copy(e);let i=this._x,n=this._y,r=this._z,a=this._w,o=a*e._w+i*e._x+n*e._y+r*e._z;if(o<0?(this._w=-e._w,this._x=-e._x,this._y=-e._y,this._z=-e._z,o=-o):this.copy(e),o>=1)return this._w=a,this._x=i,this._y=n,this._z=r,this;let l=1-o*o;if(l<=Number.EPSILON){let p=1-t;return this._w=p*a+t*this._w,this._x=p*i+t*this._x,this._y=p*n+t*this._y,this._z=p*r+t*this._z,this.normalize(),this}let c=Math.sqrt(l),h=Math.atan2(c,o),d=Math.sin((1-t)*h)/c,u=Math.sin(t*h)/c;return this._w=a*d+this._w*u,this._x=i*d+this._x*u,this._y=n*d+this._y*u,this._z=r*d+this._z*u,this._onChangeCallback(),this}slerpQuaternions(e,t,i){return this.copy(e).slerp(t,i)}random(){let e=2*Math.PI*Math.random(),t=2*Math.PI*Math.random(),i=Math.random(),n=Math.sqrt(1-i),r=Math.sqrt(i);return this.set(n*Math.sin(e),n*Math.cos(e),r*Math.sin(t),r*Math.cos(t))}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._w===this._w}fromArray(e,t=0){return this._x=e[t],this._y=e[t+1],this._z=e[t+2],this._w=e[t+3],this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._w,e}fromBufferAttribute(e,t){return this._x=e.getX(t),this._y=e.getY(t),this._z=e.getZ(t),this._w=e.getW(t),this._onChangeCallback(),this}toJSON(){return this.toArray()}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._w}},M=class s{constructor(e=0,t=0,i=0){s.prototype.isVector3=!0,this.x=e,this.y=t,this.z=i}set(e,t,i){return i===void 0&&(i=this.z),this.x=e,this.y=t,this.z=i,this}setScalar(e){return this.x=e,this.y=e,this.z=e,this}setX(e){return this.x=e,this}setY(e){return this.y=e,this}setZ(e){return this.z=e,this}setComponent(e,t){switch(e){case 0:this.x=t;break;case 1:this.y=t;break;case 2:this.z=t;break;default:throw new Error("index is out of range: "+e)}return this}getComponent(e){switch(e){case 0:return this.x;case 1:return this.y;case 2:return this.z;default:throw new Error("index is out of range: "+e)}}clone(){return new this.constructor(this.x,this.y,this.z)}copy(e){return this.x=e.x,this.y=e.y,this.z=e.z,this}add(e){return this.x+=e.x,this.y+=e.y,this.z+=e.z,this}addScalar(e){return this.x+=e,this.y+=e,this.z+=e,this}addVectors(e,t){return this.x=e.x+t.x,this.y=e.y+t.y,this.z=e.z+t.z,this}addScaledVector(e,t){return this.x+=e.x*t,this.y+=e.y*t,this.z+=e.z*t,this}sub(e){return this.x-=e.x,this.y-=e.y,this.z-=e.z,this}subScalar(e){return this.x-=e,this.y-=e,this.z-=e,this}subVectors(e,t){return this.x=e.x-t.x,this.y=e.y-t.y,this.z=e.z-t.z,this}multiply(e){return this.x*=e.x,this.y*=e.y,this.z*=e.z,this}multiplyScalar(e){return this.x*=e,this.y*=e,this.z*=e,this}multiplyVectors(e,t){return this.x=e.x*t.x,this.y=e.y*t.y,this.z=e.z*t.z,this}applyEuler(e){return this.applyQuaternion(Uh.setFromEuler(e))}applyAxisAngle(e,t){return this.applyQuaternion(Uh.setFromAxisAngle(e,t))}applyMatrix3(e){let t=this.x,i=this.y,n=this.z,r=e.elements;return this.x=r[0]*t+r[3]*i+r[6]*n,this.y=r[1]*t+r[4]*i+r[7]*n,this.z=r[2]*t+r[5]*i+r[8]*n,this}applyNormalMatrix(e){return this.applyMatrix3(e).normalize()}applyMatrix4(e){let t=this.x,i=this.y,n=this.z,r=e.elements,a=1/(r[3]*t+r[7]*i+r[11]*n+r[15]);return this.x=(r[0]*t+r[4]*i+r[8]*n+r[12])*a,this.y=(r[1]*t+r[5]*i+r[9]*n+r[13])*a,this.z=(r[2]*t+r[6]*i+r[10]*n+r[14])*a,this}applyQuaternion(e){let t=this.x,i=this.y,n=this.z,r=e.x,a=e.y,o=e.z,l=e.w,c=2*(a*n-o*i),h=2*(o*t-r*n),d=2*(r*i-a*t);return this.x=t+l*c+a*d-o*h,this.y=i+l*h+o*c-r*d,this.z=n+l*d+r*h-a*c,this}project(e){return this.applyMatrix4(e.matrixWorldInverse).applyMatrix4(e.projectionMatrix)}unproject(e){return this.applyMatrix4(e.projectionMatrixInverse).applyMatrix4(e.matrixWorld)}transformDirection(e){let t=this.x,i=this.y,n=this.z,r=e.elements;return this.x=r[0]*t+r[4]*i+r[8]*n,this.y=r[1]*t+r[5]*i+r[9]*n,this.z=r[2]*t+r[6]*i+r[10]*n,this.normalize()}divide(e){return this.x/=e.x,this.y/=e.y,this.z/=e.z,this}divideScalar(e){return this.multiplyScalar(1/e)}min(e){return this.x=Math.min(this.x,e.x),this.y=Math.min(this.y,e.y),this.z=Math.min(this.z,e.z),this}max(e){return this.x=Math.max(this.x,e.x),this.y=Math.max(this.y,e.y),this.z=Math.max(this.z,e.z),this}clamp(e,t){return this.x=Math.max(e.x,Math.min(t.x,this.x)),this.y=Math.max(e.y,Math.min(t.y,this.y)),this.z=Math.max(e.z,Math.min(t.z,this.z)),this}clampScalar(e,t){return this.x=Math.max(e,Math.min(t,this.x)),this.y=Math.max(e,Math.min(t,this.y)),this.z=Math.max(e,Math.min(t,this.z)),this}clampLength(e,t){let i=this.length();return this.divideScalar(i||1).multiplyScalar(Math.max(e,Math.min(t,i)))}floor(){return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this}ceil(){return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this}round(){return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this}roundToZero(){return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this}negate(){return this.x=-this.x,this.y=-this.y,this.z=-this.z,this}dot(e){return this.x*e.x+this.y*e.y+this.z*e.z}lengthSq(){return this.x*this.x+this.y*this.y+this.z*this.z}length(){return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)}manhattanLength(){return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)}normalize(){return this.divideScalar(this.length()||1)}setLength(e){return this.normalize().multiplyScalar(e)}lerp(e,t){return this.x+=(e.x-this.x)*t,this.y+=(e.y-this.y)*t,this.z+=(e.z-this.z)*t,this}lerpVectors(e,t,i){return this.x=e.x+(t.x-e.x)*i,this.y=e.y+(t.y-e.y)*i,this.z=e.z+(t.z-e.z)*i,this}cross(e){return this.crossVectors(this,e)}crossVectors(e,t){let i=e.x,n=e.y,r=e.z,a=t.x,o=t.y,l=t.z;return this.x=n*l-r*o,this.y=r*a-i*l,this.z=i*o-n*a,this}projectOnVector(e){let t=e.lengthSq();if(t===0)return this.set(0,0,0);let i=e.dot(this)/t;return this.copy(e).multiplyScalar(i)}projectOnPlane(e){return Ro.copy(this).projectOnVector(e),this.sub(Ro)}reflect(e){return this.sub(Ro.copy(e).multiplyScalar(2*this.dot(e)))}angleTo(e){let t=Math.sqrt(this.lengthSq()*e.lengthSq());if(t===0)return Math.PI/2;let i=this.dot(e)/t;return Math.acos(_t(i,-1,1))}distanceTo(e){return Math.sqrt(this.distanceToSquared(e))}distanceToSquared(e){let t=this.x-e.x,i=this.y-e.y,n=this.z-e.z;return t*t+i*i+n*n}manhattanDistanceTo(e){return Math.abs(this.x-e.x)+Math.abs(this.y-e.y)+Math.abs(this.z-e.z)}setFromSpherical(e){return this.setFromSphericalCoords(e.radius,e.phi,e.theta)}setFromSphericalCoords(e,t,i){let n=Math.sin(t)*e;return this.x=n*Math.sin(i),this.y=Math.cos(t)*e,this.z=n*Math.cos(i),this}setFromCylindrical(e){return this.setFromCylindricalCoords(e.radius,e.theta,e.y)}setFromCylindricalCoords(e,t,i){return this.x=e*Math.sin(t),this.y=i,this.z=e*Math.cos(t),this}setFromMatrixPosition(e){let t=e.elements;return this.x=t[12],this.y=t[13],this.z=t[14],this}setFromMatrixScale(e){let t=this.setFromMatrixColumn(e,0).length(),i=this.setFromMatrixColumn(e,1).length(),n=this.setFromMatrixColumn(e,2).length();return this.x=t,this.y=i,this.z=n,this}setFromMatrixColumn(e,t){return this.fromArray(e.elements,4*t)}setFromMatrix3Column(e,t){return this.fromArray(e.elements,3*t)}setFromEuler(e){return this.x=e._x,this.y=e._y,this.z=e._z,this}setFromColor(e){return this.x=e.r,this.y=e.g,this.z=e.b,this}equals(e){return e.x===this.x&&e.y===this.y&&e.z===this.z}fromArray(e,t=0){return this.x=e[t],this.y=e[t+1],this.z=e[t+2],this}toArray(e=[],t=0){return e[t]=this.x,e[t+1]=this.y,e[t+2]=this.z,e}fromBufferAttribute(e,t){return this.x=e.getX(t),this.y=e.getY(t),this.z=e.getZ(t),this}random(){return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this}randomDirection(){let e=Math.random()*Math.PI*2,t=2*Math.random()-1,i=Math.sqrt(1-t*t);return this.x=i*Math.cos(e),this.y=t,this.z=i*Math.sin(e),this}*[Symbol.iterator](){yield this.x,yield this.y,yield this.z}},Ro=new M,Uh=new $e,ri=class{constructor(e=new M(1/0,1/0,1/0),t=new M(-1/0,-1/0,-1/0)){this.isBox3=!0,this.min=e,this.max=t}set(e,t){return this.min.copy(e),this.max.copy(t),this}setFromArray(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t+=3)this.expandByPoint(Kt.fromArray(e,t));return this}setFromBufferAttribute(e){this.makeEmpty();for(let t=0,i=e.count;t<i;t++)this.expandByPoint(Kt.fromBufferAttribute(e,t));return this}setFromPoints(e){this.makeEmpty();for(let t=0,i=e.length;t<i;t++)this.expandByPoint(e[t]);return this}setFromCenterAndSize(e,t){let i=Kt.copy(t).multiplyScalar(.5);return this.min.copy(e).sub(i),this.max.copy(e).add(i),this}setFromObject(e,t=!1){return this.makeEmpty(),this.expandByObject(e,t)}clone(){return new this.constructor().copy(this)}copy(e){return this.min.copy(e.min),this.max.copy(e.max),this}makeEmpty(){return this.min.x=this.min.y=this.min.z=1/0,this.max.x=this.max.y=this.max.z=-1/0,this}isEmpty(){return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z}getCenter(e){return this.isEmpty()?e.set(0,0,0):e.addVectors(this.min,this.max).multiplyScalar(.5)}getSize(e){return this.isEmpty()?e.set(0,0,0):e.subVectors(this.max,this.min)}expandByPoint(e){return this.min.min(e),this.max.max(e),this}expandByVector(e){return this.min.sub(e),this.max.add(e),this}expandByScalar(e){return this.min.addScalar(-e),this.max.addScalar(e),this}expandByObject(e,t=!1){e.updateWorldMatrix(!1,!1);let i=e.geometry;if(i!==void 0){let r=i.getAttribute("position");if(t===!0&&r!==void 0&&e.isInstancedMesh!==!0)for(let a=0,o=r.count;a<o;a++)e.isMesh===!0?e.getVertexPosition(a,Kt):Kt.fromBufferAttribute(r,a),Kt.applyMatrix4(e.matrixWorld),this.expandByPoint(Kt);else e.boundingBox!==void 0?(e.boundingBox===null&&e.computeBoundingBox(),Mr.copy(e.boundingBox)):(i.boundingBox===null&&i.computeBoundingBox(),Mr.copy(i.boundingBox)),Mr.applyMatrix4(e.matrixWorld),this.union(Mr)}let n=e.children;for(let r=0,a=n.length;r<a;r++)this.expandByObject(n[r],t);return this}containsPoint(e){return e.x>=this.min.x&&e.x<=this.max.x&&e.y>=this.min.y&&e.y<=this.max.y&&e.z>=this.min.z&&e.z<=this.max.z}containsBox(e){return this.min.x<=e.min.x&&e.max.x<=this.max.x&&this.min.y<=e.min.y&&e.max.y<=this.max.y&&this.min.z<=e.min.z&&e.max.z<=this.max.z}getParameter(e,t){return t.set((e.x-this.min.x)/(this.max.x-this.min.x),(e.y-this.min.y)/(this.max.y-this.min.y),(e.z-this.min.z)/(this.max.z-this.min.z))}intersectsBox(e){return e.max.x>=this.min.x&&e.min.x<=this.max.x&&e.max.y>=this.min.y&&e.min.y<=this.max.y&&e.max.z>=this.min.z&&e.min.z<=this.max.z}intersectsSphere(e){return this.clampPoint(e.center,Kt),Kt.distanceToSquared(e.center)<=e.radius*e.radius}intersectsPlane(e){let t,i;return e.normal.x>0?(t=e.normal.x*this.min.x,i=e.normal.x*this.max.x):(t=e.normal.x*this.max.x,i=e.normal.x*this.min.x),e.normal.y>0?(t+=e.normal.y*this.min.y,i+=e.normal.y*this.max.y):(t+=e.normal.y*this.max.y,i+=e.normal.y*this.min.y),e.normal.z>0?(t+=e.normal.z*this.min.z,i+=e.normal.z*this.max.z):(t+=e.normal.z*this.max.z,i+=e.normal.z*this.min.z),t<=-e.constant&&i>=-e.constant}intersectsTriangle(e){if(this.isEmpty())return!1;this.getCenter(bs),br.subVectors(this.max,bs),wn.subVectors(e.a,bs),En.subVectors(e.b,bs),Tn.subVectors(e.c,bs),Ui.subVectors(En,wn),Ni.subVectors(Tn,En),en.subVectors(wn,Tn);let t=[0,-Ui.z,Ui.y,0,-Ni.z,Ni.y,0,-en.z,en.y,Ui.z,0,-Ui.x,Ni.z,0,-Ni.x,en.z,0,-en.x,-Ui.y,Ui.x,0,-Ni.y,Ni.x,0,-en.y,en.x,0];return!!Co(t,wn,En,Tn,br)&&(t=[1,0,0,0,1,0,0,0,1],!!Co(t,wn,En,Tn,br)&&(Sr.crossVectors(Ui,Ni),t=[Sr.x,Sr.y,Sr.z],Co(t,wn,En,Tn,br)))}clampPoint(e,t){return t.copy(e).clamp(this.min,this.max)}distanceToPoint(e){return this.clampPoint(e,Kt).distanceTo(e)}getBoundingSphere(e){return this.isEmpty()?e.makeEmpty():(this.getCenter(e.center),e.radius=.5*this.getSize(Kt).length()),e}intersect(e){return this.min.max(e.min),this.max.min(e.max),this.isEmpty()&&this.makeEmpty(),this}union(e){return this.min.min(e.min),this.max.max(e.max),this}applyMatrix4(e){return this.isEmpty()||(xi[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(e),xi[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(e),xi[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(e),xi[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(e),xi[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(e),xi[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(e),xi[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(e),xi[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(e),this.setFromPoints(xi)),this}translate(e){return this.min.add(e),this.max.add(e),this}equals(e){return e.min.equals(this.min)&&e.max.equals(this.max)}},xi=[new M,new M,new M,new M,new M,new M,new M,new M],Kt=new M,Mr=new ri,wn=new M,En=new M,Tn=new M,Ui=new M,Ni=new M,en=new M,bs=new M,br=new M,Sr=new M,tn=new M;function Co(s,e,t,i,n){for(let r=0,a=s.length-3;r<=a;r+=3){tn.fromArray(s,r);let o=n.x*Math.abs(tn.x)+n.y*Math.abs(tn.y)+n.z*Math.abs(tn.z),l=e.dot(tn),c=t.dot(tn),h=i.dot(tn);if(Math.max(-Math.max(l,c,h),Math.min(l,c,h))>o)return!1}return!0}var tp=new ri,Ss=new M,Lo=new M,ai=class{constructor(e=new M,t=-1){this.isSphere=!0,this.center=e,this.radius=t}set(e,t){return this.center.copy(e),this.radius=t,this}setFromPoints(e,t){let i=this.center;t!==void 0?i.copy(t):tp.setFromPoints(e).getCenter(i);let n=0;for(let r=0,a=e.length;r<a;r++)n=Math.max(n,i.distanceToSquared(e[r]));return this.radius=Math.sqrt(n),this}copy(e){return this.center.copy(e.center),this.radius=e.radius,this}isEmpty(){return this.radius<0}makeEmpty(){return this.center.set(0,0,0),this.radius=-1,this}containsPoint(e){return e.distanceToSquared(this.center)<=this.radius*this.radius}distanceToPoint(e){return e.distanceTo(this.center)-this.radius}intersectsSphere(e){let t=this.radius+e.radius;return e.center.distanceToSquared(this.center)<=t*t}intersectsBox(e){return e.intersectsSphere(this)}intersectsPlane(e){return Math.abs(e.distanceToPoint(this.center))<=this.radius}clampPoint(e,t){let i=this.center.distanceToSquared(e);return t.copy(e),i>this.radius*this.radius&&(t.sub(this.center).normalize(),t.multiplyScalar(this.radius).add(this.center)),t}getBoundingBox(e){return this.isEmpty()?(e.makeEmpty(),e):(e.set(this.center,this.center),e.expandByScalar(this.radius),e)}applyMatrix4(e){return this.center.applyMatrix4(e),this.radius=this.radius*e.getMaxScaleOnAxis(),this}translate(e){return this.center.add(e),this}expandByPoint(e){if(this.isEmpty())return this.center.copy(e),this.radius=0,this;Ss.subVectors(e,this.center);let t=Ss.lengthSq();if(t>this.radius*this.radius){let i=Math.sqrt(t),n=.5*(i-this.radius);this.center.addScaledVector(Ss,n/i),this.radius+=n}return this}union(e){return e.isEmpty()?this:this.isEmpty()?(this.copy(e),this):(this.center.equals(e.center)===!0?this.radius=Math.max(this.radius,e.radius):(Lo.subVectors(e.center,this.center).setLength(e.radius),this.expandByPoint(Ss.copy(e.center).add(Lo)),this.expandByPoint(Ss.copy(e.center).sub(Lo))),this)}equals(e){return e.center.equals(this.center)&&e.radius===this.radius}clone(){return new this.constructor().copy(this)}},_i=new M,Po=new M,wr=new M,Oi=new M,Io=new M,Er=new M,Do=new M,Zn=class{constructor(e=new M,t=new M(0,0,-1)){this.origin=e,this.direction=t}set(e,t){return this.origin.copy(e),this.direction.copy(t),this}copy(e){return this.origin.copy(e.origin),this.direction.copy(e.direction),this}at(e,t){return t.copy(this.origin).addScaledVector(this.direction,e)}lookAt(e){return this.direction.copy(e).sub(this.origin).normalize(),this}recast(e){return this.origin.copy(this.at(e,_i)),this}closestPointToPoint(e,t){t.subVectors(e,this.origin);let i=t.dot(this.direction);return i<0?t.copy(this.origin):t.copy(this.origin).addScaledVector(this.direction,i)}distanceToPoint(e){return Math.sqrt(this.distanceSqToPoint(e))}distanceSqToPoint(e){let t=_i.subVectors(e,this.origin).dot(this.direction);return t<0?this.origin.distanceToSquared(e):(_i.copy(this.origin).addScaledVector(this.direction,t),_i.distanceToSquared(e))}distanceSqToSegment(e,t,i,n){Po.copy(e).add(t).multiplyScalar(.5),wr.copy(t).sub(e).normalize(),Oi.copy(this.origin).sub(Po);let r=.5*e.distanceTo(t),a=-this.direction.dot(wr),o=Oi.dot(this.direction),l=-Oi.dot(wr),c=Oi.lengthSq(),h=Math.abs(1-a*a),d,u,p,m;if(h>0)if(d=a*l-o,u=a*o-l,m=r*h,d>=0)if(u>=-m)if(u<=m){let v=1/h;d*=v,u*=v,p=d*(d+a*u+2*o)+u*(a*d+u+2*l)+c}else u=r,d=Math.max(0,-(a*u+o)),p=-d*d+u*(u+2*l)+c;else u=-r,d=Math.max(0,-(a*u+o)),p=-d*d+u*(u+2*l)+c;else u<=-m?(d=Math.max(0,-(-a*r+o)),u=d>0?-r:Math.min(Math.max(-r,-l),r),p=-d*d+u*(u+2*l)+c):u<=m?(d=0,u=Math.min(Math.max(-r,-l),r),p=u*(u+2*l)+c):(d=Math.max(0,-(a*r+o)),u=d>0?r:Math.min(Math.max(-r,-l),r),p=-d*d+u*(u+2*l)+c);else u=a>0?-r:r,d=Math.max(0,-(a*u+o)),p=-d*d+u*(u+2*l)+c;return i&&i.copy(this.origin).addScaledVector(this.direction,d),n&&n.copy(Po).addScaledVector(wr,u),p}intersectSphere(e,t){_i.subVectors(e.center,this.origin);let i=_i.dot(this.direction),n=_i.dot(_i)-i*i,r=e.radius*e.radius;if(n>r)return null;let a=Math.sqrt(r-n),o=i-a,l=i+a;return l<0?null:o<0?this.at(l,t):this.at(o,t)}intersectsSphere(e){return this.distanceSqToPoint(e.center)<=e.radius*e.radius}distanceToPlane(e){let t=e.normal.dot(this.direction);if(t===0)return e.distanceToPoint(this.origin)===0?0:null;let i=-(this.origin.dot(e.normal)+e.constant)/t;return i>=0?i:null}intersectPlane(e,t){let i=this.distanceToPlane(e);return i===null?null:this.at(i,t)}intersectsPlane(e){let t=e.distanceToPoint(this.origin);return t===0?!0:e.normal.dot(this.direction)*t<0}intersectBox(e,t){let i,n,r,a,o,l,c=1/this.direction.x,h=1/this.direction.y,d=1/this.direction.z,u=this.origin;return c>=0?(i=(e.min.x-u.x)*c,n=(e.max.x-u.x)*c):(i=(e.max.x-u.x)*c,n=(e.min.x-u.x)*c),h>=0?(r=(e.min.y-u.y)*h,a=(e.max.y-u.y)*h):(r=(e.max.y-u.y)*h,a=(e.min.y-u.y)*h),i>a||r>n?null:((r>i||isNaN(i))&&(i=r),(a<n||isNaN(n))&&(n=a),d>=0?(o=(e.min.z-u.z)*d,l=(e.max.z-u.z)*d):(o=(e.max.z-u.z)*d,l=(e.min.z-u.z)*d),i>l||o>n?null:((o>i||i!=i)&&(i=o),(l<n||n!=n)&&(n=l),n<0?null:this.at(i>=0?i:n,t)))}intersectsBox(e){return this.intersectBox(e,_i)!==null}intersectTriangle(e,t,i,n,r){Io.subVectors(t,e),Er.subVectors(i,e),Do.crossVectors(Io,Er);let a,o=this.direction.dot(Do);if(o>0){if(n)return null;a=1}else{if(!(o<0))return null;a=-1,o=-o}Oi.subVectors(this.origin,e);let l=a*this.direction.dot(Er.crossVectors(Oi,Er));if(l<0)return null;let c=a*this.direction.dot(Io.cross(Oi));if(c<0||l+c>o)return null;let h=-a*Oi.dot(Do);return h<0?null:this.at(h/o,r)}applyMatrix4(e){return this.origin.applyMatrix4(e),this.direction.transformDirection(e),this}equals(e){return e.origin.equals(this.origin)&&e.direction.equals(this.direction)}clone(){return new this.constructor().copy(this)}},Ee=class s{constructor(e,t,i,n,r,a,o,l,c,h,d,u,p,m,v,f){s.prototype.isMatrix4=!0,this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],e!==void 0&&this.set(e,t,i,n,r,a,o,l,c,h,d,u,p,m,v,f)}set(e,t,i,n,r,a,o,l,c,h,d,u,p,m,v,f){let g=this.elements;return g[0]=e,g[4]=t,g[8]=i,g[12]=n,g[1]=r,g[5]=a,g[9]=o,g[13]=l,g[2]=c,g[6]=h,g[10]=d,g[14]=u,g[3]=p,g[7]=m,g[11]=v,g[15]=f,this}identity(){return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this}clone(){return new s().fromArray(this.elements)}copy(e){let t=this.elements,i=e.elements;return t[0]=i[0],t[1]=i[1],t[2]=i[2],t[3]=i[3],t[4]=i[4],t[5]=i[5],t[6]=i[6],t[7]=i[7],t[8]=i[8],t[9]=i[9],t[10]=i[10],t[11]=i[11],t[12]=i[12],t[13]=i[13],t[14]=i[14],t[15]=i[15],this}copyPosition(e){let t=this.elements,i=e.elements;return t[12]=i[12],t[13]=i[13],t[14]=i[14],this}setFromMatrix3(e){let t=e.elements;return this.set(t[0],t[3],t[6],0,t[1],t[4],t[7],0,t[2],t[5],t[8],0,0,0,0,1),this}extractBasis(e,t,i){return e.setFromMatrixColumn(this,0),t.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2),this}makeBasis(e,t,i){return this.set(e.x,t.x,i.x,0,e.y,t.y,i.y,0,e.z,t.z,i.z,0,0,0,0,1),this}extractRotation(e){let t=this.elements,i=e.elements,n=1/An.setFromMatrixColumn(e,0).length(),r=1/An.setFromMatrixColumn(e,1).length(),a=1/An.setFromMatrixColumn(e,2).length();return t[0]=i[0]*n,t[1]=i[1]*n,t[2]=i[2]*n,t[3]=0,t[4]=i[4]*r,t[5]=i[5]*r,t[6]=i[6]*r,t[7]=0,t[8]=i[8]*a,t[9]=i[9]*a,t[10]=i[10]*a,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromEuler(e){let t=this.elements,i=e.x,n=e.y,r=e.z,a=Math.cos(i),o=Math.sin(i),l=Math.cos(n),c=Math.sin(n),h=Math.cos(r),d=Math.sin(r);if(e.order==="XYZ"){let u=a*h,p=a*d,m=o*h,v=o*d;t[0]=l*h,t[4]=-l*d,t[8]=c,t[1]=p+m*c,t[5]=u-v*c,t[9]=-o*l,t[2]=v-u*c,t[6]=m+p*c,t[10]=a*l}else if(e.order==="YXZ"){let u=l*h,p=l*d,m=c*h,v=c*d;t[0]=u+v*o,t[4]=m*o-p,t[8]=a*c,t[1]=a*d,t[5]=a*h,t[9]=-o,t[2]=p*o-m,t[6]=v+u*o,t[10]=a*l}else if(e.order==="ZXY"){let u=l*h,p=l*d,m=c*h,v=c*d;t[0]=u-v*o,t[4]=-a*d,t[8]=m+p*o,t[1]=p+m*o,t[5]=a*h,t[9]=v-u*o,t[2]=-a*c,t[6]=o,t[10]=a*l}else if(e.order==="ZYX"){let u=a*h,p=a*d,m=o*h,v=o*d;t[0]=l*h,t[4]=m*c-p,t[8]=u*c+v,t[1]=l*d,t[5]=v*c+u,t[9]=p*c-m,t[2]=-c,t[6]=o*l,t[10]=a*l}else if(e.order==="YZX"){let u=a*l,p=a*c,m=o*l,v=o*c;t[0]=l*h,t[4]=v-u*d,t[8]=m*d+p,t[1]=d,t[5]=a*h,t[9]=-o*h,t[2]=-c*h,t[6]=p*d+m,t[10]=u-v*d}else if(e.order==="XZY"){let u=a*l,p=a*c,m=o*l,v=o*c;t[0]=l*h,t[4]=-d,t[8]=c*h,t[1]=u*d+v,t[5]=a*h,t[9]=p*d-m,t[2]=m*d-p,t[6]=o*h,t[10]=v*d+u}return t[3]=0,t[7]=0,t[11]=0,t[12]=0,t[13]=0,t[14]=0,t[15]=1,this}makeRotationFromQuaternion(e){return this.compose(ip,e,np)}lookAt(e,t,i){let n=this.elements;return kt.subVectors(e,t),kt.lengthSq()===0&&(kt.z=1),kt.normalize(),zi.crossVectors(i,kt),zi.lengthSq()===0&&(Math.abs(i.z)===1?kt.x+=1e-4:kt.z+=1e-4,kt.normalize(),zi.crossVectors(i,kt)),zi.normalize(),Tr.crossVectors(kt,zi),n[0]=zi.x,n[4]=Tr.x,n[8]=kt.x,n[1]=zi.y,n[5]=Tr.y,n[9]=kt.y,n[2]=zi.z,n[6]=Tr.z,n[10]=kt.z,this}multiply(e){return this.multiplyMatrices(this,e)}premultiply(e){return this.multiplyMatrices(e,this)}multiplyMatrices(e,t){let i=e.elements,n=t.elements,r=this.elements,a=i[0],o=i[4],l=i[8],c=i[12],h=i[1],d=i[5],u=i[9],p=i[13],m=i[2],v=i[6],f=i[10],g=i[14],y=i[3],x=i[7],_=i[11],b=i[15],S=n[0],R=n[4],P=n[8],C=n[12],B=n[1],z=n[5],D=n[9],F=n[13],U=n[2],X=n[6],j=n[10],Z=n[14],$=n[3],ue=n[7],_e=n[11],K=n[15];return r[0]=a*S+o*B+l*U+c*$,r[4]=a*R+o*z+l*X+c*ue,r[8]=a*P+o*D+l*j+c*_e,r[12]=a*C+o*F+l*Z+c*K,r[1]=h*S+d*B+u*U+p*$,r[5]=h*R+d*z+u*X+p*ue,r[9]=h*P+d*D+u*j+p*_e,r[13]=h*C+d*F+u*Z+p*K,r[2]=m*S+v*B+f*U+g*$,r[6]=m*R+v*z+f*X+g*ue,r[10]=m*P+v*D+f*j+g*_e,r[14]=m*C+v*F+f*Z+g*K,r[3]=y*S+x*B+_*U+b*$,r[7]=y*R+x*z+_*X+b*ue,r[11]=y*P+x*D+_*j+b*_e,r[15]=y*C+x*F+_*Z+b*K,this}multiplyScalar(e){let t=this.elements;return t[0]*=e,t[4]*=e,t[8]*=e,t[12]*=e,t[1]*=e,t[5]*=e,t[9]*=e,t[13]*=e,t[2]*=e,t[6]*=e,t[10]*=e,t[14]*=e,t[3]*=e,t[7]*=e,t[11]*=e,t[15]*=e,this}determinant(){let e=this.elements,t=e[0],i=e[4],n=e[8],r=e[12],a=e[1],o=e[5],l=e[9],c=e[13],h=e[2],d=e[6],u=e[10],p=e[14];return e[3]*(+r*l*d-n*c*d-r*o*u+i*c*u+n*o*p-i*l*p)+e[7]*(+t*l*p-t*c*u+r*a*u-n*a*p+n*c*h-r*l*h)+e[11]*(+t*c*d-t*o*p-r*a*d+i*a*p+r*o*h-i*c*h)+e[15]*(-n*o*h-t*l*d+t*o*u+n*a*d-i*a*u+i*l*h)}transpose(){let e=this.elements,t;return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this}setPosition(e,t,i){let n=this.elements;return e.isVector3?(n[12]=e.x,n[13]=e.y,n[14]=e.z):(n[12]=e,n[13]=t,n[14]=i),this}invert(){let e=this.elements,t=e[0],i=e[1],n=e[2],r=e[3],a=e[4],o=e[5],l=e[6],c=e[7],h=e[8],d=e[9],u=e[10],p=e[11],m=e[12],v=e[13],f=e[14],g=e[15],y=d*f*c-v*u*c+v*l*p-o*f*p-d*l*g+o*u*g,x=m*u*c-h*f*c-m*l*p+a*f*p+h*l*g-a*u*g,_=h*v*c-m*d*c+m*o*p-a*v*p-h*o*g+a*d*g,b=m*d*l-h*v*l-m*o*u+a*v*u+h*o*f-a*d*f,S=t*y+i*x+n*_+r*b;if(S===0)return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);let R=1/S;return e[0]=y*R,e[1]=(v*u*r-d*f*r-v*n*p+i*f*p+d*n*g-i*u*g)*R,e[2]=(o*f*r-v*l*r+v*n*c-i*f*c-o*n*g+i*l*g)*R,e[3]=(d*l*r-o*u*r-d*n*c+i*u*c+o*n*p-i*l*p)*R,e[4]=x*R,e[5]=(h*f*r-m*u*r+m*n*p-t*f*p-h*n*g+t*u*g)*R,e[6]=(m*l*r-a*f*r-m*n*c+t*f*c+a*n*g-t*l*g)*R,e[7]=(a*u*r-h*l*r+h*n*c-t*u*c-a*n*p+t*l*p)*R,e[8]=_*R,e[9]=(m*d*r-h*v*r-m*i*p+t*v*p+h*i*g-t*d*g)*R,e[10]=(a*v*r-m*o*r+m*i*c-t*v*c-a*i*g+t*o*g)*R,e[11]=(h*o*r-a*d*r-h*i*c+t*d*c+a*i*p-t*o*p)*R,e[12]=b*R,e[13]=(h*v*n-m*d*n+m*i*u-t*v*u-h*i*f+t*d*f)*R,e[14]=(m*o*n-a*v*n-m*i*l+t*v*l+a*i*f-t*o*f)*R,e[15]=(a*d*n-h*o*n+h*i*l-t*d*l-a*i*u+t*o*u)*R,this}scale(e){let t=this.elements,i=e.x,n=e.y,r=e.z;return t[0]*=i,t[4]*=n,t[8]*=r,t[1]*=i,t[5]*=n,t[9]*=r,t[2]*=i,t[6]*=n,t[10]*=r,t[3]*=i,t[7]*=n,t[11]*=r,this}getMaxScaleOnAxis(){let e=this.elements,t=e[0]*e[0]+e[1]*e[1]+e[2]*e[2],i=e[4]*e[4]+e[5]*e[5]+e[6]*e[6],n=e[8]*e[8]+e[9]*e[9]+e[10]*e[10];return Math.sqrt(Math.max(t,i,n))}makeTranslation(e,t,i){return e.isVector3?this.set(1,0,0,e.x,0,1,0,e.y,0,0,1,e.z,0,0,0,1):this.set(1,0,0,e,0,1,0,t,0,0,1,i,0,0,0,1),this}makeRotationX(e){let t=Math.cos(e),i=Math.sin(e);return this.set(1,0,0,0,0,t,-i,0,0,i,t,0,0,0,0,1),this}makeRotationY(e){let t=Math.cos(e),i=Math.sin(e);return this.set(t,0,i,0,0,1,0,0,-i,0,t,0,0,0,0,1),this}makeRotationZ(e){let t=Math.cos(e),i=Math.sin(e);return this.set(t,-i,0,0,i,t,0,0,0,0,1,0,0,0,0,1),this}makeRotationAxis(e,t){let i=Math.cos(t),n=Math.sin(t),r=1-i,a=e.x,o=e.y,l=e.z,c=r*a,h=r*o;return this.set(c*a+i,c*o-n*l,c*l+n*o,0,c*o+n*l,h*o+i,h*l-n*a,0,c*l-n*o,h*l+n*a,r*l*l+i,0,0,0,0,1),this}makeScale(e,t,i){return this.set(e,0,0,0,0,t,0,0,0,0,i,0,0,0,0,1),this}makeShear(e,t,i,n,r,a){return this.set(1,i,r,0,e,1,a,0,t,n,1,0,0,0,0,1),this}compose(e,t,i){let n=this.elements,r=t._x,a=t._y,o=t._z,l=t._w,c=r+r,h=a+a,d=o+o,u=r*c,p=r*h,m=r*d,v=a*h,f=a*d,g=o*d,y=l*c,x=l*h,_=l*d,b=i.x,S=i.y,R=i.z;return n[0]=(1-(v+g))*b,n[1]=(p+_)*b,n[2]=(m-x)*b,n[3]=0,n[4]=(p-_)*S,n[5]=(1-(u+g))*S,n[6]=(f+y)*S,n[7]=0,n[8]=(m+x)*R,n[9]=(f-y)*R,n[10]=(1-(u+v))*R,n[11]=0,n[12]=e.x,n[13]=e.y,n[14]=e.z,n[15]=1,this}decompose(e,t,i){let n=this.elements,r=An.set(n[0],n[1],n[2]).length(),a=An.set(n[4],n[5],n[6]).length(),o=An.set(n[8],n[9],n[10]).length();this.determinant()<0&&(r=-r),e.x=n[12],e.y=n[13],e.z=n[14],Qt.copy(this);let l=1/r,c=1/a,h=1/o;return Qt.elements[0]*=l,Qt.elements[1]*=l,Qt.elements[2]*=l,Qt.elements[4]*=c,Qt.elements[5]*=c,Qt.elements[6]*=c,Qt.elements[8]*=h,Qt.elements[9]*=h,Qt.elements[10]*=h,t.setFromRotationMatrix(Qt),i.x=r,i.y=a,i.z=o,this}makePerspective(e,t,i,n,r,a,o=2e3){let l=this.elements,c=2*r/(t-e),h=2*r/(i-n),d=(t+e)/(t-e),u=(i+n)/(i-n),p,m;if(o===$n)p=-(a+r)/(a-r),m=-2*a*r/(a-r);else{if(o!==la)throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+o);p=-a/(a-r),m=-a*r/(a-r)}return l[0]=c,l[4]=0,l[8]=d,l[12]=0,l[1]=0,l[5]=h,l[9]=u,l[13]=0,l[2]=0,l[6]=0,l[10]=p,l[14]=m,l[3]=0,l[7]=0,l[11]=-1,l[15]=0,this}makeOrthographic(e,t,i,n,r,a,o=2e3){let l=this.elements,c=1/(t-e),h=1/(i-n),d=1/(a-r),u=(t+e)*c,p=(i+n)*h,m,v;if(o===$n)m=(a+r)*d,v=-2*d;else{if(o!==la)throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+o);m=r*d,v=-1*d}return l[0]=2*c,l[4]=0,l[8]=0,l[12]=-u,l[1]=0,l[5]=2*h,l[9]=0,l[13]=-p,l[2]=0,l[6]=0,l[10]=v,l[14]=-m,l[3]=0,l[7]=0,l[11]=0,l[15]=1,this}equals(e){let t=this.elements,i=e.elements;for(let n=0;n<16;n++)if(t[n]!==i[n])return!1;return!0}fromArray(e,t=0){for(let i=0;i<16;i++)this.elements[i]=e[i+t];return this}toArray(e=[],t=0){let i=this.elements;return e[t]=i[0],e[t+1]=i[1],e[t+2]=i[2],e[t+3]=i[3],e[t+4]=i[4],e[t+5]=i[5],e[t+6]=i[6],e[t+7]=i[7],e[t+8]=i[8],e[t+9]=i[9],e[t+10]=i[10],e[t+11]=i[11],e[t+12]=i[12],e[t+13]=i[13],e[t+14]=i[14],e[t+15]=i[15],e}},An=new M,Qt=new Ee,ip=new M(0,0,0),np=new M(1,1,1),zi=new M,Tr=new M,kt=new M,Nh=new Ee,Oh=new $e,Et=class s{constructor(e=0,t=0,i=0,n=s.DEFAULT_ORDER){this.isEuler=!0,this._x=e,this._y=t,this._z=i,this._order=n}get x(){return this._x}set x(e){this._x=e,this._onChangeCallback()}get y(){return this._y}set y(e){this._y=e,this._onChangeCallback()}get z(){return this._z}set z(e){this._z=e,this._onChangeCallback()}get order(){return this._order}set order(e){this._order=e,this._onChangeCallback()}set(e,t,i,n=this._order){return this._x=e,this._y=t,this._z=i,this._order=n,this._onChangeCallback(),this}clone(){return new this.constructor(this._x,this._y,this._z,this._order)}copy(e){return this._x=e._x,this._y=e._y,this._z=e._z,this._order=e._order,this._onChangeCallback(),this}setFromRotationMatrix(e,t=this._order,i=!0){let n=e.elements,r=n[0],a=n[4],o=n[8],l=n[1],c=n[5],h=n[9],d=n[2],u=n[6],p=n[10];switch(t){case"XYZ":this._y=Math.asin(_t(o,-1,1)),Math.abs(o)<.9999999?(this._x=Math.atan2(-h,p),this._z=Math.atan2(-a,r)):(this._x=Math.atan2(u,c),this._z=0);break;case"YXZ":this._x=Math.asin(-_t(h,-1,1)),Math.abs(h)<.9999999?(this._y=Math.atan2(o,p),this._z=Math.atan2(l,c)):(this._y=Math.atan2(-d,r),this._z=0);break;case"ZXY":this._x=Math.asin(_t(u,-1,1)),Math.abs(u)<.9999999?(this._y=Math.atan2(-d,p),this._z=Math.atan2(-a,c)):(this._y=0,this._z=Math.atan2(l,r));break;case"ZYX":this._y=Math.asin(-_t(d,-1,1)),Math.abs(d)<.9999999?(this._x=Math.atan2(u,p),this._z=Math.atan2(l,r)):(this._x=0,this._z=Math.atan2(-a,c));break;case"YZX":this._z=Math.asin(_t(l,-1,1)),Math.abs(l)<.9999999?(this._x=Math.atan2(-h,c),this._y=Math.atan2(-d,r)):(this._x=0,this._y=Math.atan2(o,p));break;case"XZY":this._z=Math.asin(-_t(a,-1,1)),Math.abs(a)<.9999999?(this._x=Math.atan2(u,c),this._y=Math.atan2(o,r)):(this._x=Math.atan2(-h,p),this._y=0);break;default:console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: "+t)}return this._order=t,i===!0&&this._onChangeCallback(),this}setFromQuaternion(e,t,i){return Nh.makeRotationFromQuaternion(e),this.setFromRotationMatrix(Nh,t,i)}setFromVector3(e,t=this._order){return this.set(e.x,e.y,e.z,t)}reorder(e){return Oh.setFromEuler(this),this.setFromQuaternion(Oh,e)}equals(e){return e._x===this._x&&e._y===this._y&&e._z===this._z&&e._order===this._order}fromArray(e){return this._x=e[0],this._y=e[1],this._z=e[2],e[3]!==void 0&&(this._order=e[3]),this._onChangeCallback(),this}toArray(e=[],t=0){return e[t]=this._x,e[t+1]=this._y,e[t+2]=this._z,e[t+3]=this._order,e}_onChange(e){return this._onChangeCallback=e,this}_onChangeCallback(){}*[Symbol.iterator](){yield this._x,yield this._y,yield this._z,yield this._order}};Et.DEFAULT_ORDER="XYZ";var da=class{constructor(){this.mask=1}set(e){this.mask=1<<e>>>0}enable(e){this.mask|=1<<e}enableAll(){this.mask=-1}toggle(e){this.mask^=1<<e}disable(e){this.mask&=~(1<<e)}disableAll(){this.mask=0}test(e){return!!(this.mask&e.mask)}isEnabled(e){return!!(this.mask&1<<e)}},sp=0,zh=new M,Rn=new $e,Mi=new Ee,Ar=new M,ws=new M,rp=new M,ap=new $e,kh=new M(1,0,0),Fh=new M(0,1,0),Bh=new M(0,0,1),Hh={type:"added"},op={type:"removed"},Cn={type:"childadded",child:null},Uo={type:"childremoved",child:null},at=class s extends Gi{constructor(){super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:sp++}),this.uuid=fi(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=s.DEFAULT_UP.clone();let e=new M,t=new Et,i=new $e,n=new M(1,1,1);t._onChange(function(){i.setFromEuler(t,!1)}),i._onChange(function(){t.setFromQuaternion(i,void 0,!1)}),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:e},rotation:{configurable:!0,enumerable:!0,value:t},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:n},modelViewMatrix:{value:new Ee},normalMatrix:{value:new De}}),this.matrix=new Ee,this.matrixWorld=new Ee,this.matrixAutoUpdate=s.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=s.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new da,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.userData={}}onBeforeShadow(){}onAfterShadow(){}onBeforeRender(){}onAfterRender(){}applyMatrix4(e){this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(e),this.matrix.decompose(this.position,this.quaternion,this.scale)}applyQuaternion(e){return this.quaternion.premultiply(e),this}setRotationFromAxisAngle(e,t){this.quaternion.setFromAxisAngle(e,t)}setRotationFromEuler(e){this.quaternion.setFromEuler(e,!0)}setRotationFromMatrix(e){this.quaternion.setFromRotationMatrix(e)}setRotationFromQuaternion(e){this.quaternion.copy(e)}rotateOnAxis(e,t){return Rn.setFromAxisAngle(e,t),this.quaternion.multiply(Rn),this}rotateOnWorldAxis(e,t){return Rn.setFromAxisAngle(e,t),this.quaternion.premultiply(Rn),this}rotateX(e){return this.rotateOnAxis(kh,e)}rotateY(e){return this.rotateOnAxis(Fh,e)}rotateZ(e){return this.rotateOnAxis(Bh,e)}translateOnAxis(e,t){return zh.copy(e).applyQuaternion(this.quaternion),this.position.add(zh.multiplyScalar(t)),this}translateX(e){return this.translateOnAxis(kh,e)}translateY(e){return this.translateOnAxis(Fh,e)}translateZ(e){return this.translateOnAxis(Bh,e)}localToWorld(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(this.matrixWorld)}worldToLocal(e){return this.updateWorldMatrix(!0,!1),e.applyMatrix4(Mi.copy(this.matrixWorld).invert())}lookAt(e,t,i){e.isVector3?Ar.copy(e):Ar.set(e,t,i);let n=this.parent;this.updateWorldMatrix(!0,!1),ws.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?Mi.lookAt(ws,Ar,this.up):Mi.lookAt(Ar,ws,this.up),this.quaternion.setFromRotationMatrix(Mi),n&&(Mi.extractRotation(n.matrixWorld),Rn.setFromRotationMatrix(Mi),this.quaternion.premultiply(Rn.invert()))}add(e){if(arguments.length>1){for(let t=0;t<arguments.length;t++)this.add(arguments[t]);return this}return e===this?(console.error("THREE.Object3D.add: object can't be added as a child of itself.",e),this):(e&&e.isObject3D?(e.removeFromParent(),e.parent=this,this.children.push(e),e.dispatchEvent(Hh),Cn.child=e,this.dispatchEvent(Cn),Cn.child=null):console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.",e),this)}remove(e){if(arguments.length>1){for(let i=0;i<arguments.length;i++)this.remove(arguments[i]);return this}let t=this.children.indexOf(e);return t!==-1&&(e.parent=null,this.children.splice(t,1),e.dispatchEvent(op),Uo.child=e,this.dispatchEvent(Uo),Uo.child=null),this}removeFromParent(){let e=this.parent;return e!==null&&e.remove(this),this}clear(){return this.remove(...this.children)}attach(e){return this.updateWorldMatrix(!0,!1),Mi.copy(this.matrixWorld).invert(),e.parent!==null&&(e.parent.updateWorldMatrix(!0,!1),Mi.multiply(e.parent.matrixWorld)),e.applyMatrix4(Mi),e.removeFromParent(),e.parent=this,this.children.push(e),e.updateWorldMatrix(!1,!0),e.dispatchEvent(Hh),Cn.child=e,this.dispatchEvent(Cn),Cn.child=null,this}getObjectById(e){return this.getObjectByProperty("id",e)}getObjectByName(e){return this.getObjectByProperty("name",e)}getObjectByProperty(e,t){if(this[e]===t)return this;for(let i=0,n=this.children.length;i<n;i++){let r=this.children[i].getObjectByProperty(e,t);if(r!==void 0)return r}}getObjectsByProperty(e,t,i=[]){this[e]===t&&i.push(this);let n=this.children;for(let r=0,a=n.length;r<a;r++)n[r].getObjectsByProperty(e,t,i);return i}getWorldPosition(e){return this.updateWorldMatrix(!0,!1),e.setFromMatrixPosition(this.matrixWorld)}getWorldQuaternion(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ws,e,rp),e}getWorldScale(e){return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(ws,ap,e),e}getWorldDirection(e){this.updateWorldMatrix(!0,!1);let t=this.matrixWorld.elements;return e.set(t[8],t[9],t[10]).normalize()}raycast(){}traverse(e){e(this);let t=this.children;for(let i=0,n=t.length;i<n;i++)t[i].traverse(e)}traverseVisible(e){if(this.visible===!1)return;e(this);let t=this.children;for(let i=0,n=t.length;i<n;i++)t[i].traverseVisible(e)}traverseAncestors(e){let t=this.parent;t!==null&&(e(t),t.traverseAncestors(e))}updateMatrix(){this.matrix.compose(this.position,this.quaternion,this.scale),this.matrixWorldNeedsUpdate=!0}updateMatrixWorld(e){this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||e)&&(this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,e=!0);let t=this.children;for(let i=0,n=t.length;i<n;i++)t[i].updateMatrixWorld(e)}updateWorldMatrix(e,t){let i=this.parent;if(e===!0&&i!==null&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),this.matrixWorldAutoUpdate===!0&&(this.parent===null?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),t===!0){let n=this.children;for(let r=0,a=n.length;r<a;r++)n[r].updateWorldMatrix(!1,!0)}}toJSON(e){let t=e===void 0||typeof e=="string",i={};t&&(e={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.6,type:"Object",generator:"Object3D.toJSON"});let n={};function r(o,l){return o[l.uuid]===void 0&&(o[l.uuid]=l.toJSON(e)),l.uuid}if(n.uuid=this.uuid,n.type=this.type,this.name!==""&&(n.name=this.name),this.castShadow===!0&&(n.castShadow=!0),this.receiveShadow===!0&&(n.receiveShadow=!0),this.visible===!1&&(n.visible=!1),this.frustumCulled===!1&&(n.frustumCulled=!1),this.renderOrder!==0&&(n.renderOrder=this.renderOrder),Object.keys(this.userData).length>0&&(n.userData=this.userData),n.layers=this.layers.mask,n.matrix=this.matrix.toArray(),n.up=this.up.toArray(),this.matrixAutoUpdate===!1&&(n.matrixAutoUpdate=!1),this.isInstancedMesh&&(n.type="InstancedMesh",n.count=this.count,n.instanceMatrix=this.instanceMatrix.toJSON(),this.instanceColor!==null&&(n.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(n.type="BatchedMesh",n.perObjectFrustumCulled=this.perObjectFrustumCulled,n.sortObjects=this.sortObjects,n.drawRanges=this._drawRanges,n.reservedRanges=this._reservedRanges,n.visibility=this._visibility,n.active=this._active,n.bounds=this._bounds.map(o=>({boxInitialized:o.boxInitialized,boxMin:o.box.min.toArray(),boxMax:o.box.max.toArray(),sphereInitialized:o.sphereInitialized,sphereRadius:o.sphere.radius,sphereCenter:o.sphere.center.toArray()})),n.maxInstanceCount=this._maxInstanceCount,n.maxVertexCount=this._maxVertexCount,n.maxIndexCount=this._maxIndexCount,n.geometryInitialized=this._geometryInitialized,n.geometryCount=this._geometryCount,n.matricesTexture=this._matricesTexture.toJSON(e),this._colorsTexture!==null&&(n.colorsTexture=this._colorsTexture.toJSON(e)),this.boundingSphere!==null&&(n.boundingSphere={center:n.boundingSphere.center.toArray(),radius:n.boundingSphere.radius}),this.boundingBox!==null&&(n.boundingBox={min:n.boundingBox.min.toArray(),max:n.boundingBox.max.toArray()})),this.isScene)this.background&&(this.background.isColor?n.background=this.background.toJSON():this.background.isTexture&&(n.background=this.background.toJSON(e).uuid)),this.environment&&this.environment.isTexture&&this.environment.isRenderTargetTexture!==!0&&(n.environment=this.environment.toJSON(e).uuid);else if(this.isMesh||this.isLine||this.isPoints){n.geometry=r(e.geometries,this.geometry);let o=this.geometry.parameters;if(o!==void 0&&o.shapes!==void 0){let l=o.shapes;if(Array.isArray(l))for(let c=0,h=l.length;c<h;c++){let d=l[c];r(e.shapes,d)}else r(e.shapes,l)}}if(this.isSkinnedMesh&&(n.bindMode=this.bindMode,n.bindMatrix=this.bindMatrix.toArray(),this.skeleton!==void 0&&(r(e.skeletons,this.skeleton),n.skeleton=this.skeleton.uuid)),this.material!==void 0)if(Array.isArray(this.material)){let o=[];for(let l=0,c=this.material.length;l<c;l++)o.push(r(e.materials,this.material[l]));n.material=o}else n.material=r(e.materials,this.material);if(this.children.length>0){n.children=[];for(let o=0;o<this.children.length;o++)n.children.push(this.children[o].toJSON(e).object)}if(this.animations.length>0){n.animations=[];for(let o=0;o<this.animations.length;o++){let l=this.animations[o];n.animations.push(r(e.animations,l))}}if(t){let o=a(e.geometries),l=a(e.materials),c=a(e.textures),h=a(e.images),d=a(e.shapes),u=a(e.skeletons),p=a(e.animations),m=a(e.nodes);o.length>0&&(i.geometries=o),l.length>0&&(i.materials=l),c.length>0&&(i.textures=c),h.length>0&&(i.images=h),d.length>0&&(i.shapes=d),u.length>0&&(i.skeletons=u),p.length>0&&(i.animations=p),m.length>0&&(i.nodes=m)}return i.object=n,i;function a(o){let l=[];for(let c in o){let h=o[c];delete h.metadata,l.push(h)}return l}}clone(e){return new this.constructor().copy(this,e)}copy(e,t=!0){if(this.name=e.name,this.up.copy(e.up),this.position.copy(e.position),this.rotation.order=e.rotation.order,this.quaternion.copy(e.quaternion),this.scale.copy(e.scale),this.matrix.copy(e.matrix),this.matrixWorld.copy(e.matrixWorld),this.matrixAutoUpdate=e.matrixAutoUpdate,this.matrixWorldAutoUpdate=e.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=e.matrixWorldNeedsUpdate,this.layers.mask=e.layers.mask,this.visible=e.visible,this.castShadow=e.castShadow,this.receiveShadow=e.receiveShadow,this.frustumCulled=e.frustumCulled,this.renderOrder=e.renderOrder,this.animations=e.animations.slice(),this.userData=JSON.parse(JSON.stringify(e.userData)),t===!0)for(let i=0;i<e.children.length;i++){let n=e.children[i];this.add(n.clone())}return this}};at.DEFAULT_UP=new M(0,1,0),at.DEFAULT_MATRIX_AUTO_UPDATE=!0,at.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;var ei=new M,bi=new M,No=new M,Si=new M,Ln=new M,Pn=new M,Vh=new M,Oo=new M,zo=new M,ko=new M,Fo=new ct,Bo=new ct,Ho=new ct,Ei=class s{constructor(e=new M,t=new M,i=new M){this.a=e,this.b=t,this.c=i}static getNormal(e,t,i,n){n.subVectors(i,t),ei.subVectors(e,t),n.cross(ei);let r=n.lengthSq();return r>0?n.multiplyScalar(1/Math.sqrt(r)):n.set(0,0,0)}static getBarycoord(e,t,i,n,r){ei.subVectors(n,t),bi.subVectors(i,t),No.subVectors(e,t);let a=ei.dot(ei),o=ei.dot(bi),l=ei.dot(No),c=bi.dot(bi),h=bi.dot(No),d=a*c-o*o;if(d===0)return r.set(0,0,0),null;let u=1/d,p=(c*l-o*h)*u,m=(a*h-o*l)*u;return r.set(1-p-m,m,p)}static containsPoint(e,t,i,n){return this.getBarycoord(e,t,i,n,Si)!==null&&Si.x>=0&&Si.y>=0&&Si.x+Si.y<=1}static getInterpolation(e,t,i,n,r,a,o,l){return this.getBarycoord(e,t,i,n,Si)===null?(l.x=0,l.y=0,"z"in l&&(l.z=0),"w"in l&&(l.w=0),null):(l.setScalar(0),l.addScaledVector(r,Si.x),l.addScaledVector(a,Si.y),l.addScaledVector(o,Si.z),l)}static getInterpolatedAttribute(e,t,i,n,r,a){return Fo.setScalar(0),Bo.setScalar(0),Ho.setScalar(0),Fo.fromBufferAttribute(e,t),Bo.fromBufferAttribute(e,i),Ho.fromBufferAttribute(e,n),a.setScalar(0),a.addScaledVector(Fo,r.x),a.addScaledVector(Bo,r.y),a.addScaledVector(Ho,r.z),a}static isFrontFacing(e,t,i,n){return ei.subVectors(i,t),bi.subVectors(e,t),ei.cross(bi).dot(n)<0}set(e,t,i){return this.a.copy(e),this.b.copy(t),this.c.copy(i),this}setFromPointsAndIndices(e,t,i,n){return this.a.copy(e[t]),this.b.copy(e[i]),this.c.copy(e[n]),this}setFromAttributeAndIndices(e,t,i,n){return this.a.fromBufferAttribute(e,t),this.b.fromBufferAttribute(e,i),this.c.fromBufferAttribute(e,n),this}clone(){return new this.constructor().copy(this)}copy(e){return this.a.copy(e.a),this.b.copy(e.b),this.c.copy(e.c),this}getArea(){return ei.subVectors(this.c,this.b),bi.subVectors(this.a,this.b),.5*ei.cross(bi).length()}getMidpoint(e){return e.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)}getNormal(e){return s.getNormal(this.a,this.b,this.c,e)}getPlane(e){return e.setFromCoplanarPoints(this.a,this.b,this.c)}getBarycoord(e,t){return s.getBarycoord(e,this.a,this.b,this.c,t)}getInterpolation(e,t,i,n,r){return s.getInterpolation(e,this.a,this.b,this.c,t,i,n,r)}containsPoint(e){return s.containsPoint(e,this.a,this.b,this.c)}isFrontFacing(e){return s.isFrontFacing(this.a,this.b,this.c,e)}intersectsBox(e){return e.intersectsTriangle(this)}closestPointToPoint(e,t){let i=this.a,n=this.b,r=this.c,a,o;Ln.subVectors(n,i),Pn.subVectors(r,i),Oo.subVectors(e,i);let l=Ln.dot(Oo),c=Pn.dot(Oo);if(l<=0&&c<=0)return t.copy(i);zo.subVectors(e,n);let h=Ln.dot(zo),d=Pn.dot(zo);if(h>=0&&d<=h)return t.copy(n);let u=l*d-h*c;if(u<=0&&l>=0&&h<=0)return a=l/(l-h),t.copy(i).addScaledVector(Ln,a);ko.subVectors(e,r);let p=Ln.dot(ko),m=Pn.dot(ko);if(m>=0&&p<=m)return t.copy(r);let v=p*c-l*m;if(v<=0&&c>=0&&m<=0)return o=c/(c-m),t.copy(i).addScaledVector(Pn,o);let f=h*m-p*d;if(f<=0&&d-h>=0&&p-m>=0)return Vh.subVectors(r,n),o=(d-h)/(d-h+(p-m)),t.copy(n).addScaledVector(Vh,o);let g=1/(f+v+u);return a=v*g,o=u*g,t.copy(i).addScaledVector(Ln,a).addScaledVector(Pn,o)}equals(e){return e.a.equals(this.a)&&e.b.equals(this.b)&&e.c.equals(this.c)}},$u={aliceblue:15792383,antiquewhite:16444375,aqua:65535,aquamarine:8388564,azure:15794175,beige:16119260,bisque:16770244,black:0,blanchedalmond:16772045,blue:255,blueviolet:9055202,brown:10824234,burlywood:14596231,cadetblue:6266528,chartreuse:8388352,chocolate:13789470,coral:16744272,cornflowerblue:6591981,cornsilk:16775388,crimson:14423100,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:12092939,darkgray:11119017,darkgreen:25600,darkgrey:11119017,darkkhaki:12433259,darkmagenta:9109643,darkolivegreen:5597999,darkorange:16747520,darkorchid:10040012,darkred:9109504,darksalmon:15308410,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:16716947,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:11674146,floralwhite:16775920,forestgreen:2263842,fuchsia:16711935,gainsboro:14474460,ghostwhite:16316671,gold:16766720,goldenrod:14329120,gray:8421504,green:32768,greenyellow:11403055,grey:8421504,honeydew:15794160,hotpink:16738740,indianred:13458524,indigo:4915330,ivory:16777200,khaki:15787660,lavender:15132410,lavenderblush:16773365,lawngreen:8190976,lemonchiffon:16775885,lightblue:11393254,lightcoral:15761536,lightcyan:14745599,lightgoldenrodyellow:16448210,lightgray:13882323,lightgreen:9498256,lightgrey:13882323,lightpink:16758465,lightsalmon:16752762,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:11584734,lightyellow:16777184,lime:65280,limegreen:3329330,linen:16445670,magenta:16711935,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:12211667,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:13047173,midnightblue:1644912,mintcream:16121850,mistyrose:16770273,moccasin:16770229,navajowhite:16768685,navy:128,oldlace:16643558,olive:8421376,olivedrab:7048739,orange:16753920,orangered:16729344,orchid:14315734,palegoldenrod:15657130,palegreen:10025880,paleturquoise:11529966,palevioletred:14381203,papayawhip:16773077,peachpuff:16767673,peru:13468991,pink:16761035,plum:14524637,powderblue:11591910,purple:8388736,rebeccapurple:6697881,red:16711680,rosybrown:12357519,royalblue:4286945,saddlebrown:9127187,salmon:16416882,sandybrown:16032864,seagreen:3050327,seashell:16774638,sienna:10506797,silver:12632256,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:16775930,springgreen:65407,steelblue:4620980,tan:13808780,teal:32896,thistle:14204888,tomato:16737095,turquoise:4251856,violet:15631086,wheat:16113331,white:16777215,whitesmoke:16119285,yellow:16776960,yellowgreen:10145074},ki={h:0,s:0,l:0},Rr={h:0,s:0,l:0};function Vo(s,e,t){return t<0&&(t+=1),t>1&&(t-=1),t<1/6?s+6*(e-s)*t:t<.5?e:t<2/3?s+6*(e-s)*(2/3-t):s}var ye=class{constructor(e,t,i){return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(e,t,i)}set(e,t,i){if(t===void 0&&i===void 0){let n=e;n&&n.isColor?this.copy(n):typeof n=="number"?this.setHex(n):typeof n=="string"&&this.setStyle(n)}else this.setRGB(e,t,i);return this}setScalar(e){return this.r=e,this.g=e,this.b=e,this}setHex(e,t=wt){return e=Math.floor(e),this.r=(e>>16&255)/255,this.g=(e>>8&255)/255,this.b=(255&e)/255,je.toWorkingColorSpace(this,t),this}setRGB(e,t,i,n=je.workingColorSpace){return this.r=e,this.g=t,this.b=i,je.toWorkingColorSpace(this,n),this}setHSL(e,t,i,n=je.workingColorSpace){if(e=Bl(e,1),t=_t(t,0,1),i=_t(i,0,1),t===0)this.r=this.g=this.b=i;else{let r=i<=.5?i*(1+t):i+t-i*t,a=2*i-r;this.r=Vo(a,r,e+1/3),this.g=Vo(a,r,e),this.b=Vo(a,r,e-1/3)}return je.toWorkingColorSpace(this,n),this}setStyle(e,t=wt){function i(r){r!==void 0&&parseFloat(r)<1&&console.warn("THREE.Color: Alpha component of "+e+" will be ignored.")}let n;if(n=/^(\w+)\(([^\)]*)\)/.exec(e)){let r,a=n[1],o=n[2];switch(a){case"rgb":case"rgba":if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,t);if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,t);break;case"hsl":case"hsla":if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(o))return i(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,t);break;default:console.warn("THREE.Color: Unknown color model "+e)}}else if(n=/^\#([A-Fa-f\d]+)$/.exec(e)){let r=n[1],a=r.length;if(a===3)return this.setRGB(parseInt(r.charAt(0),16)/15,parseInt(r.charAt(1),16)/15,parseInt(r.charAt(2),16)/15,t);if(a===6)return this.setHex(parseInt(r,16),t);console.warn("THREE.Color: Invalid hex color "+e)}else if(e&&e.length>0)return this.setColorName(e,t);return this}setColorName(e,t=wt){let i=$u[e.toLowerCase()];return i!==void 0?this.setHex(i,t):console.warn("THREE.Color: Unknown color "+e),this}clone(){return new this.constructor(this.r,this.g,this.b)}copy(e){return this.r=e.r,this.g=e.g,this.b=e.b,this}copySRGBToLinear(e){return this.r=Ai(e.r),this.g=Ai(e.g),this.b=Ai(e.b),this}copyLinearToSRGB(e){return this.r=Gn(e.r),this.g=Gn(e.g),this.b=Gn(e.b),this}convertSRGBToLinear(){return this.copySRGBToLinear(this),this}convertLinearToSRGB(){return this.copyLinearToSRGB(this),this}getHex(e=wt){return je.fromWorkingColorSpace(Rt.copy(this),e),65536*Math.round(_t(255*Rt.r,0,255))+256*Math.round(_t(255*Rt.g,0,255))+Math.round(_t(255*Rt.b,0,255))}getHexString(e=wt){return("000000"+this.getHex(e).toString(16)).slice(-6)}getHSL(e,t=je.workingColorSpace){je.fromWorkingColorSpace(Rt.copy(this),t);let i=Rt.r,n=Rt.g,r=Rt.b,a=Math.max(i,n,r),o=Math.min(i,n,r),l,c,h=(o+a)/2;if(o===a)l=0,c=0;else{let d=a-o;switch(c=h<=.5?d/(a+o):d/(2-a-o),a){case i:l=(n-r)/d+(n<r?6:0);break;case n:l=(r-i)/d+2;break;case r:l=(i-n)/d+4}l/=6}return e.h=l,e.s=c,e.l=h,e}getRGB(e,t=je.workingColorSpace){return je.fromWorkingColorSpace(Rt.copy(this),t),e.r=Rt.r,e.g=Rt.g,e.b=Rt.b,e}getStyle(e=wt){je.fromWorkingColorSpace(Rt.copy(this),e);let t=Rt.r,i=Rt.g,n=Rt.b;return e!==wt?`color(${e} ${t.toFixed(3)} ${i.toFixed(3)} ${n.toFixed(3)})`:`rgb(${Math.round(255*t)},${Math.round(255*i)},${Math.round(255*n)})`}offsetHSL(e,t,i){return this.getHSL(ki),this.setHSL(ki.h+e,ki.s+t,ki.l+i)}add(e){return this.r+=e.r,this.g+=e.g,this.b+=e.b,this}addColors(e,t){return this.r=e.r+t.r,this.g=e.g+t.g,this.b=e.b+t.b,this}addScalar(e){return this.r+=e,this.g+=e,this.b+=e,this}sub(e){return this.r=Math.max(0,this.r-e.r),this.g=Math.max(0,this.g-e.g),this.b=Math.max(0,this.b-e.b),this}multiply(e){return this.r*=e.r,this.g*=e.g,this.b*=e.b,this}multiplyScalar(e){return this.r*=e,this.g*=e,this.b*=e,this}lerp(e,t){return this.r+=(e.r-this.r)*t,this.g+=(e.g-this.g)*t,this.b+=(e.b-this.b)*t,this}lerpColors(e,t,i){return this.r=e.r+(t.r-e.r)*i,this.g=e.g+(t.g-e.g)*i,this.b=e.b+(t.b-e.b)*i,this}lerpHSL(e,t){this.getHSL(ki),e.getHSL(Rr);let i=Ns(ki.h,Rr.h,t),n=Ns(ki.s,Rr.s,t),r=Ns(ki.l,Rr.l,t);return this.setHSL(i,n,r),this}setFromVector3(e){return this.r=e.x,this.g=e.y,this.b=e.z,this}applyMatrix3(e){let t=this.r,i=this.g,n=this.b,r=e.elements;return this.r=r[0]*t+r[3]*i+r[6]*n,this.g=r[1]*t+r[4]*i+r[7]*n,this.b=r[2]*t+r[5]*i+r[8]*n,this}equals(e){return e.r===this.r&&e.g===this.g&&e.b===this.b}fromArray(e,t=0){return this.r=e[t],this.g=e[t+1],this.b=e[t+2],this}toArray(e=[],t=0){return e[t]=this.r,e[t+1]=this.g,e[t+2]=this.b,e}fromBufferAttribute(e,t){return this.r=e.getX(t),this.g=e.getY(t),this.b=e.getZ(t),this}toJSON(){return this.getHex()}*[Symbol.iterator](){yield this.r,yield this.g,yield this.b}},Rt=new ye;ye.NAMES=$u;var lp=0,gi=class extends Gi{static get type(){return"Material"}get type(){return this.constructor.type}set type(e){}constructor(){super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:lp++}),this.uuid=fi(),this.name="",this.blending=1,this.side=0,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=ol,this.blendDst=ll,this.blendEquation=ln,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new ye(0,0,0),this.blendAlpha=0,this.depthFunc=3,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=519,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=bn,this.stencilZFail=bn,this.stencilZPass=bn,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0}get alphaTest(){return this._alphaTest}set alphaTest(e){this._alphaTest>0!=e>0&&this.version++,this._alphaTest=e}onBeforeRender(){}onBeforeCompile(){}customProgramCacheKey(){return this.onBeforeCompile.toString()}setValues(e){if(e!==void 0)for(let t in e){let i=e[t];if(i===void 0){console.warn(`THREE.Material: parameter '${t}' has value of undefined.`);continue}let n=this[t];n!==void 0?n&&n.isColor?n.set(i):n&&n.isVector3&&i&&i.isVector3?n.copy(i):this[t]=i:console.warn(`THREE.Material: '${t}' is not a property of THREE.${this.type}.`)}}toJSON(e){let t=e===void 0||typeof e=="string";t&&(e={textures:{},images:{}});let i={metadata:{version:4.6,type:"Material",generator:"Material.toJSON"}};function n(r){let a=[];for(let o in r){let l=r[o];delete l.metadata,a.push(l)}return a}if(i.uuid=this.uuid,i.type=this.type,this.name!==""&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),this.roughness!==void 0&&(i.roughness=this.roughness),this.metalness!==void 0&&(i.metalness=this.metalness),this.sheen!==void 0&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),this.sheenRoughness!==void 0&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),this.emissiveIntensity!==void 0&&this.emissiveIntensity!==1&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),this.specularIntensity!==void 0&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),this.shininess!==void 0&&(i.shininess=this.shininess),this.clearcoat!==void 0&&(i.clearcoat=this.clearcoat),this.clearcoatRoughness!==void 0&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(e).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(e).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(e).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.dispersion!==void 0&&(i.dispersion=this.dispersion),this.iridescence!==void 0&&(i.iridescence=this.iridescence),this.iridescenceIOR!==void 0&&(i.iridescenceIOR=this.iridescenceIOR),this.iridescenceThicknessRange!==void 0&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(e).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(e).uuid),this.anisotropy!==void 0&&(i.anisotropy=this.anisotropy),this.anisotropyRotation!==void 0&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(e).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(e).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(e).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(e).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(e).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(e).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(e).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(e).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(e).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(e).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(e).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(e).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(e).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(e).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(e).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(e).uuid,this.combine!==void 0&&(i.combine=this.combine)),this.envMapRotation!==void 0&&(i.envMapRotation=this.envMapRotation.toArray()),this.envMapIntensity!==void 0&&(i.envMapIntensity=this.envMapIntensity),this.reflectivity!==void 0&&(i.reflectivity=this.reflectivity),this.refractionRatio!==void 0&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(e).uuid),this.transmission!==void 0&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(e).uuid),this.thickness!==void 0&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(e).uuid),this.attenuationDistance!==void 0&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),this.attenuationColor!==void 0&&(i.attenuationColor=this.attenuationColor.getHex()),this.size!==void 0&&(i.size=this.size),this.shadowSide!==null&&(i.shadowSide=this.shadowSide),this.sizeAttenuation!==void 0&&(i.sizeAttenuation=this.sizeAttenuation),this.blending!==1&&(i.blending=this.blending),this.side!==0&&(i.side=this.side),this.vertexColors===!0&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),this.transparent===!0&&(i.transparent=!0),this.blendSrc!==ol&&(i.blendSrc=this.blendSrc),this.blendDst!==ll&&(i.blendDst=this.blendDst),this.blendEquation!==ln&&(i.blendEquation=this.blendEquation),this.blendSrcAlpha!==null&&(i.blendSrcAlpha=this.blendSrcAlpha),this.blendDstAlpha!==null&&(i.blendDstAlpha=this.blendDstAlpha),this.blendEquationAlpha!==null&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),this.blendAlpha!==0&&(i.blendAlpha=this.blendAlpha),this.depthFunc!==3&&(i.depthFunc=this.depthFunc),this.depthTest===!1&&(i.depthTest=this.depthTest),this.depthWrite===!1&&(i.depthWrite=this.depthWrite),this.colorWrite===!1&&(i.colorWrite=this.colorWrite),this.stencilWriteMask!==255&&(i.stencilWriteMask=this.stencilWriteMask),this.stencilFunc!==519&&(i.stencilFunc=this.stencilFunc),this.stencilRef!==0&&(i.stencilRef=this.stencilRef),this.stencilFuncMask!==255&&(i.stencilFuncMask=this.stencilFuncMask),this.stencilFail!==bn&&(i.stencilFail=this.stencilFail),this.stencilZFail!==bn&&(i.stencilZFail=this.stencilZFail),this.stencilZPass!==bn&&(i.stencilZPass=this.stencilZPass),this.stencilWrite===!0&&(i.stencilWrite=this.stencilWrite),this.rotation!==void 0&&this.rotation!==0&&(i.rotation=this.rotation),this.polygonOffset===!0&&(i.polygonOffset=!0),this.polygonOffsetFactor!==0&&(i.polygonOffsetFactor=this.polygonOffsetFactor),this.polygonOffsetUnits!==0&&(i.polygonOffsetUnits=this.polygonOffsetUnits),this.linewidth!==void 0&&this.linewidth!==1&&(i.linewidth=this.linewidth),this.dashSize!==void 0&&(i.dashSize=this.dashSize),this.gapSize!==void 0&&(i.gapSize=this.gapSize),this.scale!==void 0&&(i.scale=this.scale),this.dithering===!0&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),this.alphaHash===!0&&(i.alphaHash=!0),this.alphaToCoverage===!0&&(i.alphaToCoverage=!0),this.premultipliedAlpha===!0&&(i.premultipliedAlpha=!0),this.forceSinglePass===!0&&(i.forceSinglePass=!0),this.wireframe===!0&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),this.wireframeLinecap!=="round"&&(i.wireframeLinecap=this.wireframeLinecap),this.wireframeLinejoin!=="round"&&(i.wireframeLinejoin=this.wireframeLinejoin),this.flatShading===!0&&(i.flatShading=!0),this.visible===!1&&(i.visible=!1),this.toneMapped===!1&&(i.toneMapped=!1),this.fog===!1&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData),t){let r=n(e.textures),a=n(e.images);r.length>0&&(i.textures=r),a.length>0&&(i.images=a)}return i}clone(){return new this.constructor().copy(this)}copy(e){this.name=e.name,this.blending=e.blending,this.side=e.side,this.vertexColors=e.vertexColors,this.opacity=e.opacity,this.transparent=e.transparent,this.blendSrc=e.blendSrc,this.blendDst=e.blendDst,this.blendEquation=e.blendEquation,this.blendSrcAlpha=e.blendSrcAlpha,this.blendDstAlpha=e.blendDstAlpha,this.blendEquationAlpha=e.blendEquationAlpha,this.blendColor.copy(e.blendColor),this.blendAlpha=e.blendAlpha,this.depthFunc=e.depthFunc,this.depthTest=e.depthTest,this.depthWrite=e.depthWrite,this.stencilWriteMask=e.stencilWriteMask,this.stencilFunc=e.stencilFunc,this.stencilRef=e.stencilRef,this.stencilFuncMask=e.stencilFuncMask,this.stencilFail=e.stencilFail,this.stencilZFail=e.stencilZFail,this.stencilZPass=e.stencilZPass,this.stencilWrite=e.stencilWrite;let t=e.clippingPlanes,i=null;if(t!==null){let n=t.length;i=new Array(n);for(let r=0;r!==n;++r)i[r]=t[r].clone()}return this.clippingPlanes=i,this.clipIntersection=e.clipIntersection,this.clipShadows=e.clipShadows,this.shadowSide=e.shadowSide,this.colorWrite=e.colorWrite,this.precision=e.precision,this.polygonOffset=e.polygonOffset,this.polygonOffsetFactor=e.polygonOffsetFactor,this.polygonOffsetUnits=e.polygonOffsetUnits,this.dithering=e.dithering,this.alphaTest=e.alphaTest,this.alphaHash=e.alphaHash,this.alphaToCoverage=e.alphaToCoverage,this.premultipliedAlpha=e.premultipliedAlpha,this.forceSinglePass=e.forceSinglePass,this.visible=e.visible,this.toneMapped=e.toneMapped,this.userData=JSON.parse(JSON.stringify(e.userData)),this}dispose(){this.dispatchEvent({type:"dispose"})}set needsUpdate(e){e===!0&&this.version++}onBuild(){console.warn("Material: onBuild() has been removed.")}},oi=class extends gi{static get type(){return"MeshBasicMaterial"}constructor(e){super(),this.isMeshBasicMaterial=!0,this.color=new ye(16777215),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Et,this.combine=0,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.specularMap=e.specularMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.combine=e.combine,this.reflectivity=e.reflectivity,this.refractionRatio=e.refractionRatio,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.fog=e.fog,this}},zf=cp();function cp(){let s=new ArrayBuffer(4),e=new Float32Array(s),t=new Uint32Array(s),i=new Uint32Array(512),n=new Uint32Array(512);for(let l=0;l<256;++l){let c=l-127;c<-27?(i[l]=0,i[256|l]=32768,n[l]=24,n[256|l]=24):c<-14?(i[l]=1024>>-c-14,i[256|l]=1024>>-c-14|32768,n[l]=-c-1,n[256|l]=-c-1):c<=15?(i[l]=c+15<<10,i[256|l]=c+15<<10|32768,n[l]=13,n[256|l]=13):c<128?(i[l]=31744,i[256|l]=64512,n[l]=24,n[256|l]=24):(i[l]=31744,i[256|l]=64512,n[l]=13,n[256|l]=13)}let r=new Uint32Array(2048),a=new Uint32Array(64),o=new Uint32Array(64);for(let l=1;l<1024;++l){let c=l<<13,h=0;for(;!(8388608&c);)c<<=1,h-=8388608;c&=-8388609,h+=947912704,r[l]=c|h}for(let l=1024;l<2048;++l)r[l]=939524096+(l-1024<<13);for(let l=1;l<31;++l)a[l]=l<<23;a[31]=1199570944,a[32]=2147483648;for(let l=33;l<63;++l)a[l]=2147483648+(l-32<<23);a[63]=3347054592;for(let l=1;l<64;++l)l!==32&&(o[l]=1024);return{floatView:e,uint32View:t,baseTable:i,shiftTable:n,mantissaTable:r,exponentTable:a,offsetTable:o}}var mt=new M,Cr=new oe,We=class{constructor(e,t,i=!1){if(Array.isArray(e))throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");this.isBufferAttribute=!0,this.name="",this.array=e,this.itemSize=t,this.count=e!==void 0?e.length/t:0,this.normalized=i,this.usage=Fl,this.updateRanges=[],this.gpuType=pi,this.version=0}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.name=e.name,this.array=new e.array.constructor(e.array),this.itemSize=e.itemSize,this.count=e.count,this.normalized=e.normalized,this.usage=e.usage,this.gpuType=e.gpuType,this}copyAt(e,t,i){e*=this.itemSize,i*=t.itemSize;for(let n=0,r=this.itemSize;n<r;n++)this.array[e+n]=t.array[i+n];return this}copyArray(e){return this.array.set(e),this}applyMatrix3(e){if(this.itemSize===2)for(let t=0,i=this.count;t<i;t++)Cr.fromBufferAttribute(this,t),Cr.applyMatrix3(e),this.setXY(t,Cr.x,Cr.y);else if(this.itemSize===3)for(let t=0,i=this.count;t<i;t++)mt.fromBufferAttribute(this,t),mt.applyMatrix3(e),this.setXYZ(t,mt.x,mt.y,mt.z);return this}applyMatrix4(e){for(let t=0,i=this.count;t<i;t++)mt.fromBufferAttribute(this,t),mt.applyMatrix4(e),this.setXYZ(t,mt.x,mt.y,mt.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)mt.fromBufferAttribute(this,t),mt.applyNormalMatrix(e),this.setXYZ(t,mt.x,mt.y,mt.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)mt.fromBufferAttribute(this,t),mt.transformDirection(e),this.setXYZ(t,mt.x,mt.y,mt.z);return this}set(e,t=0){return this.array.set(e,t),this}getComponent(e,t){let i=this.array[e*this.itemSize+t];return this.normalized&&(i=ti(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=Ke(i,this.array)),this.array[e*this.itemSize+t]=i,this}getX(e){let t=this.array[e*this.itemSize];return this.normalized&&(t=ti(t,this.array)),t}setX(e,t){return this.normalized&&(t=Ke(t,this.array)),this.array[e*this.itemSize]=t,this}getY(e){let t=this.array[e*this.itemSize+1];return this.normalized&&(t=ti(t,this.array)),t}setY(e,t){return this.normalized&&(t=Ke(t,this.array)),this.array[e*this.itemSize+1]=t,this}getZ(e){let t=this.array[e*this.itemSize+2];return this.normalized&&(t=ti(t,this.array)),t}setZ(e,t){return this.normalized&&(t=Ke(t,this.array)),this.array[e*this.itemSize+2]=t,this}getW(e){let t=this.array[e*this.itemSize+3];return this.normalized&&(t=ti(t,this.array)),t}setW(e,t){return this.normalized&&(t=Ke(t,this.array)),this.array[e*this.itemSize+3]=t,this}setXY(e,t,i){return e*=this.itemSize,this.normalized&&(t=Ke(t,this.array),i=Ke(i,this.array)),this.array[e+0]=t,this.array[e+1]=i,this}setXYZ(e,t,i,n){return e*=this.itemSize,this.normalized&&(t=Ke(t,this.array),i=Ke(i,this.array),n=Ke(n,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=n,this}setXYZW(e,t,i,n,r){return e*=this.itemSize,this.normalized&&(t=Ke(t,this.array),i=Ke(i,this.array),n=Ke(n,this.array),r=Ke(r,this.array)),this.array[e+0]=t,this.array[e+1]=i,this.array[e+2]=n,this.array[e+3]=r,this}onUpload(e){return this.onUploadCallback=e,this}clone(){return new this.constructor(this.array,this.itemSize).copy(this)}toJSON(){let e={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};return this.name!==""&&(e.name=this.name),this.usage!==Fl&&(e.usage=this.usage),e}};var pa=class extends We{constructor(e,t,i){super(new Uint16Array(e),t,i)}};var ma=class extends We{constructor(e,t,i){super(new Uint32Array(e),t,i)}};var Te=class extends We{constructor(e,t,i){super(new Float32Array(e),t,i)}},hp=0,Vt=new Ee,Go=new at,In=new M,Ft=new ri,Es=new ri,xt=new M,Ve=class s extends Gi{constructor(){super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:hp++}),this.uuid=fi(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}}getIndex(){return this.index}setIndex(e){return Array.isArray(e)?this.index=new(Yu(e)?ma:pa)(e,1):this.index=e,this}setIndirect(e){return this.indirect=e,this}getIndirect(){return this.indirect}getAttribute(e){return this.attributes[e]}setAttribute(e,t){return this.attributes[e]=t,this}deleteAttribute(e){return delete this.attributes[e],this}hasAttribute(e){return this.attributes[e]!==void 0}addGroup(e,t,i=0){this.groups.push({start:e,count:t,materialIndex:i})}clearGroups(){this.groups=[]}setDrawRange(e,t){this.drawRange.start=e,this.drawRange.count=t}applyMatrix4(e){let t=this.attributes.position;t!==void 0&&(t.applyMatrix4(e),t.needsUpdate=!0);let i=this.attributes.normal;if(i!==void 0){let r=new De().getNormalMatrix(e);i.applyNormalMatrix(r),i.needsUpdate=!0}let n=this.attributes.tangent;return n!==void 0&&(n.transformDirection(e),n.needsUpdate=!0),this.boundingBox!==null&&this.computeBoundingBox(),this.boundingSphere!==null&&this.computeBoundingSphere(),this}applyQuaternion(e){return Vt.makeRotationFromQuaternion(e),this.applyMatrix4(Vt),this}rotateX(e){return Vt.makeRotationX(e),this.applyMatrix4(Vt),this}rotateY(e){return Vt.makeRotationY(e),this.applyMatrix4(Vt),this}rotateZ(e){return Vt.makeRotationZ(e),this.applyMatrix4(Vt),this}translate(e,t,i){return Vt.makeTranslation(e,t,i),this.applyMatrix4(Vt),this}scale(e,t,i){return Vt.makeScale(e,t,i),this.applyMatrix4(Vt),this}lookAt(e){return Go.lookAt(e),Go.updateMatrix(),this.applyMatrix4(Go.matrix),this}center(){return this.computeBoundingBox(),this.boundingBox.getCenter(In).negate(),this.translate(In.x,In.y,In.z),this}setFromPoints(e){let t=this.getAttribute("position");if(t===void 0){let i=[];for(let n=0,r=e.length;n<r;n++){let a=e[n];i.push(a.x,a.y,a.z||0)}this.setAttribute("position",new Te(i,3))}else{for(let i=0,n=t.count;i<n;i++){let r=e[i];t.setXYZ(i,r.x,r.y,r.z||0)}e.length>t.count&&console.warn("THREE.BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),t.needsUpdate=!0}return this}computeBoundingBox(){this.boundingBox===null&&(this.boundingBox=new ri);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute)return console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),void this.boundingBox.set(new M(-1/0,-1/0,-1/0),new M(1/0,1/0,1/0));if(e!==void 0){if(this.boundingBox.setFromBufferAttribute(e),t)for(let i=0,n=t.length;i<n;i++){let r=t[i];Ft.setFromBufferAttribute(r),this.morphTargetsRelative?(xt.addVectors(this.boundingBox.min,Ft.min),this.boundingBox.expandByPoint(xt),xt.addVectors(this.boundingBox.max,Ft.max),this.boundingBox.expandByPoint(xt)):(this.boundingBox.expandByPoint(Ft.min),this.boundingBox.expandByPoint(Ft.max))}}else this.boundingBox.makeEmpty();(isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&console.error('THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)}computeBoundingSphere(){this.boundingSphere===null&&(this.boundingSphere=new ai);let e=this.attributes.position,t=this.morphAttributes.position;if(e&&e.isGLBufferAttribute)return console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),void this.boundingSphere.set(new M,1/0);if(e){let i=this.boundingSphere.center;if(Ft.setFromBufferAttribute(e),t)for(let r=0,a=t.length;r<a;r++){let o=t[r];Es.setFromBufferAttribute(o),this.morphTargetsRelative?(xt.addVectors(Ft.min,Es.min),Ft.expandByPoint(xt),xt.addVectors(Ft.max,Es.max),Ft.expandByPoint(xt)):(Ft.expandByPoint(Es.min),Ft.expandByPoint(Es.max))}Ft.getCenter(i);let n=0;for(let r=0,a=e.count;r<a;r++)xt.fromBufferAttribute(e,r),n=Math.max(n,i.distanceToSquared(xt));if(t)for(let r=0,a=t.length;r<a;r++){let o=t[r],l=this.morphTargetsRelative;for(let c=0,h=o.count;c<h;c++)xt.fromBufferAttribute(o,c),l&&(In.fromBufferAttribute(e,c),xt.add(In)),n=Math.max(n,i.distanceToSquared(xt))}this.boundingSphere.radius=Math.sqrt(n),isNaN(this.boundingSphere.radius)&&console.error('THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)}}computeTangents(){let e=this.index,t=this.attributes;if(e===null||t.position===void 0||t.normal===void 0||t.uv===void 0)return void console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");let i=t.position,n=t.normal,r=t.uv;this.hasAttribute("tangent")===!1&&this.setAttribute("tangent",new We(new Float32Array(4*i.count),4));let a=this.getAttribute("tangent"),o=[],l=[];for(let P=0;P<i.count;P++)o[P]=new M,l[P]=new M;let c=new M,h=new M,d=new M,u=new oe,p=new oe,m=new oe,v=new M,f=new M;function g(P,C,B){c.fromBufferAttribute(i,P),h.fromBufferAttribute(i,C),d.fromBufferAttribute(i,B),u.fromBufferAttribute(r,P),p.fromBufferAttribute(r,C),m.fromBufferAttribute(r,B),h.sub(c),d.sub(c),p.sub(u),m.sub(u);let z=1/(p.x*m.y-m.x*p.y);isFinite(z)&&(v.copy(h).multiplyScalar(m.y).addScaledVector(d,-p.y).multiplyScalar(z),f.copy(d).multiplyScalar(p.x).addScaledVector(h,-m.x).multiplyScalar(z),o[P].add(v),o[C].add(v),o[B].add(v),l[P].add(f),l[C].add(f),l[B].add(f))}let y=this.groups;y.length===0&&(y=[{start:0,count:e.count}]);for(let P=0,C=y.length;P<C;++P){let B=y[P],z=B.start;for(let D=z,F=z+B.count;D<F;D+=3)g(e.getX(D+0),e.getX(D+1),e.getX(D+2))}let x=new M,_=new M,b=new M,S=new M;function R(P){b.fromBufferAttribute(n,P),S.copy(b);let C=o[P];x.copy(C),x.sub(b.multiplyScalar(b.dot(C))).normalize(),_.crossVectors(S,C);let B=_.dot(l[P])<0?-1:1;a.setXYZW(P,x.x,x.y,x.z,B)}for(let P=0,C=y.length;P<C;++P){let B=y[P],z=B.start;for(let D=z,F=z+B.count;D<F;D+=3)R(e.getX(D+0)),R(e.getX(D+1)),R(e.getX(D+2))}}computeVertexNormals(){let e=this.index,t=this.getAttribute("position");if(t!==void 0){let i=this.getAttribute("normal");if(i===void 0)i=new We(new Float32Array(3*t.count),3),this.setAttribute("normal",i);else for(let u=0,p=i.count;u<p;u++)i.setXYZ(u,0,0,0);let n=new M,r=new M,a=new M,o=new M,l=new M,c=new M,h=new M,d=new M;if(e)for(let u=0,p=e.count;u<p;u+=3){let m=e.getX(u+0),v=e.getX(u+1),f=e.getX(u+2);n.fromBufferAttribute(t,m),r.fromBufferAttribute(t,v),a.fromBufferAttribute(t,f),h.subVectors(a,r),d.subVectors(n,r),h.cross(d),o.fromBufferAttribute(i,m),l.fromBufferAttribute(i,v),c.fromBufferAttribute(i,f),o.add(h),l.add(h),c.add(h),i.setXYZ(m,o.x,o.y,o.z),i.setXYZ(v,l.x,l.y,l.z),i.setXYZ(f,c.x,c.y,c.z)}else for(let u=0,p=t.count;u<p;u+=3)n.fromBufferAttribute(t,u+0),r.fromBufferAttribute(t,u+1),a.fromBufferAttribute(t,u+2),h.subVectors(a,r),d.subVectors(n,r),h.cross(d),i.setXYZ(u+0,h.x,h.y,h.z),i.setXYZ(u+1,h.x,h.y,h.z),i.setXYZ(u+2,h.x,h.y,h.z);this.normalizeNormals(),i.needsUpdate=!0}}normalizeNormals(){let e=this.attributes.normal;for(let t=0,i=e.count;t<i;t++)xt.fromBufferAttribute(e,t),xt.normalize(),e.setXYZ(t,xt.x,xt.y,xt.z)}toNonIndexed(){function e(o,l){let c=o.array,h=o.itemSize,d=o.normalized,u=new c.constructor(l.length*h),p=0,m=0;for(let v=0,f=l.length;v<f;v++){p=o.isInterleavedBufferAttribute?l[v]*o.data.stride+o.offset:l[v]*h;for(let g=0;g<h;g++)u[m++]=c[p++]}return new We(u,h,d)}if(this.index===null)return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;let t=new s,i=this.index.array,n=this.attributes;for(let o in n){let l=e(n[o],i);t.setAttribute(o,l)}let r=this.morphAttributes;for(let o in r){let l=[],c=r[o];for(let h=0,d=c.length;h<d;h++){let u=e(c[h],i);l.push(u)}t.morphAttributes[o]=l}t.morphTargetsRelative=this.morphTargetsRelative;let a=this.groups;for(let o=0,l=a.length;o<l;o++){let c=a[o];t.addGroup(c.start,c.count,c.materialIndex)}return t}toJSON(){let e={metadata:{version:4.6,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};if(e.uuid=this.uuid,e.type=this.type,this.name!==""&&(e.name=this.name),Object.keys(this.userData).length>0&&(e.userData=this.userData),this.parameters!==void 0){let l=this.parameters;for(let c in l)l[c]!==void 0&&(e[c]=l[c]);return e}e.data={attributes:{}};let t=this.index;t!==null&&(e.data.index={type:t.array.constructor.name,array:Array.prototype.slice.call(t.array)});let i=this.attributes;for(let l in i){let c=i[l];e.data.attributes[l]=c.toJSON(e.data)}let n={},r=!1;for(let l in this.morphAttributes){let c=this.morphAttributes[l],h=[];for(let d=0,u=c.length;d<u;d++){let p=c[d];h.push(p.toJSON(e.data))}h.length>0&&(n[l]=h,r=!0)}r&&(e.data.morphAttributes=n,e.data.morphTargetsRelative=this.morphTargetsRelative);let a=this.groups;a.length>0&&(e.data.groups=JSON.parse(JSON.stringify(a)));let o=this.boundingSphere;return o!==null&&(e.data.boundingSphere={center:o.center.toArray(),radius:o.radius}),e}clone(){return new this.constructor().copy(this)}copy(e){this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;let t={};this.name=e.name;let i=e.index;i!==null&&this.setIndex(i.clone(t));let n=e.attributes;for(let c in n){let h=n[c];this.setAttribute(c,h.clone(t))}let r=e.morphAttributes;for(let c in r){let h=[],d=r[c];for(let u=0,p=d.length;u<p;u++)h.push(d[u].clone(t));this.morphAttributes[c]=h}this.morphTargetsRelative=e.morphTargetsRelative;let a=e.groups;for(let c=0,h=a.length;c<h;c++){let d=a[c];this.addGroup(d.start,d.count,d.materialIndex)}let o=e.boundingBox;o!==null&&(this.boundingBox=o.clone());let l=e.boundingSphere;return l!==null&&(this.boundingSphere=l.clone()),this.drawRange.start=e.drawRange.start,this.drawRange.count=e.drawRange.count,this.userData=e.userData,this}dispose(){this.dispatchEvent({type:"dispose"})}},Gh=new Ee,nn=new Zn,Lr=new ai,Wh=new M,Pr=new M,Ir=new M,Dr=new M,Wo=new M,Ur=new M,Xh=new M,Nr=new M,Ce=class extends at{constructor(e=new Ve,t=new oi){super(),this.isMesh=!0,this.type="Mesh",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),e.morphTargetInfluences!==void 0&&(this.morphTargetInfluences=e.morphTargetInfluences.slice()),e.morphTargetDictionary!==void 0&&(this.morphTargetDictionary=Object.assign({},e.morphTargetDictionary)),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let i=e[t[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let n=0,r=i.length;n<r;n++){let a=i[n].name||String(n);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=n}}}}getVertexPosition(e,t){let i=this.geometry,n=i.attributes.position,r=i.morphAttributes.position,a=i.morphTargetsRelative;t.fromBufferAttribute(n,e);let o=this.morphTargetInfluences;if(r&&o){Ur.set(0,0,0);for(let l=0,c=r.length;l<c;l++){let h=o[l],d=r[l];h!==0&&(Wo.fromBufferAttribute(d,e),a?Ur.addScaledVector(Wo,h):Ur.addScaledVector(Wo.sub(t),h))}t.add(Ur)}return t}raycast(e,t){let i=this.geometry,n=this.material,r=this.matrixWorld;if(n!==void 0){if(i.boundingSphere===null&&i.computeBoundingSphere(),Lr.copy(i.boundingSphere),Lr.applyMatrix4(r),nn.copy(e.ray).recast(e.near),Lr.containsPoint(nn.origin)===!1&&(nn.intersectSphere(Lr,Wh)===null||nn.origin.distanceToSquared(Wh)>(e.far-e.near)**2))return;Gh.copy(r).invert(),nn.copy(e.ray).applyMatrix4(Gh),i.boundingBox!==null&&nn.intersectsBox(i.boundingBox)===!1||this._computeIntersections(e,t,nn)}}_computeIntersections(e,t,i){let n,r=this.geometry,a=this.material,o=r.index,l=r.attributes.position,c=r.attributes.uv,h=r.attributes.uv1,d=r.attributes.normal,u=r.groups,p=r.drawRange;if(o!==null)if(Array.isArray(a))for(let m=0,v=u.length;m<v;m++){let f=u[m],g=a[f.materialIndex];for(let y=Math.max(f.start,p.start),x=Math.min(o.count,Math.min(f.start+f.count,p.start+p.count));y<x;y+=3)n=Or(this,g,e,i,c,h,d,o.getX(y),o.getX(y+1),o.getX(y+2)),n&&(n.faceIndex=Math.floor(y/3),n.face.materialIndex=f.materialIndex,t.push(n))}else for(let m=Math.max(0,p.start),v=Math.min(o.count,p.start+p.count);m<v;m+=3)n=Or(this,a,e,i,c,h,d,o.getX(m),o.getX(m+1),o.getX(m+2)),n&&(n.faceIndex=Math.floor(m/3),t.push(n));else if(l!==void 0)if(Array.isArray(a))for(let m=0,v=u.length;m<v;m++){let f=u[m],g=a[f.materialIndex];for(let y=Math.max(f.start,p.start),x=Math.min(l.count,Math.min(f.start+f.count,p.start+p.count));y<x;y+=3)n=Or(this,g,e,i,c,h,d,y,y+1,y+2),n&&(n.faceIndex=Math.floor(y/3),n.face.materialIndex=f.materialIndex,t.push(n))}else for(let m=Math.max(0,p.start),v=Math.min(l.count,p.start+p.count);m<v;m+=3)n=Or(this,a,e,i,c,h,d,m,m+1,m+2),n&&(n.faceIndex=Math.floor(m/3),t.push(n))}};function Or(s,e,t,i,n,r,a,o,l,c){s.getVertexPosition(o,Pr),s.getVertexPosition(l,Ir),s.getVertexPosition(c,Dr);let h=function(d,u,p,m,v,f,g,y){let x;if(x=u.side===1?m.intersectTriangle(g,f,v,!0,y):m.intersectTriangle(v,f,g,u.side===0,y),x===null)return null;Nr.copy(y),Nr.applyMatrix4(d.matrixWorld);let _=p.ray.origin.distanceTo(Nr);return _<p.near||_>p.far?null:{distance:_,point:Nr.clone(),object:d}}(s,e,t,i,Pr,Ir,Dr,Xh);if(h){let d=new M;Ei.getBarycoord(Xh,Pr,Ir,Dr,d),n&&(h.uv=Ei.getInterpolatedAttribute(n,o,l,c,d,new oe)),r&&(h.uv1=Ei.getInterpolatedAttribute(r,o,l,c,d,new oe)),a&&(h.normal=Ei.getInterpolatedAttribute(a,o,l,c,d,new M),h.normal.dot(i.direction)>0&&h.normal.multiplyScalar(-1));let u={a:o,b:l,c,normal:new M,materialIndex:0};Ei.getNormal(Pr,Ir,Dr,u.normal),h.face=u,h.barycoord=d}return h}var Ct=class s extends Ve{constructor(e=1,t=1,i=1,n=1,r=1,a=1){super(),this.type="BoxGeometry",this.parameters={width:e,height:t,depth:i,widthSegments:n,heightSegments:r,depthSegments:a};let o=this;n=Math.floor(n),r=Math.floor(r),a=Math.floor(a);let l=[],c=[],h=[],d=[],u=0,p=0;function m(v,f,g,y,x,_,b,S,R,P,C){let B=_/R,z=b/P,D=_/2,F=b/2,U=S/2,X=R+1,j=P+1,Z=0,$=0,ue=new M;for(let _e=0;_e<j;_e++){let K=_e*z-F;for(let ae=0;ae<X;ae++){let pe=ae*B-D;ue[v]=pe*y,ue[f]=K*x,ue[g]=U,c.push(ue.x,ue.y,ue.z),ue[v]=0,ue[f]=0,ue[g]=S>0?1:-1,h.push(ue.x,ue.y,ue.z),d.push(ae/R),d.push(1-_e/P),Z+=1}}for(let _e=0;_e<P;_e++)for(let K=0;K<R;K++){let ae=u+K+X*_e,pe=u+K+X*(_e+1),ge=u+(K+1)+X*(_e+1),ce=u+(K+1)+X*_e;l.push(ae,pe,ce),l.push(pe,ge,ce),$+=6}o.addGroup(p,$,C),p+=$,u+=Z}m("z","y","x",-1,-1,i,t,e,a,r,0),m("z","y","x",1,-1,i,t,-e,a,r,1),m("x","z","y",1,1,e,i,t,n,a,2),m("x","z","y",1,-1,e,i,-t,n,a,3),m("x","y","z",1,-1,e,t,i,n,r,4),m("x","y","z",-1,-1,e,t,-i,n,r,5),this.setIndex(l),this.setAttribute("position",new Te(c,3)),this.setAttribute("normal",new Te(h,3)),this.setAttribute("uv",new Te(d,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new s(e.width,e.height,e.depth,e.widthSegments,e.heightSegments,e.depthSegments)}};function Jn(s){let e={};for(let t in s){e[t]={};for(let i in s[t]){let n=s[t][i];n&&(n.isColor||n.isMatrix3||n.isMatrix4||n.isVector2||n.isVector3||n.isVector4||n.isTexture||n.isQuaternion)?n.isRenderTargetTexture?(console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[t][i]=null):e[t][i]=n.clone():Array.isArray(n)?e[t][i]=n.slice():e[t][i]=n}}return e}function Dt(s){let e={};for(let t=0;t<s.length;t++){let i=Jn(s[t]);for(let n in i)e[n]=i[n]}return e}function Zu(s){let e=s.getRenderTarget();return e===null?s.outputColorSpace:e.isXRRenderTarget===!0?e.texture.colorSpace:je.workingColorSpace}var Gc={clone:Jn,merge:Dt},Tt=class extends gi{static get type(){return"ShaderMaterial"}constructor(e){super(),this.isShaderMaterial=!0,this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader=`void main() {
	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
}`,this.fragmentShader=`void main() {
	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );
}`,this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,e!==void 0&&this.setValues(e)}copy(e){return super.copy(e),this.fragmentShader=e.fragmentShader,this.vertexShader=e.vertexShader,this.uniforms=Jn(e.uniforms),this.uniformsGroups=function(t){let i=[];for(let n=0;n<t.length;n++)i.push(t[n].clone());return i}(e.uniformsGroups),this.defines=Object.assign({},e.defines),this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.fog=e.fog,this.lights=e.lights,this.clipping=e.clipping,this.extensions=Object.assign({},e.extensions),this.glslVersion=e.glslVersion,this}toJSON(e){let t=super.toJSON(e);t.glslVersion=this.glslVersion,t.uniforms={};for(let n in this.uniforms){let r=this.uniforms[n].value;r&&r.isTexture?t.uniforms[n]={type:"t",value:r.toJSON(e).uuid}:r&&r.isColor?t.uniforms[n]={type:"c",value:r.getHex()}:r&&r.isVector2?t.uniforms[n]={type:"v2",value:r.toArray()}:r&&r.isVector3?t.uniforms[n]={type:"v3",value:r.toArray()}:r&&r.isVector4?t.uniforms[n]={type:"v4",value:r.toArray()}:r&&r.isMatrix3?t.uniforms[n]={type:"m3",value:r.toArray()}:r&&r.isMatrix4?t.uniforms[n]={type:"m4",value:r.toArray()}:t.uniforms[n]={value:r}}Object.keys(this.defines).length>0&&(t.defines=this.defines),t.vertexShader=this.vertexShader,t.fragmentShader=this.fragmentShader,t.lights=this.lights,t.clipping=this.clipping;let i={};for(let n in this.extensions)this.extensions[n]===!0&&(i[n]=!0);return Object.keys(i).length>0&&(t.extensions=i),t}},Ws=class extends at{constructor(){super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new Ee,this.projectionMatrix=new Ee,this.projectionMatrixInverse=new Ee,this.coordinateSystem=$n}copy(e,t){return super.copy(e,t),this.matrixWorldInverse.copy(e.matrixWorldInverse),this.projectionMatrix.copy(e.projectionMatrix),this.projectionMatrixInverse.copy(e.projectionMatrixInverse),this.coordinateSystem=e.coordinateSystem,this}getWorldDirection(e){return super.getWorldDirection(e).negate()}updateMatrixWorld(e){super.updateMatrixWorld(e),this.matrixWorldInverse.copy(this.matrixWorld).invert()}updateWorldMatrix(e,t){super.updateWorldMatrix(e,t),this.matrixWorldInverse.copy(this.matrixWorld).invert()}clone(){return new this.constructor().copy(this)}},Fi=new M,qh=new oe,jh=new oe,Ut=class extends Ws{constructor(e=50,t=1,i=.1,n=2e3){super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=e,this.zoom=1,this.near=i,this.far=n,this.focus=10,this.aspect=t,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.fov=e.fov,this.zoom=e.zoom,this.near=e.near,this.far=e.far,this.focus=e.focus,this.aspect=e.aspect,this.view=e.view===null?null:Object.assign({},e.view),this.filmGauge=e.filmGauge,this.filmOffset=e.filmOffset,this}setFocalLength(e){let t=.5*this.getFilmHeight()/e;this.fov=2*Gs*Math.atan(t),this.updateProjectionMatrix()}getFocalLength(){let e=Math.tan(.5*Vn*this.fov);return .5*this.getFilmHeight()/e}getEffectiveFOV(){return 2*Gs*Math.atan(Math.tan(.5*Vn*this.fov)/this.zoom)}getFilmWidth(){return this.filmGauge*Math.min(this.aspect,1)}getFilmHeight(){return this.filmGauge/Math.max(this.aspect,1)}getViewBounds(e,t,i){Fi.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),t.set(Fi.x,Fi.y).multiplyScalar(-e/Fi.z),Fi.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(Fi.x,Fi.y).multiplyScalar(-e/Fi.z)}getViewSize(e,t){return this.getViewBounds(e,qh,jh),t.subVectors(jh,qh)}setViewOffset(e,t,i,n,r,a){this.aspect=e/t,this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=n,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=this.near,t=e*Math.tan(.5*Vn*this.fov)/this.zoom,i=2*t,n=this.aspect*i,r=-.5*n,a=this.view;if(this.view!==null&&this.view.enabled){let l=a.fullWidth,c=a.fullHeight;r+=a.offsetX*n/l,t-=a.offsetY*i/c,n*=a.width/l,i*=a.height/c}let o=this.filmOffset;o!==0&&(r+=e*o/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+n,t,t-i,e,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.fov=this.fov,t.object.zoom=this.zoom,t.object.near=this.near,t.object.far=this.far,t.object.focus=this.focus,t.object.aspect=this.aspect,this.view!==null&&(t.object.view=Object.assign({},this.view)),t.object.filmGauge=this.filmGauge,t.object.filmOffset=this.filmOffset,t}},Dn=-90,Wl=class extends at{constructor(e,t,i){super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;let n=new Ut(Dn,1,e,t);n.layers=this.layers,this.add(n);let r=new Ut(Dn,1,e,t);r.layers=this.layers,this.add(r);let a=new Ut(Dn,1,e,t);a.layers=this.layers,this.add(a);let o=new Ut(Dn,1,e,t);o.layers=this.layers,this.add(o);let l=new Ut(Dn,1,e,t);l.layers=this.layers,this.add(l);let c=new Ut(Dn,1,e,t);c.layers=this.layers,this.add(c)}updateCoordinateSystem(){let e=this.coordinateSystem,t=this.children.concat(),[i,n,r,a,o,l]=t;for(let c of t)this.remove(c);if(e===$n)i.up.set(0,1,0),i.lookAt(1,0,0),n.up.set(0,1,0),n.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),a.up.set(0,0,1),a.lookAt(0,-1,0),o.up.set(0,1,0),o.lookAt(0,0,1),l.up.set(0,1,0),l.lookAt(0,0,-1);else{if(e!==la)throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+e);i.up.set(0,-1,0),i.lookAt(-1,0,0),n.up.set(0,-1,0),n.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),a.up.set(0,0,-1),a.lookAt(0,-1,0),o.up.set(0,-1,0),o.lookAt(0,0,1),l.up.set(0,-1,0),l.lookAt(0,0,-1)}for(let c of t)this.add(c),c.updateMatrixWorld()}update(e,t){this.parent===null&&this.updateMatrixWorld();let{renderTarget:i,activeMipmapLevel:n}=this;this.coordinateSystem!==e.coordinateSystem&&(this.coordinateSystem=e.coordinateSystem,this.updateCoordinateSystem());let[r,a,o,l,c,h]=this.children,d=e.getRenderTarget(),u=e.getActiveCubeFace(),p=e.getActiveMipmapLevel(),m=e.xr.enabled;e.xr.enabled=!1;let v=i.texture.generateMipmaps;i.texture.generateMipmaps=!1,e.setRenderTarget(i,0,n),e.render(t,r),e.setRenderTarget(i,1,n),e.render(t,a),e.setRenderTarget(i,2,n),e.render(t,o),e.setRenderTarget(i,3,n),e.render(t,l),e.setRenderTarget(i,4,n),e.render(t,c),i.texture.generateMipmaps=v,e.setRenderTarget(i,5,n),e.render(t,h),e.setRenderTarget(d,u,p),e.xr.enabled=m,i.texture.needsPMREMUpdate=!0}},fa=class extends Nt{constructor(e,t,i,n,r,a,o,l,c,h){super(e=e!==void 0?e:[],t=t!==void 0?t:Xn,i,n,r,a,o,l,c,h),this.isCubeTexture=!0,this.flipY=!1}get images(){return this.image}set images(e){this.image=e}},Xl=class extends si{constructor(e=1,t={}){super(e,e,t),this.isWebGLCubeRenderTarget=!0;let i={width:e,height:e,depth:1},n=[i,i,i,i,i,i];this.texture=new fa(n,t.mapping,t.wrapS,t.wrapT,t.magFilter,t.minFilter,t.format,t.type,t.anisotropy,t.colorSpace),this.texture.isRenderTargetTexture=!0,this.texture.generateMipmaps=t.generateMipmaps!==void 0&&t.generateMipmaps,this.texture.minFilter=t.minFilter!==void 0?t.minFilter:Ti}fromEquirectangularTexture(e,t){this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;let i={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},n=new Ct(5,5,5),r=new Tt({name:"CubemapFromEquirect",uniforms:Jn(i.uniforms),vertexShader:i.vertexShader,fragmentShader:i.fragmentShader,side:1,blending:0});r.uniforms.tEquirect.value=t;let a=new Ce(n,r),o=t.minFilter;return t.minFilter===Bn&&(t.minFilter=Ti),new Wl(1,10,this).update(e,a),t.minFilter=o,a.geometry.dispose(),a.material.dispose(),this}clear(e,t,i,n){let r=e.getRenderTarget();for(let a=0;a<6;a++)e.setRenderTarget(this,a),e.clear(t,i,n);e.setRenderTarget(r)}},Xo=new M,up=new M,dp=new De,wi=class{constructor(e=new M(1,0,0),t=0){this.isPlane=!0,this.normal=e,this.constant=t}set(e,t){return this.normal.copy(e),this.constant=t,this}setComponents(e,t,i,n){return this.normal.set(e,t,i),this.constant=n,this}setFromNormalAndCoplanarPoint(e,t){return this.normal.copy(e),this.constant=-t.dot(this.normal),this}setFromCoplanarPoints(e,t,i){let n=Xo.subVectors(i,t).cross(up.subVectors(e,t)).normalize();return this.setFromNormalAndCoplanarPoint(n,e),this}copy(e){return this.normal.copy(e.normal),this.constant=e.constant,this}normalize(){let e=1/this.normal.length();return this.normal.multiplyScalar(e),this.constant*=e,this}negate(){return this.constant*=-1,this.normal.negate(),this}distanceToPoint(e){return this.normal.dot(e)+this.constant}distanceToSphere(e){return this.distanceToPoint(e.center)-e.radius}projectPoint(e,t){return t.copy(e).addScaledVector(this.normal,-this.distanceToPoint(e))}intersectLine(e,t){let i=e.delta(Xo),n=this.normal.dot(i);if(n===0)return this.distanceToPoint(e.start)===0?t.copy(e.start):null;let r=-(e.start.dot(this.normal)+this.constant)/n;return r<0||r>1?null:t.copy(e.start).addScaledVector(i,r)}intersectsLine(e){let t=this.distanceToPoint(e.start),i=this.distanceToPoint(e.end);return t<0&&i>0||i<0&&t>0}intersectsBox(e){return e.intersectsPlane(this)}intersectsSphere(e){return e.intersectsPlane(this)}coplanarPoint(e){return e.copy(this.normal).multiplyScalar(-this.constant)}applyMatrix4(e,t){let i=t||dp.getNormalMatrix(e),n=this.coplanarPoint(Xo).applyMatrix4(e),r=this.normal.applyMatrix3(i).normalize();return this.constant=-n.dot(r),this}translate(e){return this.constant-=e.dot(this.normal),this}equals(e){return e.normal.equals(this.normal)&&e.constant===this.constant}clone(){return new this.constructor().copy(this)}},sn=new ai,zr=new M,Kn=class{constructor(e=new wi,t=new wi,i=new wi,n=new wi,r=new wi,a=new wi){this.planes=[e,t,i,n,r,a]}set(e,t,i,n,r,a){let o=this.planes;return o[0].copy(e),o[1].copy(t),o[2].copy(i),o[3].copy(n),o[4].copy(r),o[5].copy(a),this}copy(e){let t=this.planes;for(let i=0;i<6;i++)t[i].copy(e.planes[i]);return this}setFromProjectionMatrix(e,t=2e3){let i=this.planes,n=e.elements,r=n[0],a=n[1],o=n[2],l=n[3],c=n[4],h=n[5],d=n[6],u=n[7],p=n[8],m=n[9],v=n[10],f=n[11],g=n[12],y=n[13],x=n[14],_=n[15];if(i[0].setComponents(l-r,u-c,f-p,_-g).normalize(),i[1].setComponents(l+r,u+c,f+p,_+g).normalize(),i[2].setComponents(l+a,u+h,f+m,_+y).normalize(),i[3].setComponents(l-a,u-h,f-m,_-y).normalize(),i[4].setComponents(l-o,u-d,f-v,_-x).normalize(),t===$n)i[5].setComponents(l+o,u+d,f+v,_+x).normalize();else{if(t!==la)throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+t);i[5].setComponents(o,d,v,x).normalize()}return this}intersectsObject(e){if(e.boundingSphere!==void 0)e.boundingSphere===null&&e.computeBoundingSphere(),sn.copy(e.boundingSphere).applyMatrix4(e.matrixWorld);else{let t=e.geometry;t.boundingSphere===null&&t.computeBoundingSphere(),sn.copy(t.boundingSphere).applyMatrix4(e.matrixWorld)}return this.intersectsSphere(sn)}intersectsSprite(e){return sn.center.set(0,0,0),sn.radius=.7071067811865476,sn.applyMatrix4(e.matrixWorld),this.intersectsSphere(sn)}intersectsSphere(e){let t=this.planes,i=e.center,n=-e.radius;for(let r=0;r<6;r++)if(t[r].distanceToPoint(i)<n)return!1;return!0}intersectsBox(e){let t=this.planes;for(let i=0;i<6;i++){let n=t[i];if(zr.x=n.normal.x>0?e.max.x:e.min.x,zr.y=n.normal.y>0?e.max.y:e.min.y,zr.z=n.normal.z>0?e.max.z:e.min.z,n.distanceToPoint(zr)<0)return!1}return!0}containsPoint(e){let t=this.planes;for(let i=0;i<6;i++)if(t[i].distanceToPoint(e)<0)return!1;return!0}clone(){return new this.constructor().copy(this)}};function Ju(){let s=null,e=!1,t=null,i=null;function n(r,a){t(r,a),i=s.requestAnimationFrame(n)}return{start:function(){e!==!0&&t!==null&&(i=s.requestAnimationFrame(n),e=!0)},stop:function(){s.cancelAnimationFrame(i),e=!1},setAnimationLoop:function(r){t=r},setContext:function(r){s=r}}}function pp(s){let e=new WeakMap;return{get:function(t){return t.isInterleavedBufferAttribute&&(t=t.data),e.get(t)},remove:function(t){t.isInterleavedBufferAttribute&&(t=t.data);let i=e.get(t);i&&(s.deleteBuffer(i.buffer),e.delete(t))},update:function(t,i){if(t.isInterleavedBufferAttribute&&(t=t.data),t.isGLBufferAttribute){let r=e.get(t);return void((!r||r.version<t.version)&&e.set(t,{buffer:t.buffer,type:t.type,bytesPerElement:t.elementSize,version:t.version}))}let n=e.get(t);if(n===void 0)e.set(t,function(r,a){let o=r.array,l=r.usage,c=o.byteLength,h=s.createBuffer(),d;if(s.bindBuffer(a,h),s.bufferData(a,o,l),r.onUploadCallback(),o instanceof Float32Array)d=s.FLOAT;else if(o instanceof Uint16Array)d=r.isFloat16BufferAttribute?s.HALF_FLOAT:s.UNSIGNED_SHORT;else if(o instanceof Int16Array)d=s.SHORT;else if(o instanceof Uint32Array)d=s.UNSIGNED_INT;else if(o instanceof Int32Array)d=s.INT;else if(o instanceof Int8Array)d=s.BYTE;else if(o instanceof Uint8Array)d=s.UNSIGNED_BYTE;else{if(!(o instanceof Uint8ClampedArray))throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: "+o);d=s.UNSIGNED_BYTE}return{buffer:h,type:d,bytesPerElement:o.BYTES_PER_ELEMENT,version:r.version,size:c}}(t,i));else if(n.version<t.version){if(n.size!==t.array.byteLength)throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");(function(r,a,o){let l=a.array,c=a.updateRanges;if(s.bindBuffer(o,r),c.length===0)s.bufferSubData(o,0,l);else{c.sort((d,u)=>d.start-u.start);let h=0;for(let d=1;d<c.length;d++){let u=c[h],p=c[d];p.start<=u.start+u.count+1?u.count=Math.max(u.count,p.start+p.count-u.start):(++h,c[h]=p)}c.length=h+1;for(let d=0,u=c.length;d<u;d++){let p=c[d];s.bufferSubData(o,p.start*l.BYTES_PER_ELEMENT,l,p.start,p.count)}a.clearUpdateRanges()}a.onUploadCallback()})(n.buffer,t,i),n.version=t.version}}}}var Gt=class s extends Ve{constructor(e=1,t=1,i=1,n=1){super(),this.type="PlaneGeometry",this.parameters={width:e,height:t,widthSegments:i,heightSegments:n};let r=e/2,a=t/2,o=Math.floor(i),l=Math.floor(n),c=o+1,h=l+1,d=e/o,u=t/l,p=[],m=[],v=[],f=[];for(let g=0;g<h;g++){let y=g*u-a;for(let x=0;x<c;x++){let _=x*d-r;m.push(_,-y,0),v.push(0,0,1),f.push(x/o),f.push(1-g/l)}}for(let g=0;g<l;g++)for(let y=0;y<o;y++){let x=y+c*g,_=y+c*(g+1),b=y+1+c*(g+1),S=y+1+c*g;p.push(x,_,S),p.push(_,b,S)}this.setIndex(p),this.setAttribute("position",new Te(m,3)),this.setAttribute("normal",new Te(v,3)),this.setAttribute("uv",new Te(f,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new s(e.width,e.height,e.widthSegments,e.heightSegments)}},Ne={alphahash_fragment:`#ifdef USE_ALPHAHASH
	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;
#endif`,alphahash_pars_fragment:`#ifdef USE_ALPHAHASH
	const float ALPHA_HASH_SCALE = 0.05;
	float hash2D( vec2 value ) {
		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );
	}
	float hash3D( vec3 value ) {
		return hash2D( vec2( hash2D( value.xy ), value.z ) );
	}
	float getAlphaHashThreshold( vec3 position ) {
		float maxDeriv = max(
			length( dFdx( position.xyz ) ),
			length( dFdy( position.xyz ) )
		);
		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );
		vec2 pixScales = vec2(
			exp2( floor( log2( pixScale ) ) ),
			exp2( ceil( log2( pixScale ) ) )
		);
		vec2 alpha = vec2(
			hash3D( floor( pixScales.x * position.xyz ) ),
			hash3D( floor( pixScales.y * position.xyz ) )
		);
		float lerpFactor = fract( log2( pixScale ) );
		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;
		float a = min( lerpFactor, 1.0 - lerpFactor );
		vec3 cases = vec3(
			x * x / ( 2.0 * a * ( 1.0 - a ) ),
			( x - 0.5 * a ) / ( 1.0 - a ),
			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )
		);
		float threshold = ( x < ( 1.0 - a ) )
			? ( ( x < a ) ? cases.x : cases.y )
			: cases.z;
		return clamp( threshold , 1.0e-6, 1.0 );
	}
#endif`,alphamap_fragment:`#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;
#endif`,alphamap_pars_fragment:`#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,alphatest_fragment:`#ifdef USE_ALPHATEST
	#ifdef ALPHA_TO_COVERAGE
	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );
	if ( diffuseColor.a == 0.0 ) discard;
	#else
	if ( diffuseColor.a < alphaTest ) discard;
	#endif
#endif`,alphatest_pars_fragment:`#ifdef USE_ALPHATEST
	uniform float alphaTest;
#endif`,aomap_fragment:`#ifdef USE_AOMAP
	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;
	reflectedLight.indirectDiffuse *= ambientOcclusion;
	#if defined( USE_CLEARCOAT ) 
		clearcoatSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_SHEEN ) 
		sheenSpecularIndirect *= ambientOcclusion;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD )
		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );
		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );
	#endif
#endif`,aomap_pars_fragment:`#ifdef USE_AOMAP
	uniform sampler2D aoMap;
	uniform float aoMapIntensity;
#endif`,batching_pars_vertex:`#ifdef USE_BATCHING
	#if ! defined( GL_ANGLE_multi_draw )
	#define gl_DrawID _gl_DrawID
	uniform int _gl_DrawID;
	#endif
	uniform highp sampler2D batchingTexture;
	uniform highp usampler2D batchingIdTexture;
	mat4 getBatchingMatrix( const in float i ) {
		int size = textureSize( batchingTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
	float getIndirectIndex( const in int i ) {
		int size = textureSize( batchingIdTexture, 0 ).x;
		int x = i % size;
		int y = i / size;
		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );
	}
#endif
#ifdef USE_BATCHING_COLOR
	uniform sampler2D batchingColorTexture;
	vec3 getBatchingColor( const in float i ) {
		int size = textureSize( batchingColorTexture, 0 ).x;
		int j = int( i );
		int x = j % size;
		int y = j / size;
		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;
	}
#endif`,batching_vertex:`#ifdef USE_BATCHING
	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );
#endif`,begin_vertex:`vec3 transformed = vec3( position );
#ifdef USE_ALPHAHASH
	vPosition = vec3( position );
#endif`,beginnormal_vertex:`vec3 objectNormal = vec3( normal );
#ifdef USE_TANGENT
	vec3 objectTangent = vec3( tangent.xyz );
#endif`,bsdfs:`float G_BlinnPhong_Implicit( ) {
	return 0.25;
}
float D_BlinnPhong( const in float shininess, const in float dotNH ) {
	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );
}
vec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( specularColor, 1.0, dotVH );
	float G = G_BlinnPhong_Implicit( );
	float D = D_BlinnPhong( shininess, dotNH );
	return F * ( G * D );
} // validated`,iridescence_fragment:`#ifdef USE_IRIDESCENCE
	const mat3 XYZ_TO_REC709 = mat3(
		 3.2404542, -0.9692660,  0.0556434,
		-1.5371385,  1.8760108, -0.2040259,
		-0.4985314,  0.0415560,  1.0572252
	);
	vec3 Fresnel0ToIor( vec3 fresnel0 ) {
		vec3 sqrtF0 = sqrt( fresnel0 );
		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );
	}
	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );
	}
	float IorToFresnel0( float transmittedIor, float incidentIor ) {
		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));
	}
	vec3 evalSensitivity( float OPD, vec3 shift ) {
		float phase = 2.0 * PI * OPD * 1.0e-9;
		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );
		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );
		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );
		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );
		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );
		xyz /= 1.0685e-7;
		vec3 rgb = XYZ_TO_REC709 * xyz;
		return rgb;
	}
	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {
		vec3 I;
		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );
		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );
		float cosTheta2Sq = 1.0 - sinTheta2Sq;
		if ( cosTheta2Sq < 0.0 ) {
			return vec3( 1.0 );
		}
		float cosTheta2 = sqrt( cosTheta2Sq );
		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );
		float R12 = F_Schlick( R0, 1.0, cosTheta1 );
		float T121 = 1.0 - R12;
		float phi12 = 0.0;
		if ( iridescenceIOR < outsideIOR ) phi12 = PI;
		float phi21 = PI - phi12;
		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );
		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );
		vec3 phi23 = vec3( 0.0 );
		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;
		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;
		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;
		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;
		vec3 phi = vec3( phi21 ) + phi23;
		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );
		vec3 r123 = sqrt( R123 );
		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );
		vec3 C0 = R12 + Rs;
		I = C0;
		vec3 Cm = Rs - T121;
		for ( int m = 1; m <= 2; ++ m ) {
			Cm *= r123;
			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );
			I += Cm * Sm;
		}
		return max( I, vec3( 0.0 ) );
	}
#endif`,bumpmap_pars_fragment:`#ifdef USE_BUMPMAP
	uniform sampler2D bumpMap;
	uniform float bumpScale;
	vec2 dHdxy_fwd() {
		vec2 dSTdx = dFdx( vBumpMapUv );
		vec2 dSTdy = dFdy( vBumpMapUv );
		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;
		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;
		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;
		return vec2( dBx, dBy );
	}
	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {
		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );
		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );
		vec3 vN = surf_norm;
		vec3 R1 = cross( vSigmaY, vN );
		vec3 R2 = cross( vN, vSigmaX );
		float fDet = dot( vSigmaX, R1 ) * faceDirection;
		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );
		return normalize( abs( fDet ) * surf_norm - vGrad );
	}
#endif`,clipping_planes_fragment:`#if NUM_CLIPPING_PLANES > 0
	vec4 plane;
	#ifdef ALPHA_TO_COVERAGE
		float distanceToPlane, distanceGradient;
		float clipOpacity = 1.0;
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
			distanceGradient = fwidth( distanceToPlane ) / 2.0;
			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			if ( clipOpacity == 0.0 ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			float unionClipOpacity = 1.0;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;
				distanceGradient = fwidth( distanceToPlane ) / 2.0;
				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );
			}
			#pragma unroll_loop_end
			clipOpacity *= 1.0 - unionClipOpacity;
		#endif
		diffuseColor.a *= clipOpacity;
		if ( diffuseColor.a == 0.0 ) discard;
	#else
		#pragma unroll_loop_start
		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {
			plane = clippingPlanes[ i ];
			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;
		}
		#pragma unroll_loop_end
		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES
			bool clipped = true;
			#pragma unroll_loop_start
			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {
				plane = clippingPlanes[ i ];
				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;
			}
			#pragma unroll_loop_end
			if ( clipped ) discard;
		#endif
	#endif
#endif`,clipping_planes_pars_fragment:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];
#endif`,clipping_planes_pars_vertex:`#if NUM_CLIPPING_PLANES > 0
	varying vec3 vClipPosition;
#endif`,clipping_planes_vertex:`#if NUM_CLIPPING_PLANES > 0
	vClipPosition = - mvPosition.xyz;
#endif`,color_fragment:`#if defined( USE_COLOR_ALPHA )
	diffuseColor *= vColor;
#elif defined( USE_COLOR )
	diffuseColor.rgb *= vColor;
#endif`,color_pars_fragment:`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR )
	varying vec3 vColor;
#endif`,color_pars_vertex:`#if defined( USE_COLOR_ALPHA )
	varying vec4 vColor;
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	varying vec3 vColor;
#endif`,color_vertex:`#if defined( USE_COLOR_ALPHA )
	vColor = vec4( 1.0 );
#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
	vColor = vec3( 1.0 );
#endif
#ifdef USE_COLOR
	vColor *= color;
#endif
#ifdef USE_INSTANCING_COLOR
	vColor.xyz *= instanceColor.xyz;
#endif
#ifdef USE_BATCHING_COLOR
	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );
	vColor.xyz *= batchingColor.xyz;
#endif`,common:`#define PI 3.141592653589793
#define PI2 6.283185307179586
#define PI_HALF 1.5707963267948966
#define RECIPROCAL_PI 0.3183098861837907
#define RECIPROCAL_PI2 0.15915494309189535
#define EPSILON 1e-6
#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
#define whiteComplement( a ) ( 1.0 - saturate( a ) )
float pow2( const in float x ) { return x*x; }
vec3 pow2( const in vec3 x ) { return x*x; }
float pow3( const in float x ) { return x*x*x; }
float pow4( const in float x ) { float x2 = x*x; return x2*x2; }
float max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }
float average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }
highp float rand( const in vec2 uv ) {
	const highp float a = 12.9898, b = 78.233, c = 43758.5453;
	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );
	return fract( sin( sn ) * c );
}
#ifdef HIGH_PRECISION
	float precisionSafeLength( vec3 v ) { return length( v ); }
#else
	float precisionSafeLength( vec3 v ) {
		float maxComponent = max3( abs( v ) );
		return length( v / maxComponent ) * maxComponent;
	}
#endif
struct IncidentLight {
	vec3 color;
	vec3 direction;
	bool visible;
};
struct ReflectedLight {
	vec3 directDiffuse;
	vec3 directSpecular;
	vec3 indirectDiffuse;
	vec3 indirectSpecular;
};
#ifdef USE_ALPHAHASH
	varying vec3 vPosition;
#endif
vec3 transformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );
}
vec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {
	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );
}
mat3 transposeMat3( const in mat3 m ) {
	mat3 tmp;
	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );
	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );
	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );
	return tmp;
}
bool isPerspectiveMatrix( mat4 m ) {
	return m[ 2 ][ 3 ] == - 1.0;
}
vec2 equirectUv( in vec3 dir ) {
	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;
	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;
	return vec2( u, v );
}
vec3 BRDF_Lambert( const in vec3 diffuseColor ) {
	return RECIPROCAL_PI * diffuseColor;
}
vec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
}
float F_Schlick( const in float f0, const in float f90, const in float dotVH ) {
	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );
	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );
} // validated`,cube_uv_reflection_fragment:`#ifdef ENVMAP_TYPE_CUBE_UV
	#define cubeUV_minMipLevel 4.0
	#define cubeUV_minTileSize 16.0
	float getFace( vec3 direction ) {
		vec3 absDirection = abs( direction );
		float face = - 1.0;
		if ( absDirection.x > absDirection.z ) {
			if ( absDirection.x > absDirection.y )
				face = direction.x > 0.0 ? 0.0 : 3.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		} else {
			if ( absDirection.z > absDirection.y )
				face = direction.z > 0.0 ? 2.0 : 5.0;
			else
				face = direction.y > 0.0 ? 1.0 : 4.0;
		}
		return face;
	}
	vec2 getUV( vec3 direction, float face ) {
		vec2 uv;
		if ( face == 0.0 ) {
			uv = vec2( direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 1.0 ) {
			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );
		} else if ( face == 2.0 ) {
			uv = vec2( - direction.x, direction.y ) / abs( direction.z );
		} else if ( face == 3.0 ) {
			uv = vec2( - direction.z, direction.y ) / abs( direction.x );
		} else if ( face == 4.0 ) {
			uv = vec2( - direction.x, direction.z ) / abs( direction.y );
		} else {
			uv = vec2( direction.x, direction.y ) / abs( direction.z );
		}
		return 0.5 * ( uv + 1.0 );
	}
	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {
		float face = getFace( direction );
		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );
		mipInt = max( mipInt, cubeUV_minMipLevel );
		float faceSize = exp2( mipInt );
		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;
		if ( face > 2.0 ) {
			uv.y += faceSize;
			face -= 3.0;
		}
		uv.x += face * faceSize;
		uv.x += filterInt * 3.0 * cubeUV_minTileSize;
		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );
		uv.x *= CUBEUV_TEXEL_WIDTH;
		uv.y *= CUBEUV_TEXEL_HEIGHT;
		#ifdef texture2DGradEXT
			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;
		#else
			return texture2D( envMap, uv ).rgb;
		#endif
	}
	#define cubeUV_r0 1.0
	#define cubeUV_m0 - 2.0
	#define cubeUV_r1 0.8
	#define cubeUV_m1 - 1.0
	#define cubeUV_r4 0.4
	#define cubeUV_m4 2.0
	#define cubeUV_r5 0.305
	#define cubeUV_m5 3.0
	#define cubeUV_r6 0.21
	#define cubeUV_m6 4.0
	float roughnessToMip( float roughness ) {
		float mip = 0.0;
		if ( roughness >= cubeUV_r1 ) {
			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;
		} else if ( roughness >= cubeUV_r4 ) {
			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;
		} else if ( roughness >= cubeUV_r5 ) {
			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;
		} else if ( roughness >= cubeUV_r6 ) {
			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;
		} else {
			mip = - 2.0 * log2( 1.16 * roughness );		}
		return mip;
	}
	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {
		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );
		float mipF = fract( mip );
		float mipInt = floor( mip );
		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );
		if ( mipF == 0.0 ) {
			return vec4( color0, 1.0 );
		} else {
			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );
			return vec4( mix( color0, color1, mipF ), 1.0 );
		}
	}
#endif`,defaultnormal_vertex:`vec3 transformedNormal = objectNormal;
#ifdef USE_TANGENT
	vec3 transformedTangent = objectTangent;
#endif
#ifdef USE_BATCHING
	mat3 bm = mat3( batchingMatrix );
	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );
	transformedNormal = bm * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = bm * transformedTangent;
	#endif
#endif
#ifdef USE_INSTANCING
	mat3 im = mat3( instanceMatrix );
	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );
	transformedNormal = im * transformedNormal;
	#ifdef USE_TANGENT
		transformedTangent = im * transformedTangent;
	#endif
#endif
transformedNormal = normalMatrix * transformedNormal;
#ifdef FLIP_SIDED
	transformedNormal = - transformedNormal;
#endif
#ifdef USE_TANGENT
	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;
	#ifdef FLIP_SIDED
		transformedTangent = - transformedTangent;
	#endif
#endif`,displacementmap_pars_vertex:`#ifdef USE_DISPLACEMENTMAP
	uniform sampler2D displacementMap;
	uniform float displacementScale;
	uniform float displacementBias;
#endif`,displacementmap_vertex:`#ifdef USE_DISPLACEMENTMAP
	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );
#endif`,emissivemap_fragment:`#ifdef USE_EMISSIVEMAP
	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );
	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE
		emissiveColor = sRGBTransferEOTF( emissiveColor );
	#endif
	totalEmissiveRadiance *= emissiveColor.rgb;
#endif`,emissivemap_pars_fragment:`#ifdef USE_EMISSIVEMAP
	uniform sampler2D emissiveMap;
#endif`,colorspace_fragment:"gl_FragColor = linearToOutputTexel( gl_FragColor );",colorspace_pars_fragment:`vec4 LinearTransferOETF( in vec4 value ) {
	return value;
}
vec4 sRGBTransferEOTF( in vec4 value ) {
	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );
}
vec4 sRGBTransferOETF( in vec4 value ) {
	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );
}`,envmap_fragment:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vec3 cameraToFrag;
		if ( isOrthographic ) {
			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToFrag = normalize( vWorldPosition - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vec3 reflectVec = reflect( cameraToFrag, worldNormal );
		#else
			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );
		#endif
	#else
		vec3 reflectVec = vReflect;
	#endif
	#ifdef ENVMAP_TYPE_CUBE
		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );
	#else
		vec4 envColor = vec4( 0.0 );
	#endif
	#ifdef ENVMAP_BLENDING_MULTIPLY
		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_MIX )
		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );
	#elif defined( ENVMAP_BLENDING_ADD )
		outgoingLight += envColor.xyz * specularStrength * reflectivity;
	#endif
#endif`,envmap_common_pars_fragment:`#ifdef USE_ENVMAP
	uniform float envMapIntensity;
	uniform float flipEnvMap;
	uniform mat3 envMapRotation;
	#ifdef ENVMAP_TYPE_CUBE
		uniform samplerCube envMap;
	#else
		uniform sampler2D envMap;
	#endif
	
#endif`,envmap_pars_fragment:`#ifdef USE_ENVMAP
	uniform float reflectivity;
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		varying vec3 vWorldPosition;
		uniform float refractionRatio;
	#else
		varying vec3 vReflect;
	#endif
#endif`,envmap_pars_vertex:`#ifdef USE_ENVMAP
	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )
		#define ENV_WORLDPOS
	#endif
	#ifdef ENV_WORLDPOS
		
		varying vec3 vWorldPosition;
	#else
		varying vec3 vReflect;
		uniform float refractionRatio;
	#endif
#endif`,envmap_physical_pars_fragment:`#ifdef USE_ENVMAP
	vec3 getIBLIrradiance( const in vec3 normal ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );
			return PI * envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {
		#ifdef ENVMAP_TYPE_CUBE_UV
			vec3 reflectVec = reflect( - viewDir, normal );
			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );
			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );
			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );
			return envMapColor.rgb * envMapIntensity;
		#else
			return vec3( 0.0 );
		#endif
	}
	#ifdef USE_ANISOTROPY
		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {
			#ifdef ENVMAP_TYPE_CUBE_UV
				vec3 bentNormal = cross( bitangent, viewDir );
				bentNormal = normalize( cross( bentNormal, bitangent ) );
				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );
				return getIBLRadiance( viewDir, bentNormal, roughness );
			#else
				return vec3( 0.0 );
			#endif
		}
	#endif
#endif`,envmap_vertex:`#ifdef USE_ENVMAP
	#ifdef ENV_WORLDPOS
		vWorldPosition = worldPosition.xyz;
	#else
		vec3 cameraToVertex;
		if ( isOrthographic ) {
			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );
		} else {
			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );
		}
		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
		#ifdef ENVMAP_MODE_REFLECTION
			vReflect = reflect( cameraToVertex, worldNormal );
		#else
			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );
		#endif
	#endif
#endif`,fog_vertex:`#ifdef USE_FOG
	vFogDepth = - mvPosition.z;
#endif`,fog_pars_vertex:`#ifdef USE_FOG
	varying float vFogDepth;
#endif`,fog_fragment:`#ifdef USE_FOG
	#ifdef FOG_EXP2
		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
	#else
		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );
	#endif
	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );
#endif`,fog_pars_fragment:`#ifdef USE_FOG
	uniform vec3 fogColor;
	varying float vFogDepth;
	#ifdef FOG_EXP2
		uniform float fogDensity;
	#else
		uniform float fogNear;
		uniform float fogFar;
	#endif
#endif`,gradientmap_pars_fragment:`#ifdef USE_GRADIENTMAP
	uniform sampler2D gradientMap;
#endif
vec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {
	float dotNL = dot( normal, lightDirection );
	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );
	#ifdef USE_GRADIENTMAP
		return vec3( texture2D( gradientMap, coord ).r );
	#else
		vec2 fw = fwidth( coord ) * 0.5;
		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );
	#endif
}`,lightmap_pars_fragment:`#ifdef USE_LIGHTMAP
	uniform sampler2D lightMap;
	uniform float lightMapIntensity;
#endif`,lights_lambert_fragment:`LambertMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularStrength = specularStrength;`,lights_lambert_pars_fragment:`varying vec3 vViewPosition;
struct LambertMaterial {
	vec3 diffuseColor;
	float specularStrength;
};
void RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Lambert
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert`,lights_pars_begin:`uniform bool receiveShadow;
uniform vec3 ambientLightColor;
#if defined( USE_LIGHT_PROBES )
	uniform vec3 lightProbe[ 9 ];
#endif
vec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {
	float x = normal.x, y = normal.y, z = normal.z;
	vec3 result = shCoefficients[ 0 ] * 0.886227;
	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;
	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;
	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;
	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;
	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;
	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );
	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;
	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );
	return result;
}
vec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {
	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );
	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );
	return irradiance;
}
vec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {
	vec3 irradiance = ambientLightColor;
	return irradiance;
}
float getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {
	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );
	if ( cutoffDistance > 0.0 ) {
		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );
	}
	return distanceFalloff;
}
float getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {
	return smoothstep( coneCosine, penumbraCosine, angleCosine );
}
#if NUM_DIR_LIGHTS > 0
	struct DirectionalLight {
		vec3 direction;
		vec3 color;
	};
	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];
	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {
		light.color = directionalLight.color;
		light.direction = directionalLight.direction;
		light.visible = true;
	}
#endif
#if NUM_POINT_LIGHTS > 0
	struct PointLight {
		vec3 position;
		vec3 color;
		float distance;
		float decay;
	};
	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];
	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = pointLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float lightDistance = length( lVector );
		light.color = pointLight.color;
		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );
		light.visible = ( light.color != vec3( 0.0 ) );
	}
#endif
#if NUM_SPOT_LIGHTS > 0
	struct SpotLight {
		vec3 position;
		vec3 direction;
		vec3 color;
		float distance;
		float decay;
		float coneCos;
		float penumbraCos;
	};
	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];
	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {
		vec3 lVector = spotLight.position - geometryPosition;
		light.direction = normalize( lVector );
		float angleCos = dot( light.direction, spotLight.direction );
		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );
		if ( spotAttenuation > 0.0 ) {
			float lightDistance = length( lVector );
			light.color = spotLight.color * spotAttenuation;
			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );
			light.visible = ( light.color != vec3( 0.0 ) );
		} else {
			light.color = vec3( 0.0 );
			light.visible = false;
		}
	}
#endif
#if NUM_RECT_AREA_LIGHTS > 0
	struct RectAreaLight {
		vec3 color;
		vec3 position;
		vec3 halfWidth;
		vec3 halfHeight;
	};
	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;
	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];
#endif
#if NUM_HEMI_LIGHTS > 0
	struct HemisphereLight {
		vec3 direction;
		vec3 skyColor;
		vec3 groundColor;
	};
	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];
	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {
		float dotNL = dot( normal, hemiLight.direction );
		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;
		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );
		return irradiance;
	}
#endif`,lights_toon_fragment:`ToonMaterial material;
material.diffuseColor = diffuseColor.rgb;`,lights_toon_pars_fragment:`varying vec3 vViewPosition;
struct ToonMaterial {
	vec3 diffuseColor;
};
void RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_Toon
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon`,lights_phong_fragment:`BlinnPhongMaterial material;
material.diffuseColor = diffuseColor.rgb;
material.specularColor = specular;
material.specularShininess = shininess;
material.specularStrength = specularStrength;`,lights_phong_pars_fragment:`varying vec3 vViewPosition;
struct BlinnPhongMaterial {
	vec3 diffuseColor;
	vec3 specularColor;
	float specularShininess;
	float specularStrength;
};
void RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;
}
void RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
#define RE_Direct				RE_Direct_BlinnPhong
#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong`,lights_physical_fragment:`PhysicalMaterial material;
material.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );
vec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );
float geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );
material.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;
material.roughness = min( material.roughness, 1.0 );
#ifdef IOR
	material.ior = ior;
	#ifdef USE_SPECULAR
		float specularIntensityFactor = specularIntensity;
		vec3 specularColorFactor = specularColor;
		#ifdef USE_SPECULAR_COLORMAP
			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;
		#endif
		#ifdef USE_SPECULAR_INTENSITYMAP
			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;
		#endif
		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );
	#else
		float specularIntensityFactor = 1.0;
		vec3 specularColorFactor = vec3( 1.0 );
		material.specularF90 = 1.0;
	#endif
	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );
#else
	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );
	material.specularF90 = 1.0;
#endif
#ifdef USE_CLEARCOAT
	material.clearcoat = clearcoat;
	material.clearcoatRoughness = clearcoatRoughness;
	material.clearcoatF0 = vec3( 0.04 );
	material.clearcoatF90 = 1.0;
	#ifdef USE_CLEARCOATMAP
		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;
	#endif
	#ifdef USE_CLEARCOAT_ROUGHNESSMAP
		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;
	#endif
	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );
	material.clearcoatRoughness += geometryRoughness;
	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );
#endif
#ifdef USE_DISPERSION
	material.dispersion = dispersion;
#endif
#ifdef USE_IRIDESCENCE
	material.iridescence = iridescence;
	material.iridescenceIOR = iridescenceIOR;
	#ifdef USE_IRIDESCENCEMAP
		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;
	#endif
	#ifdef USE_IRIDESCENCE_THICKNESSMAP
		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;
	#else
		material.iridescenceThickness = iridescenceThicknessMaximum;
	#endif
#endif
#ifdef USE_SHEEN
	material.sheenColor = sheenColor;
	#ifdef USE_SHEEN_COLORMAP
		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;
	#endif
	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );
	#ifdef USE_SHEEN_ROUGHNESSMAP
		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;
	#endif
#endif
#ifdef USE_ANISOTROPY
	#ifdef USE_ANISOTROPYMAP
		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );
		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;
		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;
	#else
		vec2 anisotropyV = anisotropyVector;
	#endif
	material.anisotropy = length( anisotropyV );
	if( material.anisotropy == 0.0 ) {
		anisotropyV = vec2( 1.0, 0.0 );
	} else {
		anisotropyV /= material.anisotropy;
		material.anisotropy = saturate( material.anisotropy );
	}
	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );
	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;
	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;
#endif`,lights_physical_pars_fragment:`struct PhysicalMaterial {
	vec3 diffuseColor;
	float roughness;
	vec3 specularColor;
	float specularF90;
	float dispersion;
	#ifdef USE_CLEARCOAT
		float clearcoat;
		float clearcoatRoughness;
		vec3 clearcoatF0;
		float clearcoatF90;
	#endif
	#ifdef USE_IRIDESCENCE
		float iridescence;
		float iridescenceIOR;
		float iridescenceThickness;
		vec3 iridescenceFresnel;
		vec3 iridescenceF0;
	#endif
	#ifdef USE_SHEEN
		vec3 sheenColor;
		float sheenRoughness;
	#endif
	#ifdef IOR
		float ior;
	#endif
	#ifdef USE_TRANSMISSION
		float transmission;
		float transmissionAlpha;
		float thickness;
		float attenuationDistance;
		vec3 attenuationColor;
	#endif
	#ifdef USE_ANISOTROPY
		float anisotropy;
		float alphaT;
		vec3 anisotropyT;
		vec3 anisotropyB;
	#endif
};
vec3 clearcoatSpecularDirect = vec3( 0.0 );
vec3 clearcoatSpecularIndirect = vec3( 0.0 );
vec3 sheenSpecularDirect = vec3( 0.0 );
vec3 sheenSpecularIndirect = vec3(0.0 );
vec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {
    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );
    float x2 = x * x;
    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );
    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );
}
float V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {
	float a2 = pow2( alpha );
	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );
	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );
	return 0.5 / max( gv + gl, EPSILON );
}
float D_GGX( const in float alpha, const in float dotNH ) {
	float a2 = pow2( alpha );
	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;
	return RECIPROCAL_PI * a2 / pow2( denom );
}
#ifdef USE_ANISOTROPY
	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {
		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );
		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );
		float v = 0.5 / ( gv + gl );
		return saturate(v);
	}
	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {
		float a2 = alphaT * alphaB;
		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );
		highp float v2 = dot( v, v );
		float w2 = a2 / v2;
		return RECIPROCAL_PI * a2 * pow2 ( w2 );
	}
#endif
#ifdef USE_CLEARCOAT
	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {
		vec3 f0 = material.clearcoatF0;
		float f90 = material.clearcoatF90;
		float roughness = material.clearcoatRoughness;
		float alpha = pow2( roughness );
		vec3 halfDir = normalize( lightDir + viewDir );
		float dotNL = saturate( dot( normal, lightDir ) );
		float dotNV = saturate( dot( normal, viewDir ) );
		float dotNH = saturate( dot( normal, halfDir ) );
		float dotVH = saturate( dot( viewDir, halfDir ) );
		vec3 F = F_Schlick( f0, f90, dotVH );
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
		return F * ( V * D );
	}
#endif
vec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {
	vec3 f0 = material.specularColor;
	float f90 = material.specularF90;
	float roughness = material.roughness;
	float alpha = pow2( roughness );
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float dotVH = saturate( dot( viewDir, halfDir ) );
	vec3 F = F_Schlick( f0, f90, dotVH );
	#ifdef USE_IRIDESCENCE
		F = mix( F, material.iridescenceFresnel, material.iridescence );
	#endif
	#ifdef USE_ANISOTROPY
		float dotTL = dot( material.anisotropyT, lightDir );
		float dotTV = dot( material.anisotropyT, viewDir );
		float dotTH = dot( material.anisotropyT, halfDir );
		float dotBL = dot( material.anisotropyB, lightDir );
		float dotBV = dot( material.anisotropyB, viewDir );
		float dotBH = dot( material.anisotropyB, halfDir );
		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );
		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );
	#else
		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );
		float D = D_GGX( alpha, dotNH );
	#endif
	return F * ( V * D );
}
vec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {
	const float LUT_SIZE = 64.0;
	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;
	const float LUT_BIAS = 0.5 / LUT_SIZE;
	float dotNV = saturate( dot( N, V ) );
	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );
	uv = uv * LUT_SCALE + LUT_BIAS;
	return uv;
}
float LTC_ClippedSphereFormFactor( const in vec3 f ) {
	float l = length( f );
	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );
}
vec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {
	float x = dot( v1, v2 );
	float y = abs( x );
	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;
	float b = 3.4175940 + ( 4.1616724 + y ) * y;
	float v = a / b;
	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;
	return cross( v1, v2 ) * theta_sintheta;
}
vec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {
	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];
	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];
	vec3 lightNormal = cross( v1, v2 );
	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );
	vec3 T1, T2;
	T1 = normalize( V - N * dot( V, N ) );
	T2 = - cross( N, T1 );
	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );
	vec3 coords[ 4 ];
	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );
	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );
	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );
	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );
	coords[ 0 ] = normalize( coords[ 0 ] );
	coords[ 1 ] = normalize( coords[ 1 ] );
	coords[ 2 ] = normalize( coords[ 2 ] );
	coords[ 3 ] = normalize( coords[ 3 ] );
	vec3 vectorFormFactor = vec3( 0.0 );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );
	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );
	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );
	return vec3( result );
}
#if defined( USE_SHEEN )
float D_Charlie( float roughness, float dotNH ) {
	float alpha = pow2( roughness );
	float invAlpha = 1.0 / alpha;
	float cos2h = dotNH * dotNH;
	float sin2h = max( 1.0 - cos2h, 0.0078125 );
	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );
}
float V_Neubelt( float dotNV, float dotNL ) {
	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );
}
vec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {
	vec3 halfDir = normalize( lightDir + viewDir );
	float dotNL = saturate( dot( normal, lightDir ) );
	float dotNV = saturate( dot( normal, viewDir ) );
	float dotNH = saturate( dot( normal, halfDir ) );
	float D = D_Charlie( sheenRoughness, dotNH );
	float V = V_Neubelt( dotNV, dotNL );
	return sheenColor * ( D * V );
}
#endif
float IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	float r2 = roughness * roughness;
	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;
	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;
	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );
	return saturate( DG * RECIPROCAL_PI );
}
vec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {
	float dotNV = saturate( dot( normal, viewDir ) );
	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );
	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );
	vec4 r = roughness * c0 + c1;
	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;
	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;
	return fab;
}
vec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	return specularColor * fab.x + specularF90 * fab.y;
}
#ifdef USE_IRIDESCENCE
void computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#else
void computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {
#endif
	vec2 fab = DFGApprox( normal, viewDir, roughness );
	#ifdef USE_IRIDESCENCE
		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );
	#else
		vec3 Fr = specularColor;
	#endif
	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;
	float Ess = fab.x + fab.y;
	float Ems = 1.0 - Ess;
	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );
	singleScatter += FssEss;
	multiScatter += Fms * Ems;
}
#if NUM_RECT_AREA_LIGHTS > 0
	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
		vec3 normal = geometryNormal;
		vec3 viewDir = geometryViewDir;
		vec3 position = geometryPosition;
		vec3 lightPos = rectAreaLight.position;
		vec3 halfWidth = rectAreaLight.halfWidth;
		vec3 halfHeight = rectAreaLight.halfHeight;
		vec3 lightColor = rectAreaLight.color;
		float roughness = material.roughness;
		vec3 rectCoords[ 4 ];
		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;
		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;
		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;
		vec2 uv = LTC_Uv( normal, viewDir, roughness );
		vec4 t1 = texture2D( ltc_1, uv );
		vec4 t2 = texture2D( ltc_2, uv );
		mat3 mInv = mat3(
			vec3( t1.x, 0, t1.y ),
			vec3(    0, 1,    0 ),
			vec3( t1.z, 0, t1.w )
		);
		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );
		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );
		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );
	}
#endif
void RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );
	vec3 irradiance = dotNL * directLight.color;
	#ifdef USE_CLEARCOAT
		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );
		vec3 ccIrradiance = dotNLcc * directLight.color;
		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );
	#endif
	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );
	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {
	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );
}
void RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {
	#ifdef USE_CLEARCOAT
		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );
	#endif
	#ifdef USE_SHEEN
		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );
	#endif
	vec3 singleScattering = vec3( 0.0 );
	vec3 multiScattering = vec3( 0.0 );
	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;
	#ifdef USE_IRIDESCENCE
		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );
	#else
		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );
	#endif
	vec3 totalScattering = singleScattering + multiScattering;
	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );
	reflectedLight.indirectSpecular += radiance * singleScattering;
	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;
	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;
}
#define RE_Direct				RE_Direct_Physical
#define RE_Direct_RectArea		RE_Direct_RectArea_Physical
#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical
#define RE_IndirectSpecular		RE_IndirectSpecular_Physical
float computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {
	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );
}`,lights_fragment_begin:`
vec3 geometryPosition = - vViewPosition;
vec3 geometryNormal = normal;
vec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );
vec3 geometryClearcoatNormal = vec3( 0.0 );
#ifdef USE_CLEARCOAT
	geometryClearcoatNormal = clearcoatNormal;
#endif
#ifdef USE_IRIDESCENCE
	float dotNVi = saturate( dot( normal, geometryViewDir ) );
	if ( material.iridescenceThickness == 0.0 ) {
		material.iridescence = 0.0;
	} else {
		material.iridescence = saturate( material.iridescence );
	}
	if ( material.iridescence > 0.0 ) {
		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );
		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );
	}
#endif
IncidentLight directLight;
#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )
	PointLight pointLight;
	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {
		pointLight = pointLights[ i ];
		getPointLightInfo( pointLight, geometryPosition, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )
		pointLightShadow = pointLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )
	SpotLight spotLight;
	vec4 spotColor;
	vec3 spotLightCoord;
	bool inSpotLightMap;
	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {
		spotLight = spotLights[ i ];
		getSpotLightInfo( spotLight, geometryPosition, directLight );
		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX
		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS
		#else
		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )
		#endif
		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )
			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;
			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );
			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );
			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;
		#endif
		#undef SPOT_LIGHT_MAP_INDEX
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
		spotLightShadow = spotLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )
	DirectionalLight directionalLight;
	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLightShadow;
	#endif
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {
		directionalLight = directionalLights[ i ];
		getDirectionalLightInfo( directionalLight, directLight );
		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )
		directionalLightShadow = directionalLightShadows[ i ];
		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
		#endif
		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )
	RectAreaLight rectAreaLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {
		rectAreaLight = rectAreaLights[ i ];
		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
	}
	#pragma unroll_loop_end
#endif
#if defined( RE_IndirectDiffuse )
	vec3 iblIrradiance = vec3( 0.0 );
	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );
	#if defined( USE_LIGHT_PROBES )
		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );
	#endif
	#if ( NUM_HEMI_LIGHTS > 0 )
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {
			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );
		}
		#pragma unroll_loop_end
	#endif
#endif
#if defined( RE_IndirectSpecular )
	vec3 radiance = vec3( 0.0 );
	vec3 clearcoatRadiance = vec3( 0.0 );
#endif`,lights_fragment_maps:`#if defined( RE_IndirectDiffuse )
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;
		irradiance += lightMapIrradiance;
	#endif
	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )
		iblIrradiance += getIBLIrradiance( geometryNormal );
	#endif
#endif
#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )
	#ifdef USE_ANISOTROPY
		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );
	#else
		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );
	#endif
	#ifdef USE_CLEARCOAT
		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );
	#endif
#endif`,lights_fragment_end:`#if defined( RE_IndirectDiffuse )
	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif
#if defined( RE_IndirectSpecular )
	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );
#endif`,logdepthbuf_fragment:`#if defined( USE_LOGDEPTHBUF )
	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;
#endif`,logdepthbuf_pars_fragment:`#if defined( USE_LOGDEPTHBUF )
	uniform float logDepthBufFC;
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_pars_vertex:`#ifdef USE_LOGDEPTHBUF
	varying float vFragDepth;
	varying float vIsPerspective;
#endif`,logdepthbuf_vertex:`#ifdef USE_LOGDEPTHBUF
	vFragDepth = 1.0 + gl_Position.w;
	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );
#endif`,map_fragment:`#ifdef USE_MAP
	vec4 sampledDiffuseColor = texture2D( map, vMapUv );
	#ifdef DECODE_VIDEO_TEXTURE
		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );
	#endif
	diffuseColor *= sampledDiffuseColor;
#endif`,map_pars_fragment:`#ifdef USE_MAP
	uniform sampler2D map;
#endif`,map_particle_fragment:`#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
	#if defined( USE_POINTS_UV )
		vec2 uv = vUv;
	#else
		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;
	#endif
#endif
#ifdef USE_MAP
	diffuseColor *= texture2D( map, uv );
#endif
#ifdef USE_ALPHAMAP
	diffuseColor.a *= texture2D( alphaMap, uv ).g;
#endif`,map_particle_pars_fragment:`#if defined( USE_POINTS_UV )
	varying vec2 vUv;
#else
	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )
		uniform mat3 uvTransform;
	#endif
#endif
#ifdef USE_MAP
	uniform sampler2D map;
#endif
#ifdef USE_ALPHAMAP
	uniform sampler2D alphaMap;
#endif`,metalnessmap_fragment:`float metalnessFactor = metalness;
#ifdef USE_METALNESSMAP
	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );
	metalnessFactor *= texelMetalness.b;
#endif`,metalnessmap_pars_fragment:`#ifdef USE_METALNESSMAP
	uniform sampler2D metalnessMap;
#endif`,morphinstance_vertex:`#ifdef USE_INSTANCING_MORPH
	float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;
	}
#endif`,morphcolor_vertex:`#if defined( USE_MORPHCOLORS )
	vColor *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		#if defined( USE_COLOR_ALPHA )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];
		#elif defined( USE_COLOR )
			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];
		#endif
	}
#endif`,morphnormal_vertex:`#ifdef USE_MORPHNORMALS
	objectNormal *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,morphtarget_pars_vertex:`#ifdef USE_MORPHTARGETS
	#ifndef USE_INSTANCING_MORPH
		uniform float morphTargetBaseInfluence;
		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];
	#endif
	uniform sampler2DArray morphTargetsTexture;
	uniform ivec2 morphTargetsTextureSize;
	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {
		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;
		int y = texelIndex / morphTargetsTextureSize.x;
		int x = texelIndex - y * morphTargetsTextureSize.x;
		ivec3 morphUV = ivec3( x, y, morphTargetIndex );
		return texelFetch( morphTargetsTexture, morphUV, 0 );
	}
#endif`,morphtarget_vertex:`#ifdef USE_MORPHTARGETS
	transformed *= morphTargetBaseInfluence;
	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {
		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];
	}
#endif`,normal_fragment_begin:`float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;
#ifdef FLAT_SHADED
	vec3 fdx = dFdx( vViewPosition );
	vec3 fdy = dFdy( vViewPosition );
	vec3 normal = normalize( cross( fdx, fdy ) );
#else
	vec3 normal = normalize( vNormal );
	#ifdef DOUBLE_SIDED
		normal *= faceDirection;
	#endif
#endif
#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )
	#ifdef USE_TANGENT
		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn = getTangentFrame( - vViewPosition, normal,
		#if defined( USE_NORMALMAP )
			vNormalMapUv
		#elif defined( USE_CLEARCOAT_NORMALMAP )
			vClearcoatNormalMapUv
		#else
			vUv
		#endif
		);
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn[0] *= faceDirection;
		tbn[1] *= faceDirection;
	#endif
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	#ifdef USE_TANGENT
		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );
	#else
		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );
	#endif
	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )
		tbn2[0] *= faceDirection;
		tbn2[1] *= faceDirection;
	#endif
#endif
vec3 nonPerturbedNormal = normal;`,normal_fragment_maps:`#ifdef USE_NORMALMAP_OBJECTSPACE
	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	#ifdef FLIP_SIDED
		normal = - normal;
	#endif
	#ifdef DOUBLE_SIDED
		normal = normal * faceDirection;
	#endif
	normal = normalize( normalMatrix * normal );
#elif defined( USE_NORMALMAP_TANGENTSPACE )
	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;
	mapN.xy *= normalScale;
	normal = normalize( tbn * mapN );
#elif defined( USE_BUMPMAP )
	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );
#endif`,normal_pars_fragment:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_pars_vertex:`#ifndef FLAT_SHADED
	varying vec3 vNormal;
	#ifdef USE_TANGENT
		varying vec3 vTangent;
		varying vec3 vBitangent;
	#endif
#endif`,normal_vertex:`#ifndef FLAT_SHADED
	vNormal = normalize( transformedNormal );
	#ifdef USE_TANGENT
		vTangent = normalize( transformedTangent );
		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );
	#endif
#endif`,normalmap_pars_fragment:`#ifdef USE_NORMALMAP
	uniform sampler2D normalMap;
	uniform vec2 normalScale;
#endif
#ifdef USE_NORMALMAP_OBJECTSPACE
	uniform mat3 normalMatrix;
#endif
#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )
	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {
		vec3 q0 = dFdx( eye_pos.xyz );
		vec3 q1 = dFdy( eye_pos.xyz );
		vec2 st0 = dFdx( uv.st );
		vec2 st1 = dFdy( uv.st );
		vec3 N = surf_norm;
		vec3 q1perp = cross( q1, N );
		vec3 q0perp = cross( N, q0 );
		vec3 T = q1perp * st0.x + q0perp * st1.x;
		vec3 B = q1perp * st0.y + q0perp * st1.y;
		float det = max( dot( T, T ), dot( B, B ) );
		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );
		return mat3( T * scale, B * scale, N );
	}
#endif`,clearcoat_normal_fragment_begin:`#ifdef USE_CLEARCOAT
	vec3 clearcoatNormal = nonPerturbedNormal;
#endif`,clearcoat_normal_fragment_maps:`#ifdef USE_CLEARCOAT_NORMALMAP
	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;
	clearcoatMapN.xy *= clearcoatNormalScale;
	clearcoatNormal = normalize( tbn2 * clearcoatMapN );
#endif`,clearcoat_pars_fragment:`#ifdef USE_CLEARCOATMAP
	uniform sampler2D clearcoatMap;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform sampler2D clearcoatNormalMap;
	uniform vec2 clearcoatNormalScale;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform sampler2D clearcoatRoughnessMap;
#endif`,iridescence_pars_fragment:`#ifdef USE_IRIDESCENCEMAP
	uniform sampler2D iridescenceMap;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform sampler2D iridescenceThicknessMap;
#endif`,opaque_fragment:`#ifdef OPAQUE
diffuseColor.a = 1.0;
#endif
#ifdef USE_TRANSMISSION
diffuseColor.a *= material.transmissionAlpha;
#endif
gl_FragColor = vec4( outgoingLight, diffuseColor.a );`,packing:`vec3 packNormalToRGB( const in vec3 normal ) {
	return normalize( normal ) * 0.5 + 0.5;
}
vec3 unpackRGBToNormal( const in vec3 rgb ) {
	return 2.0 * rgb.xyz - 1.0;
}
const float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;
const float Inv255 = 1. / 255.;
const vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );
const vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );
const vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );
const vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );
vec4 packDepthToRGBA( const in float v ) {
	if( v <= 0.0 )
		return vec4( 0., 0., 0., 0. );
	if( v >= 1.0 )
		return vec4( 1., 1., 1., 1. );
	float vuf;
	float af = modf( v * PackFactors.a, vuf );
	float bf = modf( vuf * ShiftRight8, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );
}
vec3 packDepthToRGB( const in float v ) {
	if( v <= 0.0 )
		return vec3( 0., 0., 0. );
	if( v >= 1.0 )
		return vec3( 1., 1., 1. );
	float vuf;
	float bf = modf( v * PackFactors.b, vuf );
	float gf = modf( vuf * ShiftRight8, vuf );
	return vec3( vuf * Inv255, gf * PackUpscale, bf );
}
vec2 packDepthToRG( const in float v ) {
	if( v <= 0.0 )
		return vec2( 0., 0. );
	if( v >= 1.0 )
		return vec2( 1., 1. );
	float vuf;
	float gf = modf( v * 256., vuf );
	return vec2( vuf * Inv255, gf );
}
float unpackRGBAToDepth( const in vec4 v ) {
	return dot( v, UnpackFactors4 );
}
float unpackRGBToDepth( const in vec3 v ) {
	return dot( v, UnpackFactors3 );
}
float unpackRGToDepth( const in vec2 v ) {
	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;
}
vec4 pack2HalfToRGBA( const in vec2 v ) {
	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );
	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );
}
vec2 unpackRGBATo2Half( const in vec4 v ) {
	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );
}
float viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {
	return ( viewZ + near ) / ( near - far );
}
float orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return depth * ( near - far ) - near;
}
float viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {
	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );
}
float perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {
	return ( near * far ) / ( ( far - near ) * depth - far );
}`,premultiplied_alpha_fragment:`#ifdef PREMULTIPLIED_ALPHA
	gl_FragColor.rgb *= gl_FragColor.a;
#endif`,project_vertex:`vec4 mvPosition = vec4( transformed, 1.0 );
#ifdef USE_BATCHING
	mvPosition = batchingMatrix * mvPosition;
#endif
#ifdef USE_INSTANCING
	mvPosition = instanceMatrix * mvPosition;
#endif
mvPosition = modelViewMatrix * mvPosition;
gl_Position = projectionMatrix * mvPosition;`,dithering_fragment:`#ifdef DITHERING
	gl_FragColor.rgb = dithering( gl_FragColor.rgb );
#endif`,dithering_pars_fragment:`#ifdef DITHERING
	vec3 dithering( vec3 color ) {
		float grid_position = rand( gl_FragCoord.xy );
		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );
		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );
		return color + dither_shift_RGB;
	}
#endif`,roughnessmap_fragment:`float roughnessFactor = roughness;
#ifdef USE_ROUGHNESSMAP
	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );
	roughnessFactor *= texelRoughness.g;
#endif`,roughnessmap_pars_fragment:`#ifdef USE_ROUGHNESSMAP
	uniform sampler2D roughnessMap;
#endif`,shadowmap_pars_fragment:`#if NUM_SPOT_LIGHT_COORDS > 0
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#if NUM_SPOT_LIGHT_MAPS > 0
	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {
		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );
	}
	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {
		return unpackRGBATo2Half( texture2D( shadow, uv ) );
	}
	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){
		float occlusion = 1.0;
		vec2 distribution = texture2DDistribution( shadow, uv );
		float hard_shadow = step( compare , distribution.x );
		if (hard_shadow != 1.0 ) {
			float distance = compare - distribution.x ;
			float variance = max( 0.00000, distribution.y * distribution.y );
			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );
		}
		return occlusion;
	}
	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {
		float shadow = 1.0;
		shadowCoord.xyz /= shadowCoord.w;
		shadowCoord.z += shadowBias;
		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;
		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;
		if ( frustumTest ) {
		#if defined( SHADOWMAP_TYPE_PCF )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx0 = - texelSize.x * shadowRadius;
			float dy0 = - texelSize.y * shadowRadius;
			float dx1 = + texelSize.x * shadowRadius;
			float dy1 = + texelSize.y * shadowRadius;
			float dx2 = dx0 / 2.0;
			float dy2 = dy0 / 2.0;
			float dx3 = dx1 / 2.0;
			float dy3 = dy1 / 2.0;
			shadow = (
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )
			) * ( 1.0 / 17.0 );
		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )
			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;
			float dx = texelSize.x;
			float dy = texelSize.y;
			vec2 uv = shadowCoord.xy;
			vec2 f = fract( uv * shadowMapSize + 0.5 );
			uv -= f * texelSize;
			shadow = (
				texture2DCompare( shadowMap, uv, shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +
				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),
					 f.x ) +
				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),
					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),
					 f.y ) +
				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),
						  f.x ),
					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),
						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),
						  f.x ),
					 f.y )
			) * ( 1.0 / 9.0 );
		#elif defined( SHADOWMAP_TYPE_VSM )
			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );
		#else
			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );
		#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
	vec2 cubeToUV( vec3 v, float texelSizeY ) {
		vec3 absV = abs( v );
		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );
		absV *= scaleToCube;
		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );
		vec2 planar = v.xy;
		float almostATexel = 1.5 * texelSizeY;
		float almostOne = 1.0 - almostATexel;
		if ( absV.z >= almostOne ) {
			if ( v.z > 0.0 )
				planar.x = 4.0 - v.x;
		} else if ( absV.x >= almostOne ) {
			float signX = sign( v.x );
			planar.x = v.z * signX + 2.0 * signX;
		} else if ( absV.y >= almostOne ) {
			float signY = sign( v.y );
			planar.x = v.x + 2.0 * signY + 2.0;
			planar.y = v.z * signY - 2.0;
		}
		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );
	}
	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {
		float shadow = 1.0;
		vec3 lightToPosition = shadowCoord.xyz;
		
		float lightToPositionLength = length( lightToPosition );
		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {
			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;
			vec3 bd3D = normalize( lightToPosition );
			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );
			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )
				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;
				shadow = (
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +
					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )
				) * ( 1.0 / 9.0 );
			#else
				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );
			#endif
		}
		return mix( 1.0, shadow, shadowIntensity );
	}
#endif`,shadowmap_pars_vertex:`#if NUM_SPOT_LIGHT_COORDS > 0
	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];
	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];
#endif
#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];
		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];
		struct DirectionalLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
		struct SpotLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
		};
		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];
		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];
		struct PointLightShadow {
			float shadowIntensity;
			float shadowBias;
			float shadowNormalBias;
			float shadowRadius;
			vec2 shadowMapSize;
			float shadowCameraNear;
			float shadowCameraFar;
		};
		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];
	#endif
#endif`,shadowmap_vertex:`#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )
	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );
	vec4 shadowWorldPosition;
#endif
#if defined( USE_SHADOWMAP )
	#if NUM_DIR_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );
			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
		#pragma unroll_loop_start
		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );
			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;
		}
		#pragma unroll_loop_end
	#endif
#endif
#if NUM_SPOT_LIGHT_COORDS > 0
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {
		shadowWorldPosition = worldPosition;
		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )
			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;
		#endif
		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;
	}
	#pragma unroll_loop_end
#endif`,shadowmask_pars_fragment:`float getShadowMask() {
	float shadow = 1.0;
	#ifdef USE_SHADOWMAP
	#if NUM_DIR_LIGHT_SHADOWS > 0
	DirectionalLightShadow directionalLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {
		directionalLight = directionalLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_SPOT_LIGHT_SHADOWS > 0
	SpotLightShadow spotLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {
		spotLight = spotLightShadows[ i ];
		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#if NUM_POINT_LIGHT_SHADOWS > 0
	PointLightShadow pointLight;
	#pragma unroll_loop_start
	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {
		pointLight = pointLightShadows[ i ];
		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;
	}
	#pragma unroll_loop_end
	#endif
	#endif
	return shadow;
}`,skinbase_vertex:`#ifdef USE_SKINNING
	mat4 boneMatX = getBoneMatrix( skinIndex.x );
	mat4 boneMatY = getBoneMatrix( skinIndex.y );
	mat4 boneMatZ = getBoneMatrix( skinIndex.z );
	mat4 boneMatW = getBoneMatrix( skinIndex.w );
#endif`,skinning_pars_vertex:`#ifdef USE_SKINNING
	uniform mat4 bindMatrix;
	uniform mat4 bindMatrixInverse;
	uniform highp sampler2D boneTexture;
	mat4 getBoneMatrix( const in float i ) {
		int size = textureSize( boneTexture, 0 ).x;
		int j = int( i ) * 4;
		int x = j % size;
		int y = j / size;
		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );
		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );
		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );
		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );
		return mat4( v1, v2, v3, v4 );
	}
#endif`,skinning_vertex:`#ifdef USE_SKINNING
	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );
	vec4 skinned = vec4( 0.0 );
	skinned += boneMatX * skinVertex * skinWeight.x;
	skinned += boneMatY * skinVertex * skinWeight.y;
	skinned += boneMatZ * skinVertex * skinWeight.z;
	skinned += boneMatW * skinVertex * skinWeight.w;
	transformed = ( bindMatrixInverse * skinned ).xyz;
#endif`,skinnormal_vertex:`#ifdef USE_SKINNING
	mat4 skinMatrix = mat4( 0.0 );
	skinMatrix += skinWeight.x * boneMatX;
	skinMatrix += skinWeight.y * boneMatY;
	skinMatrix += skinWeight.z * boneMatZ;
	skinMatrix += skinWeight.w * boneMatW;
	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;
	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;
	#ifdef USE_TANGENT
		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;
	#endif
#endif`,specularmap_fragment:`float specularStrength;
#ifdef USE_SPECULARMAP
	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );
	specularStrength = texelSpecular.r;
#else
	specularStrength = 1.0;
#endif`,specularmap_pars_fragment:`#ifdef USE_SPECULARMAP
	uniform sampler2D specularMap;
#endif`,tonemapping_fragment:`#if defined( TONE_MAPPING )
	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );
#endif`,tonemapping_pars_fragment:`#ifndef saturate
#define saturate( a ) clamp( a, 0.0, 1.0 )
#endif
uniform float toneMappingExposure;
vec3 LinearToneMapping( vec3 color ) {
	return saturate( toneMappingExposure * color );
}
vec3 ReinhardToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	return saturate( color / ( vec3( 1.0 ) + color ) );
}
vec3 CineonToneMapping( vec3 color ) {
	color *= toneMappingExposure;
	color = max( vec3( 0.0 ), color - 0.004 );
	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );
}
vec3 RRTAndODTFit( vec3 v ) {
	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;
	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;
	return a / b;
}
vec3 ACESFilmicToneMapping( vec3 color ) {
	const mat3 ACESInputMat = mat3(
		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),
		vec3( 0.04823, 0.01566, 0.83777 )
	);
	const mat3 ACESOutputMat = mat3(
		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),
		vec3( -0.07367, -0.00605,  1.07602 )
	);
	color *= toneMappingExposure / 0.6;
	color = ACESInputMat * color;
	color = RRTAndODTFit( color );
	color = ACESOutputMat * color;
	return saturate( color );
}
const mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(
	vec3( 1.6605, - 0.1246, - 0.0182 ),
	vec3( - 0.5876, 1.1329, - 0.1006 ),
	vec3( - 0.0728, - 0.0083, 1.1187 )
);
const mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(
	vec3( 0.6274, 0.0691, 0.0164 ),
	vec3( 0.3293, 0.9195, 0.0880 ),
	vec3( 0.0433, 0.0113, 0.8956 )
);
vec3 agxDefaultContrastApprox( vec3 x ) {
	vec3 x2 = x * x;
	vec3 x4 = x2 * x2;
	return + 15.5 * x4 * x2
		- 40.14 * x4 * x
		+ 31.96 * x4
		- 6.868 * x2 * x
		+ 0.4298 * x2
		+ 0.1191 * x
		- 0.00232;
}
vec3 AgXToneMapping( vec3 color ) {
	const mat3 AgXInsetMatrix = mat3(
		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),
		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),
		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )
	);
	const mat3 AgXOutsetMatrix = mat3(
		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),
		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),
		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )
	);
	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;
	color *= toneMappingExposure;
	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;
	color = AgXInsetMatrix * color;
	color = max( color, 1e-10 );	color = log2( color );
	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );
	color = clamp( color, 0.0, 1.0 );
	color = agxDefaultContrastApprox( color );
	color = AgXOutsetMatrix * color;
	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );
	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;
	color = clamp( color, 0.0, 1.0 );
	return color;
}
vec3 NeutralToneMapping( vec3 color ) {
	const float StartCompression = 0.8 - 0.04;
	const float Desaturation = 0.15;
	color *= toneMappingExposure;
	float x = min( color.r, min( color.g, color.b ) );
	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;
	color -= offset;
	float peak = max( color.r, max( color.g, color.b ) );
	if ( peak < StartCompression ) return color;
	float d = 1. - StartCompression;
	float newPeak = 1. - d * d / ( peak + d - StartCompression );
	color *= newPeak / peak;
	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );
	return mix( color, vec3( newPeak ), g );
}
vec3 CustomToneMapping( vec3 color ) { return color; }`,transmission_fragment:`#ifdef USE_TRANSMISSION
	material.transmission = transmission;
	material.transmissionAlpha = 1.0;
	material.thickness = thickness;
	material.attenuationDistance = attenuationDistance;
	material.attenuationColor = attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;
	#endif
	#ifdef USE_THICKNESSMAP
		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;
	#endif
	vec3 pos = vWorldPosition;
	vec3 v = normalize( cameraPosition - pos );
	vec3 n = inverseTransformDirection( normal, viewMatrix );
	vec4 transmitted = getIBLVolumeRefraction(
		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,
		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,
		material.attenuationColor, material.attenuationDistance );
	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );
	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );
#endif`,transmission_pars_fragment:`#ifdef USE_TRANSMISSION
	uniform float transmission;
	uniform float thickness;
	uniform float attenuationDistance;
	uniform vec3 attenuationColor;
	#ifdef USE_TRANSMISSIONMAP
		uniform sampler2D transmissionMap;
	#endif
	#ifdef USE_THICKNESSMAP
		uniform sampler2D thicknessMap;
	#endif
	uniform vec2 transmissionSamplerSize;
	uniform sampler2D transmissionSamplerMap;
	uniform mat4 modelMatrix;
	uniform mat4 projectionMatrix;
	varying vec3 vWorldPosition;
	float w0( float a ) {
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );
	}
	float w1( float a ) {
		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );
	}
	float w2( float a ){
		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );
	}
	float w3( float a ) {
		return ( 1.0 / 6.0 ) * ( a * a * a );
	}
	float g0( float a ) {
		return w0( a ) + w1( a );
	}
	float g1( float a ) {
		return w2( a ) + w3( a );
	}
	float h0( float a ) {
		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );
	}
	float h1( float a ) {
		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );
	}
	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {
		uv = uv * texelSize.zw + 0.5;
		vec2 iuv = floor( uv );
		vec2 fuv = fract( uv );
		float g0x = g0( fuv.x );
		float g1x = g1( fuv.x );
		float h0x = h0( fuv.x );
		float h1x = h1( fuv.x );
		float h0y = h0( fuv.y );
		float h1y = h1( fuv.y );
		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;
		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;
		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +
			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );
	}
	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {
		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );
		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );
		vec2 fLodSizeInv = 1.0 / fLodSize;
		vec2 cLodSizeInv = 1.0 / cLodSize;
		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );
		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );
		return mix( fSample, cSample, fract( lod ) );
	}
	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {
		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );
		vec3 modelScale;
		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );
		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );
		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );
		return normalize( refractionVector ) * thickness * modelScale;
	}
	float applyIorToRoughness( const in float roughness, const in float ior ) {
		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );
	}
	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {
		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );
		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );
	}
	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {
		if ( isinf( attenuationDistance ) ) {
			return vec3( 1.0 );
		} else {
			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;
			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;
		}
	}
	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,
		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,
		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,
		const in vec3 attenuationColor, const in float attenuationDistance ) {
		vec4 transmittedLight;
		vec3 transmittance;
		#ifdef USE_DISPERSION
			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;
			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );
			for ( int i = 0; i < 3; i ++ ) {
				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );
				vec3 refractedRayExit = position + transmissionRay;
		
				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
				vec2 refractionCoords = ndcPos.xy / ndcPos.w;
				refractionCoords += 1.0;
				refractionCoords /= 2.0;
		
				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );
				transmittedLight[ i ] = transmissionSample[ i ];
				transmittedLight.a += transmissionSample.a;
				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];
			}
			transmittedLight.a /= 3.0;
		
		#else
		
			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );
			vec3 refractedRayExit = position + transmissionRay;
			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );
			vec2 refractionCoords = ndcPos.xy / ndcPos.w;
			refractionCoords += 1.0;
			refractionCoords /= 2.0;
			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );
			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );
		
		#endif
		vec3 attenuatedColor = transmittance * transmittedLight.rgb;
		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );
		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;
		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );
	}
#endif`,uv_pars_fragment:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_SPECULARMAP
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_pars_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	varying vec2 vUv;
#endif
#ifdef USE_MAP
	uniform mat3 mapTransform;
	varying vec2 vMapUv;
#endif
#ifdef USE_ALPHAMAP
	uniform mat3 alphaMapTransform;
	varying vec2 vAlphaMapUv;
#endif
#ifdef USE_LIGHTMAP
	uniform mat3 lightMapTransform;
	varying vec2 vLightMapUv;
#endif
#ifdef USE_AOMAP
	uniform mat3 aoMapTransform;
	varying vec2 vAoMapUv;
#endif
#ifdef USE_BUMPMAP
	uniform mat3 bumpMapTransform;
	varying vec2 vBumpMapUv;
#endif
#ifdef USE_NORMALMAP
	uniform mat3 normalMapTransform;
	varying vec2 vNormalMapUv;
#endif
#ifdef USE_DISPLACEMENTMAP
	uniform mat3 displacementMapTransform;
	varying vec2 vDisplacementMapUv;
#endif
#ifdef USE_EMISSIVEMAP
	uniform mat3 emissiveMapTransform;
	varying vec2 vEmissiveMapUv;
#endif
#ifdef USE_METALNESSMAP
	uniform mat3 metalnessMapTransform;
	varying vec2 vMetalnessMapUv;
#endif
#ifdef USE_ROUGHNESSMAP
	uniform mat3 roughnessMapTransform;
	varying vec2 vRoughnessMapUv;
#endif
#ifdef USE_ANISOTROPYMAP
	uniform mat3 anisotropyMapTransform;
	varying vec2 vAnisotropyMapUv;
#endif
#ifdef USE_CLEARCOATMAP
	uniform mat3 clearcoatMapTransform;
	varying vec2 vClearcoatMapUv;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	uniform mat3 clearcoatNormalMapTransform;
	varying vec2 vClearcoatNormalMapUv;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	uniform mat3 clearcoatRoughnessMapTransform;
	varying vec2 vClearcoatRoughnessMapUv;
#endif
#ifdef USE_SHEEN_COLORMAP
	uniform mat3 sheenColorMapTransform;
	varying vec2 vSheenColorMapUv;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	uniform mat3 sheenRoughnessMapTransform;
	varying vec2 vSheenRoughnessMapUv;
#endif
#ifdef USE_IRIDESCENCEMAP
	uniform mat3 iridescenceMapTransform;
	varying vec2 vIridescenceMapUv;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	uniform mat3 iridescenceThicknessMapTransform;
	varying vec2 vIridescenceThicknessMapUv;
#endif
#ifdef USE_SPECULARMAP
	uniform mat3 specularMapTransform;
	varying vec2 vSpecularMapUv;
#endif
#ifdef USE_SPECULAR_COLORMAP
	uniform mat3 specularColorMapTransform;
	varying vec2 vSpecularColorMapUv;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	uniform mat3 specularIntensityMapTransform;
	varying vec2 vSpecularIntensityMapUv;
#endif
#ifdef USE_TRANSMISSIONMAP
	uniform mat3 transmissionMapTransform;
	varying vec2 vTransmissionMapUv;
#endif
#ifdef USE_THICKNESSMAP
	uniform mat3 thicknessMapTransform;
	varying vec2 vThicknessMapUv;
#endif`,uv_vertex:`#if defined( USE_UV ) || defined( USE_ANISOTROPY )
	vUv = vec3( uv, 1 ).xy;
#endif
#ifdef USE_MAP
	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ALPHAMAP
	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_LIGHTMAP
	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_AOMAP
	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_BUMPMAP
	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_NORMALMAP
	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_DISPLACEMENTMAP
	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_EMISSIVEMAP
	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_METALNESSMAP
	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ROUGHNESSMAP
	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_ANISOTROPYMAP
	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOATMAP
	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_NORMALMAP
	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_CLEARCOAT_ROUGHNESSMAP
	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCEMAP
	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_IRIDESCENCE_THICKNESSMAP
	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_COLORMAP
	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SHEEN_ROUGHNESSMAP
	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULARMAP
	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_COLORMAP
	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_SPECULAR_INTENSITYMAP
	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_TRANSMISSIONMAP
	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;
#endif
#ifdef USE_THICKNESSMAP
	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;
#endif`,worldpos_vertex:`#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0
	vec4 worldPosition = vec4( transformed, 1.0 );
	#ifdef USE_BATCHING
		worldPosition = batchingMatrix * worldPosition;
	#endif
	#ifdef USE_INSTANCING
		worldPosition = instanceMatrix * worldPosition;
	#endif
	worldPosition = modelMatrix * worldPosition;
#endif`,background_vert:`varying vec2 vUv;
uniform mat3 uvTransform;
void main() {
	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	gl_Position = vec4( position.xy, 1.0, 1.0 );
}`,background_frag:`uniform sampler2D t2D;
uniform float backgroundIntensity;
varying vec2 vUv;
void main() {
	vec4 texColor = texture2D( t2D, vUv );
	#ifdef DECODE_VIDEO_TEXTURE
		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,backgroundCube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,backgroundCube_frag:`#ifdef ENVMAP_TYPE_CUBE
	uniform samplerCube envMap;
#elif defined( ENVMAP_TYPE_CUBE_UV )
	uniform sampler2D envMap;
#endif
uniform float flipEnvMap;
uniform float backgroundBlurriness;
uniform float backgroundIntensity;
uniform mat3 backgroundRotation;
varying vec3 vWorldDirection;
#include <cube_uv_reflection_fragment>
void main() {
	#ifdef ENVMAP_TYPE_CUBE
		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );
	#elif defined( ENVMAP_TYPE_CUBE_UV )
		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );
	#else
		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );
	#endif
	texColor.rgb *= backgroundIntensity;
	gl_FragColor = texColor;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,cube_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
	gl_Position.z = gl_Position.w;
}`,cube_frag:`uniform samplerCube tCube;
uniform float tFlip;
uniform float opacity;
varying vec3 vWorldDirection;
void main() {
	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );
	gl_FragColor = texColor;
	gl_FragColor.a *= opacity;
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,depth_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
varying vec2 vHighPrecisionZW;
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vHighPrecisionZW = gl_Position.zw;
}`,depth_frag:`#if DEPTH_PACKING == 3200
	uniform float opacity;
#endif
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
varying vec2 vHighPrecisionZW;
void main() {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#if DEPTH_PACKING == 3200
		diffuseColor.a = opacity;
	#endif
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <logdepthbuf_fragment>
	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;
	#if DEPTH_PACKING == 3200
		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );
	#elif DEPTH_PACKING == 3201
		gl_FragColor = packDepthToRGBA( fragCoordZ );
	#elif DEPTH_PACKING == 3202
		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );
	#elif DEPTH_PACKING == 3203
		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );
	#endif
}`,distanceRGBA_vert:`#define DISTANCE
varying vec3 vWorldPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <skinbase_vertex>
	#include <morphinstance_vertex>
	#ifdef USE_DISPLACEMENTMAP
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <worldpos_vertex>
	#include <clipping_planes_vertex>
	vWorldPosition = worldPosition.xyz;
}`,distanceRGBA_frag:`#define DISTANCE
uniform vec3 referencePosition;
uniform float nearDistance;
uniform float farDistance;
varying vec3 vWorldPosition;
#include <common>
#include <packing>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <clipping_planes_pars_fragment>
void main () {
	vec4 diffuseColor = vec4( 1.0 );
	#include <clipping_planes_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	float dist = length( vWorldPosition - referencePosition );
	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );
	dist = saturate( dist );
	gl_FragColor = packDepthToRGBA( dist );
}`,equirect_vert:`varying vec3 vWorldDirection;
#include <common>
void main() {
	vWorldDirection = transformDirection( position, modelMatrix );
	#include <begin_vertex>
	#include <project_vertex>
}`,equirect_frag:`uniform sampler2D tEquirect;
varying vec3 vWorldDirection;
#include <common>
void main() {
	vec3 direction = normalize( vWorldDirection );
	vec2 sampleUV = equirectUv( direction );
	gl_FragColor = texture2D( tEquirect, sampleUV );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
}`,linedashed_vert:`uniform float scale;
attribute float lineDistance;
varying float vLineDistance;
#include <common>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	vLineDistance = scale * lineDistance;
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,linedashed_frag:`uniform vec3 diffuse;
uniform float opacity;
uniform float dashSize;
uniform float totalSize;
varying float vLineDistance;
#include <common>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	if ( mod( vLineDistance, totalSize ) > dashSize ) {
		discard;
	}
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,meshbasic_vert:`#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )
		#include <beginnormal_vertex>
		#include <morphnormal_vertex>
		#include <skinbase_vertex>
		#include <skinnormal_vertex>
		#include <defaultnormal_vertex>
	#endif
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <fog_vertex>
}`,meshbasic_frag:`uniform vec3 diffuse;
uniform float opacity;
#ifndef FLAT_SHADED
	varying vec3 vNormal;
#endif
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	#ifdef USE_LIGHTMAP
		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );
		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;
	#else
		reflectedLight.indirectDiffuse += vec3( 1.0 );
	#endif
	#include <aomap_fragment>
	reflectedLight.indirectDiffuse *= diffuseColor.rgb;
	vec3 outgoingLight = reflectedLight.indirectDiffuse;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshlambert_vert:`#define LAMBERT
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshlambert_frag:`#define LAMBERT
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_lambert_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_lambert_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshmatcap_vert:`#define MATCAP
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <color_pars_vertex>
#include <displacementmap_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
	vViewPosition = - mvPosition.xyz;
}`,meshmatcap_frag:`#define MATCAP
uniform vec3 diffuse;
uniform float opacity;
uniform sampler2D matcap;
varying vec3 vViewPosition;
#include <common>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	vec3 viewDir = normalize( vViewPosition );
	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );
	vec3 y = cross( viewDir, x );
	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;
	#ifdef USE_MATCAP
		vec4 matcapColor = texture2D( matcap, uv );
	#else
		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );
	#endif
	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshnormal_vert:`#define NORMAL
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	vViewPosition = - mvPosition.xyz;
#endif
}`,meshnormal_frag:`#define NORMAL
uniform float opacity;
#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )
	varying vec3 vViewPosition;
#endif
#include <packing>
#include <uv_pars_fragment>
#include <normal_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );
	#include <clipping_planes_fragment>
	#include <logdepthbuf_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );
	#ifdef OPAQUE
		gl_FragColor.a = 1.0;
	#endif
}`,meshphong_vert:`#define PHONG
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <envmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <envmap_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshphong_frag:`#define PHONG
uniform vec3 diffuse;
uniform vec3 emissive;
uniform vec3 specular;
uniform float shininess;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_phong_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <specularmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <specularmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_phong_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;
	#include <envmap_fragment>
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshphysical_vert:`#define STANDARD
varying vec3 vViewPosition;
#ifdef USE_TRANSMISSION
	varying vec3 vWorldPosition;
#endif
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
#ifdef USE_TRANSMISSION
	vWorldPosition = worldPosition.xyz;
#endif
}`,meshphysical_frag:`#define STANDARD
#ifdef PHYSICAL
	#define IOR
	#define USE_SPECULAR
#endif
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float roughness;
uniform float metalness;
uniform float opacity;
#ifdef IOR
	uniform float ior;
#endif
#ifdef USE_SPECULAR
	uniform float specularIntensity;
	uniform vec3 specularColor;
	#ifdef USE_SPECULAR_COLORMAP
		uniform sampler2D specularColorMap;
	#endif
	#ifdef USE_SPECULAR_INTENSITYMAP
		uniform sampler2D specularIntensityMap;
	#endif
#endif
#ifdef USE_CLEARCOAT
	uniform float clearcoat;
	uniform float clearcoatRoughness;
#endif
#ifdef USE_DISPERSION
	uniform float dispersion;
#endif
#ifdef USE_IRIDESCENCE
	uniform float iridescence;
	uniform float iridescenceIOR;
	uniform float iridescenceThicknessMinimum;
	uniform float iridescenceThicknessMaximum;
#endif
#ifdef USE_SHEEN
	uniform vec3 sheenColor;
	uniform float sheenRoughness;
	#ifdef USE_SHEEN_COLORMAP
		uniform sampler2D sheenColorMap;
	#endif
	#ifdef USE_SHEEN_ROUGHNESSMAP
		uniform sampler2D sheenRoughnessMap;
	#endif
#endif
#ifdef USE_ANISOTROPY
	uniform vec2 anisotropyVector;
	#ifdef USE_ANISOTROPYMAP
		uniform sampler2D anisotropyMap;
	#endif
#endif
varying vec3 vViewPosition;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <iridescence_fragment>
#include <cube_uv_reflection_fragment>
#include <envmap_common_pars_fragment>
#include <envmap_physical_pars_fragment>
#include <fog_pars_fragment>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_physical_pars_fragment>
#include <transmission_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <clearcoat_pars_fragment>
#include <iridescence_pars_fragment>
#include <roughnessmap_pars_fragment>
#include <metalnessmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <roughnessmap_fragment>
	#include <metalnessmap_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <clearcoat_normal_fragment_begin>
	#include <clearcoat_normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_physical_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;
	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;
	#include <transmission_fragment>
	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;
	#ifdef USE_SHEEN
		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );
		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;
	#endif
	#ifdef USE_CLEARCOAT
		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );
		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );
		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;
	#endif
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,meshtoon_vert:`#define TOON
varying vec3 vViewPosition;
#include <common>
#include <batching_pars_vertex>
#include <uv_pars_vertex>
#include <displacementmap_pars_vertex>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <normal_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <shadowmap_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <normal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <displacementmap_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	vViewPosition = - mvPosition.xyz;
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,meshtoon_frag:`#define TOON
uniform vec3 diffuse;
uniform vec3 emissive;
uniform float opacity;
#include <common>
#include <packing>
#include <dithering_pars_fragment>
#include <color_pars_fragment>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <aomap_pars_fragment>
#include <lightmap_pars_fragment>
#include <emissivemap_pars_fragment>
#include <gradientmap_pars_fragment>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <normal_pars_fragment>
#include <lights_toon_pars_fragment>
#include <shadowmap_pars_fragment>
#include <bumpmap_pars_fragment>
#include <normalmap_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );
	vec3 totalEmissiveRadiance = emissive;
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <color_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	#include <normal_fragment_begin>
	#include <normal_fragment_maps>
	#include <emissivemap_fragment>
	#include <lights_toon_fragment>
	#include <lights_fragment_begin>
	#include <lights_fragment_maps>
	#include <lights_fragment_end>
	#include <aomap_fragment>
	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
	#include <dithering_fragment>
}`,points_vert:`uniform float size;
uniform float scale;
#include <common>
#include <color_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
#ifdef USE_POINTS_UV
	varying vec2 vUv;
	uniform mat3 uvTransform;
#endif
void main() {
	#ifdef USE_POINTS_UV
		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;
	#endif
	#include <color_vertex>
	#include <morphinstance_vertex>
	#include <morphcolor_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <project_vertex>
	gl_PointSize = size;
	#ifdef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );
	#endif
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <worldpos_vertex>
	#include <fog_vertex>
}`,points_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <color_pars_fragment>
#include <map_particle_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_particle_fragment>
	#include <color_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
	#include <premultiplied_alpha_fragment>
}`,shadow_vert:`#include <common>
#include <batching_pars_vertex>
#include <fog_pars_vertex>
#include <morphtarget_pars_vertex>
#include <skinning_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <shadowmap_pars_vertex>
void main() {
	#include <batching_vertex>
	#include <beginnormal_vertex>
	#include <morphinstance_vertex>
	#include <morphnormal_vertex>
	#include <skinbase_vertex>
	#include <skinnormal_vertex>
	#include <defaultnormal_vertex>
	#include <begin_vertex>
	#include <morphtarget_vertex>
	#include <skinning_vertex>
	#include <project_vertex>
	#include <logdepthbuf_vertex>
	#include <worldpos_vertex>
	#include <shadowmap_vertex>
	#include <fog_vertex>
}`,shadow_frag:`uniform vec3 color;
uniform float opacity;
#include <common>
#include <packing>
#include <fog_pars_fragment>
#include <bsdfs>
#include <lights_pars_begin>
#include <logdepthbuf_pars_fragment>
#include <shadowmap_pars_fragment>
#include <shadowmask_pars_fragment>
void main() {
	#include <logdepthbuf_fragment>
	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`,sprite_vert:`uniform float rotation;
uniform vec2 center;
#include <common>
#include <uv_pars_vertex>
#include <fog_pars_vertex>
#include <logdepthbuf_pars_vertex>
#include <clipping_planes_pars_vertex>
void main() {
	#include <uv_vertex>
	vec4 mvPosition = modelViewMatrix[ 3 ];
	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );
	#ifndef USE_SIZEATTENUATION
		bool isPerspective = isPerspectiveMatrix( projectionMatrix );
		if ( isPerspective ) scale *= - mvPosition.z;
	#endif
	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;
	vec2 rotatedPosition;
	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;
	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;
	mvPosition.xy += rotatedPosition;
	gl_Position = projectionMatrix * mvPosition;
	#include <logdepthbuf_vertex>
	#include <clipping_planes_vertex>
	#include <fog_vertex>
}`,sprite_frag:`uniform vec3 diffuse;
uniform float opacity;
#include <common>
#include <uv_pars_fragment>
#include <map_pars_fragment>
#include <alphamap_pars_fragment>
#include <alphatest_pars_fragment>
#include <alphahash_pars_fragment>
#include <fog_pars_fragment>
#include <logdepthbuf_pars_fragment>
#include <clipping_planes_pars_fragment>
void main() {
	vec4 diffuseColor = vec4( diffuse, opacity );
	#include <clipping_planes_fragment>
	vec3 outgoingLight = vec3( 0.0 );
	#include <logdepthbuf_fragment>
	#include <map_fragment>
	#include <alphamap_fragment>
	#include <alphatest_fragment>
	#include <alphahash_fragment>
	outgoingLight = diffuseColor.rgb;
	#include <opaque_fragment>
	#include <tonemapping_fragment>
	#include <colorspace_fragment>
	#include <fog_fragment>
}`},he={common:{diffuse:{value:new ye(16777215)},opacity:{value:1},map:{value:null},mapTransform:{value:new De},alphaMap:{value:null},alphaMapTransform:{value:new De},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new De}},envmap:{envMap:{value:null},envMapRotation:{value:new De},flipEnvMap:{value:-1},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new De}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new De}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new De},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new De},normalScale:{value:new oe(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new De},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new De}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new De}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new De}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new ye(16777215)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMap:{value:[]},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotShadowMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMap:{value:[]},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null}},points:{diffuse:{value:new ye(16777215)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new De},alphaTest:{value:0},uvTransform:{value:new De}},sprite:{diffuse:{value:new ye(16777215)},opacity:{value:1},center:{value:new oe(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new De},alphaMap:{value:null},alphaMapTransform:{value:new De},alphaTest:{value:0}}},di={basic:{uniforms:Dt([he.common,he.specularmap,he.envmap,he.aomap,he.lightmap,he.fog]),vertexShader:Ne.meshbasic_vert,fragmentShader:Ne.meshbasic_frag},lambert:{uniforms:Dt([he.common,he.specularmap,he.envmap,he.aomap,he.lightmap,he.emissivemap,he.bumpmap,he.normalmap,he.displacementmap,he.fog,he.lights,{emissive:{value:new ye(0)}}]),vertexShader:Ne.meshlambert_vert,fragmentShader:Ne.meshlambert_frag},phong:{uniforms:Dt([he.common,he.specularmap,he.envmap,he.aomap,he.lightmap,he.emissivemap,he.bumpmap,he.normalmap,he.displacementmap,he.fog,he.lights,{emissive:{value:new ye(0)},specular:{value:new ye(1118481)},shininess:{value:30}}]),vertexShader:Ne.meshphong_vert,fragmentShader:Ne.meshphong_frag},standard:{uniforms:Dt([he.common,he.envmap,he.aomap,he.lightmap,he.emissivemap,he.bumpmap,he.normalmap,he.displacementmap,he.roughnessmap,he.metalnessmap,he.fog,he.lights,{emissive:{value:new ye(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:Ne.meshphysical_vert,fragmentShader:Ne.meshphysical_frag},toon:{uniforms:Dt([he.common,he.aomap,he.lightmap,he.emissivemap,he.bumpmap,he.normalmap,he.displacementmap,he.gradientmap,he.fog,he.lights,{emissive:{value:new ye(0)}}]),vertexShader:Ne.meshtoon_vert,fragmentShader:Ne.meshtoon_frag},matcap:{uniforms:Dt([he.common,he.bumpmap,he.normalmap,he.displacementmap,he.fog,{matcap:{value:null}}]),vertexShader:Ne.meshmatcap_vert,fragmentShader:Ne.meshmatcap_frag},points:{uniforms:Dt([he.points,he.fog]),vertexShader:Ne.points_vert,fragmentShader:Ne.points_frag},dashed:{uniforms:Dt([he.common,he.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:Ne.linedashed_vert,fragmentShader:Ne.linedashed_frag},depth:{uniforms:Dt([he.common,he.displacementmap]),vertexShader:Ne.depth_vert,fragmentShader:Ne.depth_frag},normal:{uniforms:Dt([he.common,he.bumpmap,he.normalmap,he.displacementmap,{opacity:{value:1}}]),vertexShader:Ne.meshnormal_vert,fragmentShader:Ne.meshnormal_frag},sprite:{uniforms:Dt([he.sprite,he.fog]),vertexShader:Ne.sprite_vert,fragmentShader:Ne.sprite_frag},background:{uniforms:{uvTransform:{value:new De},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:Ne.background_vert,fragmentShader:Ne.background_frag},backgroundCube:{uniforms:{envMap:{value:null},flipEnvMap:{value:-1},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new De}},vertexShader:Ne.backgroundCube_vert,fragmentShader:Ne.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:Ne.cube_vert,fragmentShader:Ne.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:Ne.equirect_vert,fragmentShader:Ne.equirect_frag},distanceRGBA:{uniforms:Dt([he.common,he.displacementmap,{referencePosition:{value:new M},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:Ne.distanceRGBA_vert,fragmentShader:Ne.distanceRGBA_frag},shadow:{uniforms:Dt([he.lights,he.fog,{color:{value:new ye(0)},opacity:{value:1}}]),vertexShader:Ne.shadow_vert,fragmentShader:Ne.shadow_frag}};di.physical={uniforms:Dt([di.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new De},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new De},clearcoatNormalScale:{value:new oe(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new De},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new De},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new De},sheen:{value:0},sheenColor:{value:new ye(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new De},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new De},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new De},transmissionSamplerSize:{value:new oe},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new De},attenuationDistance:{value:0},attenuationColor:{value:new ye(0)},specularColor:{value:new ye(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new De},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new De},anisotropyVector:{value:new oe},anisotropyMap:{value:null},anisotropyMapTransform:{value:new De}}]),vertexShader:Ne.meshphysical_vert,fragmentShader:Ne.meshphysical_frag};var kr={r:0,b:0,g:0},rn=new Et,mp=new Ee;function fp(s,e,t,i,n,r,a){let o=new ye(0),l,c,h=r===!0?0:1,d=null,u=0,p=null;function m(f){let g=f.isScene===!0?f.background:null;return g&&g.isTexture&&(g=(f.backgroundBlurriness>0?t:e).get(g)),g}function v(f,g){f.getRGB(kr,Zu(s)),i.buffers.color.setClear(kr.r,kr.g,kr.b,g,a)}return{getClearColor:function(){return o},setClearColor:function(f,g=1){o.set(f),h=g,v(o,h)},getClearAlpha:function(){return h},setClearAlpha:function(f){h=f,v(o,h)},render:function(f){let g=!1,y=m(f);y===null?v(o,h):y&&y.isColor&&(v(y,1),g=!0);let x=s.xr.getEnvironmentBlendMode();x==="additive"?i.buffers.color.setClear(0,0,0,1,a):x==="alpha-blend"&&i.buffers.color.setClear(0,0,0,0,a),(s.autoClear||g)&&(i.buffers.depth.setTest(!0),i.buffers.depth.setMask(!0),i.buffers.color.setMask(!0),s.clear(s.autoClearColor,s.autoClearDepth,s.autoClearStencil))},addToRenderList:function(f,g){let y=m(g);y&&(y.isCubeTexture||y.mapping===za)?(c===void 0&&(c=new Ce(new Ct(1,1,1),new Tt({name:"BackgroundCubeMaterial",uniforms:Jn(di.backgroundCube.uniforms),vertexShader:di.backgroundCube.vertexShader,fragmentShader:di.backgroundCube.fragmentShader,side:1,depthTest:!1,depthWrite:!1,fog:!1})),c.geometry.deleteAttribute("normal"),c.geometry.deleteAttribute("uv"),c.onBeforeRender=function(x,_,b){this.matrixWorld.copyPosition(b.matrixWorld)},Object.defineProperty(c.material,"envMap",{get:function(){return this.uniforms.envMap.value}}),n.update(c)),rn.copy(g.backgroundRotation),rn.x*=-1,rn.y*=-1,rn.z*=-1,y.isCubeTexture&&y.isRenderTargetTexture===!1&&(rn.y*=-1,rn.z*=-1),c.material.uniforms.envMap.value=y,c.material.uniforms.flipEnvMap.value=y.isCubeTexture&&y.isRenderTargetTexture===!1?-1:1,c.material.uniforms.backgroundBlurriness.value=g.backgroundBlurriness,c.material.uniforms.backgroundIntensity.value=g.backgroundIntensity,c.material.uniforms.backgroundRotation.value.setFromMatrix4(mp.makeRotationFromEuler(rn)),c.material.toneMapped=je.getTransfer(y.colorSpace)!==et,d===y&&u===y.version&&p===s.toneMapping||(c.material.needsUpdate=!0,d=y,u=y.version,p=s.toneMapping),c.layers.enableAll(),f.unshift(c,c.geometry,c.material,0,0,null)):y&&y.isTexture&&(l===void 0&&(l=new Ce(new Gt(2,2),new Tt({name:"BackgroundMaterial",uniforms:Jn(di.background.uniforms),vertexShader:di.background.vertexShader,fragmentShader:di.background.fragmentShader,side:0,depthTest:!1,depthWrite:!1,fog:!1})),l.geometry.deleteAttribute("normal"),Object.defineProperty(l.material,"map",{get:function(){return this.uniforms.t2D.value}}),n.update(l)),l.material.uniforms.t2D.value=y,l.material.uniforms.backgroundIntensity.value=g.backgroundIntensity,l.material.toneMapped=je.getTransfer(y.colorSpace)!==et,y.matrixAutoUpdate===!0&&y.updateMatrix(),l.material.uniforms.uvTransform.value.copy(y.matrix),d===y&&u===y.version&&p===s.toneMapping||(l.material.needsUpdate=!0,d=y,u=y.version,p=s.toneMapping),l.layers.enableAll(),f.unshift(l,l.geometry,l.material,0,0,null))}}}function gp(s,e){let t=s.getParameter(s.MAX_VERTEX_ATTRIBS),i={},n=c(null),r=n,a=!1;function o(g){return s.bindVertexArray(g)}function l(g){return s.deleteVertexArray(g)}function c(g){let y=[],x=[],_=[];for(let b=0;b<t;b++)y[b]=0,x[b]=0,_[b]=0;return{geometry:null,program:null,wireframe:!1,newAttributes:y,enabledAttributes:x,attributeDivisors:_,object:g,attributes:{},index:null}}function h(){let g=r.newAttributes;for(let y=0,x=g.length;y<x;y++)g[y]=0}function d(g){u(g,0)}function u(g,y){let x=r.newAttributes,_=r.enabledAttributes,b=r.attributeDivisors;x[g]=1,_[g]===0&&(s.enableVertexAttribArray(g),_[g]=1),b[g]!==y&&(s.vertexAttribDivisor(g,y),b[g]=y)}function p(){let g=r.newAttributes,y=r.enabledAttributes;for(let x=0,_=y.length;x<_;x++)y[x]!==g[x]&&(s.disableVertexAttribArray(x),y[x]=0)}function m(g,y,x,_,b,S,R){R===!0?s.vertexAttribIPointer(g,y,x,b,S):s.vertexAttribPointer(g,y,x,_,b,S)}function v(){f(),a=!0,r!==n&&(r=n,o(r.object))}function f(){n.geometry=null,n.program=null,n.wireframe=!1}return{setup:function(g,y,x,_,b){let S=!1,R=function(P,C,B){let z=B.wireframe===!0,D=i[P.id];D===void 0&&(D={},i[P.id]=D);let F=D[C.id];F===void 0&&(F={},D[C.id]=F);let U=F[z];return U===void 0&&(U=c(s.createVertexArray()),F[z]=U),U}(_,x,y);r!==R&&(r=R,o(r.object)),S=function(P,C,B,z){let D=r.attributes,F=C.attributes,U=0,X=B.getAttributes();for(let j in X)if(X[j].location>=0){let Z=D[j],$=F[j];if($===void 0&&(j==="instanceMatrix"&&P.instanceMatrix&&($=P.instanceMatrix),j==="instanceColor"&&P.instanceColor&&($=P.instanceColor)),Z===void 0||Z.attribute!==$||$&&Z.data!==$.data)return!0;U++}return r.attributesNum!==U||r.index!==z}(g,_,x,b),S&&function(P,C,B,z){let D={},F=C.attributes,U=0,X=B.getAttributes();for(let j in X)if(X[j].location>=0){let Z=F[j];Z===void 0&&(j==="instanceMatrix"&&P.instanceMatrix&&(Z=P.instanceMatrix),j==="instanceColor"&&P.instanceColor&&(Z=P.instanceColor));let $={};$.attribute=Z,Z&&Z.data&&($.data=Z.data),D[j]=$,U++}r.attributes=D,r.attributesNum=U,r.index=z}(g,_,x,b),b!==null&&e.update(b,s.ELEMENT_ARRAY_BUFFER),(S||a)&&(a=!1,function(P,C,B,z){h();let D=z.attributes,F=B.getAttributes(),U=C.defaultAttributeValues;for(let X in F){let j=F[X];if(j.location>=0){let Z=D[X];if(Z===void 0&&(X==="instanceMatrix"&&P.instanceMatrix&&(Z=P.instanceMatrix),X==="instanceColor"&&P.instanceColor&&(Z=P.instanceColor)),Z!==void 0){let $=Z.normalized,ue=Z.itemSize,_e=e.get(Z);if(_e===void 0)continue;let K=_e.buffer,ae=_e.type,pe=_e.bytesPerElement,ge=ae===s.INT||ae===s.UNSIGNED_INT||Z.gpuType===Nc;if(Z.isInterleavedBufferAttribute){let ce=Z.data,A=ce.stride,T=Z.offset;if(ce.isInstancedInterleavedBuffer){for(let k=0;k<j.locationSize;k++)u(j.location+k,ce.meshPerAttribute);P.isInstancedMesh!==!0&&z._maxInstanceCount===void 0&&(z._maxInstanceCount=ce.meshPerAttribute*ce.count)}else for(let k=0;k<j.locationSize;k++)d(j.location+k);s.bindBuffer(s.ARRAY_BUFFER,K);for(let k=0;k<j.locationSize;k++)m(j.location+k,ue/j.locationSize,ae,$,A*pe,(T+ue/j.locationSize*k)*pe,ge)}else{if(Z.isInstancedBufferAttribute){for(let ce=0;ce<j.locationSize;ce++)u(j.location+ce,Z.meshPerAttribute);P.isInstancedMesh!==!0&&z._maxInstanceCount===void 0&&(z._maxInstanceCount=Z.meshPerAttribute*Z.count)}else for(let ce=0;ce<j.locationSize;ce++)d(j.location+ce);s.bindBuffer(s.ARRAY_BUFFER,K);for(let ce=0;ce<j.locationSize;ce++)m(j.location+ce,ue/j.locationSize,ae,$,ue*pe,ue/j.locationSize*ce*pe,ge)}}else if(U!==void 0){let $=U[X];if($!==void 0)switch($.length){case 2:s.vertexAttrib2fv(j.location,$);break;case 3:s.vertexAttrib3fv(j.location,$);break;case 4:s.vertexAttrib4fv(j.location,$);break;default:s.vertexAttrib1fv(j.location,$)}}}}p()}(g,y,x,_),b!==null&&s.bindBuffer(s.ELEMENT_ARRAY_BUFFER,e.get(b).buffer))},reset:v,resetDefaultState:f,dispose:function(){v();for(let g in i){let y=i[g];for(let x in y){let _=y[x];for(let b in _)l(_[b].object),delete _[b];delete y[x]}delete i[g]}},releaseStatesOfGeometry:function(g){if(i[g.id]===void 0)return;let y=i[g.id];for(let x in y){let _=y[x];for(let b in _)l(_[b].object),delete _[b];delete y[x]}delete i[g.id]},releaseStatesOfProgram:function(g){for(let y in i){let x=i[y];if(x[g.id]===void 0)continue;let _=x[g.id];for(let b in _)l(_[b].object),delete _[b];delete x[g.id]}},initAttributes:h,enableAttribute:d,disableUnusedAttributes:p}}function vp(s,e,t){let i;function n(r,a,o){o!==0&&(s.drawArraysInstanced(i,r,a,o),t.update(a,i,o))}this.setMode=function(r){i=r},this.render=function(r,a){s.drawArrays(i,r,a),t.update(a,i,1)},this.renderInstances=n,this.renderMultiDraw=function(r,a,o){if(o===0)return;e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(i,r,0,a,0,o);let l=0;for(let c=0;c<o;c++)l+=a[c];t.update(l,i,1)},this.renderMultiDrawInstances=function(r,a,o,l){if(o===0)return;let c=e.get("WEBGL_multi_draw");if(c===null)for(let h=0;h<r.length;h++)n(r[h],a[h],l[h]);else{c.multiDrawArraysInstancedWEBGL(i,r,0,a,0,l,0,o);let h=0;for(let d=0;d<o;d++)h+=a[d]*l[d];t.update(h,i,1)}}}function yp(s,e,t,i){let n;function r(u){if(u==="highp"){if(s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.HIGH_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.HIGH_FLOAT).precision>0)return"highp";u="mediump"}return u==="mediump"&&s.getShaderPrecisionFormat(s.VERTEX_SHADER,s.MEDIUM_FLOAT).precision>0&&s.getShaderPrecisionFormat(s.FRAGMENT_SHADER,s.MEDIUM_FLOAT).precision>0?"mediump":"lowp"}let a=t.precision!==void 0?t.precision:"highp",o=r(a);o!==a&&(console.warn("THREE.WebGLRenderer:",a,"not supported, using",o,"instead."),a=o);let l=t.logarithmicDepthBuffer===!0,c=t.reverseDepthBuffer===!0&&e.has("EXT_clip_control"),h=s.getParameter(s.MAX_TEXTURE_IMAGE_UNITS),d=s.getParameter(s.MAX_VERTEX_TEXTURE_IMAGE_UNITS);return{isWebGL2:!0,getMaxAnisotropy:function(){if(n!==void 0)return n;if(e.has("EXT_texture_filter_anisotropic")===!0){let u=e.get("EXT_texture_filter_anisotropic");n=s.getParameter(u.MAX_TEXTURE_MAX_ANISOTROPY_EXT)}else n=0;return n},getMaxPrecision:r,textureFormatReadable:function(u){return u===mi||i.convert(u)===s.getParameter(s.IMPLEMENTATION_COLOR_READ_FORMAT)},textureTypeReadable:function(u){let p=u===vn&&(e.has("EXT_color_buffer_half_float")||e.has("EXT_color_buffer_float"));return!(u!==Vi&&i.convert(u)!==s.getParameter(s.IMPLEMENTATION_COLOR_READ_TYPE)&&u!==pi&&!p)},precision:a,logarithmicDepthBuffer:l,reverseDepthBuffer:c,maxTextures:h,maxVertexTextures:d,maxTextureSize:s.getParameter(s.MAX_TEXTURE_SIZE),maxCubemapSize:s.getParameter(s.MAX_CUBE_MAP_TEXTURE_SIZE),maxAttributes:s.getParameter(s.MAX_VERTEX_ATTRIBS),maxVertexUniforms:s.getParameter(s.MAX_VERTEX_UNIFORM_VECTORS),maxVaryings:s.getParameter(s.MAX_VARYING_VECTORS),maxFragmentUniforms:s.getParameter(s.MAX_FRAGMENT_UNIFORM_VECTORS),vertexTextures:d>0,maxSamples:s.getParameter(s.MAX_SAMPLES)}}function xp(s){let e=this,t=null,i=0,n=!1,r=!1,a=new wi,o=new De,l={value:null,needsUpdate:!1};function c(h,d,u,p){let m=h!==null?h.length:0,v=null;if(m!==0){if(v=l.value,p!==!0||v===null){let f=u+4*m,g=d.matrixWorldInverse;o.getNormalMatrix(g),(v===null||v.length<f)&&(v=new Float32Array(f));for(let y=0,x=u;y!==m;++y,x+=4)a.copy(h[y]).applyMatrix4(g,o),a.normal.toArray(v,x),v[x+3]=a.constant}l.value=v,l.needsUpdate=!0}return e.numPlanes=m,e.numIntersection=0,v}this.uniform=l,this.numPlanes=0,this.numIntersection=0,this.init=function(h,d){let u=h.length!==0||d||i!==0||n;return n=d,i=h.length,u},this.beginShadows=function(){r=!0,c(null)},this.endShadows=function(){r=!1},this.setGlobalState=function(h,d){t=c(h,d,0)},this.setState=function(h,d,u){let p=h.clippingPlanes,m=h.clipIntersection,v=h.clipShadows,f=s.get(h);if(!n||p===null||p.length===0||r&&!v)r?c(null):function(){l.value!==t&&(l.value=t,l.needsUpdate=i>0),e.numPlanes=i,e.numIntersection=0}();else{let g=r?0:i,y=4*g,x=f.clippingState||null;l.value=x,x=c(p,d,y,u);for(let _=0;_!==y;++_)x[_]=t[_];f.clippingState=x,this.numIntersection=m?this.numPlanes:0,this.numPlanes+=g}}}function _p(s){let e=new WeakMap;function t(n,r){return r===cl?n.mapping=Xn:r===hl&&(n.mapping=qn),n}function i(n){let r=n.target;r.removeEventListener("dispose",i);let a=e.get(r);a!==void 0&&(e.delete(r),a.dispose())}return{get:function(n){if(n&&n.isTexture){let r=n.mapping;if(r===cl||r===hl){if(e.has(n))return t(e.get(n).texture,n.mapping);{let a=n.image;if(a&&a.height>0){let o=new Xl(a.height);return o.fromEquirectangularTexture(s,n),e.set(n,o),n.addEventListener("dispose",i),t(o.texture,n.mapping)}return null}}}return n},dispose:function(){e=new WeakMap}}}var Qn=class extends Ws{constructor(e=-1,t=1,i=1,n=-1,r=.1,a=2e3){super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=e,this.right=t,this.top=i,this.bottom=n,this.near=r,this.far=a,this.updateProjectionMatrix()}copy(e,t){return super.copy(e,t),this.left=e.left,this.right=e.right,this.top=e.top,this.bottom=e.bottom,this.near=e.near,this.far=e.far,this.zoom=e.zoom,this.view=e.view===null?null:Object.assign({},e.view),this}setViewOffset(e,t,i,n,r,a){this.view===null&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=e,this.view.fullHeight=t,this.view.offsetX=i,this.view.offsetY=n,this.view.width=r,this.view.height=a,this.updateProjectionMatrix()}clearViewOffset(){this.view!==null&&(this.view.enabled=!1),this.updateProjectionMatrix()}updateProjectionMatrix(){let e=(this.right-this.left)/(2*this.zoom),t=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,n=(this.top+this.bottom)/2,r=i-e,a=i+e,o=n+t,l=n-t;if(this.view!==null&&this.view.enabled){let c=(this.right-this.left)/this.view.fullWidth/this.zoom,h=(this.top-this.bottom)/this.view.fullHeight/this.zoom;r+=c*this.view.offsetX,a=r+c*this.view.width,o-=h*this.view.offsetY,l=o-h*this.view.height}this.projectionMatrix.makeOrthographic(r,a,o,l,this.near,this.far,this.coordinateSystem),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()}toJSON(e){let t=super.toJSON(e);return t.object.zoom=this.zoom,t.object.left=this.left,t.object.right=this.right,t.object.top=this.top,t.object.bottom=this.bottom,t.object.near=this.near,t.object.far=this.far,this.view!==null&&(t.object.view=Object.assign({},this.view)),t}},Yh=[.125,.215,.35,.446,.526,.582],Ts=20,qo=new Qn,$h=new ye,jo=null,Yo=0,$o=0,Zo=!1,on=(1+Math.sqrt(5))/2,Un=1/on,Zh=[new M(-on,Un,0),new M(on,Un,0),new M(-Un,0,on),new M(Un,0,on),new M(0,on,-Un),new M(0,on,Un),new M(-1,1,-1),new M(1,1,-1),new M(-1,1,1),new M(1,1,1)],es=class{constructor(e){this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._lodPlanes=[],this._sizeLods=[],this._sigmas=[],this._blurMaterial=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._compileMaterial(this._blurMaterial)}fromScene(e,t=0,i=.1,n=100){jo=this._renderer.getRenderTarget(),Yo=this._renderer.getActiveCubeFace(),$o=this._renderer.getActiveMipmapLevel(),Zo=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(256);let r=this._allocateTargets();return r.depthBuffer=!0,this._sceneToCubeUV(e,i,n,r),t>0&&this._blur(r,0,0,t),this._applyPMREM(r),this._cleanup(r),r}fromEquirectangular(e,t=null){return this._fromTexture(e,t)}fromCubemap(e,t=null){return this._fromTexture(e,t)}compileCubemapShader(){this._cubemapMaterial===null&&(this._cubemapMaterial=Qh(),this._compileMaterial(this._cubemapMaterial))}compileEquirectangularShader(){this._equirectMaterial===null&&(this._equirectMaterial=Kh(),this._compileMaterial(this._equirectMaterial))}dispose(){this._dispose(),this._cubemapMaterial!==null&&this._cubemapMaterial.dispose(),this._equirectMaterial!==null&&this._equirectMaterial.dispose()}_setSize(e){this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)}_dispose(){this._blurMaterial!==null&&this._blurMaterial.dispose(),this._pingPongRenderTarget!==null&&this._pingPongRenderTarget.dispose();for(let e=0;e<this._lodPlanes.length;e++)this._lodPlanes[e].dispose()}_cleanup(e){this._renderer.setRenderTarget(jo,Yo,$o),this._renderer.xr.enabled=Zo,e.scissorTest=!1,Fr(e,0,0,e.width,e.height)}_fromTexture(e,t){e.mapping===Xn||e.mapping===qn?this._setSize(e.image.length===0?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),jo=this._renderer.getRenderTarget(),Yo=this._renderer.getActiveCubeFace(),$o=this._renderer.getActiveMipmapLevel(),Zo=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;let i=t||this._allocateTargets();return this._textureToCubeUV(e,i),this._applyPMREM(i),this._cleanup(i),i}_allocateTargets(){let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,i={magFilter:Ti,minFilter:Ti,generateMipmaps:!1,type:vn,format:mi,colorSpace:os,depthBuffer:!1},n=Jh(e,t,i);if(this._pingPongRenderTarget===null||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){this._pingPongRenderTarget!==null&&this._dispose(),this._pingPongRenderTarget=Jh(e,t,i);let{_lodMax:r}=this;({sizeLods:this._sizeLods,lodPlanes:this._lodPlanes,sigmas:this._sigmas}=function(a){let o=[],l=[],c=[],h=a,d=a-4+1+Yh.length;for(let u=0;u<d;u++){let p=Math.pow(2,h);l.push(p);let m=1/p;u>a-4?m=Yh[u-a+4-1]:u===0&&(m=0),c.push(m);let v=1/(p-2),f=-v,g=1+v,y=[f,f,g,f,g,g,f,f,g,g,f,g],x=6,_=6,b=3,S=2,R=1,P=new Float32Array(b*_*x),C=new Float32Array(S*_*x),B=new Float32Array(R*_*x);for(let D=0;D<x;D++){let F=D%3*2/3-1,U=D>2?0:-1,X=[F,U,0,F+2/3,U,0,F+2/3,U+1,0,F,U,0,F+2/3,U+1,0,F,U+1,0];P.set(X,b*_*D),C.set(y,S*_*D);let j=[D,D,D,D,D,D];B.set(j,R*_*D)}let z=new Ve;z.setAttribute("position",new We(P,b)),z.setAttribute("uv",new We(C,S)),z.setAttribute("faceIndex",new We(B,R)),o.push(z),h>4&&h--}return{lodPlanes:o,sizeLods:l,sigmas:c}}(r)),this._blurMaterial=function(a,o,l){let c=new Float32Array(Ts),h=new M(0,1,0);return new Tt({name:"SphericalGaussianBlur",defines:{n:Ts,CUBEUV_TEXEL_WIDTH:1/o,CUBEUV_TEXEL_HEIGHT:1/l,CUBEUV_MAX_MIP:`${a}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:c},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:h}},vertexShader:Wc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}(r,e,t)}return n}_compileMaterial(e){let t=new Ce(this._lodPlanes[0],e);this._renderer.compile(t,qo)}_sceneToCubeUV(e,t,i,n){let r=new Ut(90,1,t,i),a=[1,-1,1,1,1,1],o=[1,1,1,-1,-1,-1],l=this._renderer,c=l.autoClear,h=l.toneMapping;l.getClearColor($h),l.toneMapping=0,l.autoClear=!1;let d=new oi({name:"PMREM.Background",side:1,depthWrite:!1,depthTest:!1}),u=new Ce(new Ct,d),p=!1,m=e.background;m?m.isColor&&(d.color.copy(m),e.background=null,p=!0):(d.color.copy($h),p=!0);for(let v=0;v<6;v++){let f=v%3;f===0?(r.up.set(0,a[v],0),r.lookAt(o[v],0,0)):f===1?(r.up.set(0,0,a[v]),r.lookAt(0,o[v],0)):(r.up.set(0,a[v],0),r.lookAt(0,0,o[v]));let g=this._cubeSize;Fr(n,f*g,v>2?g:0,g,g),l.setRenderTarget(n),p&&l.render(u,r),l.render(e,r)}u.geometry.dispose(),u.material.dispose(),l.toneMapping=h,l.autoClear=c,e.background=m}_textureToCubeUV(e,t){let i=this._renderer,n=e.mapping===Xn||e.mapping===qn;n?(this._cubemapMaterial===null&&(this._cubemapMaterial=Qh()),this._cubemapMaterial.uniforms.flipEnvMap.value=e.isRenderTargetTexture===!1?-1:1):this._equirectMaterial===null&&(this._equirectMaterial=Kh());let r=n?this._cubemapMaterial:this._equirectMaterial,a=new Ce(this._lodPlanes[0],r);r.uniforms.envMap.value=e;let o=this._cubeSize;Fr(t,0,0,3*o,2*o),i.setRenderTarget(t),i.render(a,qo)}_applyPMREM(e){let t=this._renderer,i=t.autoClear;t.autoClear=!1;let n=this._lodPlanes.length;for(let r=1;r<n;r++){let a=Math.sqrt(this._sigmas[r]*this._sigmas[r]-this._sigmas[r-1]*this._sigmas[r-1]),o=Zh[(n-r-1)%Zh.length];this._blur(e,r-1,r,a,o)}t.autoClear=i}_blur(e,t,i,n,r){let a=this._pingPongRenderTarget;this._halfBlur(e,a,t,i,n,"latitudinal",r),this._halfBlur(a,e,i,i,n,"longitudinal",r)}_halfBlur(e,t,i,n,r,a,o){let l=this._renderer,c=this._blurMaterial;a!=="latitudinal"&&a!=="longitudinal"&&console.error("blur direction must be either latitudinal or longitudinal!");let h=new Ce(this._lodPlanes[n],c),d=c.uniforms,u=this._sizeLods[i]-1,p=isFinite(r)?Math.PI/(2*u):2*Math.PI/39,m=r/p,v=isFinite(r)?1+Math.floor(3*m):Ts;v>Ts&&console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${v} samples when the maximum is set to 20`);let f=[],g=0;for(let _=0;_<Ts;++_){let b=_/m,S=Math.exp(-b*b/2);f.push(S),_===0?g+=S:_<v&&(g+=2*S)}for(let _=0;_<f.length;_++)f[_]=f[_]/g;d.envMap.value=e.texture,d.samples.value=v,d.weights.value=f,d.latitudinal.value=a==="latitudinal",o&&(d.poleAxis.value=o);let{_lodMax:y}=this;d.dTheta.value=p,d.mipInt.value=y-i;let x=this._sizeLods[n];Fr(t,3*x*(n>y-4?n-y+4:0),4*(this._cubeSize-x),3*x,2*x),l.setRenderTarget(t),l.render(h,qo)}};function Jh(s,e,t){let i=new si(s,e,t);return i.texture.mapping=za,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i}function Fr(s,e,t,i,n){s.viewport.set(e,t,i,n),s.scissor.set(e,t,i,n)}function Kh(){return new Tt({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:Wc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function Qh(){return new Tt({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:Wc(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:0,depthTest:!1,depthWrite:!1})}function Wc(){return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`}function Mp(s){let e=new WeakMap,t=null;function i(n){let r=n.target;r.removeEventListener("dispose",i);let a=e.get(r);a!==void 0&&(e.delete(r),a.dispose())}return{get:function(n){if(n&&n.isTexture){let r=n.mapping,a=r===cl||r===hl,o=r===Xn||r===qn;if(a||o){let l=e.get(n),c=l!==void 0?l.texture.pmremVersion:0;if(n.isRenderTargetTexture&&n.pmremVersion!==c)return t===null&&(t=new es(s)),l=a?t.fromEquirectangular(n,l):t.fromCubemap(n,l),l.texture.pmremVersion=n.pmremVersion,e.set(n,l),l.texture;if(l!==void 0)return l.texture;{let h=n.image;return a&&h&&h.height>0||o&&h&&function(d){let u=0,p=6;for(let m=0;m<p;m++)d[m]!==void 0&&u++;return u===p}(h)?(t===null&&(t=new es(s)),l=a?t.fromEquirectangular(n):t.fromCubemap(n),l.texture.pmremVersion=n.pmremVersion,e.set(n,l),n.addEventListener("dispose",i),l.texture):null}}}return n},dispose:function(){e=new WeakMap,t!==null&&(t.dispose(),t=null)}}}function bp(s){let e={};function t(i){if(e[i]!==void 0)return e[i];let n;switch(i){case"WEBGL_depth_texture":n=s.getExtension("WEBGL_depth_texture")||s.getExtension("MOZ_WEBGL_depth_texture")||s.getExtension("WEBKIT_WEBGL_depth_texture");break;case"EXT_texture_filter_anisotropic":n=s.getExtension("EXT_texture_filter_anisotropic")||s.getExtension("MOZ_EXT_texture_filter_anisotropic")||s.getExtension("WEBKIT_EXT_texture_filter_anisotropic");break;case"WEBGL_compressed_texture_s3tc":n=s.getExtension("WEBGL_compressed_texture_s3tc")||s.getExtension("MOZ_WEBGL_compressed_texture_s3tc")||s.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");break;case"WEBGL_compressed_texture_pvrtc":n=s.getExtension("WEBGL_compressed_texture_pvrtc")||s.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");break;default:n=s.getExtension(i)}return e[i]=n,n}return{has:function(i){return t(i)!==null},init:function(){t("EXT_color_buffer_float"),t("WEBGL_clip_cull_distance"),t("OES_texture_float_linear"),t("EXT_color_buffer_half_float"),t("WEBGL_multisampled_render_to_texture"),t("WEBGL_render_shared_exponent")},get:function(i){let n=t(i);return n===null&&Us("THREE.WebGLRenderer: "+i+" extension not supported."),n}}}function Sp(s,e,t,i){let n={},r=new WeakMap;function a(l){let c=l.target;c.index!==null&&e.remove(c.index);for(let d in c.attributes)e.remove(c.attributes[d]);for(let d in c.morphAttributes){let u=c.morphAttributes[d];for(let p=0,m=u.length;p<m;p++)e.remove(u[p])}c.removeEventListener("dispose",a),delete n[c.id];let h=r.get(c);h&&(e.remove(h),r.delete(c)),i.releaseStatesOfGeometry(c),c.isInstancedBufferGeometry===!0&&delete c._maxInstanceCount,t.memory.geometries--}function o(l){let c=[],h=l.index,d=l.attributes.position,u=0;if(h!==null){let v=h.array;u=h.version;for(let f=0,g=v.length;f<g;f+=3){let y=v[f+0],x=v[f+1],_=v[f+2];c.push(y,x,x,_,_,y)}}else{if(d===void 0)return;{let v=d.array;u=d.version;for(let f=0,g=v.length/3-1;f<g;f+=3){let y=f+0,x=f+1,_=f+2;c.push(y,x,x,_,_,y)}}}let p=new(Yu(c)?ma:pa)(c,1);p.version=u;let m=r.get(l);m&&e.remove(m),r.set(l,p)}return{get:function(l,c){return n[c.id]===!0||(c.addEventListener("dispose",a),n[c.id]=!0,t.memory.geometries++),c},update:function(l){let c=l.attributes;for(let d in c)e.update(c[d],s.ARRAY_BUFFER);let h=l.morphAttributes;for(let d in h){let u=h[d];for(let p=0,m=u.length;p<m;p++)e.update(u[p],s.ARRAY_BUFFER)}},getWireframeAttribute:function(l){let c=r.get(l);if(c){let h=l.index;h!==null&&c.version<h.version&&o(l)}else o(l);return r.get(l)}}}function wp(s,e,t){let i,n,r;function a(o,l,c){c!==0&&(s.drawElementsInstanced(i,l,n,o*r,c),t.update(l,i,c))}this.setMode=function(o){i=o},this.setIndex=function(o){n=o.type,r=o.bytesPerElement},this.render=function(o,l){s.drawElements(i,l,n,o*r),t.update(l,i,1)},this.renderInstances=a,this.renderMultiDraw=function(o,l,c){if(c===0)return;e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(i,l,0,n,o,0,c);let h=0;for(let d=0;d<c;d++)h+=l[d];t.update(h,i,1)},this.renderMultiDrawInstances=function(o,l,c,h){if(c===0)return;let d=e.get("WEBGL_multi_draw");if(d===null)for(let u=0;u<o.length;u++)a(o[u]/r,l[u],h[u]);else{d.multiDrawElementsInstancedWEBGL(i,l,0,n,o,0,h,0,c);let u=0;for(let p=0;p<c;p++)u+=l[p]*h[p];t.update(u,i,1)}}}function Ep(s){let e={frame:0,calls:0,triangles:0,points:0,lines:0};return{memory:{geometries:0,textures:0},render:e,programs:null,autoReset:!0,reset:function(){e.calls=0,e.triangles=0,e.points=0,e.lines=0},update:function(t,i,n){switch(e.calls++,i){case s.TRIANGLES:e.triangles+=n*(t/3);break;case s.LINES:e.lines+=n*(t/2);break;case s.LINE_STRIP:e.lines+=n*(t-1);break;case s.LINE_LOOP:e.lines+=n*t;break;case s.POINTS:e.points+=n*t;break;default:console.error("THREE.WebGLInfo: Unknown draw mode:",i)}}}}function Tp(s,e,t){let i=new WeakMap,n=new ct;return{update:function(r,a,o){let l=r.morphTargetInfluences,c=a.morphAttributes.position||a.morphAttributes.normal||a.morphAttributes.color,h=c!==void 0?c.length:0,d=i.get(a);if(d===void 0||d.count!==h){let P=function(){S.dispose(),i.delete(a),a.removeEventListener("dispose",P)};d!==void 0&&d.texture.dispose();let u=a.morphAttributes.position!==void 0,p=a.morphAttributes.normal!==void 0,m=a.morphAttributes.color!==void 0,v=a.morphAttributes.position||[],f=a.morphAttributes.normal||[],g=a.morphAttributes.color||[],y=0;u===!0&&(y=1),p===!0&&(y=2),m===!0&&(y=3);let x=a.attributes.position.count*y,_=1;x>e.maxTextureSize&&(_=Math.ceil(x/e.maxTextureSize),x=e.maxTextureSize);let b=new Float32Array(x*_*4*h),S=new ua(b,x,_,h);S.type=pi,S.needsUpdate=!0;let R=4*y;for(let C=0;C<h;C++){let B=v[C],z=f[C],D=g[C],F=x*_*4*C;for(let U=0;U<B.count;U++){let X=U*R;u===!0&&(n.fromBufferAttribute(B,U),b[F+X+0]=n.x,b[F+X+1]=n.y,b[F+X+2]=n.z,b[F+X+3]=0),p===!0&&(n.fromBufferAttribute(z,U),b[F+X+4]=n.x,b[F+X+5]=n.y,b[F+X+6]=n.z,b[F+X+7]=0),m===!0&&(n.fromBufferAttribute(D,U),b[F+X+8]=n.x,b[F+X+9]=n.y,b[F+X+10]=n.z,b[F+X+11]=D.itemSize===4?n.w:1)}}d={count:h,texture:S,size:new oe(x,_)},i.set(a,d),a.addEventListener("dispose",P)}if(r.isInstancedMesh===!0&&r.morphTexture!==null)o.getUniforms().setValue(s,"morphTexture",r.morphTexture,t);else{let u=0;for(let m=0;m<l.length;m++)u+=l[m];let p=a.morphTargetsRelative?1:1-u;o.getUniforms().setValue(s,"morphTargetBaseInfluence",p),o.getUniforms().setValue(s,"morphTargetInfluences",l)}o.getUniforms().setValue(s,"morphTargetsTexture",d.texture,t),o.getUniforms().setValue(s,"morphTargetsTextureSize",d.size)}}}function Ap(s,e,t,i){let n=new WeakMap;function r(a){let o=a.target;o.removeEventListener("dispose",r),t.remove(o.instanceMatrix),o.instanceColor!==null&&t.remove(o.instanceColor)}return{update:function(a){let o=i.render.frame,l=a.geometry,c=e.get(a,l);if(n.get(c)!==o&&(e.update(c),n.set(c,o)),a.isInstancedMesh&&(a.hasEventListener("dispose",r)===!1&&a.addEventListener("dispose",r),n.get(a)!==o&&(t.update(a.instanceMatrix,s.ARRAY_BUFFER),a.instanceColor!==null&&t.update(a.instanceColor,s.ARRAY_BUFFER),n.set(a,o))),a.isSkinnedMesh){let h=a.skeleton;n.get(h)!==o&&(h.update(),n.set(h,o))}return c},dispose:function(){n=new WeakMap}}}var ga=class extends Nt{constructor(e,t,i,n,r,a,o,l,c,h=1026){if(h!==Vs&&h!==Yn)throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");i===void 0&&h===Vs&&(i=un),i===void 0&&h===Yn&&(i=jn),super(null,n,r,a,o,l,h,i,c),this.isDepthTexture=!0,this.image={width:e,height:t},this.magFilter=o!==void 0?o:ii,this.minFilter=l!==void 0?l:ii,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null}copy(e){return super.copy(e),this.compareFunction=e.compareFunction,this}toJSON(e){let t=super.toJSON(e);return this.compareFunction!==null&&(t.compareFunction=this.compareFunction),t}},Ku=new Nt,eu=new ga(1,1),Qu=new ua,ed=new Gl,td=new fa,tu=[],iu=[],nu=new Float32Array(16),su=new Float32Array(9),ru=new Float32Array(4);function ls(s,e,t){let i=s[0];if(i<=0||i>0)return s;let n=e*t,r=tu[n];if(r===void 0&&(r=new Float32Array(n),tu[n]=r),e!==0){i.toArray(r,0);for(let a=1,o=0;a!==e;++a)o+=t,s[a].toArray(r,o)}return r}function gt(s,e){if(s.length!==e.length)return!1;for(let t=0,i=s.length;t<i;t++)if(s[t]!==e[t])return!1;return!0}function vt(s,e){for(let t=0,i=e.length;t<i;t++)s[t]=e[t]}function Fa(s,e){let t=iu[e];t===void 0&&(t=new Int32Array(e),iu[e]=t);for(let i=0;i!==e;++i)t[i]=s.allocateTextureUnit();return t}function Rp(s,e){let t=this.cache;t[0]!==e&&(s.uniform1f(this.addr,e),t[0]=e)}function Cp(s,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y||(s.uniform2f(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(gt(t,e))return;s.uniform2fv(this.addr,e),vt(t,e)}}function Lp(s,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z||(s.uniform3f(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else if(e.r!==void 0)t[0]===e.r&&t[1]===e.g&&t[2]===e.b||(s.uniform3f(this.addr,e.r,e.g,e.b),t[0]=e.r,t[1]=e.g,t[2]=e.b);else{if(gt(t,e))return;s.uniform3fv(this.addr,e),vt(t,e)}}function Pp(s,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z&&t[3]===e.w||(s.uniform4f(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(gt(t,e))return;s.uniform4fv(this.addr,e),vt(t,e)}}function Ip(s,e){let t=this.cache,i=e.elements;if(i===void 0){if(gt(t,e))return;s.uniformMatrix2fv(this.addr,!1,e),vt(t,e)}else{if(gt(t,i))return;ru.set(i),s.uniformMatrix2fv(this.addr,!1,ru),vt(t,i)}}function Dp(s,e){let t=this.cache,i=e.elements;if(i===void 0){if(gt(t,e))return;s.uniformMatrix3fv(this.addr,!1,e),vt(t,e)}else{if(gt(t,i))return;su.set(i),s.uniformMatrix3fv(this.addr,!1,su),vt(t,i)}}function Up(s,e){let t=this.cache,i=e.elements;if(i===void 0){if(gt(t,e))return;s.uniformMatrix4fv(this.addr,!1,e),vt(t,e)}else{if(gt(t,i))return;nu.set(i),s.uniformMatrix4fv(this.addr,!1,nu),vt(t,i)}}function Np(s,e){let t=this.cache;t[0]!==e&&(s.uniform1i(this.addr,e),t[0]=e)}function Op(s,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y||(s.uniform2i(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(gt(t,e))return;s.uniform2iv(this.addr,e),vt(t,e)}}function zp(s,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z||(s.uniform3i(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(gt(t,e))return;s.uniform3iv(this.addr,e),vt(t,e)}}function kp(s,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z&&t[3]===e.w||(s.uniform4i(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(gt(t,e))return;s.uniform4iv(this.addr,e),vt(t,e)}}function Fp(s,e){let t=this.cache;t[0]!==e&&(s.uniform1ui(this.addr,e),t[0]=e)}function Bp(s,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y||(s.uniform2ui(this.addr,e.x,e.y),t[0]=e.x,t[1]=e.y);else{if(gt(t,e))return;s.uniform2uiv(this.addr,e),vt(t,e)}}function Hp(s,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z||(s.uniform3ui(this.addr,e.x,e.y,e.z),t[0]=e.x,t[1]=e.y,t[2]=e.z);else{if(gt(t,e))return;s.uniform3uiv(this.addr,e),vt(t,e)}}function Vp(s,e){let t=this.cache;if(e.x!==void 0)t[0]===e.x&&t[1]===e.y&&t[2]===e.z&&t[3]===e.w||(s.uniform4ui(this.addr,e.x,e.y,e.z,e.w),t[0]=e.x,t[1]=e.y,t[2]=e.z,t[3]=e.w);else{if(gt(t,e))return;s.uniform4uiv(this.addr,e),vt(t,e)}}function Gp(s,e,t){let i=this.cache,n=t.allocateTextureUnit(),r;i[0]!==n&&(s.uniform1i(this.addr,n),i[0]=n),this.type===s.SAMPLER_2D_SHADOW?(eu.compareFunction=515,r=eu):r=Ku,t.setTexture2D(e||r,n)}function Wp(s,e,t){let i=this.cache,n=t.allocateTextureUnit();i[0]!==n&&(s.uniform1i(this.addr,n),i[0]=n),t.setTexture3D(e||ed,n)}function Xp(s,e,t){let i=this.cache,n=t.allocateTextureUnit();i[0]!==n&&(s.uniform1i(this.addr,n),i[0]=n),t.setTextureCube(e||td,n)}function qp(s,e,t){let i=this.cache,n=t.allocateTextureUnit();i[0]!==n&&(s.uniform1i(this.addr,n),i[0]=n),t.setTexture2DArray(e||Qu,n)}function jp(s,e){s.uniform1fv(this.addr,e)}function Yp(s,e){let t=ls(e,this.size,2);s.uniform2fv(this.addr,t)}function $p(s,e){let t=ls(e,this.size,3);s.uniform3fv(this.addr,t)}function Zp(s,e){let t=ls(e,this.size,4);s.uniform4fv(this.addr,t)}function Jp(s,e){let t=ls(e,this.size,4);s.uniformMatrix2fv(this.addr,!1,t)}function Kp(s,e){let t=ls(e,this.size,9);s.uniformMatrix3fv(this.addr,!1,t)}function Qp(s,e){let t=ls(e,this.size,16);s.uniformMatrix4fv(this.addr,!1,t)}function em(s,e){s.uniform1iv(this.addr,e)}function tm(s,e){s.uniform2iv(this.addr,e)}function im(s,e){s.uniform3iv(this.addr,e)}function nm(s,e){s.uniform4iv(this.addr,e)}function sm(s,e){s.uniform1uiv(this.addr,e)}function rm(s,e){s.uniform2uiv(this.addr,e)}function am(s,e){s.uniform3uiv(this.addr,e)}function om(s,e){s.uniform4uiv(this.addr,e)}function lm(s,e,t){let i=this.cache,n=e.length,r=Fa(t,n);gt(i,r)||(s.uniform1iv(this.addr,r),vt(i,r));for(let a=0;a!==n;++a)t.setTexture2D(e[a]||Ku,r[a])}function cm(s,e,t){let i=this.cache,n=e.length,r=Fa(t,n);gt(i,r)||(s.uniform1iv(this.addr,r),vt(i,r));for(let a=0;a!==n;++a)t.setTexture3D(e[a]||ed,r[a])}function hm(s,e,t){let i=this.cache,n=e.length,r=Fa(t,n);gt(i,r)||(s.uniform1iv(this.addr,r),vt(i,r));for(let a=0;a!==n;++a)t.setTextureCube(e[a]||td,r[a])}function um(s,e,t){let i=this.cache,n=e.length,r=Fa(t,n);gt(i,r)||(s.uniform1iv(this.addr,r),vt(i,r));for(let a=0;a!==n;++a)t.setTexture2DArray(e[a]||Qu,r[a])}var ql=class{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.setValue=function(n){switch(n){case 5126:return Rp;case 35664:return Cp;case 35665:return Lp;case 35666:return Pp;case 35674:return Ip;case 35675:return Dp;case 35676:return Up;case 5124:case 35670:return Np;case 35667:case 35671:return Op;case 35668:case 35672:return zp;case 35669:case 35673:return kp;case 5125:return Fp;case 36294:return Bp;case 36295:return Hp;case 36296:return Vp;case 35678:case 36198:case 36298:case 36306:case 35682:return Gp;case 35679:case 36299:case 36307:return Wp;case 35680:case 36300:case 36308:case 36293:return Xp;case 36289:case 36303:case 36311:case 36292:return qp}}(t.type)}},jl=class{constructor(e,t,i){this.id=e,this.addr=i,this.cache=[],this.type=t.type,this.size=t.size,this.setValue=function(n){switch(n){case 5126:return jp;case 35664:return Yp;case 35665:return $p;case 35666:return Zp;case 35674:return Jp;case 35675:return Kp;case 35676:return Qp;case 5124:case 35670:return em;case 35667:case 35671:return tm;case 35668:case 35672:return im;case 35669:case 35673:return nm;case 5125:return sm;case 36294:return rm;case 36295:return am;case 36296:return om;case 35678:case 36198:case 36298:case 36306:case 35682:return lm;case 35679:case 36299:case 36307:return cm;case 35680:case 36300:case 36308:case 36293:return hm;case 36289:case 36303:case 36311:case 36292:return um}}(t.type)}},Yl=class{constructor(e){this.id=e,this.seq=[],this.map={}}setValue(e,t,i){let n=this.seq;for(let r=0,a=n.length;r!==a;++r){let o=n[r];o.setValue(e,t[o.id],i)}}},Jo=/(\w+)(\])?(\[|\.)?/g;function au(s,e){s.seq.push(e),s.map[e.id]=e}function dm(s,e,t){let i=s.name,n=i.length;for(Jo.lastIndex=0;;){let r=Jo.exec(i),a=Jo.lastIndex,o=r[1],l=r[2]==="]",c=r[3];if(l&&(o|=0),c===void 0||c==="["&&a+2===n){au(t,c===void 0?new ql(o,s,e):new jl(o,s,e));break}{let h=t.map[o];h===void 0&&(h=new Yl(o),au(t,h)),t=h}}}var Wn=class{constructor(e,t){this.seq=[],this.map={};let i=e.getProgramParameter(t,e.ACTIVE_UNIFORMS);for(let n=0;n<i;++n){let r=e.getActiveUniform(t,n);dm(r,e.getUniformLocation(t,r.name),this)}}setValue(e,t,i,n){let r=this.map[t];r!==void 0&&r.setValue(e,i,n)}setOptional(e,t,i){let n=t[i];n!==void 0&&this.setValue(e,i,n)}static upload(e,t,i,n){for(let r=0,a=t.length;r!==a;++r){let o=t[r],l=i[o.id];l.needsUpdate!==!1&&o.setValue(e,l.value,n)}}static seqWithValue(e,t){let i=[];for(let n=0,r=e.length;n!==r;++n){let a=e[n];a.id in t&&i.push(a)}return i}};function ou(s,e,t){let i=s.createShader(e);return s.shaderSource(i,t),s.compileShader(i),i}var pm=0,lu=new De;function cu(s,e,t){let i=s.getShaderParameter(e,s.COMPILE_STATUS),n=s.getShaderInfoLog(e).trim();if(i&&n==="")return"";let r=/ERROR: 0:(\d+)/.exec(n);if(r){let a=parseInt(r[1]);return t.toUpperCase()+`

`+n+`

`+function(o,l){let c=o.split(`
`),h=[],d=Math.max(l-6,0),u=Math.min(l+6,c.length);for(let p=d;p<u;p++){let m=p+1;h.push(`${m===l?">":" "} ${m}: ${c[p]}`)}return h.join(`
`)}(s.getShaderSource(e),a)}return n}function mm(s,e){let t=function(i){je._getMatrix(lu,je.workingColorSpace,i);let n=`mat3( ${lu.elements.map(r=>r.toFixed(4))} )`;switch(je.getTransfer(i)){case ka:return[n,"LinearTransferOETF"];case et:return[n,"sRGBTransferOETF"];default:return console.warn("THREE.WebGLProgram: Unsupported color space: ",i),[n,"LinearTransferOETF"]}}(e);return[`vec4 ${s}( vec4 value ) {`,`	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );`,"}"].join(`
`)}function fm(s,e){let t;switch(e){case 1:t="Linear";break;case 2:t="Reinhard";break;case 3:t="Cineon";break;case 4:t="ACESFilmic";break;case 6:t="AgX";break;case 7:t="Neutral";break;case 5:t="Custom";break;default:console.warn("THREE.WebGLProgram: Unsupported toneMapping:",e),t="Linear"}return"vec3 "+s+"( vec3 color ) { return "+t+"ToneMapping( color ); }"}var Br=new M;function gm(){return je.getLuminanceCoefficients(Br),["float luminance( const in vec3 rgb ) {",`	const vec3 weights = vec3( ${Br.x.toFixed(4)}, ${Br.y.toFixed(4)}, ${Br.z.toFixed(4)} );`,"	return dot( weights, rgb );","}"].join(`
`)}function As(s){return s!==""}function hu(s,e){let t=e.numSpotLightShadows+e.numSpotLightMaps-e.numSpotLightShadowsWithMaps;return s.replace(/NUM_DIR_LIGHTS/g,e.numDirLights).replace(/NUM_SPOT_LIGHTS/g,e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,e.numPointLights).replace(/NUM_HEMI_LIGHTS/g,e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,e.numPointLightShadows)}function uu(s,e){return s.replace(/NUM_CLIPPING_PLANES/g,e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,e.numClippingPlanes-e.numClipIntersection)}var vm=/^[ \t]*#include +<([\w\d./]+)>/gm;function $l(s){return s.replace(vm,xm)}var ym=new Map;function xm(s,e){let t=Ne[e];if(t===void 0){let i=ym.get(e);if(i===void 0)throw new Error("Can not resolve #include <"+e+">");t=Ne[i],console.warn('THREE.WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',e,i)}return $l(t)}var _m=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;function du(s){return s.replace(_m,Mm)}function Mm(s,e,t,i){let n="";for(let r=parseInt(e);r<parseInt(t);r++)n+=i.replace(/\[\s*i\s*\]/g,"[ "+r+" ]").replace(/UNROLLED_LOOP_INDEX/g,r);return n}function pu(s){let e=`precision ${s.precision} float;
	precision ${s.precision} int;
	precision ${s.precision} sampler2D;
	precision ${s.precision} samplerCube;
	precision ${s.precision} sampler3D;
	precision ${s.precision} sampler2DArray;
	precision ${s.precision} sampler2DShadow;
	precision ${s.precision} samplerCubeShadow;
	precision ${s.precision} sampler2DArrayShadow;
	precision ${s.precision} isampler2D;
	precision ${s.precision} isampler3D;
	precision ${s.precision} isamplerCube;
	precision ${s.precision} isampler2DArray;
	precision ${s.precision} usampler2D;
	precision ${s.precision} usampler3D;
	precision ${s.precision} usamplerCube;
	precision ${s.precision} usampler2DArray;
	`;return s.precision==="highp"?e+=`
#define HIGH_PRECISION`:s.precision==="mediump"?e+=`
#define MEDIUM_PRECISION`:s.precision==="lowp"&&(e+=`
#define LOW_PRECISION`),e}function bm(s,e,t,i){let n=s.getContext(),r=t.defines,a=t.vertexShader,o=t.fragmentShader,l=function(z){let D="SHADOWMAP_TYPE_BASIC";return z.shadowMapType===1?D="SHADOWMAP_TYPE_PCF":z.shadowMapType===2?D="SHADOWMAP_TYPE_PCF_SOFT":z.shadowMapType===3&&(D="SHADOWMAP_TYPE_VSM"),D}(t),c=function(z){let D="ENVMAP_TYPE_CUBE";if(z.envMap)switch(z.envMapMode){case Xn:case qn:D="ENVMAP_TYPE_CUBE";break;case za:D="ENVMAP_TYPE_CUBE_UV"}return D}(t),h=function(z){let D="ENVMAP_MODE_REFLECTION";return z.envMap&&z.envMapMode===qn&&(D="ENVMAP_MODE_REFRACTION"),D}(t),d=function(z){let D="ENVMAP_BLENDING_NONE";if(z.envMap)switch(z.combine){case 0:D="ENVMAP_BLENDING_MULTIPLY";break;case 1:D="ENVMAP_BLENDING_MIX";break;case 2:D="ENVMAP_BLENDING_ADD"}return D}(t),u=function(z){let D=z.envMapCubeUVHeight;if(D===null)return null;let F=Math.log2(D)-2,U=1/D;return{texelWidth:1/(3*Math.max(Math.pow(2,F),112)),texelHeight:U,maxMip:F}}(t),p=function(z){return[z.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",z.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(As).join(`
`)}(t),m=function(z){let D=[];for(let F in z){let U=z[F];U!==!1&&D.push("#define "+F+" "+U)}return D.join(`
`)}(r),v=n.createProgram(),f,g,y=t.glslVersion?"#version "+t.glslVersion+`
`:"";t.isRawShaderMaterial?(f=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m].filter(As).join(`
`),f.length>0&&(f+=`
`),g=["#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m].filter(As).join(`
`),g.length>0&&(g+=`
`)):(f=[pu(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m,t.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",t.batching?"#define USE_BATCHING":"",t.batchingColor?"#define USE_BATCHING_COLOR":"",t.instancing?"#define USE_INSTANCING":"",t.instancingColor?"#define USE_INSTANCING_COLOR":"",t.instancingMorph?"#define USE_INSTANCING_MORPH":"",t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.map?"#define USE_MAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+h:"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.displacementMap?"#define USE_DISPLACEMENTMAP":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.mapUv?"#define MAP_UV "+t.mapUv:"",t.alphaMapUv?"#define ALPHAMAP_UV "+t.alphaMapUv:"",t.lightMapUv?"#define LIGHTMAP_UV "+t.lightMapUv:"",t.aoMapUv?"#define AOMAP_UV "+t.aoMapUv:"",t.emissiveMapUv?"#define EMISSIVEMAP_UV "+t.emissiveMapUv:"",t.bumpMapUv?"#define BUMPMAP_UV "+t.bumpMapUv:"",t.normalMapUv?"#define NORMALMAP_UV "+t.normalMapUv:"",t.displacementMapUv?"#define DISPLACEMENTMAP_UV "+t.displacementMapUv:"",t.metalnessMapUv?"#define METALNESSMAP_UV "+t.metalnessMapUv:"",t.roughnessMapUv?"#define ROUGHNESSMAP_UV "+t.roughnessMapUv:"",t.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+t.anisotropyMapUv:"",t.clearcoatMapUv?"#define CLEARCOATMAP_UV "+t.clearcoatMapUv:"",t.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+t.clearcoatNormalMapUv:"",t.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+t.clearcoatRoughnessMapUv:"",t.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+t.iridescenceMapUv:"",t.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+t.iridescenceThicknessMapUv:"",t.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+t.sheenColorMapUv:"",t.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+t.sheenRoughnessMapUv:"",t.specularMapUv?"#define SPECULARMAP_UV "+t.specularMapUv:"",t.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+t.specularColorMapUv:"",t.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+t.specularIntensityMapUv:"",t.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+t.transmissionMapUv:"",t.thicknessMapUv?"#define THICKNESSMAP_UV "+t.thicknessMapUv:"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.flatShading?"#define FLAT_SHADED":"",t.skinning?"#define USE_SKINNING":"",t.morphTargets?"#define USE_MORPHTARGETS":"",t.morphNormals&&t.flatShading===!1?"#define USE_MORPHNORMALS":"",t.morphColors?"#define USE_MORPHCOLORS":"",t.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+t.morphTextureStride:"",t.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+t.morphTargetsCount:"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.sizeAttenuation?"#define USE_SIZEATTENUATION":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif",`
`].filter(As).join(`
`),g=[pu(t),"#define SHADER_TYPE "+t.shaderType,"#define SHADER_NAME "+t.shaderName,m,t.useFog&&t.fog?"#define USE_FOG":"",t.useFog&&t.fogExp2?"#define FOG_EXP2":"",t.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",t.map?"#define USE_MAP":"",t.matcap?"#define USE_MATCAP":"",t.envMap?"#define USE_ENVMAP":"",t.envMap?"#define "+c:"",t.envMap?"#define "+h:"",t.envMap?"#define "+d:"",u?"#define CUBEUV_TEXEL_WIDTH "+u.texelWidth:"",u?"#define CUBEUV_TEXEL_HEIGHT "+u.texelHeight:"",u?"#define CUBEUV_MAX_MIP "+u.maxMip+".0":"",t.lightMap?"#define USE_LIGHTMAP":"",t.aoMap?"#define USE_AOMAP":"",t.bumpMap?"#define USE_BUMPMAP":"",t.normalMap?"#define USE_NORMALMAP":"",t.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",t.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",t.emissiveMap?"#define USE_EMISSIVEMAP":"",t.anisotropy?"#define USE_ANISOTROPY":"",t.anisotropyMap?"#define USE_ANISOTROPYMAP":"",t.clearcoat?"#define USE_CLEARCOAT":"",t.clearcoatMap?"#define USE_CLEARCOATMAP":"",t.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",t.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",t.dispersion?"#define USE_DISPERSION":"",t.iridescence?"#define USE_IRIDESCENCE":"",t.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",t.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",t.specularMap?"#define USE_SPECULARMAP":"",t.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",t.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",t.roughnessMap?"#define USE_ROUGHNESSMAP":"",t.metalnessMap?"#define USE_METALNESSMAP":"",t.alphaMap?"#define USE_ALPHAMAP":"",t.alphaTest?"#define USE_ALPHATEST":"",t.alphaHash?"#define USE_ALPHAHASH":"",t.sheen?"#define USE_SHEEN":"",t.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",t.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",t.transmission?"#define USE_TRANSMISSION":"",t.transmissionMap?"#define USE_TRANSMISSIONMAP":"",t.thicknessMap?"#define USE_THICKNESSMAP":"",t.vertexTangents&&t.flatShading===!1?"#define USE_TANGENT":"",t.vertexColors||t.instancingColor||t.batchingColor?"#define USE_COLOR":"",t.vertexAlphas?"#define USE_COLOR_ALPHA":"",t.vertexUv1s?"#define USE_UV1":"",t.vertexUv2s?"#define USE_UV2":"",t.vertexUv3s?"#define USE_UV3":"",t.pointsUvs?"#define USE_POINTS_UV":"",t.gradientMap?"#define USE_GRADIENTMAP":"",t.flatShading?"#define FLAT_SHADED":"",t.doubleSided?"#define DOUBLE_SIDED":"",t.flipSided?"#define FLIP_SIDED":"",t.shadowMapEnabled?"#define USE_SHADOWMAP":"",t.shadowMapEnabled?"#define "+l:"",t.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",t.numLightProbes>0?"#define USE_LIGHT_PROBES":"",t.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",t.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",t.logarithmicDepthBuffer?"#define USE_LOGDEPTHBUF":"",t.reverseDepthBuffer?"#define USE_REVERSEDEPTHBUF":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",t.toneMapping!==0?"#define TONE_MAPPING":"",t.toneMapping!==0?Ne.tonemapping_pars_fragment:"",t.toneMapping!==0?fm("toneMapping",t.toneMapping):"",t.dithering?"#define DITHERING":"",t.opaque?"#define OPAQUE":"",Ne.colorspace_pars_fragment,mm("linearToOutputTexel",t.outputColorSpace),gm(),t.useDepthPacking?"#define DEPTH_PACKING "+t.depthPacking:"",`
`].filter(As).join(`
`)),a=$l(a),a=hu(a,t),a=uu(a,t),o=$l(o),o=hu(o,t),o=uu(o,t),a=du(a),o=du(o),t.isRawShaderMaterial!==!0&&(y=`#version 300 es
`,f=[p,"#define attribute in","#define varying out","#define texture2D texture"].join(`
`)+`
`+f,g=["#define varying in",t.glslVersion===Th?"":"layout(location = 0) out highp vec4 pc_fragColor;",t.glslVersion===Th?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth","#define texture2D texture","#define textureCube texture","#define texture2DProj textureProj","#define texture2DLodEXT textureLod","#define texture2DProjLodEXT textureProjLod","#define textureCubeLodEXT textureLod","#define texture2DGradEXT textureGrad","#define texture2DProjGradEXT textureProjGrad","#define textureCubeGradEXT textureGrad"].join(`
`)+`
`+g);let x=y+f+a,_=y+g+o,b=ou(n,n.VERTEX_SHADER,x),S=ou(n,n.FRAGMENT_SHADER,_);function R(z){if(s.debug.checkShaderErrors){let D=n.getProgramInfoLog(v).trim(),F=n.getShaderInfoLog(b).trim(),U=n.getShaderInfoLog(S).trim(),X=!0,j=!0;if(n.getProgramParameter(v,n.LINK_STATUS)===!1)if(X=!1,typeof s.debug.onShaderError=="function")s.debug.onShaderError(n,v,b,S);else{let Z=cu(n,b,"vertex"),$=cu(n,S,"fragment");console.error("THREE.WebGLProgram: Shader Error "+n.getError()+" - VALIDATE_STATUS "+n.getProgramParameter(v,n.VALIDATE_STATUS)+`

Material Name: `+z.name+`
Material Type: `+z.type+`

Program Info Log: `+D+`
`+Z+`
`+$)}else D!==""?console.warn("THREE.WebGLProgram: Program Info Log:",D):F!==""&&U!==""||(j=!1);j&&(z.diagnostics={runnable:X,programLog:D,vertexShader:{log:F,prefix:f},fragmentShader:{log:U,prefix:g}})}n.deleteShader(b),n.deleteShader(S),P=new Wn(n,v),C=function(D,F){let U={},X=D.getProgramParameter(F,D.ACTIVE_ATTRIBUTES);for(let j=0;j<X;j++){let Z=D.getActiveAttrib(F,j),$=Z.name,ue=1;Z.type===D.FLOAT_MAT2&&(ue=2),Z.type===D.FLOAT_MAT3&&(ue=3),Z.type===D.FLOAT_MAT4&&(ue=4),U[$]={type:Z.type,location:D.getAttribLocation(F,$),locationSize:ue}}return U}(n,v)}let P,C;n.attachShader(v,b),n.attachShader(v,S),t.index0AttributeName!==void 0?n.bindAttribLocation(v,0,t.index0AttributeName):t.morphTargets===!0&&n.bindAttribLocation(v,0,"position"),n.linkProgram(v),this.getUniforms=function(){return P===void 0&&R(this),P},this.getAttributes=function(){return C===void 0&&R(this),C};let B=t.rendererExtensionParallelShaderCompile===!1;return this.isReady=function(){return B===!1&&(B=n.getProgramParameter(v,37297)),B},this.destroy=function(){i.releaseStatesOfProgram(this),n.deleteProgram(v),this.program=void 0},this.type=t.shaderType,this.name=t.shaderName,this.id=pm++,this.cacheKey=e,this.usedTimes=1,this.program=v,this.vertexShader=b,this.fragmentShader=S,this}var Sm=0,Zl=class{constructor(){this.shaderCache=new Map,this.materialCache=new Map}update(e){let t=e.vertexShader,i=e.fragmentShader,n=this._getShaderStage(t),r=this._getShaderStage(i),a=this._getShaderCacheForMaterial(e);return a.has(n)===!1&&(a.add(n),n.usedTimes++),a.has(r)===!1&&(a.add(r),r.usedTimes++),this}remove(e){let t=this.materialCache.get(e);for(let i of t)i.usedTimes--,i.usedTimes===0&&this.shaderCache.delete(i.code);return this.materialCache.delete(e),this}getVertexShaderID(e){return this._getShaderStage(e.vertexShader).id}getFragmentShaderID(e){return this._getShaderStage(e.fragmentShader).id}dispose(){this.shaderCache.clear(),this.materialCache.clear()}_getShaderCacheForMaterial(e){let t=this.materialCache,i=t.get(e);return i===void 0&&(i=new Set,t.set(e,i)),i}_getShaderStage(e){let t=this.shaderCache,i=t.get(e);return i===void 0&&(i=new Jl(e),t.set(e,i)),i}},Jl=class{constructor(e){this.id=Sm++,this.code=e,this.usedTimes=0}};function wm(s,e,t,i,n,r,a){let o=new da,l=new Zl,c=new Set,h=[],d=n.logarithmicDepthBuffer,u=n.vertexTextures,p=n.precision,m={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distanceRGBA",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};function v(f){return c.add(f),f===0?"uv":`uv${f}`}return{getParameters:function(f,g,y,x,_){let b=x.fog,S=_.geometry,R=f.isMeshStandardMaterial?x.environment:null,P=(f.isMeshStandardMaterial?t:e).get(f.envMap||R),C=P&&P.mapping===za?P.image.height:null,B=m[f.type];f.precision!==null&&(p=n.getMaxPrecision(f.precision),p!==f.precision&&console.warn("THREE.WebGLProgram.getParameters:",f.precision,"not supported, using",p,"instead."));let z=S.morphAttributes.position||S.morphAttributes.normal||S.morphAttributes.color,D=z!==void 0?z.length:0,F,U,X,j,Z=0;if(S.morphAttributes.position!==void 0&&(Z=1),S.morphAttributes.normal!==void 0&&(Z=2),S.morphAttributes.color!==void 0&&(Z=3),B){let gs=di[B];F=gs.vertexShader,U=gs.fragmentShader}else F=f.vertexShader,U=f.fragmentShader,l.update(f),X=l.getVertexShaderID(f),j=l.getFragmentShaderID(f);let $=s.getRenderTarget(),ue=s.state.buffers.depth.getReversed(),_e=_.isInstancedMesh===!0,K=_.isBatchedMesh===!0,ae=!!f.map,pe=!!f.matcap,ge=!!P,ce=!!f.aoMap,A=!!f.lightMap,T=!!f.bumpMap,k=!!f.normalMap,O=!!f.displacementMap,L=!!f.emissiveMap,N=!!f.metalnessMap,w=!!f.roughnessMap,I=f.anisotropy>0,V=f.clearcoat>0,te=f.dispersion>0,H=f.iridescence>0,Q=f.sheen>0,J=f.transmission>0,ne=I&&!!f.anisotropyMap,ve=V&&!!f.clearcoatMap,me=V&&!!f.clearcoatNormalMap,Se=V&&!!f.clearcoatRoughnessMap,Le=H&&!!f.iridescenceMap,Xe=H&&!!f.iridescenceThicknessMap,ze=Q&&!!f.sheenColorMap,we=Q&&!!f.sheenRoughnessMap,Ze=!!f.specularMap,nt=!!f.specularColorMap,ht=!!f.specularIntensityMap,Me=J&&!!f.transmissionMap,Fe=J&&!!f.thicknessMap,tt=!!f.gradientMap,_n=!!f.alphaMap,dr=f.alphaTest>0,Yt=!!f.alphaHash,hi=!!f.extensions,$i=0;f.toneMapped&&($!==null&&$.isXRRenderTarget!==!0||($i=s.toneMapping));let G={shaderID:B,shaderType:f.type,shaderName:f.name,vertexShader:F,fragmentShader:U,defines:f.defines,customVertexShaderID:X,customFragmentShaderID:j,isRawShaderMaterial:f.isRawShaderMaterial===!0,glslVersion:f.glslVersion,precision:p,batching:K,batchingColor:K&&_._colorsTexture!==null,instancing:_e,instancingColor:_e&&_.instanceColor!==null,instancingMorph:_e&&_.morphTexture!==null,supportsVertexTextures:u,outputColorSpace:$===null?s.outputColorSpace:$.isXRRenderTarget===!0?$.texture.colorSpace:os,alphaToCoverage:!!f.alphaToCoverage,map:ae,matcap:pe,envMap:ge,envMapMode:ge&&P.mapping,envMapCubeUVHeight:C,aoMap:ce,lightMap:A,bumpMap:T,normalMap:k,displacementMap:u&&O,emissiveMap:L,normalMapObjectSpace:k&&f.normalMapType===1,normalMapTangentSpace:k&&f.normalMapType===0,metalnessMap:N,roughnessMap:w,anisotropy:I,anisotropyMap:ne,clearcoat:V,clearcoatMap:ve,clearcoatNormalMap:me,clearcoatRoughnessMap:Se,dispersion:te,iridescence:H,iridescenceMap:Le,iridescenceThicknessMap:Xe,sheen:Q,sheenColorMap:ze,sheenRoughnessMap:we,specularMap:Ze,specularColorMap:nt,specularIntensityMap:ht,transmission:J,transmissionMap:Me,thicknessMap:Fe,gradientMap:tt,opaque:f.transparent===!1&&f.blending===1&&f.alphaToCoverage===!1,alphaMap:_n,alphaTest:dr,alphaHash:Yt,combine:f.combine,mapUv:ae&&v(f.map.channel),aoMapUv:ce&&v(f.aoMap.channel),lightMapUv:A&&v(f.lightMap.channel),bumpMapUv:T&&v(f.bumpMap.channel),normalMapUv:k&&v(f.normalMap.channel),displacementMapUv:O&&v(f.displacementMap.channel),emissiveMapUv:L&&v(f.emissiveMap.channel),metalnessMapUv:N&&v(f.metalnessMap.channel),roughnessMapUv:w&&v(f.roughnessMap.channel),anisotropyMapUv:ne&&v(f.anisotropyMap.channel),clearcoatMapUv:ve&&v(f.clearcoatMap.channel),clearcoatNormalMapUv:me&&v(f.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:Se&&v(f.clearcoatRoughnessMap.channel),iridescenceMapUv:Le&&v(f.iridescenceMap.channel),iridescenceThicknessMapUv:Xe&&v(f.iridescenceThicknessMap.channel),sheenColorMapUv:ze&&v(f.sheenColorMap.channel),sheenRoughnessMapUv:we&&v(f.sheenRoughnessMap.channel),specularMapUv:Ze&&v(f.specularMap.channel),specularColorMapUv:nt&&v(f.specularColorMap.channel),specularIntensityMapUv:ht&&v(f.specularIntensityMap.channel),transmissionMapUv:Me&&v(f.transmissionMap.channel),thicknessMapUv:Fe&&v(f.thicknessMap.channel),alphaMapUv:_n&&v(f.alphaMap.channel),vertexTangents:!!S.attributes.tangent&&(k||I),vertexColors:f.vertexColors,vertexAlphas:f.vertexColors===!0&&!!S.attributes.color&&S.attributes.color.itemSize===4,pointsUvs:_.isPoints===!0&&!!S.attributes.uv&&(ae||_n),fog:!!b,useFog:f.fog===!0,fogExp2:!!b&&b.isFogExp2,flatShading:f.flatShading===!0,sizeAttenuation:f.sizeAttenuation===!0,logarithmicDepthBuffer:d,reverseDepthBuffer:ue,skinning:_.isSkinnedMesh===!0,morphTargets:S.morphAttributes.position!==void 0,morphNormals:S.morphAttributes.normal!==void 0,morphColors:S.morphAttributes.color!==void 0,morphTargetsCount:D,morphTextureStride:Z,numDirLights:g.directional.length,numPointLights:g.point.length,numSpotLights:g.spot.length,numSpotLightMaps:g.spotLightMap.length,numRectAreaLights:g.rectArea.length,numHemiLights:g.hemi.length,numDirLightShadows:g.directionalShadowMap.length,numPointLightShadows:g.pointShadowMap.length,numSpotLightShadows:g.spotShadowMap.length,numSpotLightShadowsWithMaps:g.numSpotLightShadowsWithMaps,numLightProbes:g.numLightProbes,numClippingPlanes:a.numPlanes,numClipIntersection:a.numIntersection,dithering:f.dithering,shadowMapEnabled:s.shadowMap.enabled&&y.length>0,shadowMapType:s.shadowMap.type,toneMapping:$i,decodeVideoTexture:ae&&f.map.isVideoTexture===!0&&je.getTransfer(f.map.colorSpace)===et,decodeVideoTextureEmissive:L&&f.emissiveMap.isVideoTexture===!0&&je.getTransfer(f.emissiveMap.colorSpace)===et,premultipliedAlpha:f.premultipliedAlpha,doubleSided:f.side===2,flipSided:f.side===1,useDepthPacking:f.depthPacking>=0,depthPacking:f.depthPacking||0,index0AttributeName:f.index0AttributeName,extensionClipCullDistance:hi&&f.extensions.clipCullDistance===!0&&i.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(hi&&f.extensions.multiDraw===!0||K)&&i.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:i.has("KHR_parallel_shader_compile"),customProgramCacheKey:f.customProgramCacheKey()};return G.vertexUv1s=c.has(1),G.vertexUv2s=c.has(2),G.vertexUv3s=c.has(3),c.clear(),G},getProgramCacheKey:function(f){let g=[];if(f.shaderID?g.push(f.shaderID):(g.push(f.customVertexShaderID),g.push(f.customFragmentShaderID)),f.defines!==void 0)for(let y in f.defines)g.push(y),g.push(f.defines[y]);return f.isRawShaderMaterial===!1&&(function(y,x){y.push(x.precision),y.push(x.outputColorSpace),y.push(x.envMapMode),y.push(x.envMapCubeUVHeight),y.push(x.mapUv),y.push(x.alphaMapUv),y.push(x.lightMapUv),y.push(x.aoMapUv),y.push(x.bumpMapUv),y.push(x.normalMapUv),y.push(x.displacementMapUv),y.push(x.emissiveMapUv),y.push(x.metalnessMapUv),y.push(x.roughnessMapUv),y.push(x.anisotropyMapUv),y.push(x.clearcoatMapUv),y.push(x.clearcoatNormalMapUv),y.push(x.clearcoatRoughnessMapUv),y.push(x.iridescenceMapUv),y.push(x.iridescenceThicknessMapUv),y.push(x.sheenColorMapUv),y.push(x.sheenRoughnessMapUv),y.push(x.specularMapUv),y.push(x.specularColorMapUv),y.push(x.specularIntensityMapUv),y.push(x.transmissionMapUv),y.push(x.thicknessMapUv),y.push(x.combine),y.push(x.fogExp2),y.push(x.sizeAttenuation),y.push(x.morphTargetsCount),y.push(x.morphAttributeCount),y.push(x.numDirLights),y.push(x.numPointLights),y.push(x.numSpotLights),y.push(x.numSpotLightMaps),y.push(x.numHemiLights),y.push(x.numRectAreaLights),y.push(x.numDirLightShadows),y.push(x.numPointLightShadows),y.push(x.numSpotLightShadows),y.push(x.numSpotLightShadowsWithMaps),y.push(x.numLightProbes),y.push(x.shadowMapType),y.push(x.toneMapping),y.push(x.numClippingPlanes),y.push(x.numClipIntersection),y.push(x.depthPacking)}(g,f),function(y,x){o.disableAll(),x.supportsVertexTextures&&o.enable(0),x.instancing&&o.enable(1),x.instancingColor&&o.enable(2),x.instancingMorph&&o.enable(3),x.matcap&&o.enable(4),x.envMap&&o.enable(5),x.normalMapObjectSpace&&o.enable(6),x.normalMapTangentSpace&&o.enable(7),x.clearcoat&&o.enable(8),x.iridescence&&o.enable(9),x.alphaTest&&o.enable(10),x.vertexColors&&o.enable(11),x.vertexAlphas&&o.enable(12),x.vertexUv1s&&o.enable(13),x.vertexUv2s&&o.enable(14),x.vertexUv3s&&o.enable(15),x.vertexTangents&&o.enable(16),x.anisotropy&&o.enable(17),x.alphaHash&&o.enable(18),x.batching&&o.enable(19),x.dispersion&&o.enable(20),x.batchingColor&&o.enable(21),y.push(o.mask),o.disableAll(),x.fog&&o.enable(0),x.useFog&&o.enable(1),x.flatShading&&o.enable(2),x.logarithmicDepthBuffer&&o.enable(3),x.reverseDepthBuffer&&o.enable(4),x.skinning&&o.enable(5),x.morphTargets&&o.enable(6),x.morphNormals&&o.enable(7),x.morphColors&&o.enable(8),x.premultipliedAlpha&&o.enable(9),x.shadowMapEnabled&&o.enable(10),x.doubleSided&&o.enable(11),x.flipSided&&o.enable(12),x.useDepthPacking&&o.enable(13),x.dithering&&o.enable(14),x.transmission&&o.enable(15),x.sheen&&o.enable(16),x.opaque&&o.enable(17),x.pointsUvs&&o.enable(18),x.decodeVideoTexture&&o.enable(19),x.decodeVideoTextureEmissive&&o.enable(20),x.alphaToCoverage&&o.enable(21),y.push(o.mask)}(g,f),g.push(s.outputColorSpace)),g.push(f.customProgramCacheKey),g.join()},getUniforms:function(f){let g=m[f.type],y;if(g){let x=di[g];y=Gc.clone(x.uniforms)}else y=f.uniforms;return y},acquireProgram:function(f,g){let y;for(let x=0,_=h.length;x<_;x++){let b=h[x];if(b.cacheKey===g){y=b,++y.usedTimes;break}}return y===void 0&&(y=new bm(s,g,f,r),h.push(y)),y},releaseProgram:function(f){if(--f.usedTimes==0){let g=h.indexOf(f);h[g]=h[h.length-1],h.pop(),f.destroy()}},releaseShaderCache:function(f){l.remove(f)},programs:h,dispose:function(){l.dispose()}}}function Em(){let s=new WeakMap;return{has:function(e){return s.has(e)},get:function(e){let t=s.get(e);return t===void 0&&(t={},s.set(e,t)),t},remove:function(e){s.delete(e)},update:function(e,t,i){s.get(e)[t]=i},dispose:function(){s=new WeakMap}}}function Tm(s,e){return s.groupOrder!==e.groupOrder?s.groupOrder-e.groupOrder:s.renderOrder!==e.renderOrder?s.renderOrder-e.renderOrder:s.material.id!==e.material.id?s.material.id-e.material.id:s.z!==e.z?s.z-e.z:s.id-e.id}function mu(s,e){return s.groupOrder!==e.groupOrder?s.groupOrder-e.groupOrder:s.renderOrder!==e.renderOrder?s.renderOrder-e.renderOrder:s.z!==e.z?e.z-s.z:s.id-e.id}function fu(){let s=[],e=0,t=[],i=[],n=[];function r(a,o,l,c,h,d){let u=s[e];return u===void 0?(u={id:a.id,object:a,geometry:o,material:l,groupOrder:c,renderOrder:a.renderOrder,z:h,group:d},s[e]=u):(u.id=a.id,u.object=a,u.geometry=o,u.material=l,u.groupOrder=c,u.renderOrder=a.renderOrder,u.z=h,u.group=d),e++,u}return{opaque:t,transmissive:i,transparent:n,init:function(){e=0,t.length=0,i.length=0,n.length=0},push:function(a,o,l,c,h,d){let u=r(a,o,l,c,h,d);l.transmission>0?i.push(u):l.transparent===!0?n.push(u):t.push(u)},unshift:function(a,o,l,c,h,d){let u=r(a,o,l,c,h,d);l.transmission>0?i.unshift(u):l.transparent===!0?n.unshift(u):t.unshift(u)},finish:function(){for(let a=e,o=s.length;a<o;a++){let l=s[a];if(l.id===null)break;l.id=null,l.object=null,l.geometry=null,l.material=null,l.group=null}},sort:function(a,o){t.length>1&&t.sort(a||Tm),i.length>1&&i.sort(o||mu),n.length>1&&n.sort(o||mu)}}}function Am(){let s=new WeakMap;return{get:function(e,t){let i=s.get(e),n;return i===void 0?(n=new fu,s.set(e,[n])):t>=i.length?(n=new fu,i.push(n)):n=i[t],n},dispose:function(){s=new WeakMap}}}function Rm(){let s={};return{get:function(e){if(s[e.id]!==void 0)return s[e.id];let t;switch(e.type){case"DirectionalLight":t={direction:new M,color:new ye};break;case"SpotLight":t={position:new M,direction:new M,color:new ye,distance:0,coneCos:0,penumbraCos:0,decay:0};break;case"PointLight":t={position:new M,color:new ye,distance:0,decay:0};break;case"HemisphereLight":t={direction:new M,skyColor:new ye,groundColor:new ye};break;case"RectAreaLight":t={color:new ye,position:new M,halfWidth:new M,halfHeight:new M}}return s[e.id]=t,t}}}var Cm=0;function Lm(s,e){return(e.castShadow?2:0)-(s.castShadow?2:0)+(e.map?1:0)-(s.map?1:0)}function Pm(s){let e=new Rm,t=function(){let o={};return{get:function(l){if(o[l.id]!==void 0)return o[l.id];let c;switch(l.type){case"DirectionalLight":case"SpotLight":c={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new oe};break;case"PointLight":c={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new oe,shadowCameraNear:1,shadowCameraFar:1e3}}return o[l.id]=c,c}}}(),i={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};for(let o=0;o<9;o++)i.probe.push(new M);let n=new M,r=new Ee,a=new Ee;return{setup:function(o){let l=0,c=0,h=0;for(let R=0;R<9;R++)i.probe[R].set(0,0,0);let d=0,u=0,p=0,m=0,v=0,f=0,g=0,y=0,x=0,_=0,b=0;o.sort(Lm);for(let R=0,P=o.length;R<P;R++){let C=o[R],B=C.color,z=C.intensity,D=C.distance,F=C.shadow&&C.shadow.map?C.shadow.map.texture:null;if(C.isAmbientLight)l+=B.r*z,c+=B.g*z,h+=B.b*z;else if(C.isLightProbe){for(let U=0;U<9;U++)i.probe[U].addScaledVector(C.sh.coefficients[U],z);b++}else if(C.isDirectionalLight){let U=e.get(C);if(U.color.copy(C.color).multiplyScalar(C.intensity),C.castShadow){let X=C.shadow,j=t.get(C);j.shadowIntensity=X.intensity,j.shadowBias=X.bias,j.shadowNormalBias=X.normalBias,j.shadowRadius=X.radius,j.shadowMapSize=X.mapSize,i.directionalShadow[d]=j,i.directionalShadowMap[d]=F,i.directionalShadowMatrix[d]=C.shadow.matrix,f++}i.directional[d]=U,d++}else if(C.isSpotLight){let U=e.get(C);U.position.setFromMatrixPosition(C.matrixWorld),U.color.copy(B).multiplyScalar(z),U.distance=D,U.coneCos=Math.cos(C.angle),U.penumbraCos=Math.cos(C.angle*(1-C.penumbra)),U.decay=C.decay,i.spot[p]=U;let X=C.shadow;if(C.map&&(i.spotLightMap[x]=C.map,x++,X.updateMatrices(C),C.castShadow&&_++),i.spotLightMatrix[p]=X.matrix,C.castShadow){let j=t.get(C);j.shadowIntensity=X.intensity,j.shadowBias=X.bias,j.shadowNormalBias=X.normalBias,j.shadowRadius=X.radius,j.shadowMapSize=X.mapSize,i.spotShadow[p]=j,i.spotShadowMap[p]=F,y++}p++}else if(C.isRectAreaLight){let U=e.get(C);U.color.copy(B).multiplyScalar(z),U.halfWidth.set(.5*C.width,0,0),U.halfHeight.set(0,.5*C.height,0),i.rectArea[m]=U,m++}else if(C.isPointLight){let U=e.get(C);if(U.color.copy(C.color).multiplyScalar(C.intensity),U.distance=C.distance,U.decay=C.decay,C.castShadow){let X=C.shadow,j=t.get(C);j.shadowIntensity=X.intensity,j.shadowBias=X.bias,j.shadowNormalBias=X.normalBias,j.shadowRadius=X.radius,j.shadowMapSize=X.mapSize,j.shadowCameraNear=X.camera.near,j.shadowCameraFar=X.camera.far,i.pointShadow[u]=j,i.pointShadowMap[u]=F,i.pointShadowMatrix[u]=C.shadow.matrix,g++}i.point[u]=U,u++}else if(C.isHemisphereLight){let U=e.get(C);U.skyColor.copy(C.color).multiplyScalar(z),U.groundColor.copy(C.groundColor).multiplyScalar(z),i.hemi[v]=U,v++}}m>0&&(s.has("OES_texture_float_linear")===!0?(i.rectAreaLTC1=he.LTC_FLOAT_1,i.rectAreaLTC2=he.LTC_FLOAT_2):(i.rectAreaLTC1=he.LTC_HALF_1,i.rectAreaLTC2=he.LTC_HALF_2)),i.ambient[0]=l,i.ambient[1]=c,i.ambient[2]=h;let S=i.hash;S.directionalLength===d&&S.pointLength===u&&S.spotLength===p&&S.rectAreaLength===m&&S.hemiLength===v&&S.numDirectionalShadows===f&&S.numPointShadows===g&&S.numSpotShadows===y&&S.numSpotMaps===x&&S.numLightProbes===b||(i.directional.length=d,i.spot.length=p,i.rectArea.length=m,i.point.length=u,i.hemi.length=v,i.directionalShadow.length=f,i.directionalShadowMap.length=f,i.pointShadow.length=g,i.pointShadowMap.length=g,i.spotShadow.length=y,i.spotShadowMap.length=y,i.directionalShadowMatrix.length=f,i.pointShadowMatrix.length=g,i.spotLightMatrix.length=y+x-_,i.spotLightMap.length=x,i.numSpotLightShadowsWithMaps=_,i.numLightProbes=b,S.directionalLength=d,S.pointLength=u,S.spotLength=p,S.rectAreaLength=m,S.hemiLength=v,S.numDirectionalShadows=f,S.numPointShadows=g,S.numSpotShadows=y,S.numSpotMaps=x,S.numLightProbes=b,i.version=Cm++)},setupView:function(o,l){let c=0,h=0,d=0,u=0,p=0,m=l.matrixWorldInverse;for(let v=0,f=o.length;v<f;v++){let g=o[v];if(g.isDirectionalLight){let y=i.directional[c];y.direction.setFromMatrixPosition(g.matrixWorld),n.setFromMatrixPosition(g.target.matrixWorld),y.direction.sub(n),y.direction.transformDirection(m),c++}else if(g.isSpotLight){let y=i.spot[d];y.position.setFromMatrixPosition(g.matrixWorld),y.position.applyMatrix4(m),y.direction.setFromMatrixPosition(g.matrixWorld),n.setFromMatrixPosition(g.target.matrixWorld),y.direction.sub(n),y.direction.transformDirection(m),d++}else if(g.isRectAreaLight){let y=i.rectArea[u];y.position.setFromMatrixPosition(g.matrixWorld),y.position.applyMatrix4(m),a.identity(),r.copy(g.matrixWorld),r.premultiply(m),a.extractRotation(r),y.halfWidth.set(.5*g.width,0,0),y.halfHeight.set(0,.5*g.height,0),y.halfWidth.applyMatrix4(a),y.halfHeight.applyMatrix4(a),u++}else if(g.isPointLight){let y=i.point[h];y.position.setFromMatrixPosition(g.matrixWorld),y.position.applyMatrix4(m),h++}else if(g.isHemisphereLight){let y=i.hemi[p];y.direction.setFromMatrixPosition(g.matrixWorld),y.direction.transformDirection(m),p++}}},state:i}}function gu(s){let e=new Pm(s),t=[],i=[],n={lightsArray:t,shadowsArray:i,camera:null,lights:e,transmissionRenderTarget:{}};return{init:function(r){n.camera=r,t.length=0,i.length=0},state:n,setupLights:function(){e.setup(t)},setupLightsView:function(r){e.setupView(t,r)},pushLight:function(r){t.push(r)},pushShadow:function(r){i.push(r)}}}function Im(s){let e=new WeakMap;return{get:function(t,i=0){let n=e.get(t),r;return n===void 0?(r=new gu(s),e.set(t,[r])):i>=n.length?(r=new gu(s),n.push(r)):r=n[i],r},dispose:function(){e=new WeakMap}}}var Kl=class extends gi{static get type(){return"MeshDepthMaterial"}constructor(e){super(),this.isMeshDepthMaterial=!0,this.depthPacking=3200,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(e)}copy(e){return super.copy(e),this.depthPacking=e.depthPacking,this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this}},Ql=class extends gi{static get type(){return"MeshDistanceMaterial"}constructor(e){super(),this.isMeshDistanceMaterial=!0,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(e)}copy(e){return super.copy(e),this.map=e.map,this.alphaMap=e.alphaMap,this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this}};function Dm(s,e,t){let i=new Kn,n=new oe,r=new oe,a=new ct,o=new Kl({depthPacking:3201}),l=new Ql,c={},h=t.maxTextureSize,d={[xd]:1,[Uc]:0,[Xt]:2},u=new Tt({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new oe},radius:{value:4}},vertexShader:`void main() {
	gl_Position = vec4( position, 1.0 );
}`,fragmentShader:`uniform sampler2D shadow_pass;
uniform vec2 resolution;
uniform float radius;
#include <packing>
void main() {
	const float samples = float( VSM_SAMPLES );
	float mean = 0.0;
	float squared_mean = 0.0;
	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );
	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;
	for ( float i = 0.0; i < samples; i ++ ) {
		float uvOffset = uvStart + i * uvStride;
		#ifdef HORIZONTAL_PASS
			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );
			mean += distribution.x;
			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;
		#else
			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );
			mean += depth;
			squared_mean += depth * depth;
		#endif
	}
	mean = mean / samples;
	squared_mean = squared_mean / samples;
	float std_dev = sqrt( squared_mean - mean * mean );
	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );
}`}),p=u.clone();p.defines.HORIZONTAL_PASS=1;let m=new Ve;m.setAttribute("position",new We(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));let v=new Ce(m,u),f=this;this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=1;let g=this.type;function y(S,R){let P=e.update(v);u.defines.VSM_SAMPLES!==S.blurSamples&&(u.defines.VSM_SAMPLES=S.blurSamples,p.defines.VSM_SAMPLES=S.blurSamples,u.needsUpdate=!0,p.needsUpdate=!0),S.mapPass===null&&(S.mapPass=new si(n.x,n.y)),u.uniforms.shadow_pass.value=S.map.texture,u.uniforms.resolution.value=S.mapSize,u.uniforms.radius.value=S.radius,s.setRenderTarget(S.mapPass),s.clear(),s.renderBufferDirect(R,null,P,u,v,null),p.uniforms.shadow_pass.value=S.mapPass.texture,p.uniforms.resolution.value=S.mapSize,p.uniforms.radius.value=S.radius,s.setRenderTarget(S.map),s.clear(),s.renderBufferDirect(R,null,P,p,v,null)}function x(S,R,P,C){let B=null,z=P.isPointLight===!0?S.customDistanceMaterial:S.customDepthMaterial;if(z!==void 0)B=z;else if(B=P.isPointLight===!0?l:o,s.localClippingEnabled&&R.clipShadows===!0&&Array.isArray(R.clippingPlanes)&&R.clippingPlanes.length!==0||R.displacementMap&&R.displacementScale!==0||R.alphaMap&&R.alphaTest>0||R.map&&R.alphaTest>0){let D=B.uuid,F=R.uuid,U=c[D];U===void 0&&(U={},c[D]=U);let X=U[F];X===void 0&&(X=B.clone(),U[F]=X,R.addEventListener("dispose",b)),B=X}return B.visible=R.visible,B.wireframe=R.wireframe,B.side=C===3?R.shadowSide!==null?R.shadowSide:R.side:R.shadowSide!==null?R.shadowSide:d[R.side],B.alphaMap=R.alphaMap,B.alphaTest=R.alphaTest,B.map=R.map,B.clipShadows=R.clipShadows,B.clippingPlanes=R.clippingPlanes,B.clipIntersection=R.clipIntersection,B.displacementMap=R.displacementMap,B.displacementScale=R.displacementScale,B.displacementBias=R.displacementBias,B.wireframeLinewidth=R.wireframeLinewidth,B.linewidth=R.linewidth,P.isPointLight===!0&&B.isMeshDistanceMaterial===!0&&(s.properties.get(B).light=P),B}function _(S,R,P,C,B){if(S.visible===!1)return;if(S.layers.test(R.layers)&&(S.isMesh||S.isLine||S.isPoints)&&(S.castShadow||S.receiveShadow&&B===3)&&(!S.frustumCulled||i.intersectsObject(S))){S.modelViewMatrix.multiplyMatrices(P.matrixWorldInverse,S.matrixWorld);let D=e.update(S),F=S.material;if(Array.isArray(F)){let U=D.groups;for(let X=0,j=U.length;X<j;X++){let Z=U[X],$=F[Z.materialIndex];if($&&$.visible){let ue=x(S,$,C,B);S.onBeforeShadow(s,S,R,P,D,ue,Z),s.renderBufferDirect(P,null,D,ue,S,Z),S.onAfterShadow(s,S,R,P,D,ue,Z)}}}else if(F.visible){let U=x(S,F,C,B);S.onBeforeShadow(s,S,R,P,D,U,null),s.renderBufferDirect(P,null,D,U,S,null),S.onAfterShadow(s,S,R,P,D,U,null)}}let z=S.children;for(let D=0,F=z.length;D<F;D++)_(z[D],R,P,C,B)}function b(S){S.target.removeEventListener("dispose",b);for(let R in c){let P=c[R],C=S.target.uuid;C in P&&(P[C].dispose(),delete P[C])}}this.render=function(S,R,P){if(f.enabled===!1||f.autoUpdate===!1&&f.needsUpdate===!1||S.length===0)return;let C=s.getRenderTarget(),B=s.getActiveCubeFace(),z=s.getActiveMipmapLevel(),D=s.state;D.setBlending(0),D.buffers.color.setClear(1,1,1,1),D.buffers.depth.setTest(!0),D.setScissorTest(!1);let F=g!==3&&this.type===3,U=g===3&&this.type!==3;for(let X=0,j=S.length;X<j;X++){let Z=S[X],$=Z.shadow;if($===void 0){console.warn("THREE.WebGLShadowMap:",Z,"has no shadow.");continue}if($.autoUpdate===!1&&$.needsUpdate===!1)continue;n.copy($.mapSize);let ue=$.getFrameExtents();if(n.multiply(ue),r.copy($.mapSize),(n.x>h||n.y>h)&&(n.x>h&&(r.x=Math.floor(h/ue.x),n.x=r.x*ue.x,$.mapSize.x=r.x),n.y>h&&(r.y=Math.floor(h/ue.y),n.y=r.y*ue.y,$.mapSize.y=r.y)),$.map===null||F===!0||U===!0){let K=this.type!==3?{minFilter:ii,magFilter:ii}:{};$.map!==null&&$.map.dispose(),$.map=new si(n.x,n.y,K),$.map.texture.name=Z.name+".shadowMap",$.camera.updateProjectionMatrix()}s.setRenderTarget($.map),s.clear();let _e=$.getViewportCount();for(let K=0;K<_e;K++){let ae=$.getViewport(K);a.set(r.x*ae.x,r.y*ae.y,r.x*ae.z,r.y*ae.w),D.viewport(a),$.updateMatrices(Z,K),i=$.getFrustum(),_(R,P,$.camera,Z,this.type)}$.isPointLightShadow!==!0&&this.type===3&&y($,P),$.needsUpdate=!1}g=this.type,f.needsUpdate=!1,s.setRenderTarget(C,B,z)}}var Um={[Nd]:1,[zd]:6,[Fd]:7,[kd]:5,[Od]:0,[Hd]:2,[Vd]:4,[Bd]:3};function Nm(s,e){let t=new function(){let w=!1,I=new ct,V=null,te=new ct(0,0,0,0);return{setMask:function(H){V===H||w||(s.colorMask(H,H,H,H),V=H)},setLocked:function(H){w=H},setClear:function(H,Q,J,ne,ve){ve===!0&&(H*=ne,Q*=ne,J*=ne),I.set(H,Q,J,ne),te.equals(I)===!1&&(s.clearColor(H,Q,J,ne),te.copy(I))},reset:function(){w=!1,V=null,te.set(-1,0,0,0)}}},i=new function(){let w=!1,I=!1,V=null,te=null,H=null;return{setReversed:function(Q){if(I!==Q){let J=e.get("EXT_clip_control");I?J.clipControlEXT(J.LOWER_LEFT_EXT,J.ZERO_TO_ONE_EXT):J.clipControlEXT(J.LOWER_LEFT_EXT,J.NEGATIVE_ONE_TO_ONE_EXT);let ne=H;H=null,this.setClear(ne)}I=Q},getReversed:function(){return I},setTest:function(Q){Q?ge(s.DEPTH_TEST):ce(s.DEPTH_TEST)},setMask:function(Q){V===Q||w||(s.depthMask(Q),V=Q)},setFunc:function(Q){if(I&&(Q=Um[Q]),te!==Q){switch(Q){case 0:s.depthFunc(s.NEVER);break;case 1:s.depthFunc(s.ALWAYS);break;case 2:s.depthFunc(s.LESS);break;case 3:default:s.depthFunc(s.LEQUAL);break;case 4:s.depthFunc(s.EQUAL);break;case 5:s.depthFunc(s.GEQUAL);break;case 6:s.depthFunc(s.GREATER);break;case 7:s.depthFunc(s.NOTEQUAL)}te=Q}},setLocked:function(Q){w=Q},setClear:function(Q){H!==Q&&(I&&(Q=1-Q),s.clearDepth(Q),H=Q)},reset:function(){w=!1,V=null,te=null,H=null,I=!1}}},n=new function(){let w=!1,I=null,V=null,te=null,H=null,Q=null,J=null,ne=null,ve=null;return{setTest:function(me){w||(me?ge(s.STENCIL_TEST):ce(s.STENCIL_TEST))},setMask:function(me){I===me||w||(s.stencilMask(me),I=me)},setFunc:function(me,Se,Le){V===me&&te===Se&&H===Le||(s.stencilFunc(me,Se,Le),V=me,te=Se,H=Le)},setOp:function(me,Se,Le){Q===me&&J===Se&&ne===Le||(s.stencilOp(me,Se,Le),Q=me,J=Se,ne=Le)},setLocked:function(me){w=me},setClear:function(me){ve!==me&&(s.clearStencil(me),ve=me)},reset:function(){w=!1,I=null,V=null,te=null,H=null,Q=null,J=null,ne=null,ve=null}}},r=new WeakMap,a=new WeakMap,o={},l={},c=new WeakMap,h=[],d=null,u=!1,p=null,m=null,v=null,f=null,g=null,y=null,x=null,_=new ye(0,0,0),b=0,S=!1,R=null,P=null,C=null,B=null,z=null,D=s.getParameter(s.MAX_COMBINED_TEXTURE_IMAGE_UNITS),F=!1,U=0,X=s.getParameter(s.VERSION);X.indexOf("WebGL")!==-1?(U=parseFloat(/^WebGL (\d)/.exec(X)[1]),F=U>=1):X.indexOf("OpenGL ES")!==-1&&(U=parseFloat(/^OpenGL ES (\d)/.exec(X)[1]),F=U>=2);let j=null,Z={},$=s.getParameter(s.SCISSOR_BOX),ue=s.getParameter(s.VIEWPORT),_e=new ct().fromArray($),K=new ct().fromArray(ue);function ae(w,I,V,te){let H=new Uint8Array(4),Q=s.createTexture();s.bindTexture(w,Q),s.texParameteri(w,s.TEXTURE_MIN_FILTER,s.NEAREST),s.texParameteri(w,s.TEXTURE_MAG_FILTER,s.NEAREST);for(let J=0;J<V;J++)w===s.TEXTURE_3D||w===s.TEXTURE_2D_ARRAY?s.texImage3D(I,0,s.RGBA,1,1,te,0,s.RGBA,s.UNSIGNED_BYTE,H):s.texImage2D(I+J,0,s.RGBA,1,1,0,s.RGBA,s.UNSIGNED_BYTE,H);return Q}let pe={};function ge(w){o[w]!==!0&&(s.enable(w),o[w]=!0)}function ce(w){o[w]!==!1&&(s.disable(w),o[w]=!1)}pe[s.TEXTURE_2D]=ae(s.TEXTURE_2D,s.TEXTURE_2D,1),pe[s.TEXTURE_CUBE_MAP]=ae(s.TEXTURE_CUBE_MAP,s.TEXTURE_CUBE_MAP_POSITIVE_X,6),pe[s.TEXTURE_2D_ARRAY]=ae(s.TEXTURE_2D_ARRAY,s.TEXTURE_2D_ARRAY,1,1),pe[s.TEXTURE_3D]=ae(s.TEXTURE_3D,s.TEXTURE_3D,1,1),t.setClear(0,0,0,1),i.setClear(1),n.setClear(0),ge(s.DEPTH_TEST),i.setFunc(3),O(!1),L(1),ge(s.CULL_FACE),k(0);let A={[ln]:s.FUNC_ADD,[_d]:s.FUNC_SUBTRACT,[Md]:s.FUNC_REVERSE_SUBTRACT};A[103]=s.MIN,A[104]=s.MAX;let T={[bd]:s.ZERO,[Sd]:s.ONE,[wd]:s.SRC_COLOR,[ol]:s.SRC_ALPHA,[Ld]:s.SRC_ALPHA_SATURATE,[Rd]:s.DST_COLOR,[Td]:s.DST_ALPHA,[Ed]:s.ONE_MINUS_SRC_COLOR,[ll]:s.ONE_MINUS_SRC_ALPHA,[Cd]:s.ONE_MINUS_DST_COLOR,[Ad]:s.ONE_MINUS_DST_ALPHA,[Pd]:s.CONSTANT_COLOR,[Id]:s.ONE_MINUS_CONSTANT_COLOR,[Dd]:s.CONSTANT_ALPHA,[Ud]:s.ONE_MINUS_CONSTANT_ALPHA};function k(w,I,V,te,H,Q,J,ne,ve,me){if(w!==0){if(u===!1&&(ge(s.BLEND),u=!0),w===5)H=H||I,Q=Q||V,J=J||te,I===m&&H===g||(s.blendEquationSeparate(A[I],A[H]),m=I,g=H),V===v&&te===f&&Q===y&&J===x||(s.blendFuncSeparate(T[V],T[te],T[Q],T[J]),v=V,f=te,y=Q,x=J),ne.equals(_)!==!1&&ve===b||(s.blendColor(ne.r,ne.g,ne.b,ve),_.copy(ne),b=ve),p=w,S=!1;else if(w!==p||me!==S){if(m===ln&&g===ln||(s.blendEquation(s.FUNC_ADD),m=ln,g=ln),me)switch(w){case 1:s.blendFuncSeparate(s.ONE,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case 2:s.blendFunc(s.ONE,s.ONE);break;case 3:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case 4:s.blendFuncSeparate(s.ZERO,s.SRC_COLOR,s.ZERO,s.SRC_ALPHA);break;default:console.error("THREE.WebGLState: Invalid blending: ",w)}else switch(w){case 1:s.blendFuncSeparate(s.SRC_ALPHA,s.ONE_MINUS_SRC_ALPHA,s.ONE,s.ONE_MINUS_SRC_ALPHA);break;case 2:s.blendFunc(s.SRC_ALPHA,s.ONE);break;case 3:s.blendFuncSeparate(s.ZERO,s.ONE_MINUS_SRC_COLOR,s.ZERO,s.ONE);break;case 4:s.blendFunc(s.ZERO,s.SRC_COLOR);break;default:console.error("THREE.WebGLState: Invalid blending: ",w)}v=null,f=null,y=null,x=null,_.set(0,0,0),b=0,p=w,S=me}}else u===!0&&(ce(s.BLEND),u=!1)}function O(w){R!==w&&(w?s.frontFace(s.CW):s.frontFace(s.CCW),R=w)}function L(w){w!==0?(ge(s.CULL_FACE),w!==P&&(w===1?s.cullFace(s.BACK):w===2?s.cullFace(s.FRONT):s.cullFace(s.FRONT_AND_BACK))):ce(s.CULL_FACE),P=w}function N(w,I,V){w?(ge(s.POLYGON_OFFSET_FILL),B===I&&z===V||(s.polygonOffset(I,V),B=I,z=V)):ce(s.POLYGON_OFFSET_FILL)}return{buffers:{color:t,depth:i,stencil:n},enable:ge,disable:ce,bindFramebuffer:function(w,I){return l[w]!==I&&(s.bindFramebuffer(w,I),l[w]=I,w===s.DRAW_FRAMEBUFFER&&(l[s.FRAMEBUFFER]=I),w===s.FRAMEBUFFER&&(l[s.DRAW_FRAMEBUFFER]=I),!0)},drawBuffers:function(w,I){let V=h,te=!1;if(w){V=c.get(I),V===void 0&&(V=[],c.set(I,V));let H=w.textures;if(V.length!==H.length||V[0]!==s.COLOR_ATTACHMENT0){for(let Q=0,J=H.length;Q<J;Q++)V[Q]=s.COLOR_ATTACHMENT0+Q;V.length=H.length,te=!0}}else V[0]!==s.BACK&&(V[0]=s.BACK,te=!0);te&&s.drawBuffers(V)},useProgram:function(w){return d!==w&&(s.useProgram(w),d=w,!0)},setBlending:k,setMaterial:function(w,I){w.side===2?ce(s.CULL_FACE):ge(s.CULL_FACE);let V=w.side===1;I&&(V=!V),O(V),w.blending===1&&w.transparent===!1?k(0):k(w.blending,w.blendEquation,w.blendSrc,w.blendDst,w.blendEquationAlpha,w.blendSrcAlpha,w.blendDstAlpha,w.blendColor,w.blendAlpha,w.premultipliedAlpha),i.setFunc(w.depthFunc),i.setTest(w.depthTest),i.setMask(w.depthWrite),t.setMask(w.colorWrite);let te=w.stencilWrite;n.setTest(te),te&&(n.setMask(w.stencilWriteMask),n.setFunc(w.stencilFunc,w.stencilRef,w.stencilFuncMask),n.setOp(w.stencilFail,w.stencilZFail,w.stencilZPass)),N(w.polygonOffset,w.polygonOffsetFactor,w.polygonOffsetUnits),w.alphaToCoverage===!0?ge(s.SAMPLE_ALPHA_TO_COVERAGE):ce(s.SAMPLE_ALPHA_TO_COVERAGE)},setFlipSided:O,setCullFace:L,setLineWidth:function(w){w!==C&&(F&&s.lineWidth(w),C=w)},setPolygonOffset:N,setScissorTest:function(w){w?ge(s.SCISSOR_TEST):ce(s.SCISSOR_TEST)},activeTexture:function(w){w===void 0&&(w=s.TEXTURE0+D-1),j!==w&&(s.activeTexture(w),j=w)},bindTexture:function(w,I,V){V===void 0&&(V=j===null?s.TEXTURE0+D-1:j);let te=Z[V];te===void 0&&(te={type:void 0,texture:void 0},Z[V]=te),te.type===w&&te.texture===I||(j!==V&&(s.activeTexture(V),j=V),s.bindTexture(w,I||pe[w]),te.type=w,te.texture=I)},unbindTexture:function(){let w=Z[j];w!==void 0&&w.type!==void 0&&(s.bindTexture(w.type,null),w.type=void 0,w.texture=void 0)},compressedTexImage2D:function(){try{s.compressedTexImage2D.apply(s,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},compressedTexImage3D:function(){try{s.compressedTexImage3D.apply(s,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},texImage2D:function(){try{s.texImage2D.apply(s,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},texImage3D:function(){try{s.texImage3D.apply(s,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},updateUBOMapping:function(w,I){let V=a.get(I);V===void 0&&(V=new WeakMap,a.set(I,V));let te=V.get(w);te===void 0&&(te=s.getUniformBlockIndex(I,w.name),V.set(w,te))},uniformBlockBinding:function(w,I){let V=a.get(I).get(w);r.get(I)!==V&&(s.uniformBlockBinding(I,V,w.__bindingPointIndex),r.set(I,V))},texStorage2D:function(){try{s.texStorage2D.apply(s,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},texStorage3D:function(){try{s.texStorage3D.apply(s,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},texSubImage2D:function(){try{s.texSubImage2D.apply(s,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},texSubImage3D:function(){try{s.texSubImage3D.apply(s,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},compressedTexSubImage2D:function(){try{s.compressedTexSubImage2D.apply(s,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},compressedTexSubImage3D:function(){try{s.compressedTexSubImage3D.apply(s,arguments)}catch(w){console.error("THREE.WebGLState:",w)}},scissor:function(w){_e.equals(w)===!1&&(s.scissor(w.x,w.y,w.z,w.w),_e.copy(w))},viewport:function(w){K.equals(w)===!1&&(s.viewport(w.x,w.y,w.z,w.w),K.copy(w))},reset:function(){s.disable(s.BLEND),s.disable(s.CULL_FACE),s.disable(s.DEPTH_TEST),s.disable(s.POLYGON_OFFSET_FILL),s.disable(s.SCISSOR_TEST),s.disable(s.STENCIL_TEST),s.disable(s.SAMPLE_ALPHA_TO_COVERAGE),s.blendEquation(s.FUNC_ADD),s.blendFunc(s.ONE,s.ZERO),s.blendFuncSeparate(s.ONE,s.ZERO,s.ONE,s.ZERO),s.blendColor(0,0,0,0),s.colorMask(!0,!0,!0,!0),s.clearColor(0,0,0,0),s.depthMask(!0),s.depthFunc(s.LESS),i.setReversed(!1),s.clearDepth(1),s.stencilMask(4294967295),s.stencilFunc(s.ALWAYS,0,4294967295),s.stencilOp(s.KEEP,s.KEEP,s.KEEP),s.clearStencil(0),s.cullFace(s.BACK),s.frontFace(s.CCW),s.polygonOffset(0,0),s.activeTexture(s.TEXTURE0),s.bindFramebuffer(s.FRAMEBUFFER,null),s.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),s.bindFramebuffer(s.READ_FRAMEBUFFER,null),s.useProgram(null),s.lineWidth(1),s.scissor(0,0,s.canvas.width,s.canvas.height),s.viewport(0,0,s.canvas.width,s.canvas.height),o={},j=null,Z={},l={},c=new WeakMap,h=[],d=null,u=!1,p=null,m=null,v=null,f=null,g=null,y=null,x=null,_=new ye(0,0,0),b=0,S=!1,R=null,P=null,C=null,B=null,z=null,_e.set(0,0,s.canvas.width,s.canvas.height),K.set(0,0,s.canvas.width,s.canvas.height),t.reset(),i.reset(),n.reset()}}}function vu(s,e,t,i){let n=function(r){switch(r){case Vi:case Fu:return{byteLength:1,components:1};case Hs:case Bu:case vn:return{byteLength:2,components:1};case Oc:case zc:return{byteLength:2,components:4};case un:case Nc:case pi:return{byteLength:4,components:1};case Hu:return{byteLength:4,components:3}}throw new Error(`Unknown texture type ${r}.`)}(i);switch(t){case Vu:case Wu:return s*e;case Xu:return s*e*2;case kc:case Fc:return s*e/n.components*n.byteLength;case qu:case Bc:return s*e*2/n.components*n.byteLength;case Gu:return s*e*3/n.components*n.byteLength;case mi:case Hc:return s*e*4/n.components*n.byteLength;case ia:case na:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*8;case sa:case ra:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*16;case pl:case fl:return Math.max(s,16)*Math.max(e,8)/4;case dl:case ml:return Math.max(s,8)*Math.max(e,8)/2;case gl:case vl:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*8;case yl:case xl:return Math.floor((s+3)/4)*Math.floor((e+3)/4)*16;case _l:return Math.floor((s+4)/5)*Math.floor((e+3)/4)*16;case Ml:return Math.floor((s+4)/5)*Math.floor((e+4)/5)*16;case bl:return Math.floor((s+5)/6)*Math.floor((e+4)/5)*16;case Sl:return Math.floor((s+5)/6)*Math.floor((e+5)/6)*16;case wl:return Math.floor((s+7)/8)*Math.floor((e+4)/5)*16;case El:return Math.floor((s+7)/8)*Math.floor((e+5)/6)*16;case Tl:return Math.floor((s+7)/8)*Math.floor((e+7)/8)*16;case Al:return Math.floor((s+9)/10)*Math.floor((e+4)/5)*16;case Rl:return Math.floor((s+9)/10)*Math.floor((e+5)/6)*16;case Cl:return Math.floor((s+9)/10)*Math.floor((e+7)/8)*16;case Ll:return Math.floor((s+9)/10)*Math.floor((e+9)/10)*16;case Pl:return Math.floor((s+11)/12)*Math.floor((e+9)/10)*16;case Il:return Math.floor((s+11)/12)*Math.floor((e+11)/12)*16;case aa:case Dl:case Ul:return Math.ceil(s/4)*Math.ceil(e/4)*16;case ju:case Nl:return Math.ceil(s/4)*Math.ceil(e/4)*8;case Ol:case zl:return Math.ceil(s/4)*Math.ceil(e/4)*16}throw new Error(`Unable to determine texture byte length for ${t} format.`)}function Om(s,e,t,i,n,r,a){let o=e.has("WEBGL_multisampled_render_to_texture")?e.get("WEBGL_multisampled_render_to_texture"):null,l=typeof navigator<"u"&&/OculusBrowser/g.test(navigator.userAgent),c=new oe,h=new WeakMap,d,u=new WeakMap,p=!1;try{p=typeof OffscreenCanvas<"u"&&new OffscreenCanvas(1,1).getContext("2d")!==null}catch{}function m(A,T){return p?new OffscreenCanvas(A,T):ca("canvas")}function v(A,T,k){let O=1,L=ce(A);if((L.width>k||L.height>k)&&(O=k/Math.max(L.width,L.height)),O<1){if(typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement||typeof HTMLCanvasElement<"u"&&A instanceof HTMLCanvasElement||typeof ImageBitmap<"u"&&A instanceof ImageBitmap||typeof VideoFrame<"u"&&A instanceof VideoFrame){let N=Math.floor(O*L.width),w=Math.floor(O*L.height);d===void 0&&(d=m(N,w));let I=T?m(N,w):d;return I.width=N,I.height=w,I.getContext("2d").drawImage(A,0,0,N,w),console.warn("THREE.WebGLRenderer: Texture has been resized from ("+L.width+"x"+L.height+") to ("+N+"x"+w+")."),I}return"data"in A&&console.warn("THREE.WebGLRenderer: Image in DataTexture is too big ("+L.width+"x"+L.height+")."),A}return A}function f(A){return A.generateMipmaps}function g(A){s.generateMipmap(A)}function y(A){return A.isWebGLCubeRenderTarget?s.TEXTURE_CUBE_MAP:A.isWebGL3DRenderTarget?s.TEXTURE_3D:A.isWebGLArrayRenderTarget||A.isCompressedArrayTexture?s.TEXTURE_2D_ARRAY:s.TEXTURE_2D}function x(A,T,k,O,L=!1){if(A!==null){if(s[A]!==void 0)return s[A];console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '"+A+"'")}let N=T;if(T===s.RED&&(k===s.FLOAT&&(N=s.R32F),k===s.HALF_FLOAT&&(N=s.R16F),k===s.UNSIGNED_BYTE&&(N=s.R8)),T===s.RED_INTEGER&&(k===s.UNSIGNED_BYTE&&(N=s.R8UI),k===s.UNSIGNED_SHORT&&(N=s.R16UI),k===s.UNSIGNED_INT&&(N=s.R32UI),k===s.BYTE&&(N=s.R8I),k===s.SHORT&&(N=s.R16I),k===s.INT&&(N=s.R32I)),T===s.RG&&(k===s.FLOAT&&(N=s.RG32F),k===s.HALF_FLOAT&&(N=s.RG16F),k===s.UNSIGNED_BYTE&&(N=s.RG8)),T===s.RG_INTEGER&&(k===s.UNSIGNED_BYTE&&(N=s.RG8UI),k===s.UNSIGNED_SHORT&&(N=s.RG16UI),k===s.UNSIGNED_INT&&(N=s.RG32UI),k===s.BYTE&&(N=s.RG8I),k===s.SHORT&&(N=s.RG16I),k===s.INT&&(N=s.RG32I)),T===s.RGB_INTEGER&&(k===s.UNSIGNED_BYTE&&(N=s.RGB8UI),k===s.UNSIGNED_SHORT&&(N=s.RGB16UI),k===s.UNSIGNED_INT&&(N=s.RGB32UI),k===s.BYTE&&(N=s.RGB8I),k===s.SHORT&&(N=s.RGB16I),k===s.INT&&(N=s.RGB32I)),T===s.RGBA_INTEGER&&(k===s.UNSIGNED_BYTE&&(N=s.RGBA8UI),k===s.UNSIGNED_SHORT&&(N=s.RGBA16UI),k===s.UNSIGNED_INT&&(N=s.RGBA32UI),k===s.BYTE&&(N=s.RGBA8I),k===s.SHORT&&(N=s.RGBA16I),k===s.INT&&(N=s.RGBA32I)),T===s.RGB&&k===s.UNSIGNED_INT_5_9_9_9_REV&&(N=s.RGB9_E5),T===s.RGBA){let w=L?ka:je.getTransfer(O);k===s.FLOAT&&(N=s.RGBA32F),k===s.HALF_FLOAT&&(N=s.RGBA16F),k===s.UNSIGNED_BYTE&&(N=w===et?s.SRGB8_ALPHA8:s.RGBA8),k===s.UNSIGNED_SHORT_4_4_4_4&&(N=s.RGBA4),k===s.UNSIGNED_SHORT_5_5_5_1&&(N=s.RGB5_A1)}return N!==s.R16F&&N!==s.R32F&&N!==s.RG16F&&N!==s.RG32F&&N!==s.RGBA16F&&N!==s.RGBA32F||e.get("EXT_color_buffer_float"),N}function _(A,T){let k;return A?T===null||T===un||T===jn?k=s.DEPTH24_STENCIL8:T===pi?k=s.DEPTH32F_STENCIL8:T===Hs&&(k=s.DEPTH24_STENCIL8,console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):T===null||T===un||T===jn?k=s.DEPTH_COMPONENT24:T===pi?k=s.DEPTH_COMPONENT32F:T===Hs&&(k=s.DEPTH_COMPONENT16),k}function b(A,T){return f(A)===!0||A.isFramebufferTexture&&A.minFilter!==ii&&A.minFilter!==Ti?Math.log2(Math.max(T.width,T.height))+1:A.mipmaps!==void 0&&A.mipmaps.length>0?A.mipmaps.length:A.isCompressedTexture&&Array.isArray(A.image)?T.mipmaps.length:1}function S(A){let T=A.target;T.removeEventListener("dispose",S),function(k){let O=i.get(k);if(O.__webglInit===void 0)return;let L=k.source,N=u.get(L);if(N){let w=N[O.__cacheKey];w.usedTimes--,w.usedTimes===0&&P(k),Object.keys(N).length===0&&u.delete(L)}i.remove(k)}(T),T.isVideoTexture&&h.delete(T)}function R(A){let T=A.target;T.removeEventListener("dispose",R),function(k){let O=i.get(k);if(k.depthTexture&&(k.depthTexture.dispose(),i.remove(k.depthTexture)),k.isWebGLCubeRenderTarget)for(let N=0;N<6;N++){if(Array.isArray(O.__webglFramebuffer[N]))for(let w=0;w<O.__webglFramebuffer[N].length;w++)s.deleteFramebuffer(O.__webglFramebuffer[N][w]);else s.deleteFramebuffer(O.__webglFramebuffer[N]);O.__webglDepthbuffer&&s.deleteRenderbuffer(O.__webglDepthbuffer[N])}else{if(Array.isArray(O.__webglFramebuffer))for(let N=0;N<O.__webglFramebuffer.length;N++)s.deleteFramebuffer(O.__webglFramebuffer[N]);else s.deleteFramebuffer(O.__webglFramebuffer);if(O.__webglDepthbuffer&&s.deleteRenderbuffer(O.__webglDepthbuffer),O.__webglMultisampledFramebuffer&&s.deleteFramebuffer(O.__webglMultisampledFramebuffer),O.__webglColorRenderbuffer)for(let N=0;N<O.__webglColorRenderbuffer.length;N++)O.__webglColorRenderbuffer[N]&&s.deleteRenderbuffer(O.__webglColorRenderbuffer[N]);O.__webglDepthRenderbuffer&&s.deleteRenderbuffer(O.__webglDepthRenderbuffer)}let L=k.textures;for(let N=0,w=L.length;N<w;N++){let I=i.get(L[N]);I.__webglTexture&&(s.deleteTexture(I.__webglTexture),a.memory.textures--),i.remove(L[N])}i.remove(k)}(T)}function P(A){let T=i.get(A);s.deleteTexture(T.__webglTexture);let k=A.source;delete u.get(k)[T.__cacheKey],a.memory.textures--}let C=0;function B(A,T){let k=i.get(A);if(A.isVideoTexture&&function(O){let L=a.render.frame;h.get(O)!==L&&(h.set(O,L),O.update())}(A),A.isRenderTargetTexture===!1&&A.version>0&&k.__version!==A.version){let O=A.image;if(O===null)console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");else{if(O.complete!==!1)return void j(k,A,T);console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete")}}t.bindTexture(s.TEXTURE_2D,k.__webglTexture,s.TEXTURE0+T)}let z={[Fs]:s.REPEAT,[Bs]:s.CLAMP_TO_EDGE,[ul]:s.MIRRORED_REPEAT},D={[ii]:s.NEAREST,[Gd]:s.NEAREST_MIPMAP_NEAREST,[_r]:s.NEAREST_MIPMAP_LINEAR,[Ti]:s.LINEAR,[wo]:s.LINEAR_MIPMAP_NEAREST,[Bn]:s.LINEAR_MIPMAP_LINEAR},F={[Wd]:s.NEVER,[Jd]:s.ALWAYS,[Xd]:s.LESS,[jd]:s.LEQUAL,[qd]:s.EQUAL,[Zd]:s.GEQUAL,[Yd]:s.GREATER,[$d]:s.NOTEQUAL};function U(A,T){if(T.type!==pi||e.has("OES_texture_float_linear")!==!1||T.magFilter!==Ti&&T.magFilter!==wo&&T.magFilter!==_r&&T.magFilter!==Bn&&T.minFilter!==Ti&&T.minFilter!==wo&&T.minFilter!==_r&&T.minFilter!==Bn||console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),s.texParameteri(A,s.TEXTURE_WRAP_S,z[T.wrapS]),s.texParameteri(A,s.TEXTURE_WRAP_T,z[T.wrapT]),A!==s.TEXTURE_3D&&A!==s.TEXTURE_2D_ARRAY||s.texParameteri(A,s.TEXTURE_WRAP_R,z[T.wrapR]),s.texParameteri(A,s.TEXTURE_MAG_FILTER,D[T.magFilter]),s.texParameteri(A,s.TEXTURE_MIN_FILTER,D[T.minFilter]),T.compareFunction&&(s.texParameteri(A,s.TEXTURE_COMPARE_MODE,s.COMPARE_REF_TO_TEXTURE),s.texParameteri(A,s.TEXTURE_COMPARE_FUNC,F[T.compareFunction])),e.has("EXT_texture_filter_anisotropic")===!0){if(T.magFilter===ii||T.minFilter!==_r&&T.minFilter!==Bn||T.type===pi&&e.has("OES_texture_float_linear")===!1)return;if(T.anisotropy>1||i.get(T).__currentAnisotropy){let k=e.get("EXT_texture_filter_anisotropic");s.texParameterf(A,k.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(T.anisotropy,n.getMaxAnisotropy())),i.get(T).__currentAnisotropy=T.anisotropy}}}function X(A,T){let k=!1;A.__webglInit===void 0&&(A.__webglInit=!0,T.addEventListener("dispose",S));let O=T.source,L=u.get(O);L===void 0&&(L={},u.set(O,L));let N=function(w){let I=[];return I.push(w.wrapS),I.push(w.wrapT),I.push(w.wrapR||0),I.push(w.magFilter),I.push(w.minFilter),I.push(w.anisotropy),I.push(w.internalFormat),I.push(w.format),I.push(w.type),I.push(w.generateMipmaps),I.push(w.premultiplyAlpha),I.push(w.flipY),I.push(w.unpackAlignment),I.push(w.colorSpace),I.join()}(T);if(N!==A.__cacheKey){L[N]===void 0&&(L[N]={texture:s.createTexture(),usedTimes:0},a.memory.textures++,k=!0),L[N].usedTimes++;let w=L[A.__cacheKey];w!==void 0&&(L[A.__cacheKey].usedTimes--,w.usedTimes===0&&P(T)),A.__cacheKey=N,A.__webglTexture=L[N].texture}return k}function j(A,T,k){let O=s.TEXTURE_2D;(T.isDataArrayTexture||T.isCompressedArrayTexture)&&(O=s.TEXTURE_2D_ARRAY),T.isData3DTexture&&(O=s.TEXTURE_3D);let L=X(A,T),N=T.source;t.bindTexture(O,A.__webglTexture,s.TEXTURE0+k);let w=i.get(N);if(N.version!==w.__version||L===!0){t.activeTexture(s.TEXTURE0+k);let I=je.getPrimaries(je.workingColorSpace),V=T.colorSpace===Bi?null:je.getPrimaries(T.colorSpace),te=T.colorSpace===Bi||I===V?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,T.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,T.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,T.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,te);let H=v(T.image,!1,n.maxTextureSize);H=ge(T,H);let Q=r.convert(T.format,T.colorSpace),J=r.convert(T.type),ne,ve=x(T.internalFormat,Q,J,T.colorSpace,T.isVideoTexture);U(O,T);let me=T.mipmaps,Se=T.isVideoTexture!==!0,Le=w.__version===void 0||L===!0,Xe=N.dataReady,ze=b(T,H);if(T.isDepthTexture)ve=_(T.format===Yn,T.type),Le&&(Se?t.texStorage2D(s.TEXTURE_2D,1,ve,H.width,H.height):t.texImage2D(s.TEXTURE_2D,0,ve,H.width,H.height,0,Q,J,null));else if(T.isDataTexture)if(me.length>0){Se&&Le&&t.texStorage2D(s.TEXTURE_2D,ze,ve,me[0].width,me[0].height);for(let we=0,Ze=me.length;we<Ze;we++)ne=me[we],Se?Xe&&t.texSubImage2D(s.TEXTURE_2D,we,0,0,ne.width,ne.height,Q,J,ne.data):t.texImage2D(s.TEXTURE_2D,we,ve,ne.width,ne.height,0,Q,J,ne.data);T.generateMipmaps=!1}else Se?(Le&&t.texStorage2D(s.TEXTURE_2D,ze,ve,H.width,H.height),Xe&&t.texSubImage2D(s.TEXTURE_2D,0,0,0,H.width,H.height,Q,J,H.data)):t.texImage2D(s.TEXTURE_2D,0,ve,H.width,H.height,0,Q,J,H.data);else if(T.isCompressedTexture)if(T.isCompressedArrayTexture){Se&&Le&&t.texStorage3D(s.TEXTURE_2D_ARRAY,ze,ve,me[0].width,me[0].height,H.depth);for(let we=0,Ze=me.length;we<Ze;we++)if(ne=me[we],T.format!==mi)if(Q!==null)if(Se){if(Xe)if(T.layerUpdates.size>0){let nt=vu(ne.width,ne.height,T.format,T.type);for(let ht of T.layerUpdates){let Me=ne.data.subarray(ht*nt/ne.data.BYTES_PER_ELEMENT,(ht+1)*nt/ne.data.BYTES_PER_ELEMENT);t.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,we,0,0,ht,ne.width,ne.height,1,Q,Me)}T.clearLayerUpdates()}else t.compressedTexSubImage3D(s.TEXTURE_2D_ARRAY,we,0,0,0,ne.width,ne.height,H.depth,Q,ne.data)}else t.compressedTexImage3D(s.TEXTURE_2D_ARRAY,we,ve,ne.width,ne.height,H.depth,0,ne.data,0,0);else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");else Se?Xe&&t.texSubImage3D(s.TEXTURE_2D_ARRAY,we,0,0,0,ne.width,ne.height,H.depth,Q,J,ne.data):t.texImage3D(s.TEXTURE_2D_ARRAY,we,ve,ne.width,ne.height,H.depth,0,Q,J,ne.data)}else{Se&&Le&&t.texStorage2D(s.TEXTURE_2D,ze,ve,me[0].width,me[0].height);for(let we=0,Ze=me.length;we<Ze;we++)ne=me[we],T.format!==mi?Q!==null?Se?Xe&&t.compressedTexSubImage2D(s.TEXTURE_2D,we,0,0,ne.width,ne.height,Q,ne.data):t.compressedTexImage2D(s.TEXTURE_2D,we,ve,ne.width,ne.height,0,ne.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):Se?Xe&&t.texSubImage2D(s.TEXTURE_2D,we,0,0,ne.width,ne.height,Q,J,ne.data):t.texImage2D(s.TEXTURE_2D,we,ve,ne.width,ne.height,0,Q,J,ne.data)}else if(T.isDataArrayTexture)if(Se){if(Le&&t.texStorage3D(s.TEXTURE_2D_ARRAY,ze,ve,H.width,H.height,H.depth),Xe)if(T.layerUpdates.size>0){let we=vu(H.width,H.height,T.format,T.type);for(let Ze of T.layerUpdates){let nt=H.data.subarray(Ze*we/H.data.BYTES_PER_ELEMENT,(Ze+1)*we/H.data.BYTES_PER_ELEMENT);t.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,Ze,H.width,H.height,1,Q,J,nt)}T.clearLayerUpdates()}else t.texSubImage3D(s.TEXTURE_2D_ARRAY,0,0,0,0,H.width,H.height,H.depth,Q,J,H.data)}else t.texImage3D(s.TEXTURE_2D_ARRAY,0,ve,H.width,H.height,H.depth,0,Q,J,H.data);else if(T.isData3DTexture)Se?(Le&&t.texStorage3D(s.TEXTURE_3D,ze,ve,H.width,H.height,H.depth),Xe&&t.texSubImage3D(s.TEXTURE_3D,0,0,0,0,H.width,H.height,H.depth,Q,J,H.data)):t.texImage3D(s.TEXTURE_3D,0,ve,H.width,H.height,H.depth,0,Q,J,H.data);else if(T.isFramebufferTexture){if(Le)if(Se)t.texStorage2D(s.TEXTURE_2D,ze,ve,H.width,H.height);else{let we=H.width,Ze=H.height;for(let nt=0;nt<ze;nt++)t.texImage2D(s.TEXTURE_2D,nt,ve,we,Ze,0,Q,J,null),we>>=1,Ze>>=1}}else if(me.length>0){if(Se&&Le){let we=ce(me[0]);t.texStorage2D(s.TEXTURE_2D,ze,ve,we.width,we.height)}for(let we=0,Ze=me.length;we<Ze;we++)ne=me[we],Se?Xe&&t.texSubImage2D(s.TEXTURE_2D,we,0,0,Q,J,ne):t.texImage2D(s.TEXTURE_2D,we,ve,Q,J,ne);T.generateMipmaps=!1}else if(Se){if(Le){let we=ce(H);t.texStorage2D(s.TEXTURE_2D,ze,ve,we.width,we.height)}Xe&&t.texSubImage2D(s.TEXTURE_2D,0,0,0,Q,J,H)}else t.texImage2D(s.TEXTURE_2D,0,ve,Q,J,H);f(T)&&g(O),w.__version=N.version,T.onUpdate&&T.onUpdate(T)}A.__version=T.version}function Z(A,T,k,O,L,N){let w=r.convert(k.format,k.colorSpace),I=r.convert(k.type),V=x(k.internalFormat,w,I,k.colorSpace),te=i.get(T),H=i.get(k);if(H.__renderTarget=T,!te.__hasExternalTextures){let Q=Math.max(1,T.width>>N),J=Math.max(1,T.height>>N);L===s.TEXTURE_3D||L===s.TEXTURE_2D_ARRAY?t.texImage3D(L,N,V,Q,J,T.depth,0,w,I,null):t.texImage2D(L,N,V,Q,J,0,w,I,null)}t.bindFramebuffer(s.FRAMEBUFFER,A),pe(T)?o.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,O,L,H.__webglTexture,0,ae(T)):(L===s.TEXTURE_2D||L>=s.TEXTURE_CUBE_MAP_POSITIVE_X&&L<=s.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&s.framebufferTexture2D(s.FRAMEBUFFER,O,L,H.__webglTexture,N),t.bindFramebuffer(s.FRAMEBUFFER,null)}function $(A,T,k){if(s.bindRenderbuffer(s.RENDERBUFFER,A),T.depthBuffer){let O=T.depthTexture,L=O&&O.isDepthTexture?O.type:null,N=_(T.stencilBuffer,L),w=T.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,I=ae(T);pe(T)?o.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,I,N,T.width,T.height):k?s.renderbufferStorageMultisample(s.RENDERBUFFER,I,N,T.width,T.height):s.renderbufferStorage(s.RENDERBUFFER,N,T.width,T.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,w,s.RENDERBUFFER,A)}else{let O=T.textures;for(let L=0;L<O.length;L++){let N=O[L],w=r.convert(N.format,N.colorSpace),I=r.convert(N.type),V=x(N.internalFormat,w,I,N.colorSpace),te=ae(T);k&&pe(T)===!1?s.renderbufferStorageMultisample(s.RENDERBUFFER,te,V,T.width,T.height):pe(T)?o.renderbufferStorageMultisampleEXT(s.RENDERBUFFER,te,V,T.width,T.height):s.renderbufferStorage(s.RENDERBUFFER,V,T.width,T.height)}}s.bindRenderbuffer(s.RENDERBUFFER,null)}function ue(A){let T=i.get(A),k=A.isWebGLCubeRenderTarget===!0;if(T.__boundDepthTexture!==A.depthTexture){let O=A.depthTexture;if(T.__depthDisposeCallback&&T.__depthDisposeCallback(),O){let L=()=>{delete T.__boundDepthTexture,delete T.__depthDisposeCallback,O.removeEventListener("dispose",L)};O.addEventListener("dispose",L),T.__depthDisposeCallback=L}T.__boundDepthTexture=O}if(A.depthTexture&&!T.__autoAllocateDepthBuffer){if(k)throw new Error("target.depthTexture not supported in Cube render targets");(function(O,L){if(L&&L.isWebGLCubeRenderTarget)throw new Error("Depth Texture with cube render targets is not supported");if(t.bindFramebuffer(s.FRAMEBUFFER,O),!L.depthTexture||!L.depthTexture.isDepthTexture)throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");let N=i.get(L.depthTexture);N.__renderTarget=L,N.__webglTexture&&L.depthTexture.image.width===L.width&&L.depthTexture.image.height===L.height||(L.depthTexture.image.width=L.width,L.depthTexture.image.height=L.height,L.depthTexture.needsUpdate=!0),B(L.depthTexture,0);let w=N.__webglTexture,I=ae(L);if(L.depthTexture.format===Vs)pe(L)?o.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,w,0,I):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_ATTACHMENT,s.TEXTURE_2D,w,0);else{if(L.depthTexture.format!==Yn)throw new Error("Unknown depthTexture format");pe(L)?o.framebufferTexture2DMultisampleEXT(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,w,0,I):s.framebufferTexture2D(s.FRAMEBUFFER,s.DEPTH_STENCIL_ATTACHMENT,s.TEXTURE_2D,w,0)}})(T.__webglFramebuffer,A)}else if(k){T.__webglDepthbuffer=[];for(let O=0;O<6;O++)if(t.bindFramebuffer(s.FRAMEBUFFER,T.__webglFramebuffer[O]),T.__webglDepthbuffer[O]===void 0)T.__webglDepthbuffer[O]=s.createRenderbuffer(),$(T.__webglDepthbuffer[O],A,!1);else{let L=A.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,N=T.__webglDepthbuffer[O];s.bindRenderbuffer(s.RENDERBUFFER,N),s.framebufferRenderbuffer(s.FRAMEBUFFER,L,s.RENDERBUFFER,N)}}else if(t.bindFramebuffer(s.FRAMEBUFFER,T.__webglFramebuffer),T.__webglDepthbuffer===void 0)T.__webglDepthbuffer=s.createRenderbuffer(),$(T.__webglDepthbuffer,A,!1);else{let O=A.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,L=T.__webglDepthbuffer;s.bindRenderbuffer(s.RENDERBUFFER,L),s.framebufferRenderbuffer(s.FRAMEBUFFER,O,s.RENDERBUFFER,L)}t.bindFramebuffer(s.FRAMEBUFFER,null)}let _e=[],K=[];function ae(A){return Math.min(n.maxSamples,A.samples)}function pe(A){let T=i.get(A);return A.samples>0&&e.has("WEBGL_multisampled_render_to_texture")===!0&&T.__useRenderToTexture!==!1}function ge(A,T){let k=A.colorSpace,O=A.format,L=A.type;return A.isCompressedTexture===!0||A.isVideoTexture===!0||k!==os&&k!==Bi&&(je.getTransfer(k)===et?O===mi&&L===Vi||console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):console.error("THREE.WebGLTextures: Unsupported texture color space:",k)),T}function ce(A){return typeof HTMLImageElement<"u"&&A instanceof HTMLImageElement?(c.width=A.naturalWidth||A.width,c.height=A.naturalHeight||A.height):typeof VideoFrame<"u"&&A instanceof VideoFrame?(c.width=A.displayWidth,c.height=A.displayHeight):(c.width=A.width,c.height=A.height),c}this.allocateTextureUnit=function(){let A=C;return A>=n.maxTextures&&console.warn("THREE.WebGLTextures: Trying to use "+A+" texture units while this GPU supports only "+n.maxTextures),C+=1,A},this.resetTextureUnits=function(){C=0},this.setTexture2D=B,this.setTexture2DArray=function(A,T){let k=i.get(A);A.version>0&&k.__version!==A.version?j(k,A,T):t.bindTexture(s.TEXTURE_2D_ARRAY,k.__webglTexture,s.TEXTURE0+T)},this.setTexture3D=function(A,T){let k=i.get(A);A.version>0&&k.__version!==A.version?j(k,A,T):t.bindTexture(s.TEXTURE_3D,k.__webglTexture,s.TEXTURE0+T)},this.setTextureCube=function(A,T){let k=i.get(A);A.version>0&&k.__version!==A.version?function(O,L,N){if(L.image.length!==6)return;let w=X(O,L),I=L.source;t.bindTexture(s.TEXTURE_CUBE_MAP,O.__webglTexture,s.TEXTURE0+N);let V=i.get(I);if(I.version!==V.__version||w===!0){t.activeTexture(s.TEXTURE0+N);let te=je.getPrimaries(je.workingColorSpace),H=L.colorSpace===Bi?null:je.getPrimaries(L.colorSpace),Q=L.colorSpace===Bi||te===H?s.NONE:s.BROWSER_DEFAULT_WEBGL;s.pixelStorei(s.UNPACK_FLIP_Y_WEBGL,L.flipY),s.pixelStorei(s.UNPACK_PREMULTIPLY_ALPHA_WEBGL,L.premultiplyAlpha),s.pixelStorei(s.UNPACK_ALIGNMENT,L.unpackAlignment),s.pixelStorei(s.UNPACK_COLORSPACE_CONVERSION_WEBGL,Q);let J=L.isCompressedTexture||L.image[0].isCompressedTexture,ne=L.image[0]&&L.image[0].isDataTexture,ve=[];for(let Me=0;Me<6;Me++)ve[Me]=J||ne?ne?L.image[Me].image:L.image[Me]:v(L.image[Me],!0,n.maxCubemapSize),ve[Me]=ge(L,ve[Me]);let me=ve[0],Se=r.convert(L.format,L.colorSpace),Le=r.convert(L.type),Xe=x(L.internalFormat,Se,Le,L.colorSpace),ze=L.isVideoTexture!==!0,we=V.__version===void 0||w===!0,Ze=I.dataReady,nt,ht=b(L,me);if(U(s.TEXTURE_CUBE_MAP,L),J){ze&&we&&t.texStorage2D(s.TEXTURE_CUBE_MAP,ht,Xe,me.width,me.height);for(let Me=0;Me<6;Me++){nt=ve[Me].mipmaps;for(let Fe=0;Fe<nt.length;Fe++){let tt=nt[Fe];L.format!==mi?Se!==null?ze?Ze&&t.compressedTexSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Me,Fe,0,0,tt.width,tt.height,Se,tt.data):t.compressedTexImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Me,Fe,Xe,tt.width,tt.height,0,tt.data):console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):ze?Ze&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Me,Fe,0,0,tt.width,tt.height,Se,Le,tt.data):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Me,Fe,Xe,tt.width,tt.height,0,Se,Le,tt.data)}}}else{if(nt=L.mipmaps,ze&&we){nt.length>0&&ht++;let Me=ce(ve[0]);t.texStorage2D(s.TEXTURE_CUBE_MAP,ht,Xe,Me.width,Me.height)}for(let Me=0;Me<6;Me++)if(ne){ze?Ze&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Me,0,0,0,ve[Me].width,ve[Me].height,Se,Le,ve[Me].data):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Me,0,Xe,ve[Me].width,ve[Me].height,0,Se,Le,ve[Me].data);for(let Fe=0;Fe<nt.length;Fe++){let tt=nt[Fe].image[Me].image;ze?Ze&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Me,Fe+1,0,0,tt.width,tt.height,Se,Le,tt.data):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Me,Fe+1,Xe,tt.width,tt.height,0,Se,Le,tt.data)}}else{ze?Ze&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Me,0,0,0,Se,Le,ve[Me]):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Me,0,Xe,Se,Le,ve[Me]);for(let Fe=0;Fe<nt.length;Fe++){let tt=nt[Fe];ze?Ze&&t.texSubImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Me,Fe+1,0,0,Se,Le,tt.image[Me]):t.texImage2D(s.TEXTURE_CUBE_MAP_POSITIVE_X+Me,Fe+1,Xe,Se,Le,tt.image[Me])}}}f(L)&&g(s.TEXTURE_CUBE_MAP),V.__version=I.version,L.onUpdate&&L.onUpdate(L)}O.__version=L.version}(k,A,T):t.bindTexture(s.TEXTURE_CUBE_MAP,k.__webglTexture,s.TEXTURE0+T)},this.rebindTextures=function(A,T,k){let O=i.get(A);T!==void 0&&Z(O.__webglFramebuffer,A,A.texture,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,0),k!==void 0&&ue(A)},this.setupRenderTarget=function(A){let T=A.texture,k=i.get(A),O=i.get(T);A.addEventListener("dispose",R);let L=A.textures,N=A.isWebGLCubeRenderTarget===!0,w=L.length>1;if(w||(O.__webglTexture===void 0&&(O.__webglTexture=s.createTexture()),O.__version=T.version,a.memory.textures++),N){k.__webglFramebuffer=[];for(let I=0;I<6;I++)if(T.mipmaps&&T.mipmaps.length>0){k.__webglFramebuffer[I]=[];for(let V=0;V<T.mipmaps.length;V++)k.__webglFramebuffer[I][V]=s.createFramebuffer()}else k.__webglFramebuffer[I]=s.createFramebuffer()}else{if(T.mipmaps&&T.mipmaps.length>0){k.__webglFramebuffer=[];for(let I=0;I<T.mipmaps.length;I++)k.__webglFramebuffer[I]=s.createFramebuffer()}else k.__webglFramebuffer=s.createFramebuffer();if(w)for(let I=0,V=L.length;I<V;I++){let te=i.get(L[I]);te.__webglTexture===void 0&&(te.__webglTexture=s.createTexture(),a.memory.textures++)}if(A.samples>0&&pe(A)===!1){k.__webglMultisampledFramebuffer=s.createFramebuffer(),k.__webglColorRenderbuffer=[],t.bindFramebuffer(s.FRAMEBUFFER,k.__webglMultisampledFramebuffer);for(let I=0;I<L.length;I++){let V=L[I];k.__webglColorRenderbuffer[I]=s.createRenderbuffer(),s.bindRenderbuffer(s.RENDERBUFFER,k.__webglColorRenderbuffer[I]);let te=r.convert(V.format,V.colorSpace),H=r.convert(V.type),Q=x(V.internalFormat,te,H,V.colorSpace,A.isXRRenderTarget===!0),J=ae(A);s.renderbufferStorageMultisample(s.RENDERBUFFER,J,Q,A.width,A.height),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+I,s.RENDERBUFFER,k.__webglColorRenderbuffer[I])}s.bindRenderbuffer(s.RENDERBUFFER,null),A.depthBuffer&&(k.__webglDepthRenderbuffer=s.createRenderbuffer(),$(k.__webglDepthRenderbuffer,A,!0)),t.bindFramebuffer(s.FRAMEBUFFER,null)}}if(N){t.bindTexture(s.TEXTURE_CUBE_MAP,O.__webglTexture),U(s.TEXTURE_CUBE_MAP,T);for(let I=0;I<6;I++)if(T.mipmaps&&T.mipmaps.length>0)for(let V=0;V<T.mipmaps.length;V++)Z(k.__webglFramebuffer[I][V],A,T,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+I,V);else Z(k.__webglFramebuffer[I],A,T,s.COLOR_ATTACHMENT0,s.TEXTURE_CUBE_MAP_POSITIVE_X+I,0);f(T)&&g(s.TEXTURE_CUBE_MAP),t.unbindTexture()}else if(w){for(let I=0,V=L.length;I<V;I++){let te=L[I],H=i.get(te);t.bindTexture(s.TEXTURE_2D,H.__webglTexture),U(s.TEXTURE_2D,te),Z(k.__webglFramebuffer,A,te,s.COLOR_ATTACHMENT0+I,s.TEXTURE_2D,0),f(te)&&g(s.TEXTURE_2D)}t.unbindTexture()}else{let I=s.TEXTURE_2D;if((A.isWebGL3DRenderTarget||A.isWebGLArrayRenderTarget)&&(I=A.isWebGL3DRenderTarget?s.TEXTURE_3D:s.TEXTURE_2D_ARRAY),t.bindTexture(I,O.__webglTexture),U(I,T),T.mipmaps&&T.mipmaps.length>0)for(let V=0;V<T.mipmaps.length;V++)Z(k.__webglFramebuffer[V],A,T,s.COLOR_ATTACHMENT0,I,V);else Z(k.__webglFramebuffer,A,T,s.COLOR_ATTACHMENT0,I,0);f(T)&&g(I),t.unbindTexture()}A.depthBuffer&&ue(A)},this.updateRenderTargetMipmap=function(A){let T=A.textures;for(let k=0,O=T.length;k<O;k++){let L=T[k];if(f(L)){let N=y(A),w=i.get(L).__webglTexture;t.bindTexture(N,w),g(N),t.unbindTexture()}}},this.updateMultisampleRenderTarget=function(A){if(A.samples>0){if(pe(A)===!1){let T=A.textures,k=A.width,O=A.height,L=s.COLOR_BUFFER_BIT,N=A.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT,w=i.get(A),I=T.length>1;if(I)for(let V=0;V<T.length;V++)t.bindFramebuffer(s.FRAMEBUFFER,w.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+V,s.RENDERBUFFER,null),t.bindFramebuffer(s.FRAMEBUFFER,w.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+V,s.TEXTURE_2D,null,0);t.bindFramebuffer(s.READ_FRAMEBUFFER,w.__webglMultisampledFramebuffer),t.bindFramebuffer(s.DRAW_FRAMEBUFFER,w.__webglFramebuffer);for(let V=0;V<T.length;V++){if(A.resolveDepthBuffer&&(A.depthBuffer&&(L|=s.DEPTH_BUFFER_BIT),A.stencilBuffer&&A.resolveStencilBuffer&&(L|=s.STENCIL_BUFFER_BIT)),I){s.framebufferRenderbuffer(s.READ_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.RENDERBUFFER,w.__webglColorRenderbuffer[V]);let te=i.get(T[V]).__webglTexture;s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0,s.TEXTURE_2D,te,0)}s.blitFramebuffer(0,0,k,O,0,0,k,O,L,s.NEAREST),l===!0&&(_e.length=0,K.length=0,_e.push(s.COLOR_ATTACHMENT0+V),A.depthBuffer&&A.resolveDepthBuffer===!1&&(_e.push(N),K.push(N),s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,K)),s.invalidateFramebuffer(s.READ_FRAMEBUFFER,_e))}if(t.bindFramebuffer(s.READ_FRAMEBUFFER,null),t.bindFramebuffer(s.DRAW_FRAMEBUFFER,null),I)for(let V=0;V<T.length;V++){t.bindFramebuffer(s.FRAMEBUFFER,w.__webglMultisampledFramebuffer),s.framebufferRenderbuffer(s.FRAMEBUFFER,s.COLOR_ATTACHMENT0+V,s.RENDERBUFFER,w.__webglColorRenderbuffer[V]);let te=i.get(T[V]).__webglTexture;t.bindFramebuffer(s.FRAMEBUFFER,w.__webglFramebuffer),s.framebufferTexture2D(s.DRAW_FRAMEBUFFER,s.COLOR_ATTACHMENT0+V,s.TEXTURE_2D,te,0)}t.bindFramebuffer(s.DRAW_FRAMEBUFFER,w.__webglMultisampledFramebuffer)}else if(A.depthBuffer&&A.resolveDepthBuffer===!1&&l){let T=A.stencilBuffer?s.DEPTH_STENCIL_ATTACHMENT:s.DEPTH_ATTACHMENT;s.invalidateFramebuffer(s.DRAW_FRAMEBUFFER,[T])}}},this.setupDepthRenderbuffer=ue,this.setupFrameBufferTexture=Z,this.useMultisampledRTT=pe}function zm(s,e){return{convert:function(t,i=""){let n,r=je.getTransfer(i);if(t===Vi)return s.UNSIGNED_BYTE;if(t===Oc)return s.UNSIGNED_SHORT_4_4_4_4;if(t===zc)return s.UNSIGNED_SHORT_5_5_5_1;if(t===Hu)return s.UNSIGNED_INT_5_9_9_9_REV;if(t===Fu)return s.BYTE;if(t===Bu)return s.SHORT;if(t===Hs)return s.UNSIGNED_SHORT;if(t===Nc)return s.INT;if(t===un)return s.UNSIGNED_INT;if(t===pi)return s.FLOAT;if(t===vn)return s.HALF_FLOAT;if(t===Vu)return s.ALPHA;if(t===Gu)return s.RGB;if(t===mi)return s.RGBA;if(t===Wu)return s.LUMINANCE;if(t===Xu)return s.LUMINANCE_ALPHA;if(t===Vs)return s.DEPTH_COMPONENT;if(t===Yn)return s.DEPTH_STENCIL;if(t===kc)return s.RED;if(t===Fc)return s.RED_INTEGER;if(t===qu)return s.RG;if(t===Bc)return s.RG_INTEGER;if(t===Hc)return s.RGBA_INTEGER;if(t===ia||t===na||t===sa||t===ra)if(r===et){if(n=e.get("WEBGL_compressed_texture_s3tc_srgb"),n===null)return null;if(t===ia)return n.COMPRESSED_SRGB_S3TC_DXT1_EXT;if(t===na)return n.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;if(t===sa)return n.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;if(t===ra)return n.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT}else{if(n=e.get("WEBGL_compressed_texture_s3tc"),n===null)return null;if(t===ia)return n.COMPRESSED_RGB_S3TC_DXT1_EXT;if(t===na)return n.COMPRESSED_RGBA_S3TC_DXT1_EXT;if(t===sa)return n.COMPRESSED_RGBA_S3TC_DXT3_EXT;if(t===ra)return n.COMPRESSED_RGBA_S3TC_DXT5_EXT}if(t===dl||t===pl||t===ml||t===fl){if(n=e.get("WEBGL_compressed_texture_pvrtc"),n===null)return null;if(t===dl)return n.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;if(t===pl)return n.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;if(t===ml)return n.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;if(t===fl)return n.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG}if(t===gl||t===vl||t===yl){if(n=e.get("WEBGL_compressed_texture_etc"),n===null)return null;if(t===gl||t===vl)return r===et?n.COMPRESSED_SRGB8_ETC2:n.COMPRESSED_RGB8_ETC2;if(t===yl)return r===et?n.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:n.COMPRESSED_RGBA8_ETC2_EAC}if(t===xl||t===_l||t===Ml||t===bl||t===Sl||t===wl||t===El||t===Tl||t===Al||t===Rl||t===Cl||t===Ll||t===Pl||t===Il){if(n=e.get("WEBGL_compressed_texture_astc"),n===null)return null;if(t===xl)return r===et?n.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:n.COMPRESSED_RGBA_ASTC_4x4_KHR;if(t===_l)return r===et?n.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:n.COMPRESSED_RGBA_ASTC_5x4_KHR;if(t===Ml)return r===et?n.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:n.COMPRESSED_RGBA_ASTC_5x5_KHR;if(t===bl)return r===et?n.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:n.COMPRESSED_RGBA_ASTC_6x5_KHR;if(t===Sl)return r===et?n.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:n.COMPRESSED_RGBA_ASTC_6x6_KHR;if(t===wl)return r===et?n.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:n.COMPRESSED_RGBA_ASTC_8x5_KHR;if(t===El)return r===et?n.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:n.COMPRESSED_RGBA_ASTC_8x6_KHR;if(t===Tl)return r===et?n.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:n.COMPRESSED_RGBA_ASTC_8x8_KHR;if(t===Al)return r===et?n.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:n.COMPRESSED_RGBA_ASTC_10x5_KHR;if(t===Rl)return r===et?n.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:n.COMPRESSED_RGBA_ASTC_10x6_KHR;if(t===Cl)return r===et?n.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:n.COMPRESSED_RGBA_ASTC_10x8_KHR;if(t===Ll)return r===et?n.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:n.COMPRESSED_RGBA_ASTC_10x10_KHR;if(t===Pl)return r===et?n.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:n.COMPRESSED_RGBA_ASTC_12x10_KHR;if(t===Il)return r===et?n.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:n.COMPRESSED_RGBA_ASTC_12x12_KHR}if(t===aa||t===Dl||t===Ul){if(n=e.get("EXT_texture_compression_bptc"),n===null)return null;if(t===aa)return r===et?n.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:n.COMPRESSED_RGBA_BPTC_UNORM_EXT;if(t===Dl)return n.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;if(t===Ul)return n.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT}if(t===ju||t===Nl||t===Ol||t===zl){if(n=e.get("EXT_texture_compression_rgtc"),n===null)return null;if(t===aa)return n.COMPRESSED_RED_RGTC1_EXT;if(t===Nl)return n.COMPRESSED_SIGNED_RED_RGTC1_EXT;if(t===Ol)return n.COMPRESSED_RED_GREEN_RGTC2_EXT;if(t===zl)return n.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT}return t===jn?s.UNSIGNED_INT_24_8:s[t]!==void 0?s[t]:null}}}var ec=class extends Ut{constructor(e=[]){super(),this.isArrayCamera=!0,this.cameras=e}},Qe=class extends at{constructor(){super(),this.isGroup=!0,this.type="Group"}},km={type:"move"},Os=class{constructor(){this._targetRay=null,this._grip=null,this._hand=null}getHandSpace(){return this._hand===null&&(this._hand=new Qe,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand}getTargetRaySpace(){return this._targetRay===null&&(this._targetRay=new Qe,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new M,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new M),this._targetRay}getGripSpace(){return this._grip===null&&(this._grip=new Qe,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new M,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new M),this._grip}dispatchEvent(e){return this._targetRay!==null&&this._targetRay.dispatchEvent(e),this._grip!==null&&this._grip.dispatchEvent(e),this._hand!==null&&this._hand.dispatchEvent(e),this}connect(e){if(e&&e.hand){let t=this._hand;if(t)for(let i of e.hand.values())this._getHandJoint(t,i)}return this.dispatchEvent({type:"connected",data:e}),this}disconnect(e){return this.dispatchEvent({type:"disconnected",data:e}),this._targetRay!==null&&(this._targetRay.visible=!1),this._grip!==null&&(this._grip.visible=!1),this._hand!==null&&(this._hand.visible=!1),this}update(e,t,i){let n=null,r=null,a=null,o=this._targetRay,l=this._grip,c=this._hand;if(e&&t.session.visibilityState!=="visible-blurred"){if(c&&e.hand){a=!0;for(let v of e.hand.values()){let f=t.getJointPose(v,i),g=this._getHandJoint(c,v);f!==null&&(g.matrix.fromArray(f.transform.matrix),g.matrix.decompose(g.position,g.rotation,g.scale),g.matrixWorldNeedsUpdate=!0,g.jointRadius=f.radius),g.visible=f!==null}let h=c.joints["index-finger-tip"],d=c.joints["thumb-tip"],u=h.position.distanceTo(d.position),p=.02,m=.005;c.inputState.pinching&&u>p+m?(c.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:e.handedness,target:this})):!c.inputState.pinching&&u<=p-m&&(c.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:e.handedness,target:this}))}else l!==null&&e.gripSpace&&(r=t.getPose(e.gripSpace,i),r!==null&&(l.matrix.fromArray(r.transform.matrix),l.matrix.decompose(l.position,l.rotation,l.scale),l.matrixWorldNeedsUpdate=!0,r.linearVelocity?(l.hasLinearVelocity=!0,l.linearVelocity.copy(r.linearVelocity)):l.hasLinearVelocity=!1,r.angularVelocity?(l.hasAngularVelocity=!0,l.angularVelocity.copy(r.angularVelocity)):l.hasAngularVelocity=!1));o!==null&&(n=t.getPose(e.targetRaySpace,i),n===null&&r!==null&&(n=r),n!==null&&(o.matrix.fromArray(n.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,n.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(n.linearVelocity)):o.hasLinearVelocity=!1,n.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(n.angularVelocity)):o.hasAngularVelocity=!1,this.dispatchEvent(km)))}return o!==null&&(o.visible=n!==null),l!==null&&(l.visible=r!==null),c!==null&&(c.visible=a!==null),this}_getHandJoint(e,t){if(e.joints[t.jointName]===void 0){let i=new Qe;i.matrixAutoUpdate=!1,i.visible=!1,e.joints[t.jointName]=i,e.add(i)}return e.joints[t.jointName]}},tc=class{constructor(){this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0}init(e,t,i){if(this.texture===null){let n=new Nt;e.properties.get(n).__webglTexture=t.texture,t.depthNear==i.depthNear&&t.depthFar==i.depthFar||(this.depthNear=t.depthNear,this.depthFar=t.depthFar),this.texture=n}}getMesh(e){if(this.texture!==null&&this.mesh===null){let t=e.cameras[0].viewport,i=new Tt({vertexShader:`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,fragmentShader:`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});this.mesh=new Ce(new Gt(20,20),i)}return this.mesh}reset(){this.texture=null,this.mesh=null}getDepthTexture(){return this.texture}},ic=class extends Gi{constructor(e,t){super();let i=this,n=null,r=1,a=null,o="local-floor",l=1,c=null,h=null,d=null,u=null,p=null,m=null,v=new tc,f=t.getContextAttributes(),g=null,y=null,x=[],_=[],b=new oe,S=null,R=new Ut;R.viewport=new ct;let P=new Ut;P.viewport=new ct;let C=[R,P],B=new ec,z=null,D=null;function F(K){let ae=_.indexOf(K.inputSource);if(ae===-1)return;let pe=x[ae];pe!==void 0&&(pe.update(K.inputSource,K.frame,c||a),pe.dispatchEvent({type:K.type,data:K.inputSource}))}function U(){n.removeEventListener("select",F),n.removeEventListener("selectstart",F),n.removeEventListener("selectend",F),n.removeEventListener("squeeze",F),n.removeEventListener("squeezestart",F),n.removeEventListener("squeezeend",F),n.removeEventListener("end",U),n.removeEventListener("inputsourceschange",X);for(let K=0;K<x.length;K++){let ae=_[K];ae!==null&&(_[K]=null,x[K].disconnect(ae))}z=null,D=null,v.reset(),e.setRenderTarget(g),p=null,u=null,d=null,n=null,y=null,_e.stop(),i.isPresenting=!1,e.setPixelRatio(S),e.setSize(b.width,b.height,!1),i.dispatchEvent({type:"sessionend"})}function X(K){for(let ae=0;ae<K.removed.length;ae++){let pe=K.removed[ae],ge=_.indexOf(pe);ge>=0&&(_[ge]=null,x[ge].disconnect(pe))}for(let ae=0;ae<K.added.length;ae++){let pe=K.added[ae],ge=_.indexOf(pe);if(ge===-1){for(let A=0;A<x.length;A++){if(A>=_.length){_.push(pe),ge=A;break}if(_[A]===null){_[A]=pe,ge=A;break}}if(ge===-1)break}let ce=x[ge];ce&&ce.connect(pe)}}this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(K){let ae=x[K];return ae===void 0&&(ae=new Os,x[K]=ae),ae.getTargetRaySpace()},this.getControllerGrip=function(K){let ae=x[K];return ae===void 0&&(ae=new Os,x[K]=ae),ae.getGripSpace()},this.getHand=function(K){let ae=x[K];return ae===void 0&&(ae=new Os,x[K]=ae),ae.getHandSpace()},this.setFramebufferScaleFactor=function(K){r=K,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.")},this.setReferenceSpaceType=function(K){o=K,i.isPresenting===!0&&console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.")},this.getReferenceSpace=function(){return c||a},this.setReferenceSpace=function(K){c=K},this.getBaseLayer=function(){return u!==null?u:p},this.getBinding=function(){return d},this.getFrame=function(){return m},this.getSession=function(){return n},this.setSession=async function(K){if(n=K,n!==null){if(g=e.getRenderTarget(),n.addEventListener("select",F),n.addEventListener("selectstart",F),n.addEventListener("selectend",F),n.addEventListener("squeeze",F),n.addEventListener("squeezestart",F),n.addEventListener("squeezeend",F),n.addEventListener("end",U),n.addEventListener("inputsourceschange",X),f.xrCompatible!==!0&&await t.makeXRCompatible(),S=e.getPixelRatio(),e.getSize(b),n.renderState.layers===void 0){let ae={antialias:f.antialias,alpha:!0,depth:f.depth,stencil:f.stencil,framebufferScaleFactor:r};p=new XRWebGLLayer(n,t,ae),n.updateRenderState({baseLayer:p}),e.setPixelRatio(1),e.setSize(p.framebufferWidth,p.framebufferHeight,!1),y=new si(p.framebufferWidth,p.framebufferHeight,{format:mi,type:Vi,colorSpace:e.outputColorSpace,stencilBuffer:f.stencil})}else{let ae=null,pe=null,ge=null;f.depth&&(ge=f.stencil?t.DEPTH24_STENCIL8:t.DEPTH_COMPONENT24,ae=f.stencil?Yn:Vs,pe=f.stencil?jn:un);let ce={colorFormat:t.RGBA8,depthFormat:ge,scaleFactor:r};d=new XRWebGLBinding(n,t),u=d.createProjectionLayer(ce),n.updateRenderState({layers:[u]}),e.setPixelRatio(1),e.setSize(u.textureWidth,u.textureHeight,!1),y=new si(u.textureWidth,u.textureHeight,{format:mi,type:Vi,depthTexture:new ga(u.textureWidth,u.textureHeight,pe,void 0,void 0,void 0,void 0,void 0,void 0,ae),stencilBuffer:f.stencil,colorSpace:e.outputColorSpace,samples:f.antialias?4:0,resolveDepthBuffer:u.ignoreDepthValues===!1})}y.isXRRenderTarget=!0,this.setFoveation(l),c=null,a=await n.requestReferenceSpace(o),_e.setContext(n),_e.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})}},this.getEnvironmentBlendMode=function(){if(n!==null)return n.environmentBlendMode},this.getDepthTexture=function(){return v.getDepthTexture()};let j=new M,Z=new M;function $(K,ae){ae===null?K.matrixWorld.copy(K.matrix):K.matrixWorld.multiplyMatrices(ae.matrixWorld,K.matrix),K.matrixWorldInverse.copy(K.matrixWorld).invert()}this.updateCamera=function(K){if(n===null)return;let ae=K.near,pe=K.far;v.texture!==null&&(v.depthNear>0&&(ae=v.depthNear),v.depthFar>0&&(pe=v.depthFar)),B.near=P.near=R.near=ae,B.far=P.far=R.far=pe,z===B.near&&D===B.far||(n.updateRenderState({depthNear:B.near,depthFar:B.far}),z=B.near,D=B.far),R.layers.mask=2|K.layers.mask,P.layers.mask=4|K.layers.mask,B.layers.mask=R.layers.mask|P.layers.mask;let ge=K.parent,ce=B.cameras;$(B,ge);for(let A=0;A<ce.length;A++)$(ce[A],ge);ce.length===2?function(A,T,k){j.setFromMatrixPosition(T.matrixWorld),Z.setFromMatrixPosition(k.matrixWorld);let O=j.distanceTo(Z),L=T.projectionMatrix.elements,N=k.projectionMatrix.elements,w=L[14]/(L[10]-1),I=L[14]/(L[10]+1),V=(L[9]+1)/L[5],te=(L[9]-1)/L[5],H=(L[8]-1)/L[0],Q=(N[8]+1)/N[0],J=w*H,ne=w*Q,ve=O/(-H+Q),me=ve*-H;if(T.matrixWorld.decompose(A.position,A.quaternion,A.scale),A.translateX(me),A.translateZ(ve),A.matrixWorld.compose(A.position,A.quaternion,A.scale),A.matrixWorldInverse.copy(A.matrixWorld).invert(),L[10]===-1)A.projectionMatrix.copy(T.projectionMatrix),A.projectionMatrixInverse.copy(T.projectionMatrixInverse);else{let Se=w+ve,Le=I+ve,Xe=J-me,ze=ne+(O-me),we=V*I/Le*Se,Ze=te*I/Le*Se;A.projectionMatrix.makePerspective(Xe,ze,we,Ze,Se,Le),A.projectionMatrixInverse.copy(A.projectionMatrix).invert()}}(B,R,P):B.projectionMatrix.copy(R.projectionMatrix),function(A,T,k){k===null?A.matrix.copy(T.matrixWorld):(A.matrix.copy(k.matrixWorld),A.matrix.invert(),A.matrix.multiply(T.matrixWorld)),A.matrix.decompose(A.position,A.quaternion,A.scale),A.updateMatrixWorld(!0),A.projectionMatrix.copy(T.projectionMatrix),A.projectionMatrixInverse.copy(T.projectionMatrixInverse),A.isPerspectiveCamera&&(A.fov=2*Gs*Math.atan(1/A.projectionMatrix.elements[5]),A.zoom=1)}(K,B,ge)},this.getCamera=function(){return B},this.getFoveation=function(){if(u!==null||p!==null)return l},this.setFoveation=function(K){l=K,u!==null&&(u.fixedFoveation=K),p!==null&&p.fixedFoveation!==void 0&&(p.fixedFoveation=K)},this.hasDepthSensing=function(){return v.texture!==null},this.getDepthSensingMesh=function(){return v.getMesh(B)};let ue=null,_e=new Ju;_e.setAnimationLoop(function(K,ae){if(h=ae.getViewerPose(c||a),m=ae,h!==null){let pe=h.views;p!==null&&(e.setRenderTargetFramebuffer(y,p.framebuffer),e.setRenderTarget(y));let ge=!1;pe.length!==B.cameras.length&&(B.cameras.length=0,ge=!0);for(let A=0;A<pe.length;A++){let T=pe[A],k=null;if(p!==null)k=p.getViewport(T);else{let L=d.getViewSubImage(u,T);k=L.viewport,A===0&&(e.setRenderTargetTextures(y,L.colorTexture,u.ignoreDepthValues?void 0:L.depthStencilTexture),e.setRenderTarget(y))}let O=C[A];O===void 0&&(O=new Ut,O.layers.enable(A),O.viewport=new ct,C[A]=O),O.matrix.fromArray(T.transform.matrix),O.matrix.decompose(O.position,O.quaternion,O.scale),O.projectionMatrix.fromArray(T.projectionMatrix),O.projectionMatrixInverse.copy(O.projectionMatrix).invert(),O.viewport.set(k.x,k.y,k.width,k.height),A===0&&(B.matrix.copy(O.matrix),B.matrix.decompose(B.position,B.quaternion,B.scale)),ge===!0&&B.cameras.push(O)}let ce=n.enabledFeatures;if(ce&&ce.includes("depth-sensing")){let A=d.getDepthInformation(pe[0]);A&&A.isValid&&A.texture&&v.init(e,A,n.renderState)}}for(let pe=0;pe<x.length;pe++){let ge=_[pe],ce=x[pe];ge!==null&&ce!==void 0&&ce.update(ge,ae,c||a)}ue&&ue(K,ae),ae.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:ae}),m=null}),this.setAnimationLoop=function(K){ue=K},this.dispose=function(){}}},an=new Et,Fm=new Ee;function Bm(s,e){function t(n,r){n.matrixAutoUpdate===!0&&n.updateMatrix(),r.value.copy(n.matrix)}function i(n,r){n.opacity.value=r.opacity,r.color&&n.diffuse.value.copy(r.color),r.emissive&&n.emissive.value.copy(r.emissive).multiplyScalar(r.emissiveIntensity),r.map&&(n.map.value=r.map,t(r.map,n.mapTransform)),r.alphaMap&&(n.alphaMap.value=r.alphaMap,t(r.alphaMap,n.alphaMapTransform)),r.bumpMap&&(n.bumpMap.value=r.bumpMap,t(r.bumpMap,n.bumpMapTransform),n.bumpScale.value=r.bumpScale,r.side===1&&(n.bumpScale.value*=-1)),r.normalMap&&(n.normalMap.value=r.normalMap,t(r.normalMap,n.normalMapTransform),n.normalScale.value.copy(r.normalScale),r.side===1&&n.normalScale.value.negate()),r.displacementMap&&(n.displacementMap.value=r.displacementMap,t(r.displacementMap,n.displacementMapTransform),n.displacementScale.value=r.displacementScale,n.displacementBias.value=r.displacementBias),r.emissiveMap&&(n.emissiveMap.value=r.emissiveMap,t(r.emissiveMap,n.emissiveMapTransform)),r.specularMap&&(n.specularMap.value=r.specularMap,t(r.specularMap,n.specularMapTransform)),r.alphaTest>0&&(n.alphaTest.value=r.alphaTest);let a=e.get(r),o=a.envMap,l=a.envMapRotation;o&&(n.envMap.value=o,an.copy(l),an.x*=-1,an.y*=-1,an.z*=-1,o.isCubeTexture&&o.isRenderTargetTexture===!1&&(an.y*=-1,an.z*=-1),n.envMapRotation.value.setFromMatrix4(Fm.makeRotationFromEuler(an)),n.flipEnvMap.value=o.isCubeTexture&&o.isRenderTargetTexture===!1?-1:1,n.reflectivity.value=r.reflectivity,n.ior.value=r.ior,n.refractionRatio.value=r.refractionRatio),r.lightMap&&(n.lightMap.value=r.lightMap,n.lightMapIntensity.value=r.lightMapIntensity,t(r.lightMap,n.lightMapTransform)),r.aoMap&&(n.aoMap.value=r.aoMap,n.aoMapIntensity.value=r.aoMapIntensity,t(r.aoMap,n.aoMapTransform))}return{refreshFogUniforms:function(n,r){r.color.getRGB(n.fogColor.value,Zu(s)),r.isFog?(n.fogNear.value=r.near,n.fogFar.value=r.far):r.isFogExp2&&(n.fogDensity.value=r.density)},refreshMaterialUniforms:function(n,r,a,o,l){r.isMeshBasicMaterial||r.isMeshLambertMaterial?i(n,r):r.isMeshToonMaterial?(i(n,r),function(c,h){h.gradientMap&&(c.gradientMap.value=h.gradientMap)}(n,r)):r.isMeshPhongMaterial?(i(n,r),function(c,h){c.specular.value.copy(h.specular),c.shininess.value=Math.max(h.shininess,1e-4)}(n,r)):r.isMeshStandardMaterial?(i(n,r),function(c,h){c.metalness.value=h.metalness,h.metalnessMap&&(c.metalnessMap.value=h.metalnessMap,t(h.metalnessMap,c.metalnessMapTransform)),c.roughness.value=h.roughness,h.roughnessMap&&(c.roughnessMap.value=h.roughnessMap,t(h.roughnessMap,c.roughnessMapTransform)),h.envMap&&(c.envMapIntensity.value=h.envMapIntensity)}(n,r),r.isMeshPhysicalMaterial&&function(c,h,d){c.ior.value=h.ior,h.sheen>0&&(c.sheenColor.value.copy(h.sheenColor).multiplyScalar(h.sheen),c.sheenRoughness.value=h.sheenRoughness,h.sheenColorMap&&(c.sheenColorMap.value=h.sheenColorMap,t(h.sheenColorMap,c.sheenColorMapTransform)),h.sheenRoughnessMap&&(c.sheenRoughnessMap.value=h.sheenRoughnessMap,t(h.sheenRoughnessMap,c.sheenRoughnessMapTransform))),h.clearcoat>0&&(c.clearcoat.value=h.clearcoat,c.clearcoatRoughness.value=h.clearcoatRoughness,h.clearcoatMap&&(c.clearcoatMap.value=h.clearcoatMap,t(h.clearcoatMap,c.clearcoatMapTransform)),h.clearcoatRoughnessMap&&(c.clearcoatRoughnessMap.value=h.clearcoatRoughnessMap,t(h.clearcoatRoughnessMap,c.clearcoatRoughnessMapTransform)),h.clearcoatNormalMap&&(c.clearcoatNormalMap.value=h.clearcoatNormalMap,t(h.clearcoatNormalMap,c.clearcoatNormalMapTransform),c.clearcoatNormalScale.value.copy(h.clearcoatNormalScale),h.side===1&&c.clearcoatNormalScale.value.negate())),h.dispersion>0&&(c.dispersion.value=h.dispersion),h.iridescence>0&&(c.iridescence.value=h.iridescence,c.iridescenceIOR.value=h.iridescenceIOR,c.iridescenceThicknessMinimum.value=h.iridescenceThicknessRange[0],c.iridescenceThicknessMaximum.value=h.iridescenceThicknessRange[1],h.iridescenceMap&&(c.iridescenceMap.value=h.iridescenceMap,t(h.iridescenceMap,c.iridescenceMapTransform)),h.iridescenceThicknessMap&&(c.iridescenceThicknessMap.value=h.iridescenceThicknessMap,t(h.iridescenceThicknessMap,c.iridescenceThicknessMapTransform))),h.transmission>0&&(c.transmission.value=h.transmission,c.transmissionSamplerMap.value=d.texture,c.transmissionSamplerSize.value.set(d.width,d.height),h.transmissionMap&&(c.transmissionMap.value=h.transmissionMap,t(h.transmissionMap,c.transmissionMapTransform)),c.thickness.value=h.thickness,h.thicknessMap&&(c.thicknessMap.value=h.thicknessMap,t(h.thicknessMap,c.thicknessMapTransform)),c.attenuationDistance.value=h.attenuationDistance,c.attenuationColor.value.copy(h.attenuationColor)),h.anisotropy>0&&(c.anisotropyVector.value.set(h.anisotropy*Math.cos(h.anisotropyRotation),h.anisotropy*Math.sin(h.anisotropyRotation)),h.anisotropyMap&&(c.anisotropyMap.value=h.anisotropyMap,t(h.anisotropyMap,c.anisotropyMapTransform))),c.specularIntensity.value=h.specularIntensity,c.specularColor.value.copy(h.specularColor),h.specularColorMap&&(c.specularColorMap.value=h.specularColorMap,t(h.specularColorMap,c.specularColorMapTransform)),h.specularIntensityMap&&(c.specularIntensityMap.value=h.specularIntensityMap,t(h.specularIntensityMap,c.specularIntensityMapTransform))}(n,r,l)):r.isMeshMatcapMaterial?(i(n,r),function(c,h){h.matcap&&(c.matcap.value=h.matcap)}(n,r)):r.isMeshDepthMaterial?i(n,r):r.isMeshDistanceMaterial?(i(n,r),function(c,h){let d=e.get(h).light;c.referencePosition.value.setFromMatrixPosition(d.matrixWorld),c.nearDistance.value=d.shadow.camera.near,c.farDistance.value=d.shadow.camera.far}(n,r)):r.isMeshNormalMaterial?i(n,r):r.isLineBasicMaterial?(function(c,h){c.diffuse.value.copy(h.color),c.opacity.value=h.opacity,h.map&&(c.map.value=h.map,t(h.map,c.mapTransform))}(n,r),r.isLineDashedMaterial&&function(c,h){c.dashSize.value=h.dashSize,c.totalSize.value=h.dashSize+h.gapSize,c.scale.value=h.scale}(n,r)):r.isPointsMaterial?function(c,h,d,u){c.diffuse.value.copy(h.color),c.opacity.value=h.opacity,c.size.value=h.size*d,c.scale.value=.5*u,h.map&&(c.map.value=h.map,t(h.map,c.uvTransform)),h.alphaMap&&(c.alphaMap.value=h.alphaMap,t(h.alphaMap,c.alphaMapTransform)),h.alphaTest>0&&(c.alphaTest.value=h.alphaTest)}(n,r,a,o):r.isSpriteMaterial?function(c,h){c.diffuse.value.copy(h.color),c.opacity.value=h.opacity,c.rotation.value=h.rotation,h.map&&(c.map.value=h.map,t(h.map,c.mapTransform)),h.alphaMap&&(c.alphaMap.value=h.alphaMap,t(h.alphaMap,c.alphaMapTransform)),h.alphaTest>0&&(c.alphaTest.value=h.alphaTest)}(n,r):r.isShadowMaterial?(n.color.value.copy(r.color),n.opacity.value=r.opacity):r.isShaderMaterial&&(r.uniformsNeedUpdate=!1)}}}function Hm(s,e,t,i){let n={},r={},a=[],o=s.getParameter(s.MAX_UNIFORM_BUFFER_BINDINGS);function l(d,u,p,m){let v=d.value,f=u+"_"+p;if(m[f]===void 0)return m[f]=typeof v=="number"||typeof v=="boolean"?v:v.clone(),!0;{let g=m[f];if(typeof v=="number"||typeof v=="boolean"){if(g!==v)return m[f]=v,!0}else if(g.equals(v)===!1)return g.copy(v),!0}return!1}function c(d){let u={boundary:0,storage:0};return typeof d=="number"||typeof d=="boolean"?(u.boundary=4,u.storage=4):d.isVector2?(u.boundary=8,u.storage=8):d.isVector3||d.isColor?(u.boundary=16,u.storage=12):d.isVector4?(u.boundary=16,u.storage=16):d.isMatrix3?(u.boundary=48,u.storage=48):d.isMatrix4?(u.boundary=64,u.storage=64):d.isTexture?console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group."):console.warn("THREE.WebGLRenderer: Unsupported uniform value type.",d),u}function h(d){let u=d.target;u.removeEventListener("dispose",h);let p=a.indexOf(u.__bindingPointIndex);a.splice(p,1),s.deleteBuffer(n[u.id]),delete n[u.id],delete r[u.id]}return{bind:function(d,u){let p=u.program;i.uniformBlockBinding(d,p)},update:function(d,u){let p=n[d.id];p===void 0&&(function(f){let g=f.uniforms,y=0,x=16;for(let b=0,S=g.length;b<S;b++){let R=Array.isArray(g[b])?g[b]:[g[b]];for(let P=0,C=R.length;P<C;P++){let B=R[P],z=Array.isArray(B.value)?B.value:[B.value];for(let D=0,F=z.length;D<F;D++){let U=c(z[D]),X=y%x,j=X%U.boundary,Z=X+j;y+=j,Z!==0&&x-Z<U.storage&&(y+=x-Z),B.__data=new Float32Array(U.storage/Float32Array.BYTES_PER_ELEMENT),B.__offset=y,y+=U.storage}}}let _=y%x;_>0&&(y+=x-_),f.__size=y,f.__cache={}}(d),p=function(f){let g=function(){for(let b=0;b<o;b++)if(a.indexOf(b)===-1)return a.push(b),b;return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0}();f.__bindingPointIndex=g;let y=s.createBuffer(),x=f.__size,_=f.usage;return s.bindBuffer(s.UNIFORM_BUFFER,y),s.bufferData(s.UNIFORM_BUFFER,x,_),s.bindBuffer(s.UNIFORM_BUFFER,null),s.bindBufferBase(s.UNIFORM_BUFFER,g,y),y}(d),n[d.id]=p,d.addEventListener("dispose",h));let m=u.program;i.updateUBOMapping(d,m);let v=e.render.frame;r[d.id]!==v&&(function(f){let g=n[f.id],y=f.uniforms,x=f.__cache;s.bindBuffer(s.UNIFORM_BUFFER,g);for(let _=0,b=y.length;_<b;_++){let S=Array.isArray(y[_])?y[_]:[y[_]];for(let R=0,P=S.length;R<P;R++){let C=S[R];if(l(C,_,R,x)===!0){let B=C.__offset,z=Array.isArray(C.value)?C.value:[C.value],D=0;for(let F=0;F<z.length;F++){let U=z[F],X=c(U);typeof U=="number"||typeof U=="boolean"?(C.__data[0]=U,s.bufferSubData(s.UNIFORM_BUFFER,B+D,C.__data)):U.isMatrix3?(C.__data[0]=U.elements[0],C.__data[1]=U.elements[1],C.__data[2]=U.elements[2],C.__data[3]=0,C.__data[4]=U.elements[3],C.__data[5]=U.elements[4],C.__data[6]=U.elements[5],C.__data[7]=0,C.__data[8]=U.elements[6],C.__data[9]=U.elements[7],C.__data[10]=U.elements[8],C.__data[11]=0):(U.toArray(C.__data,D),D+=X.storage/Float32Array.BYTES_PER_ELEMENT)}s.bufferSubData(s.UNIFORM_BUFFER,B,C.__data)}}}s.bindBuffer(s.UNIFORM_BUFFER,null)}(d),r[d.id]=v)},dispose:function(){for(let d in n)s.deleteBuffer(n[d]);a=[],n={},r={}}}}var va=class{constructor(e={}){let{canvas:t=Kd(),context:i=null,depth:n=!0,stencil:r=!1,alpha:a=!1,antialias:o=!1,premultipliedAlpha:l=!0,preserveDrawingBuffer:c=!1,powerPreference:h="default",failIfMajorPerformanceCaveat:d=!1,reverseDepthBuffer:u=!1}=e,p;if(this.isWebGLRenderer=!0,i!==null){if(typeof WebGLRenderingContext<"u"&&i instanceof WebGLRenderingContext)throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");p=i.getContextAttributes().alpha}else p=a;let m=new Uint32Array(4),v=new Int32Array(4),f=null,g=null,y=[],x=[];this.domElement=t,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this._outputColorSpace=wt,this.toneMapping=0,this.toneMappingExposure=1;let _=this,b=!1,S=0,R=0,P=null,C=-1,B=null,z=new ct,D=new ct,F=null,U=new ye(0),X=0,j=t.width,Z=t.height,$=1,ue=null,_e=null,K=new ct(0,0,j,Z),ae=new ct(0,0,j,Z),pe=!1,ge=new Kn,ce=!1,A=!1,T=new Ee,k=new Ee,O=new M,L=new ct,N={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0},w=!1;function I(){return P===null?$:1}let V,te,H,Q,J,ne,ve,me,Se,Le,Xe,ze,we,Ze,nt,ht,Me,Fe,tt,_n,dr,Yt,hi,$i,G=i;function gs(E,W){return t.getContext(E,W)}try{let E={alpha:!0,depth:n,stencil:r,antialias:o,premultipliedAlpha:l,preserveDrawingBuffer:c,powerPreference:h,failIfMajorPerformanceCaveat:d};if("setAttribute"in t&&t.setAttribute("data-engine",`three.js r${al}`),t.addEventListener("webglcontextlost",nh,!1),t.addEventListener("webglcontextrestored",sh,!1),t.addEventListener("webglcontextcreationerror",rh,!1),G===null){let W="webgl2";if(G=gs(W,E),G===null)throw gs(W)?new Error("Error creating WebGL context with your selected attributes."):new Error("Error creating WebGL context.")}}catch(E){throw console.error("THREE.WebGLRenderer: "+E.message),E}function ih(){V=new bp(G),V.init(),Yt=new zm(G,V),te=new yp(G,V,e,Yt),H=new Nm(G,V),te.reverseDepthBuffer&&u&&H.buffers.depth.setReversed(!0),Q=new Ep(G),J=new Em,ne=new Om(G,V,H,J,te,Yt,Q),ve=new _p(_),me=new Mp(_),Se=new pp(G),hi=new gp(G,Se),Le=new Sp(G,Se,Q,hi),Xe=new Ap(G,Le,Se,Q),tt=new Tp(G,te,ne),ht=new xp(J),ze=new wm(_,ve,me,V,te,hi,ht),we=new Bm(_,J),Ze=new Am,nt=new Im(V),Fe=new fp(_,ve,me,H,Xe,p,l),Me=new Dm(_,Xe,te),$i=new Hm(G,Q,te,H),_n=new vp(G,V,Q),dr=new wp(G,V,Q),Q.programs=ze.programs,_.capabilities=te,_.extensions=V,_.properties=J,_.renderLists=Ze,_.shadowMap=Me,_.state=H,_.info=Q}ih();let yt=new ic(_,G);function nh(E){E.preventDefault(),console.log("THREE.WebGLRenderer: Context Lost."),b=!0}function sh(){console.log("THREE.WebGLRenderer: Context Restored."),b=!1;let E=Q.autoReset,W=Me.enabled,Y=Me.autoUpdate,ee=Me.needsUpdate,q=Me.type;ih(),Q.autoReset=E,Me.enabled=W,Me.autoUpdate=Y,Me.needsUpdate=ee,Me.type=q}function rh(E){console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ",E.statusMessage)}function ah(E){let W=E.target;W.removeEventListener("dispose",ah),function(Y){(function(ee){let q=J.get(ee).programs;q!==void 0&&(q.forEach(function(le){ze.releaseProgram(le)}),ee.isShaderMaterial&&ze.releaseShaderCache(ee))})(Y),J.remove(Y)}(W)}function oh(E,W,Y){E.transparent===!0&&E.side===2&&E.forceSinglePass===!1?(E.side=1,E.needsUpdate=!0,mr(E,W,Y),E.side=0,E.needsUpdate=!0,mr(E,W,Y),E.side=2):mr(E,W,Y)}this.xr=yt,this.getContext=function(){return G},this.getContextAttributes=function(){return G.getContextAttributes()},this.forceContextLoss=function(){let E=V.get("WEBGL_lose_context");E&&E.loseContext()},this.forceContextRestore=function(){let E=V.get("WEBGL_lose_context");E&&E.restoreContext()},this.getPixelRatio=function(){return $},this.setPixelRatio=function(E){E!==void 0&&($=E,this.setSize(j,Z,!1))},this.getSize=function(E){return E.set(j,Z)},this.setSize=function(E,W,Y=!0){yt.isPresenting?console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting."):(j=E,Z=W,t.width=Math.floor(E*$),t.height=Math.floor(W*$),Y===!0&&(t.style.width=E+"px",t.style.height=W+"px"),this.setViewport(0,0,E,W))},this.getDrawingBufferSize=function(E){return E.set(j*$,Z*$).floor()},this.setDrawingBufferSize=function(E,W,Y){j=E,Z=W,$=Y,t.width=Math.floor(E*Y),t.height=Math.floor(W*Y),this.setViewport(0,0,E,W)},this.getCurrentViewport=function(E){return E.copy(z)},this.getViewport=function(E){return E.copy(K)},this.setViewport=function(E,W,Y,ee){E.isVector4?K.set(E.x,E.y,E.z,E.w):K.set(E,W,Y,ee),H.viewport(z.copy(K).multiplyScalar($).round())},this.getScissor=function(E){return E.copy(ae)},this.setScissor=function(E,W,Y,ee){E.isVector4?ae.set(E.x,E.y,E.z,E.w):ae.set(E,W,Y,ee),H.scissor(D.copy(ae).multiplyScalar($).round())},this.getScissorTest=function(){return pe},this.setScissorTest=function(E){H.setScissorTest(pe=E)},this.setOpaqueSort=function(E){ue=E},this.setTransparentSort=function(E){_e=E},this.getClearColor=function(E){return E.copy(Fe.getClearColor())},this.setClearColor=function(){Fe.setClearColor.apply(Fe,arguments)},this.getClearAlpha=function(){return Fe.getClearAlpha()},this.setClearAlpha=function(){Fe.setClearAlpha.apply(Fe,arguments)},this.clear=function(E=!0,W=!0,Y=!0){let ee=0;if(E){let q=!1;if(P!==null){let le=P.texture.format;q=le===Hc||le===Bc||le===Fc}if(q){let le=P.texture.type,xe=le===Vi||le===un||le===Hs||le===jn||le===Oc||le===zc,be=Fe.getClearColor(),Ae=Fe.getClearAlpha(),Ie=be.r,Ue=be.g,Re=be.b;xe?(m[0]=Ie,m[1]=Ue,m[2]=Re,m[3]=Ae,G.clearBufferuiv(G.COLOR,0,m)):(v[0]=Ie,v[1]=Ue,v[2]=Re,v[3]=Ae,G.clearBufferiv(G.COLOR,0,v))}else ee|=G.COLOR_BUFFER_BIT}W&&(ee|=G.DEPTH_BUFFER_BIT),Y&&(ee|=G.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(4294967295)),G.clear(ee)},this.clearColor=function(){this.clear(!0,!1,!1)},this.clearDepth=function(){this.clear(!1,!0,!1)},this.clearStencil=function(){this.clear(!1,!1,!0)},this.dispose=function(){t.removeEventListener("webglcontextlost",nh,!1),t.removeEventListener("webglcontextrestored",sh,!1),t.removeEventListener("webglcontextcreationerror",rh,!1),Ze.dispose(),nt.dispose(),J.dispose(),ve.dispose(),me.dispose(),Xe.dispose(),hi.dispose(),$i.dispose(),ze.dispose(),yt.dispose(),yt.removeEventListener("sessionstart",lh),yt.removeEventListener("sessionend",ch),Zi.stop()},this.renderBufferDirect=function(E,W,Y,ee,q,le){W===null&&(W=N);let xe=q.isMesh&&q.matrixWorld.determinant()<0,be=function(Ge,Lt,St,Oe,Pe){Lt.isScene!==!0&&(Lt=N),ne.resetTextureUnits();let $t=Lt.fog,fo=Oe.isMeshStandardMaterial?Lt.environment:null,vs=P===null?_.outputColorSpace:P.isXRRenderTarget===!0?P.texture.colorSpace:os,Mn=(Oe.isMeshStandardMaterial?me:ve).get(Oe.envMap||fo),go=Oe.vertexColors===!0&&!!St.attributes.color&&St.attributes.color.itemSize===4,vo=!!St.attributes.tangent&&(!!Oe.normalMap||Oe.anisotropy>0),yo=!!St.morphAttributes.position,Ii=!!St.morphAttributes.normal,fd=!!St.morphAttributes.color,fh=0;Oe.toneMapped&&(P!==null&&P.isXRRenderTarget!==!0||(fh=_.toneMapping));let gh=St.morphAttributes.position||St.morphAttributes.normal||St.morphAttributes.color,gd=gh!==void 0?gh.length:0,Be=J.get(Oe),vd=g.state.lights;if(ce===!0&&(A===!0||Ge!==B)){let Bt=Ge===B&&Oe.id===C;ht.setState(Oe,Ge,Bt)}let Zt=!1;Oe.version===Be.__version?Be.needsLights&&Be.lightsStateVersion!==vd.state.version||Be.outputColorSpace!==vs||Pe.isBatchedMesh&&Be.batching===!1?Zt=!0:Pe.isBatchedMesh||Be.batching!==!0?Pe.isBatchedMesh&&Be.batchingColor===!0&&Pe.colorTexture===null||Pe.isBatchedMesh&&Be.batchingColor===!1&&Pe.colorTexture!==null||Pe.isInstancedMesh&&Be.instancing===!1?Zt=!0:Pe.isInstancedMesh||Be.instancing!==!0?Pe.isSkinnedMesh&&Be.skinning===!1?Zt=!0:Pe.isSkinnedMesh||Be.skinning!==!0?Pe.isInstancedMesh&&Be.instancingColor===!0&&Pe.instanceColor===null||Pe.isInstancedMesh&&Be.instancingColor===!1&&Pe.instanceColor!==null||Pe.isInstancedMesh&&Be.instancingMorph===!0&&Pe.morphTexture===null||Pe.isInstancedMesh&&Be.instancingMorph===!1&&Pe.morphTexture!==null||Be.envMap!==Mn||Oe.fog===!0&&Be.fog!==$t?Zt=!0:Be.numClippingPlanes===void 0||Be.numClippingPlanes===ht.numPlanes&&Be.numIntersection===ht.numIntersection?(Be.vertexAlphas!==go||Be.vertexTangents!==vo||Be.morphTargets!==yo||Be.morphNormals!==Ii||Be.morphColors!==fd||Be.toneMapping!==fh||Be.morphTargetsCount!==gd)&&(Zt=!0):Zt=!0:Zt=!0:Zt=!0:Zt=!0:(Zt=!0,Be.__version=Oe.version);let Ji=Be.currentProgram;Zt===!0&&(Ji=mr(Oe,Lt,Pe));let vh=!1,ys=!1,xo=!1,pt=Ji.getUniforms(),Di=Be.uniforms;if(H.useProgram(Ji.program)&&(vh=!0,ys=!0,xo=!0),Oe.id!==C&&(C=Oe.id,ys=!0),vh||B!==Ge){H.buffers.depth.getReversed()?(T.copy(Ge.projectionMatrix),function(Ki){let ot=Ki.elements;ot[2]=.5*ot[2]+.5*ot[3],ot[6]=.5*ot[6]+.5*ot[7],ot[10]=.5*ot[10]+.5*ot[11],ot[14]=.5*ot[14]+.5*ot[15]}(T),function(Ki){let ot=Ki.elements;ot[11]===-1?(ot[10]=-ot[10]-1,ot[14]=-ot[14]):(ot[10]=-ot[10],ot[14]=1-ot[14])}(T),pt.setValue(G,"projectionMatrix",T)):pt.setValue(G,"projectionMatrix",Ge.projectionMatrix),pt.setValue(G,"viewMatrix",Ge.matrixWorldInverse);let Bt=pt.map.cameraPosition;Bt!==void 0&&Bt.setValue(G,O.setFromMatrixPosition(Ge.matrixWorld)),te.logarithmicDepthBuffer&&pt.setValue(G,"logDepthBufFC",2/(Math.log(Ge.far+1)/Math.LN2)),(Oe.isMeshPhongMaterial||Oe.isMeshToonMaterial||Oe.isMeshLambertMaterial||Oe.isMeshBasicMaterial||Oe.isMeshStandardMaterial||Oe.isShaderMaterial)&&pt.setValue(G,"isOrthographic",Ge.isOrthographicCamera===!0),B!==Ge&&(B=Ge,ys=!0,xo=!0)}if(Pe.isSkinnedMesh){pt.setOptional(G,Pe,"bindMatrix"),pt.setOptional(G,Pe,"bindMatrixInverse");let Bt=Pe.skeleton;Bt&&(Bt.boneTexture===null&&Bt.computeBoneTexture(),pt.setValue(G,"boneTexture",Bt.boneTexture,ne))}Pe.isBatchedMesh&&(pt.setOptional(G,Pe,"batchingTexture"),pt.setValue(G,"batchingTexture",Pe._matricesTexture,ne),pt.setOptional(G,Pe,"batchingIdTexture"),pt.setValue(G,"batchingIdTexture",Pe._indirectTexture,ne),pt.setOptional(G,Pe,"batchingColorTexture"),Pe._colorsTexture!==null&&pt.setValue(G,"batchingColorTexture",Pe._colorsTexture,ne));let _o=St.morphAttributes;_o.position===void 0&&_o.normal===void 0&&_o.color===void 0||tt.update(Pe,St,Ji),(ys||Be.receiveShadow!==Pe.receiveShadow)&&(Be.receiveShadow=Pe.receiveShadow,pt.setValue(G,"receiveShadow",Pe.receiveShadow)),Oe.isMeshGouraudMaterial&&Oe.envMap!==null&&(Di.envMap.value=Mn,Di.flipEnvMap.value=Mn.isCubeTexture&&Mn.isRenderTargetTexture===!1?-1:1),Oe.isMeshStandardMaterial&&Oe.envMap===null&&Lt.environment!==null&&(Di.envMapIntensity.value=Lt.environmentIntensity),ys&&(pt.setValue(G,"toneMappingExposure",_.toneMappingExposure),Be.needsLights&&(Jt=xo,(ui=Di).ambientLightColor.needsUpdate=Jt,ui.lightProbe.needsUpdate=Jt,ui.directionalLights.needsUpdate=Jt,ui.directionalLightShadows.needsUpdate=Jt,ui.pointLights.needsUpdate=Jt,ui.pointLightShadows.needsUpdate=Jt,ui.spotLights.needsUpdate=Jt,ui.spotLightShadows.needsUpdate=Jt,ui.rectAreaLights.needsUpdate=Jt,ui.hemisphereLights.needsUpdate=Jt),$t&&Oe.fog===!0&&we.refreshFogUniforms(Di,$t),we.refreshMaterialUniforms(Di,Oe,$,Z,g.state.transmissionRenderTarget[Ge.id]),Wn.upload(G,ph(Be),Di,ne));var ui,Jt;if(Oe.isShaderMaterial&&Oe.uniformsNeedUpdate===!0&&(Wn.upload(G,ph(Be),Di,ne),Oe.uniformsNeedUpdate=!1),Oe.isSpriteMaterial&&pt.setValue(G,"center",Pe.center),pt.setValue(G,"modelViewMatrix",Pe.modelViewMatrix),pt.setValue(G,"normalMatrix",Pe.normalMatrix),pt.setValue(G,"modelMatrix",Pe.matrixWorld),Oe.isShaderMaterial||Oe.isRawShaderMaterial){let Bt=Oe.uniformsGroups;for(let Ki=0,ot=Bt.length;Ki<ot;Ki++){let yh=Bt[Ki];$i.update(yh,Ji),$i.bind(yh,Ji)}}return Ji}(E,W,Y,ee,q);H.setMaterial(ee,xe);let Ae=Y.index,Ie=1;if(ee.wireframe===!0){if(Ae=Le.getWireframeAttribute(Y),Ae===void 0)return;Ie=2}let Ue=Y.drawRange,Re=Y.attributes.position,ke=Ue.start*Ie,dt=(Ue.start+Ue.count)*Ie;le!==null&&(ke=Math.max(ke,le.start*Ie),dt=Math.min(dt,(le.start+le.count)*Ie)),Ae!==null?(ke=Math.max(ke,0),dt=Math.min(dt,Ae.count)):Re!=null&&(ke=Math.max(ke,0),dt=Math.min(dt,Re.count));let st=dt-ke;if(st<0||st===1/0)return;let ft;hi.setup(q,ee,be,Y,Ae);let rt=_n;if(Ae!==null&&(ft=Se.get(Ae),rt=dr,rt.setIndex(ft)),q.isMesh)ee.wireframe===!0?(H.setLineWidth(ee.wireframeLinewidth*I()),rt.setMode(G.LINES)):rt.setMode(G.TRIANGLES);else if(q.isLine){let Ge=ee.linewidth;Ge===void 0&&(Ge=1),H.setLineWidth(Ge*I()),q.isLineSegments?rt.setMode(G.LINES):q.isLineLoop?rt.setMode(G.LINE_LOOP):rt.setMode(G.LINE_STRIP)}else q.isPoints?rt.setMode(G.POINTS):q.isSprite&&rt.setMode(G.TRIANGLES);if(q.isBatchedMesh)if(q._multiDrawInstances!==null)rt.renderMultiDrawInstances(q._multiDrawStarts,q._multiDrawCounts,q._multiDrawCount,q._multiDrawInstances);else if(V.get("WEBGL_multi_draw"))rt.renderMultiDraw(q._multiDrawStarts,q._multiDrawCounts,q._multiDrawCount);else{let Ge=q._multiDrawStarts,Lt=q._multiDrawCounts,St=q._multiDrawCount,Oe=Ae?Se.get(Ae).bytesPerElement:1,Pe=J.get(ee).currentProgram.getUniforms();for(let $t=0;$t<St;$t++)Pe.setValue(G,"_gl_DrawID",$t),rt.render(Ge[$t]/Oe,Lt[$t])}else if(q.isInstancedMesh)rt.renderInstances(ke,st,q.count);else if(Y.isInstancedBufferGeometry){let Ge=Y._maxInstanceCount!==void 0?Y._maxInstanceCount:1/0,Lt=Math.min(Y.instanceCount,Ge);rt.renderInstances(ke,st,Lt)}else rt.render(ke,st)},this.compile=function(E,W,Y=null){Y===null&&(Y=E),g=nt.get(Y),g.init(W),x.push(g),Y.traverseVisible(function(q){q.isLight&&q.layers.test(W.layers)&&(g.pushLight(q),q.castShadow&&g.pushShadow(q))}),E!==Y&&E.traverseVisible(function(q){q.isLight&&q.layers.test(W.layers)&&(g.pushLight(q),q.castShadow&&g.pushShadow(q))}),g.setupLights();let ee=new Set;return E.traverse(function(q){if(!(q.isMesh||q.isPoints||q.isLine||q.isSprite))return;let le=q.material;if(le)if(Array.isArray(le))for(let xe=0;xe<le.length;xe++){let be=le[xe];oh(be,Y,q),ee.add(be)}else oh(le,Y,q),ee.add(le)}),x.pop(),g=null,ee},this.compileAsync=function(E,W,Y=null){let ee=this.compile(E,W,Y);return new Promise(q=>{function le(){ee.forEach(function(xe){J.get(xe).currentProgram.isReady()&&ee.delete(xe)}),ee.size!==0?setTimeout(le,10):q(E)}V.get("KHR_parallel_shader_compile")!==null?le():setTimeout(le,10)})};let po=null;function lh(){Zi.stop()}function ch(){Zi.start()}let Zi=new Ju;function mo(E,W,Y,ee){if(E.visible===!1)return;if(E.layers.test(W.layers)){if(E.isGroup)Y=E.renderOrder;else if(E.isLOD)E.autoUpdate===!0&&E.update(W);else if(E.isLight)g.pushLight(E),E.castShadow&&g.pushShadow(E);else if(E.isSprite){if(!E.frustumCulled||ge.intersectsSprite(E)){ee&&L.setFromMatrixPosition(E.matrixWorld).applyMatrix4(k);let le=Xe.update(E),xe=E.material;xe.visible&&f.push(E,le,xe,Y,L.z,null)}}else if((E.isMesh||E.isLine||E.isPoints)&&(!E.frustumCulled||ge.intersectsObject(E))){let le=Xe.update(E),xe=E.material;if(ee&&(E.boundingSphere!==void 0?(E.boundingSphere===null&&E.computeBoundingSphere(),L.copy(E.boundingSphere.center)):(le.boundingSphere===null&&le.computeBoundingSphere(),L.copy(le.boundingSphere.center)),L.applyMatrix4(E.matrixWorld).applyMatrix4(k)),Array.isArray(xe)){let be=le.groups;for(let Ae=0,Ie=be.length;Ae<Ie;Ae++){let Ue=be[Ae],Re=xe[Ue.materialIndex];Re&&Re.visible&&f.push(E,le,Re,Y,L.z,Ue)}}else xe.visible&&f.push(E,le,xe,Y,L.z,null)}}let q=E.children;for(let le=0,xe=q.length;le<xe;le++)mo(q[le],W,Y,ee)}function hh(E,W,Y,ee){let q=E.opaque,le=E.transmissive,xe=E.transparent;g.setupLightsView(Y),ce===!0&&ht.setGlobalState(_.clippingPlanes,Y),ee&&H.viewport(z.copy(ee)),q.length>0&&pr(q,W,Y),le.length>0&&pr(le,W,Y),xe.length>0&&pr(xe,W,Y),H.buffers.depth.setTest(!0),H.buffers.depth.setMask(!0),H.buffers.color.setMask(!0),H.setPolygonOffset(!1)}function uh(E,W,Y,ee){if((Y.isScene===!0?Y.overrideMaterial:null)!==null)return;g.state.transmissionRenderTarget[ee.id]===void 0&&(g.state.transmissionRenderTarget[ee.id]=new si(1,1,{generateMipmaps:!0,type:V.has("EXT_color_buffer_half_float")||V.has("EXT_color_buffer_float")?vn:Vi,minFilter:Bn,samples:4,stencilBuffer:r,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:je.workingColorSpace}));let q=g.state.transmissionRenderTarget[ee.id],le=ee.viewport||z;q.setSize(le.z,le.w);let xe=_.getRenderTarget();_.setRenderTarget(q),_.getClearColor(U),X=_.getClearAlpha(),X<1&&_.setClearColor(16777215,.5),_.clear(),w&&Fe.render(Y);let be=_.toneMapping;_.toneMapping=0;let Ae=ee.viewport;if(ee.viewport!==void 0&&(ee.viewport=void 0),g.setupLightsView(ee),ce===!0&&ht.setGlobalState(_.clippingPlanes,ee),pr(E,Y,ee),ne.updateMultisampleRenderTarget(q),ne.updateRenderTargetMipmap(q),V.has("WEBGL_multisampled_render_to_texture")===!1){let Ie=!1;for(let Ue=0,Re=W.length;Ue<Re;Ue++){let ke=W[Ue],dt=ke.object,st=ke.geometry,ft=ke.material,rt=ke.group;if(ft.side===2&&dt.layers.test(ee.layers)){let Ge=ft.side;ft.side=1,ft.needsUpdate=!0,dh(dt,Y,ee,st,ft,rt),ft.side=Ge,ft.needsUpdate=!0,Ie=!0}}Ie===!0&&(ne.updateMultisampleRenderTarget(q),ne.updateRenderTargetMipmap(q))}_.setRenderTarget(xe),_.setClearColor(U,X),Ae!==void 0&&(ee.viewport=Ae),_.toneMapping=be}function pr(E,W,Y){let ee=W.isScene===!0?W.overrideMaterial:null;for(let q=0,le=E.length;q<le;q++){let xe=E[q],be=xe.object,Ae=xe.geometry,Ie=ee===null?xe.material:ee,Ue=xe.group;be.layers.test(Y.layers)&&dh(be,W,Y,Ae,Ie,Ue)}}function dh(E,W,Y,ee,q,le){E.onBeforeRender(_,W,Y,ee,q,le),E.modelViewMatrix.multiplyMatrices(Y.matrixWorldInverse,E.matrixWorld),E.normalMatrix.getNormalMatrix(E.modelViewMatrix),q.onBeforeRender(_,W,Y,ee,E,le),q.transparent===!0&&q.side===2&&q.forceSinglePass===!1?(q.side=1,q.needsUpdate=!0,_.renderBufferDirect(Y,W,ee,q,E,le),q.side=0,q.needsUpdate=!0,_.renderBufferDirect(Y,W,ee,q,E,le),q.side=2):_.renderBufferDirect(Y,W,ee,q,E,le),E.onAfterRender(_,W,Y,ee,q,le)}function mr(E,W,Y){W.isScene!==!0&&(W=N);let ee=J.get(E),q=g.state.lights,le=g.state.shadowsArray,xe=q.state.version,be=ze.getParameters(E,q.state,le,W,Y),Ae=ze.getProgramCacheKey(be),Ie=ee.programs;ee.environment=E.isMeshStandardMaterial?W.environment:null,ee.fog=W.fog,ee.envMap=(E.isMeshStandardMaterial?me:ve).get(E.envMap||ee.environment),ee.envMapRotation=ee.environment!==null&&E.envMap===null?W.environmentRotation:E.envMapRotation,Ie===void 0&&(E.addEventListener("dispose",ah),Ie=new Map,ee.programs=Ie);let Ue=Ie.get(Ae);if(Ue!==void 0){if(ee.currentProgram===Ue&&ee.lightsStateVersion===xe)return mh(E,be),Ue}else be.uniforms=ze.getUniforms(E),E.onBeforeCompile(be,_),Ue=ze.acquireProgram(be,Ae),Ie.set(Ae,Ue),ee.uniforms=be.uniforms;let Re=ee.uniforms;return(E.isShaderMaterial||E.isRawShaderMaterial)&&E.clipping!==!0||(Re.clippingPlanes=ht.uniform),mh(E,be),ee.needsLights=function(ke){return ke.isMeshLambertMaterial||ke.isMeshToonMaterial||ke.isMeshPhongMaterial||ke.isMeshStandardMaterial||ke.isShadowMaterial||ke.isShaderMaterial&&ke.lights===!0}(E),ee.lightsStateVersion=xe,ee.needsLights&&(Re.ambientLightColor.value=q.state.ambient,Re.lightProbe.value=q.state.probe,Re.directionalLights.value=q.state.directional,Re.directionalLightShadows.value=q.state.directionalShadow,Re.spotLights.value=q.state.spot,Re.spotLightShadows.value=q.state.spotShadow,Re.rectAreaLights.value=q.state.rectArea,Re.ltc_1.value=q.state.rectAreaLTC1,Re.ltc_2.value=q.state.rectAreaLTC2,Re.pointLights.value=q.state.point,Re.pointLightShadows.value=q.state.pointShadow,Re.hemisphereLights.value=q.state.hemi,Re.directionalShadowMap.value=q.state.directionalShadowMap,Re.directionalShadowMatrix.value=q.state.directionalShadowMatrix,Re.spotShadowMap.value=q.state.spotShadowMap,Re.spotLightMatrix.value=q.state.spotLightMatrix,Re.spotLightMap.value=q.state.spotLightMap,Re.pointShadowMap.value=q.state.pointShadowMap,Re.pointShadowMatrix.value=q.state.pointShadowMatrix),ee.currentProgram=Ue,ee.uniformsList=null,Ue}function ph(E){if(E.uniformsList===null){let W=E.currentProgram.getUniforms();E.uniformsList=Wn.seqWithValue(W.seq,E.uniforms)}return E.uniformsList}function mh(E,W){let Y=J.get(E);Y.outputColorSpace=W.outputColorSpace,Y.batching=W.batching,Y.batchingColor=W.batchingColor,Y.instancing=W.instancing,Y.instancingColor=W.instancingColor,Y.instancingMorph=W.instancingMorph,Y.skinning=W.skinning,Y.morphTargets=W.morphTargets,Y.morphNormals=W.morphNormals,Y.morphColors=W.morphColors,Y.morphTargetsCount=W.morphTargetsCount,Y.numClippingPlanes=W.numClippingPlanes,Y.numIntersection=W.numClipIntersection,Y.vertexAlphas=W.vertexAlphas,Y.vertexTangents=W.vertexTangents,Y.toneMapping=W.toneMapping}Zi.setAnimationLoop(function(E){po&&po(E)}),typeof self<"u"&&Zi.setContext(self),this.setAnimationLoop=function(E){po=E,yt.setAnimationLoop(E),E===null?Zi.stop():Zi.start()},yt.addEventListener("sessionstart",lh),yt.addEventListener("sessionend",ch),this.render=function(E,W){if(W!==void 0&&W.isCamera!==!0)return void console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");if(b===!0)return;if(E.matrixWorldAutoUpdate===!0&&E.updateMatrixWorld(),W.parent===null&&W.matrixWorldAutoUpdate===!0&&W.updateMatrixWorld(),yt.enabled===!0&&yt.isPresenting===!0&&(yt.cameraAutoUpdate===!0&&yt.updateCamera(W),W=yt.getCamera()),E.isScene===!0&&E.onBeforeRender(_,E,W,P),g=nt.get(E,x.length),g.init(W),x.push(g),k.multiplyMatrices(W.projectionMatrix,W.matrixWorldInverse),ge.setFromProjectionMatrix(k),A=this.localClippingEnabled,ce=ht.init(this.clippingPlanes,A),f=Ze.get(E,y.length),f.init(),y.push(f),yt.enabled===!0&&yt.isPresenting===!0){let le=_.xr.getDepthSensingMesh();le!==null&&mo(le,W,-1/0,_.sortObjects)}mo(E,W,0,_.sortObjects),f.finish(),_.sortObjects===!0&&f.sort(ue,_e),w=yt.enabled===!1||yt.isPresenting===!1||yt.hasDepthSensing()===!1,w&&Fe.addToRenderList(f,E),this.info.render.frame++,ce===!0&&ht.beginShadows();let Y=g.state.shadowsArray;Me.render(Y,E,W),ce===!0&&ht.endShadows(),this.info.autoReset===!0&&this.info.reset();let ee=f.opaque,q=f.transmissive;if(g.setupLights(),W.isArrayCamera){let le=W.cameras;if(q.length>0)for(let xe=0,be=le.length;xe<be;xe++)uh(ee,q,E,le[xe]);w&&Fe.render(E);for(let xe=0,be=le.length;xe<be;xe++){let Ae=le[xe];hh(f,E,Ae,Ae.viewport)}}else q.length>0&&uh(ee,q,E,W),w&&Fe.render(E),hh(f,E,W);P!==null&&(ne.updateMultisampleRenderTarget(P),ne.updateRenderTargetMipmap(P)),E.isScene===!0&&E.onAfterRender(_,E,W),hi.resetDefaultState(),C=-1,B=null,x.pop(),x.length>0?(g=x[x.length-1],ce===!0&&ht.setGlobalState(_.clippingPlanes,g.state.camera)):g=null,y.pop(),f=y.length>0?y[y.length-1]:null},this.getActiveCubeFace=function(){return S},this.getActiveMipmapLevel=function(){return R},this.getRenderTarget=function(){return P},this.setRenderTargetTextures=function(E,W,Y){J.get(E.texture).__webglTexture=W,J.get(E.depthTexture).__webglTexture=Y;let ee=J.get(E);ee.__hasExternalTextures=!0,ee.__autoAllocateDepthBuffer=Y===void 0,ee.__autoAllocateDepthBuffer||V.has("WEBGL_multisampled_render_to_texture")===!0&&(console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"),ee.__useRenderToTexture=!1)},this.setRenderTargetFramebuffer=function(E,W){let Y=J.get(E);Y.__webglFramebuffer=W,Y.__useDefaultFramebuffer=W===void 0},this.setRenderTarget=function(E,W=0,Y=0){P=E,S=W,R=Y;let ee=!0,q=null,le=!1,xe=!1;if(E){let be=J.get(E);if(be.__useDefaultFramebuffer!==void 0)H.bindFramebuffer(G.FRAMEBUFFER,null),ee=!1;else if(be.__webglFramebuffer===void 0)ne.setupRenderTarget(E);else if(be.__hasExternalTextures)ne.rebindTextures(E,J.get(E.texture).__webglTexture,J.get(E.depthTexture).__webglTexture);else if(E.depthBuffer){let Ue=E.depthTexture;if(be.__boundDepthTexture!==Ue){if(Ue!==null&&J.has(Ue)&&(E.width!==Ue.image.width||E.height!==Ue.image.height))throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");ne.setupDepthRenderbuffer(E)}}let Ae=E.texture;(Ae.isData3DTexture||Ae.isDataArrayTexture||Ae.isCompressedArrayTexture)&&(xe=!0);let Ie=J.get(E).__webglFramebuffer;E.isWebGLCubeRenderTarget?(q=Array.isArray(Ie[W])?Ie[W][Y]:Ie[W],le=!0):q=E.samples>0&&ne.useMultisampledRTT(E)===!1?J.get(E).__webglMultisampledFramebuffer:Array.isArray(Ie)?Ie[Y]:Ie,z.copy(E.viewport),D.copy(E.scissor),F=E.scissorTest}else z.copy(K).multiplyScalar($).floor(),D.copy(ae).multiplyScalar($).floor(),F=pe;if(H.bindFramebuffer(G.FRAMEBUFFER,q)&&ee&&H.drawBuffers(E,q),H.viewport(z),H.scissor(D),H.setScissorTest(F),le){let be=J.get(E.texture);G.framebufferTexture2D(G.FRAMEBUFFER,G.COLOR_ATTACHMENT0,G.TEXTURE_CUBE_MAP_POSITIVE_X+W,be.__webglTexture,Y)}else if(xe){let be=J.get(E.texture),Ae=W||0;G.framebufferTextureLayer(G.FRAMEBUFFER,G.COLOR_ATTACHMENT0,be.__webglTexture,Y||0,Ae)}C=-1},this.readRenderTargetPixels=function(E,W,Y,ee,q,le,xe){if(!E||!E.isWebGLRenderTarget)return void console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let be=J.get(E).__webglFramebuffer;if(E.isWebGLCubeRenderTarget&&xe!==void 0&&(be=be[xe]),be){H.bindFramebuffer(G.FRAMEBUFFER,be);try{let Ae=E.texture,Ie=Ae.format,Ue=Ae.type;if(!te.textureFormatReadable(Ie))return void console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");if(!te.textureTypeReadable(Ue))return void console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");W>=0&&W<=E.width-ee&&Y>=0&&Y<=E.height-q&&G.readPixels(W,Y,ee,q,Yt.convert(Ie),Yt.convert(Ue),le)}finally{let Ae=P!==null?J.get(P).__webglFramebuffer:null;H.bindFramebuffer(G.FRAMEBUFFER,Ae)}}},this.readRenderTargetPixelsAsync=async function(E,W,Y,ee,q,le,xe){if(!E||!E.isWebGLRenderTarget)throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");let be=J.get(E).__webglFramebuffer;if(E.isWebGLCubeRenderTarget&&xe!==void 0&&(be=be[xe]),be){let Ae=E.texture,Ie=Ae.format,Ue=Ae.type;if(!te.textureFormatReadable(Ie))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");if(!te.textureTypeReadable(Ue))throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");if(W>=0&&W<=E.width-ee&&Y>=0&&Y<=E.height-q){H.bindFramebuffer(G.FRAMEBUFFER,be);let Re=G.createBuffer();G.bindBuffer(G.PIXEL_PACK_BUFFER,Re),G.bufferData(G.PIXEL_PACK_BUFFER,le.byteLength,G.STREAM_READ),G.readPixels(W,Y,ee,q,Yt.convert(Ie),Yt.convert(Ue),0);let ke=P!==null?J.get(P).__webglFramebuffer:null;H.bindFramebuffer(G.FRAMEBUFFER,ke);let dt=G.fenceSync(G.SYNC_GPU_COMMANDS_COMPLETE,0);return G.flush(),await function(st,ft,rt){return new Promise(function(Ge,Lt){setTimeout(function St(){switch(st.clientWaitSync(ft,st.SYNC_FLUSH_COMMANDS_BIT,0)){case st.WAIT_FAILED:Lt();break;case st.TIMEOUT_EXPIRED:setTimeout(St,rt);break;default:Ge()}},rt)})}(G,dt,4),G.bindBuffer(G.PIXEL_PACK_BUFFER,Re),G.getBufferSubData(G.PIXEL_PACK_BUFFER,0,le),G.deleteBuffer(Re),G.deleteSync(dt),le}throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")}},this.copyFramebufferToTexture=function(E,W=null,Y=0){E.isTexture!==!0&&(Us("WebGLRenderer: copyFramebufferToTexture function signature has changed."),W=arguments[0]||null,E=arguments[1]);let ee=Math.pow(2,-Y),q=Math.floor(E.image.width*ee),le=Math.floor(E.image.height*ee),xe=W!==null?W.x:0,be=W!==null?W.y:0;ne.setTexture2D(E,0),G.copyTexSubImage2D(G.TEXTURE_2D,Y,0,0,xe,be,q,le),H.unbindTexture()},this.copyTextureToTexture=function(E,W,Y=null,ee=null,q=0){let le,xe,be,Ae,Ie,Ue,Re,ke,dt;E.isTexture!==!0&&(Us("WebGLRenderer: copyTextureToTexture function signature has changed."),ee=arguments[0]||null,E=arguments[1],W=arguments[2],q=arguments[3]||0,Y=null);let st=E.isCompressedTexture?E.mipmaps[q]:E.image;Y!==null?(le=Y.max.x-Y.min.x,xe=Y.max.y-Y.min.y,be=Y.isBox3?Y.max.z-Y.min.z:1,Ae=Y.min.x,Ie=Y.min.y,Ue=Y.isBox3?Y.min.z:0):(le=st.width,xe=st.height,be=st.depth||1,Ae=0,Ie=0,Ue=0),ee!==null?(Re=ee.x,ke=ee.y,dt=ee.z):(Re=0,ke=0,dt=0);let ft=Yt.convert(W.format),rt=Yt.convert(W.type),Ge;W.isData3DTexture?(ne.setTexture3D(W,0),Ge=G.TEXTURE_3D):W.isDataArrayTexture||W.isCompressedArrayTexture?(ne.setTexture2DArray(W,0),Ge=G.TEXTURE_2D_ARRAY):(ne.setTexture2D(W,0),Ge=G.TEXTURE_2D),G.pixelStorei(G.UNPACK_FLIP_Y_WEBGL,W.flipY),G.pixelStorei(G.UNPACK_PREMULTIPLY_ALPHA_WEBGL,W.premultiplyAlpha),G.pixelStorei(G.UNPACK_ALIGNMENT,W.unpackAlignment);let Lt=G.getParameter(G.UNPACK_ROW_LENGTH),St=G.getParameter(G.UNPACK_IMAGE_HEIGHT),Oe=G.getParameter(G.UNPACK_SKIP_PIXELS),Pe=G.getParameter(G.UNPACK_SKIP_ROWS),$t=G.getParameter(G.UNPACK_SKIP_IMAGES);G.pixelStorei(G.UNPACK_ROW_LENGTH,st.width),G.pixelStorei(G.UNPACK_IMAGE_HEIGHT,st.height),G.pixelStorei(G.UNPACK_SKIP_PIXELS,Ae),G.pixelStorei(G.UNPACK_SKIP_ROWS,Ie),G.pixelStorei(G.UNPACK_SKIP_IMAGES,Ue);let fo=E.isDataArrayTexture||E.isData3DTexture,vs=W.isDataArrayTexture||W.isData3DTexture;if(E.isRenderTargetTexture||E.isDepthTexture){let Mn=J.get(E),go=J.get(W),vo=J.get(Mn.__renderTarget),yo=J.get(go.__renderTarget);H.bindFramebuffer(G.READ_FRAMEBUFFER,vo.__webglFramebuffer),H.bindFramebuffer(G.DRAW_FRAMEBUFFER,yo.__webglFramebuffer);for(let Ii=0;Ii<be;Ii++)fo&&G.framebufferTextureLayer(G.READ_FRAMEBUFFER,G.COLOR_ATTACHMENT0,J.get(E).__webglTexture,q,Ue+Ii),E.isDepthTexture?(vs&&G.framebufferTextureLayer(G.DRAW_FRAMEBUFFER,G.COLOR_ATTACHMENT0,J.get(W).__webglTexture,q,dt+Ii),G.blitFramebuffer(Ae,Ie,le,xe,Re,ke,le,xe,G.DEPTH_BUFFER_BIT,G.NEAREST)):vs?G.copyTexSubImage3D(Ge,q,Re,ke,dt+Ii,Ae,Ie,le,xe):G.copyTexSubImage2D(Ge,q,Re,ke,dt+Ii,Ae,Ie,le,xe);H.bindFramebuffer(G.READ_FRAMEBUFFER,null),H.bindFramebuffer(G.DRAW_FRAMEBUFFER,null)}else vs?E.isDataTexture||E.isData3DTexture?G.texSubImage3D(Ge,q,Re,ke,dt,le,xe,be,ft,rt,st.data):W.isCompressedArrayTexture?G.compressedTexSubImage3D(Ge,q,Re,ke,dt,le,xe,be,ft,st.data):G.texSubImage3D(Ge,q,Re,ke,dt,le,xe,be,ft,rt,st):E.isDataTexture?G.texSubImage2D(G.TEXTURE_2D,q,Re,ke,le,xe,ft,rt,st.data):E.isCompressedTexture?G.compressedTexSubImage2D(G.TEXTURE_2D,q,Re,ke,st.width,st.height,ft,st.data):G.texSubImage2D(G.TEXTURE_2D,q,Re,ke,le,xe,ft,rt,st);G.pixelStorei(G.UNPACK_ROW_LENGTH,Lt),G.pixelStorei(G.UNPACK_IMAGE_HEIGHT,St),G.pixelStorei(G.UNPACK_SKIP_PIXELS,Oe),G.pixelStorei(G.UNPACK_SKIP_ROWS,Pe),G.pixelStorei(G.UNPACK_SKIP_IMAGES,$t),q===0&&W.generateMipmaps&&G.generateMipmap(Ge),H.unbindTexture()},this.copyTextureToTexture3D=function(E,W,Y=null,ee=null,q=0){return E.isTexture!==!0&&(Us("WebGLRenderer: copyTextureToTexture3D function signature has changed."),Y=arguments[0]||null,ee=arguments[1]||null,E=arguments[2],W=arguments[3],q=arguments[4]||0),Us('WebGLRenderer: copyTextureToTexture3D function has been deprecated. Use "copyTextureToTexture" instead.'),this.copyTextureToTexture(E,W,Y,ee,q)},this.initRenderTarget=function(E){J.get(E).__webglFramebuffer===void 0&&ne.setupRenderTarget(E)},this.initTexture=function(E){E.isCubeTexture?ne.setTextureCube(E,0):E.isData3DTexture?ne.setTexture3D(E,0):E.isDataArrayTexture||E.isCompressedArrayTexture?ne.setTexture2DArray(E,0):ne.setTexture2D(E,0),H.unbindTexture()},this.resetState=function(){S=0,R=0,P=null,H.reset(),hi.reset()},typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}get coordinateSystem(){return $n}get outputColorSpace(){return this._outputColorSpace}set outputColorSpace(e){this._outputColorSpace=e;let t=this.getContext();t.drawingBufferColorspace=je._getDrawingBufferColorSpace(e),t.unpackColorSpace=je._getUnpackColorSpace()}},ya=class s{constructor(e,t=25e-5){this.isFogExp2=!0,this.name="",this.color=new ye(e),this.density=t}clone(){return new s(this.color,this.density)}toJSON(){return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}}};var Wi=class extends at{constructor(){super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new Et,this.environmentIntensity=1,this.environmentRotation=new Et,this.overrideMaterial=null,typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))}copy(e,t){return super.copy(e,t),e.background!==null&&(this.background=e.background.clone()),e.environment!==null&&(this.environment=e.environment.clone()),e.fog!==null&&(this.fog=e.fog.clone()),this.backgroundBlurriness=e.backgroundBlurriness,this.backgroundIntensity=e.backgroundIntensity,this.backgroundRotation.copy(e.backgroundRotation),this.environmentIntensity=e.environmentIntensity,this.environmentRotation.copy(e.environmentRotation),e.overrideMaterial!==null&&(this.overrideMaterial=e.overrideMaterial.clone()),this.matrixAutoUpdate=e.matrixAutoUpdate,this}toJSON(e){let t=super.toJSON(e);return this.fog!==null&&(t.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(t.object.backgroundBlurriness=this.backgroundBlurriness),this.backgroundIntensity!==1&&(t.object.backgroundIntensity=this.backgroundIntensity),t.object.backgroundRotation=this.backgroundRotation.toArray(),this.environmentIntensity!==1&&(t.object.environmentIntensity=this.environmentIntensity),t.object.environmentRotation=this.environmentRotation.toArray(),t}},nc=class{constructor(e,t){this.isInterleavedBuffer=!0,this.array=e,this.stride=t,this.count=e!==void 0?e.length/t:0,this.usage=Fl,this.updateRanges=[],this.version=0,this.uuid=fi()}onUploadCallback(){}set needsUpdate(e){e===!0&&this.version++}setUsage(e){return this.usage=e,this}addUpdateRange(e,t){this.updateRanges.push({start:e,count:t})}clearUpdateRanges(){this.updateRanges.length=0}copy(e){return this.array=new e.array.constructor(e.array),this.count=e.count,this.stride=e.stride,this.usage=e.usage,this}copyAt(e,t,i){e*=this.stride,i*=t.stride;for(let n=0,r=this.stride;n<r;n++)this.array[e+n]=t.array[i+n];return this}set(e,t=0){return this.array.set(e,t),this}clone(e){e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=fi()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);let t=new this.array.constructor(e.arrayBuffers[this.array.buffer._uuid]),i=new this.constructor(t,this.stride);return i.setUsage(this.usage),i}onUpload(e){return this.onUploadCallback=e,this}toJSON(e){return e.arrayBuffers===void 0&&(e.arrayBuffers={}),this.array.buffer._uuid===void 0&&(this.array.buffer._uuid=fi()),e.arrayBuffers[this.array.buffer._uuid]===void 0&&(e.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}}},It=new M,xa=class s{constructor(e,t,i,n=!1){this.isInterleavedBufferAttribute=!0,this.name="",this.data=e,this.itemSize=t,this.offset=i,this.normalized=n}get count(){return this.data.count}get array(){return this.data.array}set needsUpdate(e){this.data.needsUpdate=e}applyMatrix4(e){for(let t=0,i=this.data.count;t<i;t++)It.fromBufferAttribute(this,t),It.applyMatrix4(e),this.setXYZ(t,It.x,It.y,It.z);return this}applyNormalMatrix(e){for(let t=0,i=this.count;t<i;t++)It.fromBufferAttribute(this,t),It.applyNormalMatrix(e),this.setXYZ(t,It.x,It.y,It.z);return this}transformDirection(e){for(let t=0,i=this.count;t<i;t++)It.fromBufferAttribute(this,t),It.transformDirection(e),this.setXYZ(t,It.x,It.y,It.z);return this}getComponent(e,t){let i=this.array[e*this.data.stride+this.offset+t];return this.normalized&&(i=ti(i,this.array)),i}setComponent(e,t,i){return this.normalized&&(i=Ke(i,this.array)),this.data.array[e*this.data.stride+this.offset+t]=i,this}setX(e,t){return this.normalized&&(t=Ke(t,this.array)),this.data.array[e*this.data.stride+this.offset]=t,this}setY(e,t){return this.normalized&&(t=Ke(t,this.array)),this.data.array[e*this.data.stride+this.offset+1]=t,this}setZ(e,t){return this.normalized&&(t=Ke(t,this.array)),this.data.array[e*this.data.stride+this.offset+2]=t,this}setW(e,t){return this.normalized&&(t=Ke(t,this.array)),this.data.array[e*this.data.stride+this.offset+3]=t,this}getX(e){let t=this.data.array[e*this.data.stride+this.offset];return this.normalized&&(t=ti(t,this.array)),t}getY(e){let t=this.data.array[e*this.data.stride+this.offset+1];return this.normalized&&(t=ti(t,this.array)),t}getZ(e){let t=this.data.array[e*this.data.stride+this.offset+2];return this.normalized&&(t=ti(t,this.array)),t}getW(e){let t=this.data.array[e*this.data.stride+this.offset+3];return this.normalized&&(t=ti(t,this.array)),t}setXY(e,t,i){return e=e*this.data.stride+this.offset,this.normalized&&(t=Ke(t,this.array),i=Ke(i,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this}setXYZ(e,t,i,n){return e=e*this.data.stride+this.offset,this.normalized&&(t=Ke(t,this.array),i=Ke(i,this.array),n=Ke(n,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=n,this}setXYZW(e,t,i,n,r){return e=e*this.data.stride+this.offset,this.normalized&&(t=Ke(t,this.array),i=Ke(i,this.array),n=Ke(n,this.array),r=Ke(r,this.array)),this.data.array[e+0]=t,this.data.array[e+1]=i,this.data.array[e+2]=n,this.data.array[e+3]=r,this}clone(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let i=0;i<this.count;i++){let n=i*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[n+r])}return new We(new this.array.constructor(t),this.itemSize,this.normalized)}return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.clone(e)),new s(e.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized)}toJSON(e){if(e===void 0){console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");let t=[];for(let i=0;i<this.count;i++){let n=i*this.data.stride+this.offset;for(let r=0;r<this.itemSize;r++)t.push(this.data.array[n+r])}return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}}return e.interleavedBuffers===void 0&&(e.interleavedBuffers={}),e.interleavedBuffers[this.data.uuid]===void 0&&(e.interleavedBuffers[this.data.uuid]=this.data.toJSON(e)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized}}},Xs=class extends gi{static get type(){return"SpriteMaterial"}constructor(e){super(),this.isSpriteMaterial=!0,this.color=new ye(16777215),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.rotation=e.rotation,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},Nn,Rs=new M,On=new M,zn=new M,kn=new oe,Cs=new oe,id=new Ee,Hr=new M,Ls=new M,Vr=new M,yu=new oe,Ko=new oe,xu=new oe,_a=class extends at{constructor(e=new Xs){if(super(),this.isSprite=!0,this.type="Sprite",Nn===void 0){Nn=new Ve;let t=new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),i=new nc(t,5);Nn.setIndex([0,1,2,0,2,3]),Nn.setAttribute("position",new xa(i,3,0,!1)),Nn.setAttribute("uv",new xa(i,2,3,!1))}this.geometry=Nn,this.material=e,this.center=new oe(.5,.5)}raycast(e,t){e.camera===null&&console.error('THREE.Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),On.setFromMatrixScale(this.matrixWorld),id.copy(e.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(e.camera.matrixWorldInverse,this.matrixWorld),zn.setFromMatrixPosition(this.modelViewMatrix),e.camera.isPerspectiveCamera&&this.material.sizeAttenuation===!1&&On.multiplyScalar(-zn.z);let i=this.material.rotation,n,r;i!==0&&(r=Math.cos(i),n=Math.sin(i));let a=this.center;Gr(Hr.set(-.5,-.5,0),zn,a,On,n,r),Gr(Ls.set(.5,-.5,0),zn,a,On,n,r),Gr(Vr.set(.5,.5,0),zn,a,On,n,r),yu.set(0,0),Ko.set(1,0),xu.set(1,1);let o=e.ray.intersectTriangle(Hr,Ls,Vr,!1,Rs);if(o===null&&(Gr(Ls.set(-.5,.5,0),zn,a,On,n,r),Ko.set(0,1),o=e.ray.intersectTriangle(Hr,Vr,Ls,!1,Rs),o===null))return;let l=e.ray.origin.distanceTo(Rs);l<e.near||l>e.far||t.push({distance:l,point:Rs.clone(),uv:Ei.getInterpolation(Rs,Hr,Ls,Vr,yu,Ko,xu,new oe),face:null,object:this})}copy(e,t){return super.copy(e,t),e.center!==void 0&&this.center.copy(e.center),this.material=e.material,this}};function Gr(s,e,t,i,n,r){kn.subVectors(s,t).addScalar(.5).multiply(i),n!==void 0?(Cs.x=r*kn.x-n*kn.y,Cs.y=n*kn.x+r*kn.y):Cs.copy(kn),s.copy(e),s.x+=Cs.x,s.y+=Cs.y,s.applyMatrix4(id)}var kf=new M,Ff=new M;var Bf=new M,Hf=new ct,Vf=new ct,Gf=new M,Wf=new Ee,Xf=new M,qf=new ai,jf=new Ee,Yf=new Zn;var sc=class extends Nt{constructor(e=null,t=1,i=1,n,r,a,o,l,c=1003,h=1003,d,u){super(null,a,o,l,c,h,n,r,d,u),this.isDataTexture=!0,this.image={data:e,width:t,height:i},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1}},$f=new Ee,Zf=new Ee;var Ma=class extends We{constructor(e,t,i,n=1){super(e,t,i),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=n}copy(e){return super.copy(e),this.meshPerAttribute=e.meshPerAttribute,this}toJSON(){let e=super.toJSON();return e.meshPerAttribute=this.meshPerAttribute,e.isInstancedBufferAttribute=!0,e}},Fn=new Ee,_u=new Ee,Wr=[],Mu=new ri,Vm=new Ee,Ps=new Ce,Is=new ai,dn=class extends Ce{constructor(e,t,i){super(e,t),this.isInstancedMesh=!0,this.instanceMatrix=new Ma(new Float32Array(16*i),16),this.instanceColor=null,this.morphTexture=null,this.count=i,this.boundingBox=null,this.boundingSphere=null;for(let n=0;n<i;n++)this.setMatrixAt(n,Vm)}computeBoundingBox(){let e=this.geometry,t=this.count;this.boundingBox===null&&(this.boundingBox=new ri),e.boundingBox===null&&e.computeBoundingBox(),this.boundingBox.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,Fn),Mu.copy(e.boundingBox).applyMatrix4(Fn),this.boundingBox.union(Mu)}computeBoundingSphere(){let e=this.geometry,t=this.count;this.boundingSphere===null&&(this.boundingSphere=new ai),e.boundingSphere===null&&e.computeBoundingSphere(),this.boundingSphere.makeEmpty();for(let i=0;i<t;i++)this.getMatrixAt(i,Fn),Is.copy(e.boundingSphere).applyMatrix4(Fn),this.boundingSphere.union(Is)}copy(e,t){return super.copy(e,t),this.instanceMatrix.copy(e.instanceMatrix),e.morphTexture!==null&&(this.morphTexture=e.morphTexture.clone()),e.instanceColor!==null&&(this.instanceColor=e.instanceColor.clone()),this.count=e.count,e.boundingBox!==null&&(this.boundingBox=e.boundingBox.clone()),e.boundingSphere!==null&&(this.boundingSphere=e.boundingSphere.clone()),this}getColorAt(e,t){t.fromArray(this.instanceColor.array,3*e)}getMatrixAt(e,t){t.fromArray(this.instanceMatrix.array,16*e)}getMorphAt(e,t){let i=t.morphTargetInfluences,n=this.morphTexture.source.data.data,r=e*(i.length+1)+1;for(let a=0;a<i.length;a++)i[a]=n[r+a]}raycast(e,t){let i=this.matrixWorld,n=this.count;if(Ps.geometry=this.geometry,Ps.material=this.material,Ps.material!==void 0&&(this.boundingSphere===null&&this.computeBoundingSphere(),Is.copy(this.boundingSphere),Is.applyMatrix4(i),e.ray.intersectsSphere(Is)!==!1))for(let r=0;r<n;r++){this.getMatrixAt(r,Fn),_u.multiplyMatrices(i,Fn),Ps.matrixWorld=_u,Ps.raycast(e,Wr);for(let a=0,o=Wr.length;a<o;a++){let l=Wr[a];l.instanceId=r,l.object=this,t.push(l)}Wr.length=0}}setColorAt(e,t){this.instanceColor===null&&(this.instanceColor=new Ma(new Float32Array(3*this.instanceMatrix.count).fill(1),3)),t.toArray(this.instanceColor.array,3*e)}setMatrixAt(e,t){t.toArray(this.instanceMatrix.array,16*e)}setMorphAt(e,t){let i=t.morphTargetInfluences,n=i.length+1;this.morphTexture===null&&(this.morphTexture=new sc(new Float32Array(n*this.count),n,this.count,kc,pi));let r=this.morphTexture.source.data.data,a=0;for(let c=0;c<i.length;c++)a+=i[c];let o=this.geometry.morphTargetsRelative?1:1-a,l=n*e;r[l]=o,r.set(i,l+1)}updateMorphTargets(){}dispose(){return this.dispatchEvent({type:"dispose"}),this.morphTexture!==null&&(this.morphTexture.dispose(),this.morphTexture=null),this}};var rc=class{constructor(){this.index=0,this.pool=[],this.list=[]}push(e,t,i,n){let r=this.pool,a=this.list;this.index>=r.length&&r.push({start:-1,count:-1,z:-1,index:-1});let o=r[this.index];a.push(o),this.index++,o.start=e,o.count=t,o.z=i,o.index=n}reset(){this.list.length=0,this.index=0}},Jf=new Ee,Kf=new ye(1,1,1),Qf=new Kn,eg=new ri,tg=new ai,ig=new M,ng=new M,sg=new M,rg=new rc,ag=new Ce;var pn=class extends gi{static get type(){return"LineBasicMaterial"}constructor(e){super(),this.isLineBasicMaterial=!0,this.color=new ye(16777215),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.linewidth=e.linewidth,this.linecap=e.linecap,this.linejoin=e.linejoin,this.fog=e.fog,this}},ba=new M,Sa=new M,bu=new Ee,Ds=new Zn,Xr=new ai,Qo=new M,Su=new M,ac=class extends at{constructor(e=new Ve,t=new pn){super(),this.isLine=!0,this.type="Line",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,i=[0];for(let n=1,r=t.count;n<r;n++)ba.fromBufferAttribute(t,n-1),Sa.fromBufferAttribute(t,n),i[n]=i[n-1],i[n]+=ba.distanceTo(Sa);e.setAttribute("lineDistance",new Te(i,1))}else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}raycast(e,t){let i=this.geometry,n=this.matrixWorld,r=e.params.Line.threshold,a=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),Xr.copy(i.boundingSphere),Xr.applyMatrix4(n),Xr.radius+=r,e.ray.intersectsSphere(Xr)===!1)return;bu.copy(n).invert(),Ds.copy(e.ray).applyMatrix4(bu);let o=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=this.isLineSegments?2:1,h=i.index,d=i.attributes.position;if(h!==null){let u=Math.max(0,a.start),p=Math.min(h.count,a.start+a.count);for(let m=u,v=p-1;m<v;m+=c){let f=h.getX(m),g=h.getX(m+1),y=qr(this,e,Ds,l,f,g);y&&t.push(y)}if(this.isLineLoop){let m=h.getX(p-1),v=h.getX(u),f=qr(this,e,Ds,l,m,v);f&&t.push(f)}}else{let u=Math.max(0,a.start),p=Math.min(d.count,a.start+a.count);for(let m=u,v=p-1;m<v;m+=c){let f=qr(this,e,Ds,l,m,m+1);f&&t.push(f)}if(this.isLineLoop){let m=qr(this,e,Ds,l,p-1,u);m&&t.push(m)}}}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let i=e[t[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let n=0,r=i.length;n<r;n++){let a=i[n].name||String(n);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=n}}}}};function qr(s,e,t,i,n,r){let a=s.geometry.attributes.position;if(ba.fromBufferAttribute(a,n),Sa.fromBufferAttribute(a,r),t.distanceSqToSegment(ba,Sa,Qo,Su)>i)return;Qo.applyMatrix4(s.matrixWorld);let o=e.ray.origin.distanceTo(Qo);return o<e.near||o>e.far?void 0:{distance:o,point:Su.clone().applyMatrix4(s.matrixWorld),index:n,face:null,faceIndex:null,barycoord:null,object:s}}var wu=new M,Eu=new M,ts=class extends ac{constructor(e,t){super(e,t),this.isLineSegments=!0,this.type="LineSegments"}computeLineDistances(){let e=this.geometry;if(e.index===null){let t=e.attributes.position,i=[];for(let n=0,r=t.count;n<r;n+=2)wu.fromBufferAttribute(t,n),Eu.fromBufferAttribute(t,n+1),i[n]=n===0?0:i[n-1],i[n+1]=i[n]+wu.distanceTo(Eu);e.setAttribute("lineDistance",new Te(i,1))}else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");return this}};var qs=class extends gi{static get type(){return"PointsMaterial"}constructor(e){super(),this.isPointsMaterial=!0,this.color=new ye(16777215),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.color.copy(e.color),this.map=e.map,this.alphaMap=e.alphaMap,this.size=e.size,this.sizeAttenuation=e.sizeAttenuation,this.fog=e.fog,this}},Tu=new Ee,oc=new Zn,jr=new ai,Yr=new M,is=class extends at{constructor(e=new Ve,t=new qs){super(),this.isPoints=!0,this.type="Points",this.geometry=e,this.material=t,this.updateMorphTargets()}copy(e,t){return super.copy(e,t),this.material=Array.isArray(e.material)?e.material.slice():e.material,this.geometry=e.geometry,this}raycast(e,t){let i=this.geometry,n=this.matrixWorld,r=e.params.Points.threshold,a=i.drawRange;if(i.boundingSphere===null&&i.computeBoundingSphere(),jr.copy(i.boundingSphere),jr.applyMatrix4(n),jr.radius+=r,e.ray.intersectsSphere(jr)===!1)return;Tu.copy(n).invert(),oc.copy(e.ray).applyMatrix4(Tu);let o=r/((this.scale.x+this.scale.y+this.scale.z)/3),l=o*o,c=i.index,h=i.attributes.position;if(c!==null)for(let d=Math.max(0,a.start),u=Math.min(c.count,a.start+a.count);d<u;d++){let p=c.getX(d);Yr.fromBufferAttribute(h,p),Au(Yr,p,l,n,e,t,this)}else for(let d=Math.max(0,a.start),u=Math.min(h.count,a.start+a.count);d<u;d++)Yr.fromBufferAttribute(h,d),Au(Yr,d,l,n,e,t,this)}updateMorphTargets(){let e=this.geometry.morphAttributes,t=Object.keys(e);if(t.length>0){let i=e[t[0]];if(i!==void 0){this.morphTargetInfluences=[],this.morphTargetDictionary={};for(let n=0,r=i.length;n<r;n++){let a=i[n].name||String(n);this.morphTargetInfluences.push(0),this.morphTargetDictionary[a]=n}}}}};function Au(s,e,t,i,n,r,a){let o=oc.distanceSqToPoint(s);if(o<t){let l=new M;oc.closestPointToPoint(s,l),l.applyMatrix4(i);let c=n.ray.origin.distanceTo(l);if(c<n.near||c>n.far)return;r.push({distance:c,distanceToRay:Math.sqrt(o),point:l,index:e,face:null,faceIndex:null,barycoord:null,object:a})}}var vi=class extends Nt{constructor(e,t,i,n,r,a,o,l,c){super(e,t,i,n,r,a,o,l,c),this.isCanvasTexture=!0,this.needsUpdate=!0}},Wt=class{constructor(){this.type="Curve",this.arcLengthDivisions=200}getPoint(){return console.warn("THREE.Curve: .getPoint() not implemented."),null}getPointAt(e,t){let i=this.getUtoTmapping(e);return this.getPoint(i,t)}getPoints(e=5){let t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return t}getSpacedPoints(e=5){let t=[];for(let i=0;i<=e;i++)t.push(this.getPointAt(i/e));return t}getLength(){let e=this.getLengths();return e[e.length-1]}getLengths(e=this.arcLengthDivisions){if(this.cacheArcLengths&&this.cacheArcLengths.length===e+1&&!this.needsUpdate)return this.cacheArcLengths;this.needsUpdate=!1;let t=[],i,n=this.getPoint(0),r=0;t.push(0);for(let a=1;a<=e;a++)i=this.getPoint(a/e),r+=i.distanceTo(n),t.push(r),n=i;return this.cacheArcLengths=t,t}updateArcLengths(){this.needsUpdate=!0,this.getLengths()}getUtoTmapping(e,t){let i=this.getLengths(),n=0,r=i.length,a;a=t||e*i[r-1];let o,l=0,c=r-1;for(;l<=c;)if(n=Math.floor(l+(c-l)/2),o=i[n]-a,o<0)l=n+1;else{if(!(o>0)){c=n;break}c=n-1}if(n=c,i[n]===a)return n/(r-1);let h=i[n];return(n+(a-h)/(i[n+1]-h))/(r-1)}getTangent(e,t){let n=e-1e-4,r=e+1e-4;n<0&&(n=0),r>1&&(r=1);let a=this.getPoint(n),o=this.getPoint(r),l=t||(a.isVector2?new oe:new M);return l.copy(o).sub(a).normalize(),l}getTangentAt(e,t){let i=this.getUtoTmapping(e);return this.getTangent(i,t)}computeFrenetFrames(e,t){let i=new M,n=[],r=[],a=[],o=new M,l=new Ee;for(let p=0;p<=e;p++){let m=p/e;n[p]=this.getTangentAt(m,new M)}r[0]=new M,a[0]=new M;let c=Number.MAX_VALUE,h=Math.abs(n[0].x),d=Math.abs(n[0].y),u=Math.abs(n[0].z);h<=c&&(c=h,i.set(1,0,0)),d<=c&&(c=d,i.set(0,1,0)),u<=c&&i.set(0,0,1),o.crossVectors(n[0],i).normalize(),r[0].crossVectors(n[0],o),a[0].crossVectors(n[0],r[0]);for(let p=1;p<=e;p++){if(r[p]=r[p-1].clone(),a[p]=a[p-1].clone(),o.crossVectors(n[p-1],n[p]),o.length()>Number.EPSILON){o.normalize();let m=Math.acos(_t(n[p-1].dot(n[p]),-1,1));r[p].applyMatrix4(l.makeRotationAxis(o,m))}a[p].crossVectors(n[p],r[p])}if(t===!0){let p=Math.acos(_t(r[0].dot(r[e]),-1,1));p/=e,n[0].dot(o.crossVectors(r[0],r[e]))>0&&(p=-p);for(let m=1;m<=e;m++)r[m].applyMatrix4(l.makeRotationAxis(n[m],p*m)),a[m].crossVectors(n[m],r[m])}return{tangents:n,normals:r,binormals:a}}clone(){return new this.constructor().copy(this)}copy(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}toJSON(){let e={metadata:{version:4.6,type:"Curve",generator:"Curve.toJSON"}};return e.arcLengthDivisions=this.arcLengthDivisions,e.type=this.type,e}fromJSON(e){return this.arcLengthDivisions=e.arcLengthDivisions,this}},js=class extends Wt{constructor(e=0,t=0,i=1,n=1,r=0,a=2*Math.PI,o=!1,l=0){super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=e,this.aY=t,this.xRadius=i,this.yRadius=n,this.aStartAngle=r,this.aEndAngle=a,this.aClockwise=o,this.aRotation=l}getPoint(e,t=new oe){let i=t,n=2*Math.PI,r=this.aEndAngle-this.aStartAngle,a=Math.abs(r)<Number.EPSILON;for(;r<0;)r+=n;for(;r>n;)r-=n;r<Number.EPSILON&&(r=a?0:n),this.aClockwise!==!0||a||(r===n?r=-n:r-=n);let o=this.aStartAngle+e*r,l=this.aX+this.xRadius*Math.cos(o),c=this.aY+this.yRadius*Math.sin(o);if(this.aRotation!==0){let h=Math.cos(this.aRotation),d=Math.sin(this.aRotation),u=l-this.aX,p=c-this.aY;l=u*h-p*d+this.aX,c=u*d+p*h+this.aY}return i.set(l,c)}copy(e){return super.copy(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}toJSON(){let e=super.toJSON();return e.aX=this.aX,e.aY=this.aY,e.xRadius=this.xRadius,e.yRadius=this.yRadius,e.aStartAngle=this.aStartAngle,e.aEndAngle=this.aEndAngle,e.aClockwise=this.aClockwise,e.aRotation=this.aRotation,e}fromJSON(e){return super.fromJSON(e),this.aX=e.aX,this.aY=e.aY,this.xRadius=e.xRadius,this.yRadius=e.yRadius,this.aStartAngle=e.aStartAngle,this.aEndAngle=e.aEndAngle,this.aClockwise=e.aClockwise,this.aRotation=e.aRotation,this}},lc=class extends js{constructor(e,t,i,n,r,a){super(e,t,i,i,n,r,a),this.isArcCurve=!0,this.type="ArcCurve"}};function Xc(){let s=0,e=0,t=0,i=0;function n(r,a,o,l){s=r,e=o,t=-3*r+3*a-2*o-l,i=2*r-2*a+o+l}return{initCatmullRom:function(r,a,o,l,c){n(a,o,c*(o-r),c*(l-a))},initNonuniformCatmullRom:function(r,a,o,l,c,h,d){let u=(a-r)/c-(o-r)/(c+h)+(o-a)/h,p=(o-a)/h-(l-a)/(h+d)+(l-o)/d;u*=h,p*=h,n(a,o,u,p)},calc:function(r){let a=r*r;return s+e*r+t*a+i*(a*r)}}}var $r=new M,el=new Xc,tl=new Xc,il=new Xc,cc=class extends Wt{constructor(e=[],t=!1,i="centripetal",n=.5){super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=e,this.closed=t,this.curveType=i,this.tension=n}getPoint(e,t=new M){let i=t,n=this.points,r=n.length,a=(r-(this.closed?0:1))*e,o,l,c=Math.floor(a),h=a-c;this.closed?c+=c>0?0:(Math.floor(Math.abs(c)/r)+1)*r:h===0&&c===r-1&&(c=r-2,h=1),this.closed||c>0?o=n[(c-1)%r]:($r.subVectors(n[0],n[1]).add(n[0]),o=$r);let d=n[c%r],u=n[(c+1)%r];if(this.closed||c+2<r?l=n[(c+2)%r]:($r.subVectors(n[r-1],n[r-2]).add(n[r-1]),l=$r),this.curveType==="centripetal"||this.curveType==="chordal"){let p=this.curveType==="chordal"?.5:.25,m=Math.pow(o.distanceToSquared(d),p),v=Math.pow(d.distanceToSquared(u),p),f=Math.pow(u.distanceToSquared(l),p);v<1e-4&&(v=1),m<1e-4&&(m=v),f<1e-4&&(f=v),el.initNonuniformCatmullRom(o.x,d.x,u.x,l.x,m,v,f),tl.initNonuniformCatmullRom(o.y,d.y,u.y,l.y,m,v,f),il.initNonuniformCatmullRom(o.z,d.z,u.z,l.z,m,v,f)}else this.curveType==="catmullrom"&&(el.initCatmullRom(o.x,d.x,u.x,l.x,this.tension),tl.initCatmullRom(o.y,d.y,u.y,l.y,this.tension),il.initCatmullRom(o.z,d.z,u.z,l.z,this.tension));return i.set(el.calc(h),tl.calc(h),il.calc(h)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let n=e.points[t];this.points.push(n.clone())}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){let n=this.points[t];e.points.push(n.toArray())}return e.closed=this.closed,e.curveType=this.curveType,e.tension=this.tension,e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let n=e.points[t];this.points.push(new M().fromArray(n))}return this.closed=e.closed,this.curveType=e.curveType,this.tension=e.tension,this}};function Ru(s,e,t,i,n){let r=.5*(i-e),a=.5*(n-t),o=s*s;return(2*t-2*i+r+a)*(s*o)+(-3*t+3*i-2*r-a)*o+r*s+t}function zs(s,e,t,i){return function(n,r){let a=1-n;return a*a*r}(s,e)+function(n,r){return 2*(1-n)*n*r}(s,t)+function(n,r){return n*n*r}(s,i)}function ks(s,e,t,i,n){return function(r,a){let o=1-r;return o*o*o*a}(s,e)+function(r,a){let o=1-r;return 3*o*o*r*a}(s,t)+function(r,a){return 3*(1-r)*r*r*a}(s,i)+function(r,a){return r*r*r*a}(s,n)}var wa=class extends Wt{constructor(e=new oe,t=new oe,i=new oe,n=new oe){super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=e,this.v1=t,this.v2=i,this.v3=n}getPoint(e,t=new oe){let i=t,n=this.v0,r=this.v1,a=this.v2,o=this.v3;return i.set(ks(e,n.x,r.x,a.x,o.x),ks(e,n.y,r.y,a.y,o.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},hc=class extends Wt{constructor(e=new M,t=new M,i=new M,n=new M){super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=e,this.v1=t,this.v2=i,this.v3=n}getPoint(e,t=new M){let i=t,n=this.v0,r=this.v1,a=this.v2,o=this.v3;return i.set(ks(e,n.x,r.x,a.x,o.x),ks(e,n.y,r.y,a.y,o.y),ks(e,n.z,r.z,a.z,o.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this.v3.copy(e.v3),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e.v3=this.v3.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this.v3.fromArray(e.v3),this}},Ea=class extends Wt{constructor(e=new oe,t=new oe){super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=e,this.v2=t}getPoint(e,t=new oe){let i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new oe){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},uc=class extends Wt{constructor(e=new M,t=new M){super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=e,this.v2=t}getPoint(e,t=new M){let i=t;return e===1?i.copy(this.v2):(i.copy(this.v2).sub(this.v1),i.multiplyScalar(e).add(this.v1)),i}getPointAt(e,t){return this.getPoint(e,t)}getTangent(e,t=new M){return t.subVectors(this.v2,this.v1).normalize()}getTangentAt(e,t){return this.getTangent(e,t)}copy(e){return super.copy(e),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Ta=class extends Wt{constructor(e=new oe,t=new oe,i=new oe){super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new oe){let i=t,n=this.v0,r=this.v1,a=this.v2;return i.set(zs(e,n.x,r.x,a.x),zs(e,n.y,r.y,a.y)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Aa=class extends Wt{constructor(e=new M,t=new M,i=new M){super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=e,this.v1=t,this.v2=i}getPoint(e,t=new M){let i=t,n=this.v0,r=this.v1,a=this.v2;return i.set(zs(e,n.x,r.x,a.x),zs(e,n.y,r.y,a.y),zs(e,n.z,r.z,a.z)),i}copy(e){return super.copy(e),this.v0.copy(e.v0),this.v1.copy(e.v1),this.v2.copy(e.v2),this}toJSON(){let e=super.toJSON();return e.v0=this.v0.toArray(),e.v1=this.v1.toArray(),e.v2=this.v2.toArray(),e}fromJSON(e){return super.fromJSON(e),this.v0.fromArray(e.v0),this.v1.fromArray(e.v1),this.v2.fromArray(e.v2),this}},Ra=class extends Wt{constructor(e=[]){super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=e}getPoint(e,t=new oe){let i=t,n=this.points,r=(n.length-1)*e,a=Math.floor(r),o=r-a,l=n[a===0?a:a-1],c=n[a],h=n[a>n.length-2?n.length-1:a+1],d=n[a>n.length-3?n.length-1:a+2];return i.set(Ru(o,l.x,c.x,h.x,d.x),Ru(o,l.y,c.y,h.y,d.y)),i}copy(e){super.copy(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let n=e.points[t];this.points.push(n.clone())}return this}toJSON(){let e=super.toJSON();e.points=[];for(let t=0,i=this.points.length;t<i;t++){let n=this.points[t];e.points.push(n.toArray())}return e}fromJSON(e){super.fromJSON(e),this.points=[];for(let t=0,i=e.points.length;t<i;t++){let n=e.points[t];this.points.push(new oe().fromArray(n))}return this}},Ca=Object.freeze({__proto__:null,ArcCurve:lc,CatmullRomCurve3:cc,CubicBezierCurve:wa,CubicBezierCurve3:hc,EllipseCurve:js,LineCurve:Ea,LineCurve3:uc,QuadraticBezierCurve:Ta,QuadraticBezierCurve3:Aa,SplineCurve:Ra}),dc=class extends Wt{constructor(){super(),this.type="CurvePath",this.curves=[],this.autoClose=!1}add(e){this.curves.push(e)}closePath(){let e=this.curves[0].getPoint(0),t=this.curves[this.curves.length-1].getPoint(1);if(!e.equals(t)){let i=e.isVector2===!0?"LineCurve":"LineCurve3";this.curves.push(new Ca[i](t,e))}return this}getPoint(e,t){let i=e*this.getLength(),n=this.getCurveLengths(),r=0;for(;r<n.length;){if(n[r]>=i){let a=n[r]-i,o=this.curves[r],l=o.getLength(),c=l===0?0:1-a/l;return o.getPointAt(c,t)}r++}return null}getLength(){let e=this.getCurveLengths();return e[e.length-1]}updateArcLengths(){this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()}getCurveLengths(){if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)return this.cacheLengths;let e=[],t=0;for(let i=0,n=this.curves.length;i<n;i++)t+=this.curves[i].getLength(),e.push(t);return this.cacheLengths=e,e}getSpacedPoints(e=40){let t=[];for(let i=0;i<=e;i++)t.push(this.getPoint(i/e));return this.autoClose&&t.push(t[0]),t}getPoints(e=12){let t=[],i;for(let n=0,r=this.curves;n<r.length;n++){let a=r[n],o=a.isEllipseCurve?2*e:a.isLineCurve||a.isLineCurve3?1:a.isSplineCurve?e*a.points.length:e,l=a.getPoints(o);for(let c=0;c<l.length;c++){let h=l[c];i&&i.equals(h)||(t.push(h),i=h)}}return this.autoClose&&t.length>1&&!t[t.length-1].equals(t[0])&&t.push(t[0]),t}copy(e){super.copy(e),this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){let n=e.curves[t];this.curves.push(n.clone())}return this.autoClose=e.autoClose,this}toJSON(){let e=super.toJSON();e.autoClose=this.autoClose,e.curves=[];for(let t=0,i=this.curves.length;t<i;t++){let n=this.curves[t];e.curves.push(n.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.autoClose=e.autoClose,this.curves=[];for(let t=0,i=e.curves.length;t<i;t++){let n=e.curves[t];this.curves.push(new Ca[n.type]().fromJSON(n))}return this}},Ys=class extends dc{constructor(e){super(),this.type="Path",this.currentPoint=new oe,e&&this.setFromPoints(e)}setFromPoints(e){this.moveTo(e[0].x,e[0].y);for(let t=1,i=e.length;t<i;t++)this.lineTo(e[t].x,e[t].y);return this}moveTo(e,t){return this.currentPoint.set(e,t),this}lineTo(e,t){let i=new Ea(this.currentPoint.clone(),new oe(e,t));return this.curves.push(i),this.currentPoint.set(e,t),this}quadraticCurveTo(e,t,i,n){let r=new Ta(this.currentPoint.clone(),new oe(e,t),new oe(i,n));return this.curves.push(r),this.currentPoint.set(i,n),this}bezierCurveTo(e,t,i,n,r,a){let o=new wa(this.currentPoint.clone(),new oe(e,t),new oe(i,n),new oe(r,a));return this.curves.push(o),this.currentPoint.set(r,a),this}splineThru(e){let t=[this.currentPoint.clone()].concat(e),i=new Ra(t);return this.curves.push(i),this.currentPoint.copy(e[e.length-1]),this}arc(e,t,i,n,r,a){let o=this.currentPoint.x,l=this.currentPoint.y;return this.absarc(e+o,t+l,i,n,r,a),this}absarc(e,t,i,n,r,a){return this.absellipse(e,t,i,i,n,r,a),this}ellipse(e,t,i,n,r,a,o,l){let c=this.currentPoint.x,h=this.currentPoint.y;return this.absellipse(e+c,t+h,i,n,r,a,o,l),this}absellipse(e,t,i,n,r,a,o,l){let c=new js(e,t,i,n,r,a,o,l);if(this.curves.length>0){let d=c.getPoint(0);d.equals(this.currentPoint)||this.lineTo(d.x,d.y)}this.curves.push(c);let h=c.getPoint(1);return this.currentPoint.copy(h),this}copy(e){return super.copy(e),this.currentPoint.copy(e.currentPoint),this}toJSON(){let e=super.toJSON();return e.currentPoint=this.currentPoint.toArray(),e}fromJSON(e){return super.fromJSON(e),this.currentPoint.fromArray(e.currentPoint),this}},La=class s extends Ve{constructor(e=[new oe(0,-.5),new oe(.5,0),new oe(0,.5)],t=12,i=0,n=2*Math.PI){super(),this.type="LatheGeometry",this.parameters={points:e,segments:t,phiStart:i,phiLength:n},t=Math.floor(t),n=_t(n,0,2*Math.PI);let r=[],a=[],o=[],l=[],c=[],h=1/t,d=new M,u=new oe,p=new M,m=new M,v=new M,f=0,g=0;for(let y=0;y<=e.length-1;y++)switch(y){case 0:f=e[y+1].x-e[y].x,g=e[y+1].y-e[y].y,p.x=1*g,p.y=-f,p.z=0*g,v.copy(p),p.normalize(),l.push(p.x,p.y,p.z);break;case e.length-1:l.push(v.x,v.y,v.z);break;default:f=e[y+1].x-e[y].x,g=e[y+1].y-e[y].y,p.x=1*g,p.y=-f,p.z=0*g,m.copy(p),p.x+=v.x,p.y+=v.y,p.z+=v.z,p.normalize(),l.push(p.x,p.y,p.z),v.copy(m)}for(let y=0;y<=t;y++){let x=i+y*h*n,_=Math.sin(x),b=Math.cos(x);for(let S=0;S<=e.length-1;S++){d.x=e[S].x*_,d.y=e[S].y,d.z=e[S].x*b,a.push(d.x,d.y,d.z),u.x=y/t,u.y=S/(e.length-1),o.push(u.x,u.y);let R=l[3*S+0]*_,P=l[3*S+1],C=l[3*S+0]*b;c.push(R,P,C)}}for(let y=0;y<t;y++)for(let x=0;x<e.length-1;x++){let _=x+y*e.length,b=_,S=_+e.length,R=_+e.length+1,P=_+1;r.push(b,S,P),r.push(R,P,S)}this.setIndex(r),this.setAttribute("position",new Te(a,3)),this.setAttribute("uv",new Te(o,2)),this.setAttribute("normal",new Te(c,3))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new s(e.points,e.segments,e.phiStart,e.phiLength)}},ns=class s extends La{constructor(e=1,t=1,i=4,n=8){let r=new Ys;r.absarc(0,-t/2,e,1.5*Math.PI,0),r.absarc(0,t/2,e,0,.5*Math.PI),super(r.getPoints(i),n),this.type="CapsuleGeometry",this.parameters={radius:e,length:t,capSegments:i,radialSegments:n}}static fromJSON(e){return new s(e.radius,e.length,e.capSegments,e.radialSegments)}},$s=class s extends Ve{constructor(e=1,t=32,i=0,n=2*Math.PI){super(),this.type="CircleGeometry",this.parameters={radius:e,segments:t,thetaStart:i,thetaLength:n},t=Math.max(3,t);let r=[],a=[],o=[],l=[],c=new M,h=new oe;a.push(0,0,0),o.push(0,0,1),l.push(.5,.5);for(let d=0,u=3;d<=t;d++,u+=3){let p=i+d/t*n;c.x=e*Math.cos(p),c.y=e*Math.sin(p),a.push(c.x,c.y,c.z),o.push(0,0,1),h.x=(a[u]/e+1)/2,h.y=(a[u+1]/e+1)/2,l.push(h.x,h.y)}for(let d=1;d<=t;d++)r.push(d,d+1,0);this.setIndex(r),this.setAttribute("position",new Te(a,3)),this.setAttribute("normal",new Te(o,3)),this.setAttribute("uv",new Te(l,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new s(e.radius,e.segments,e.thetaStart,e.thetaLength)}},li=class s extends Ve{constructor(e=1,t=1,i=1,n=32,r=1,a=!1,o=0,l=2*Math.PI){super(),this.type="CylinderGeometry",this.parameters={radiusTop:e,radiusBottom:t,height:i,radialSegments:n,heightSegments:r,openEnded:a,thetaStart:o,thetaLength:l};let c=this;n=Math.floor(n),r=Math.floor(r);let h=[],d=[],u=[],p=[],m=0,v=[],f=i/2,g=0;function y(x){let _=m,b=new oe,S=new M,R=0,P=x===!0?e:t,C=x===!0?1:-1;for(let z=1;z<=n;z++)d.push(0,f*C,0),u.push(0,C,0),p.push(.5,.5),m++;let B=m;for(let z=0;z<=n;z++){let D=z/n*l+o,F=Math.cos(D),U=Math.sin(D);S.x=P*U,S.y=f*C,S.z=P*F,d.push(S.x,S.y,S.z),u.push(0,C,0),b.x=.5*F+.5,b.y=.5*U*C+.5,p.push(b.x,b.y),m++}for(let z=0;z<n;z++){let D=_+z,F=B+z;x===!0?h.push(F,F+1,D):h.push(F+1,F,D),R+=3}c.addGroup(g,R,x===!0?1:2),g+=R}(function(){let x=new M,_=new M,b=0,S=(t-e)/i;for(let R=0;R<=r;R++){let P=[],C=R/r,B=C*(t-e)+e;for(let z=0;z<=n;z++){let D=z/n,F=D*l+o,U=Math.sin(F),X=Math.cos(F);_.x=B*U,_.y=-C*i+f,_.z=B*X,d.push(_.x,_.y,_.z),x.set(U,S,X).normalize(),u.push(x.x,x.y,x.z),p.push(D,1-C),P.push(m++)}v.push(P)}for(let R=0;R<n;R++)for(let P=0;P<r;P++){let C=v[P][R],B=v[P+1][R],z=v[P+1][R+1],D=v[P][R+1];(e>0||P!==0)&&(h.push(C,B,D),b+=3),(t>0||P!==r-1)&&(h.push(B,z,D),b+=3)}c.addGroup(g,b,0),g+=b})(),a===!1&&(e>0&&y(!0),t>0&&y(!1)),this.setIndex(h),this.setAttribute("position",new Te(d,3)),this.setAttribute("normal",new Te(u,3)),this.setAttribute("uv",new Te(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new s(e.radiusTop,e.radiusBottom,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}},Xi=class s extends li{constructor(e=1,t=1,i=32,n=1,r=!1,a=0,o=2*Math.PI){super(0,e,t,i,n,r,a,o),this.type="ConeGeometry",this.parameters={radius:e,height:t,radialSegments:i,heightSegments:n,openEnded:r,thetaStart:a,thetaLength:o}}static fromJSON(e){return new s(e.radius,e.height,e.radialSegments,e.heightSegments,e.openEnded,e.thetaStart,e.thetaLength)}},mn=class s extends Ve{constructor(e=[],t=[],i=1,n=0){super(),this.type="PolyhedronGeometry",this.parameters={vertices:e,indices:t,radius:i,detail:n};let r=[],a=[];function o(u,p,m,v){let f=v+1,g=[];for(let y=0;y<=f;y++){g[y]=[];let x=u.clone().lerp(m,y/f),_=p.clone().lerp(m,y/f),b=f-y;for(let S=0;S<=b;S++)g[y][S]=S===0&&y===f?x:x.clone().lerp(_,S/b)}for(let y=0;y<f;y++)for(let x=0;x<2*(f-y)-1;x++){let _=Math.floor(x/2);x%2==0?(l(g[y][_+1]),l(g[y+1][_]),l(g[y][_])):(l(g[y][_+1]),l(g[y+1][_+1]),l(g[y+1][_]))}}function l(u){r.push(u.x,u.y,u.z)}function c(u,p){let m=3*u;p.x=e[m+0],p.y=e[m+1],p.z=e[m+2]}function h(u,p,m,v){v<0&&u.x===1&&(a[p]=u.x-1),m.x===0&&m.z===0&&(a[p]=v/2/Math.PI+.5)}function d(u){return Math.atan2(u.z,-u.x)}(function(u){let p=new M,m=new M,v=new M;for(let f=0;f<t.length;f+=3)c(t[f+0],p),c(t[f+1],m),c(t[f+2],v),o(p,m,v,u)})(n),function(u){let p=new M;for(let m=0;m<r.length;m+=3)p.x=r[m+0],p.y=r[m+1],p.z=r[m+2],p.normalize().multiplyScalar(u),r[m+0]=p.x,r[m+1]=p.y,r[m+2]=p.z}(i),function(){let u=new M;for(let m=0;m<r.length;m+=3){u.x=r[m+0],u.y=r[m+1],u.z=r[m+2];let v=d(u)/2/Math.PI+.5,f=(p=u,Math.atan2(-p.y,Math.sqrt(p.x*p.x+p.z*p.z))/Math.PI+.5);a.push(v,1-f)}var p;(function(){let m=new M,v=new M,f=new M,g=new M,y=new oe,x=new oe,_=new oe;for(let b=0,S=0;b<r.length;b+=9,S+=6){m.set(r[b+0],r[b+1],r[b+2]),v.set(r[b+3],r[b+4],r[b+5]),f.set(r[b+6],r[b+7],r[b+8]),y.set(a[S+0],a[S+1]),x.set(a[S+2],a[S+3]),_.set(a[S+4],a[S+5]),g.copy(m).add(v).add(f).divideScalar(3);let R=d(g);h(y,S+0,m,R),h(x,S+2,v,R),h(_,S+4,f,R)}})(),function(){for(let m=0;m<a.length;m+=6){let v=a[m+0],f=a[m+2],g=a[m+4],y=Math.max(v,f,g),x=Math.min(v,f,g);y>.9&&x<.1&&(v<.2&&(a[m+0]+=1),f<.2&&(a[m+2]+=1),g<.2&&(a[m+4]+=1))}}()}(),this.setAttribute("position",new Te(r,3)),this.setAttribute("normal",new Te(r.slice(),3)),this.setAttribute("uv",new Te(a,2)),n===0?this.computeVertexNormals():this.normalizeNormals()}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new s(e.vertices,e.indices,e.radius,e.details)}},Zs=class s extends mn{constructor(e=1,t=0){let i=(1+Math.sqrt(5))/2,n=1/i;super([-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-n,-i,0,-n,i,0,n,-i,0,n,i,-n,-i,0,-n,i,0,n,-i,0,n,i,0,-i,0,-n,i,0,-n,-i,0,n,i,0,n],[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9],e,t),this.type="DodecahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new s(e.radius,e.detail)}},Zr=new M,Jr=new M,nl=new M,Kr=new Ei,pc=class extends Ve{constructor(e=null,t=1){if(super(),this.type="EdgesGeometry",this.parameters={geometry:e,thresholdAngle:t},e!==null){let n=Math.pow(10,4),r=Math.cos(Vn*t),a=e.getIndex(),o=e.getAttribute("position"),l=a?a.count:o.count,c=[0,0,0],h=["a","b","c"],d=new Array(3),u={},p=[];for(let m=0;m<l;m+=3){a?(c[0]=a.getX(m),c[1]=a.getX(m+1),c[2]=a.getX(m+2)):(c[0]=m,c[1]=m+1,c[2]=m+2);let{a:v,b:f,c:g}=Kr;if(v.fromBufferAttribute(o,c[0]),f.fromBufferAttribute(o,c[1]),g.fromBufferAttribute(o,c[2]),Kr.getNormal(nl),d[0]=`${Math.round(v.x*n)},${Math.round(v.y*n)},${Math.round(v.z*n)}`,d[1]=`${Math.round(f.x*n)},${Math.round(f.y*n)},${Math.round(f.z*n)}`,d[2]=`${Math.round(g.x*n)},${Math.round(g.y*n)},${Math.round(g.z*n)}`,d[0]!==d[1]&&d[1]!==d[2]&&d[2]!==d[0])for(let y=0;y<3;y++){let x=(y+1)%3,_=d[y],b=d[x],S=Kr[h[y]],R=Kr[h[x]],P=`${_}_${b}`,C=`${b}_${_}`;C in u&&u[C]?(nl.dot(u[C].normal)<=r&&(p.push(S.x,S.y,S.z),p.push(R.x,R.y,R.z)),u[C]=null):P in u||(u[P]={index0:c[y],index1:c[x],normal:nl.clone()})}}for(let m in u)if(u[m]){let{index0:v,index1:f}=u[m];Zr.fromBufferAttribute(o,v),Jr.fromBufferAttribute(o,f),p.push(Zr.x,Zr.y,Zr.z),p.push(Jr.x,Jr.y,Jr.z)}this.setAttribute("position",new Te(p,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}},Pa=class extends Ys{constructor(e){super(e),this.uuid=fi(),this.type="Shape",this.holes=[]}getPointsHoles(e){let t=[];for(let i=0,n=this.holes.length;i<n;i++)t[i]=this.holes[i].getPoints(e);return t}extractPoints(e){return{shape:this.getPoints(e),holes:this.getPointsHoles(e)}}copy(e){super.copy(e),this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){let n=e.holes[t];this.holes.push(n.clone())}return this}toJSON(){let e=super.toJSON();e.uuid=this.uuid,e.holes=[];for(let t=0,i=this.holes.length;t<i;t++){let n=this.holes[t];e.holes.push(n.toJSON())}return e}fromJSON(e){super.fromJSON(e),this.uuid=e.uuid,this.holes=[];for(let t=0,i=e.holes.length;t<i;t++){let n=e.holes[t];this.holes.push(new Ys().fromJSON(n))}return this}},Gm=function(s,e,t=2){let i=e&&e.length,n=i?e[0]*t:s.length,r=Cu(s,0,n,t,!0),a=[];if(!r||r.next===r.prev)return a;let o,l,c,h,d,u,p;if(i&&(r=function(m,v,f,g){let y=[],x,_,b,S,R;for(x=0,_=v.length;x<_;x++)b=v[x]*g,S=x<_-1?v[x+1]*g:m.length,R=Cu(m,b,S,g,!1),R===R.next&&(R.steiner=!0),y.push(Jm(R));for(y.sort(Ym),x=0;x<y.length;x++)f=$m(y[x],f);return f}(s,e,r,t)),s.length>80*t){o=c=s[0],l=h=s[1];for(let m=t;m<n;m+=t)d=s[m],u=s[m+1],d<o&&(o=d),u<l&&(l=u),d>c&&(c=d),u>h&&(h=u);p=Math.max(c-o,h-l),p=p!==0?32767/p:0}return Js(r,a,t,o,l,p,0),a};function Cu(s,e,t,i,n){let r,a;if(n===function(o,l,c,h){let d=0;for(let u=l,p=c-h;u<c;u+=h)d+=(o[p]-o[u])*(o[u+1]+o[p+1]),p=u;return d}(s,e,t,i)>0)for(r=e;r<t;r+=i)a=Lu(r,s[r],s[r+1],a);else for(r=t-i;r>=e;r-=i)a=Lu(r,s[r],s[r+1],a);return a&&Ba(a,a.next)&&(Qs(a),a=a.next),a}function fn(s,e){if(!s)return s;e||(e=s);let t,i=s;do if(t=!1,i.steiner||!Ba(i,i.next)&&ut(i.prev,i,i.next)!==0)i=i.next;else{if(Qs(i),i=e=i.prev,i===i.next)break;t=!0}while(t||i!==e);return e}function Js(s,e,t,i,n,r,a){if(!s)return;!a&&r&&function(h,d,u,p){let m=h;do m.z===0&&(m.z=mc(m.x,m.y,d,u,p)),m.prevZ=m.prev,m.nextZ=m.next,m=m.next;while(m!==h);m.prevZ.nextZ=null,m.prevZ=null,function(v){let f,g,y,x,_,b,S,R,P=1;do{for(g=v,v=null,_=null,b=0;g;){for(b++,y=g,S=0,f=0;f<P&&(S++,y=y.nextZ,y);f++);for(R=P;S>0||R>0&&y;)S!==0&&(R===0||!y||g.z<=y.z)?(x=g,g=g.nextZ,S--):(x=y,y=y.nextZ,R--),_?_.nextZ=x:v=x,x.prevZ=_,_=x;g=y}_.nextZ=null,P*=2}while(b>1)}(m)}(s,i,n,r);let o,l,c=s;for(;s.prev!==s.next;)if(o=s.prev,l=s.next,r?Xm(s,i,n,r):Wm(s))e.push(o.i/t|0),e.push(s.i/t|0),e.push(l.i/t|0),Qs(s),s=l.next,c=l.next;else if((s=l)===c){a?a===1?Js(s=qm(fn(s),e,t),e,t,i,n,r,2):a===2&&jm(s,e,t,i,n,r):Js(fn(s),e,t,i,n,r,1);break}}function Wm(s){let e=s.prev,t=s,i=s.next;if(ut(e,t,i)>=0)return!1;let n=e.x,r=t.x,a=i.x,o=e.y,l=t.y,c=i.y,h=n<r?n<a?n:a:r<a?r:a,d=o<l?o<c?o:c:l<c?l:c,u=n>r?n>a?n:a:r>a?r:a,p=o>l?o>c?o:c:l>c?l:c,m=i.next;for(;m!==e;){if(m.x>=h&&m.x<=u&&m.y>=d&&m.y<=p&&Hn(n,o,r,l,a,c,m.x,m.y)&&ut(m.prev,m,m.next)>=0)return!1;m=m.next}return!0}function Xm(s,e,t,i){let n=s.prev,r=s,a=s.next;if(ut(n,r,a)>=0)return!1;let o=n.x,l=r.x,c=a.x,h=n.y,d=r.y,u=a.y,p=o<l?o<c?o:c:l<c?l:c,m=h<d?h<u?h:u:d<u?d:u,v=o>l?o>c?o:c:l>c?l:c,f=h>d?h>u?h:u:d>u?d:u,g=mc(p,m,e,t,i),y=mc(v,f,e,t,i),x=s.prevZ,_=s.nextZ;for(;x&&x.z>=g&&_&&_.z<=y;){if(x.x>=p&&x.x<=v&&x.y>=m&&x.y<=f&&x!==n&&x!==a&&Hn(o,h,l,d,c,u,x.x,x.y)&&ut(x.prev,x,x.next)>=0||(x=x.prevZ,_.x>=p&&_.x<=v&&_.y>=m&&_.y<=f&&_!==n&&_!==a&&Hn(o,h,l,d,c,u,_.x,_.y)&&ut(_.prev,_,_.next)>=0))return!1;_=_.nextZ}for(;x&&x.z>=g;){if(x.x>=p&&x.x<=v&&x.y>=m&&x.y<=f&&x!==n&&x!==a&&Hn(o,h,l,d,c,u,x.x,x.y)&&ut(x.prev,x,x.next)>=0)return!1;x=x.prevZ}for(;_&&_.z<=y;){if(_.x>=p&&_.x<=v&&_.y>=m&&_.y<=f&&_!==n&&_!==a&&Hn(o,h,l,d,c,u,_.x,_.y)&&ut(_.prev,_,_.next)>=0)return!1;_=_.nextZ}return!0}function qm(s,e,t){let i=s;do{let n=i.prev,r=i.next.next;!Ba(n,r)&&nd(n,i,i.next,r)&&Ks(n,r)&&Ks(r,n)&&(e.push(n.i/t|0),e.push(i.i/t|0),e.push(r.i/t|0),Qs(i),Qs(i.next),i=s=r),i=i.next}while(i!==s);return fn(i)}function jm(s,e,t,i,n,r){let a=s;do{let o=a.next.next;for(;o!==a.prev;){if(a.i!==o.i&&Km(a,o)){let l=sd(a,o);return a=fn(a,a.next),l=fn(l,l.next),Js(a,e,t,i,n,r,0),void Js(l,e,t,i,n,r,0)}o=o.next}a=a.next}while(a!==s)}function Ym(s,e){return s.x-e.x}function $m(s,e){let t=function(n,r){let a,o=r,l=-1/0,c=n.x,h=n.y;do{if(h<=o.y&&h>=o.next.y&&o.next.y!==o.y){let f=o.x+(h-o.y)*(o.next.x-o.x)/(o.next.y-o.y);if(f<=c&&f>l&&(l=f,a=o.x<o.next.x?o:o.next,f===c))return a}o=o.next}while(o!==r);if(!a)return null;let d=a,u=a.x,p=a.y,m,v=1/0;o=a;do c>=o.x&&o.x>=u&&c!==o.x&&Hn(h<p?c:l,h,u,p,h<p?l:c,h,o.x,o.y)&&(m=Math.abs(h-o.y)/(c-o.x),Ks(o,n)&&(m<v||m===v&&(o.x>a.x||o.x===a.x&&Zm(a,o)))&&(a=o,v=m)),o=o.next;while(o!==d);return a}(s,e);if(!t)return e;let i=sd(t,s);return fn(i,i.next),fn(t,t.next)}function Zm(s,e){return ut(s.prev,s,e.prev)<0&&ut(e.next,s,s.next)<0}function mc(s,e,t,i,n){return(s=1431655765&((s=858993459&((s=252645135&((s=16711935&((s=(s-t)*n|0)|s<<8))|s<<4))|s<<2))|s<<1))|(e=1431655765&((e=858993459&((e=252645135&((e=16711935&((e=(e-i)*n|0)|e<<8))|e<<4))|e<<2))|e<<1))<<1}function Jm(s){let e=s,t=s;do(e.x<t.x||e.x===t.x&&e.y<t.y)&&(t=e),e=e.next;while(e!==s);return t}function Hn(s,e,t,i,n,r,a,o){return(n-a)*(e-o)>=(s-a)*(r-o)&&(s-a)*(i-o)>=(t-a)*(e-o)&&(t-a)*(r-o)>=(n-a)*(i-o)}function Km(s,e){return s.next.i!==e.i&&s.prev.i!==e.i&&!function(t,i){let n=t;do{if(n.i!==t.i&&n.next.i!==t.i&&n.i!==i.i&&n.next.i!==i.i&&nd(n,n.next,t,i))return!0;n=n.next}while(n!==t);return!1}(s,e)&&(Ks(s,e)&&Ks(e,s)&&function(t,i){let n=t,r=!1,a=(t.x+i.x)/2,o=(t.y+i.y)/2;do n.y>o!=n.next.y>o&&n.next.y!==n.y&&a<(n.next.x-n.x)*(o-n.y)/(n.next.y-n.y)+n.x&&(r=!r),n=n.next;while(n!==t);return r}(s,e)&&(ut(s.prev,s,e.prev)||ut(s,e.prev,e))||Ba(s,e)&&ut(s.prev,s,s.next)>0&&ut(e.prev,e,e.next)>0)}function ut(s,e,t){return(e.y-s.y)*(t.x-e.x)-(e.x-s.x)*(t.y-e.y)}function Ba(s,e){return s.x===e.x&&s.y===e.y}function nd(s,e,t,i){let n=ea(ut(s,e,t)),r=ea(ut(s,e,i)),a=ea(ut(t,i,s)),o=ea(ut(t,i,e));return n!==r&&a!==o||!(n!==0||!Qr(s,t,e))||!(r!==0||!Qr(s,i,e))||!(a!==0||!Qr(t,s,i))||!(o!==0||!Qr(t,e,i))}function Qr(s,e,t){return e.x<=Math.max(s.x,t.x)&&e.x>=Math.min(s.x,t.x)&&e.y<=Math.max(s.y,t.y)&&e.y>=Math.min(s.y,t.y)}function ea(s){return s>0?1:s<0?-1:0}function Ks(s,e){return ut(s.prev,s,s.next)<0?ut(s,e,s.next)>=0&&ut(s,s.prev,e)>=0:ut(s,e,s.prev)<0||ut(s,s.next,e)<0}function sd(s,e){let t=new fc(s.i,s.x,s.y),i=new fc(e.i,e.x,e.y),n=s.next,r=e.prev;return s.next=e,e.prev=s,t.next=n,n.prev=t,i.next=t,t.prev=i,r.next=i,i.prev=r,i}function Lu(s,e,t,i){let n=new fc(s,e,t);return i?(n.next=i.next,n.prev=i,i.next.prev=n,i.next=n):(n.prev=n,n.next=n),n}function Qs(s){s.next.prev=s.prev,s.prev.next=s.next,s.prevZ&&(s.prevZ.nextZ=s.nextZ),s.nextZ&&(s.nextZ.prevZ=s.prevZ)}function fc(s,e,t){this.i=s,this.x=e,this.y=t,this.prev=null,this.next=null,this.z=0,this.prevZ=null,this.nextZ=null,this.steiner=!1}var Hi=class s{static area(e){let t=e.length,i=0;for(let n=t-1,r=0;r<t;n=r++)i+=e[n].x*e[r].y-e[r].x*e[n].y;return .5*i}static isClockWise(e){return s.area(e)<0}static triangulateShape(e,t){let i=[],n=[],r=[];Pu(e),Iu(i,e);let a=e.length;t.forEach(Pu);for(let l=0;l<t.length;l++)n.push(a),a+=t[l].length,Iu(i,t[l]);let o=Gm(i,n);for(let l=0;l<o.length;l+=3)r.push(o.slice(l,l+3));return r}};function Pu(s){let e=s.length;e>2&&s[e-1].equals(s[0])&&s.pop()}function Iu(s,e){for(let t=0;t<e.length;t++)s.push(e[t].x),s.push(e[t].y)}var gc=class s extends Ve{constructor(e=new Pa([new oe(.5,.5),new oe(-.5,.5),new oe(-.5,-.5),new oe(.5,-.5)]),t={}){super(),this.type="ExtrudeGeometry",this.parameters={shapes:e,options:t},e=Array.isArray(e)?e:[e];let i=this,n=[],r=[];for(let o=0,l=e.length;o<l;o++)a(e[o]);function a(o){let l=[],c=t.curveSegments!==void 0?t.curveSegments:12,h=t.steps!==void 0?t.steps:1,d=t.depth!==void 0?t.depth:1,u=t.bevelEnabled===void 0||t.bevelEnabled,p=t.bevelThickness!==void 0?t.bevelThickness:.2,m=t.bevelSize!==void 0?t.bevelSize:p-.1,v=t.bevelOffset!==void 0?t.bevelOffset:0,f=t.bevelSegments!==void 0?t.bevelSegments:3,g=t.extrudePath,y=t.UVGenerator!==void 0?t.UVGenerator:Qm,x,_,b,S,R,P=!1;g&&(x=g.getSpacedPoints(h),P=!0,u=!1,_=g.computeFrenetFrames(h,!1),b=new M,S=new M,R=new M),u||(f=0,p=0,m=0,v=0);let C=o.extractPoints(c),B=C.shape,z=C.holes;if(!Hi.isClockWise(B)){B=B.reverse();for(let O=0,L=z.length;O<L;O++){let N=z[O];Hi.isClockWise(N)&&(z[O]=N.reverse())}}let D=Hi.triangulateShape(B,z),F=B;for(let O=0,L=z.length;O<L;O++){let N=z[O];B=B.concat(N)}function U(O,L,N){return L||console.error("THREE.ExtrudeGeometry: vec does not exist"),O.clone().addScaledVector(L,N)}let X=B.length,j=D.length;function Z(O,L,N){let w,I,V,te=O.x-L.x,H=O.y-L.y,Q=N.x-O.x,J=N.y-O.y,ne=te*te+H*H,ve=te*J-H*Q;if(Math.abs(ve)>Number.EPSILON){let me=Math.sqrt(ne),Se=Math.sqrt(Q*Q+J*J),Le=L.x-H/me,Xe=L.y+te/me,ze=((N.x-J/Se-Le)*J-(N.y+Q/Se-Xe)*Q)/(te*J-H*Q);w=Le+te*ze-O.x,I=Xe+H*ze-O.y;let we=w*w+I*I;if(we<=2)return new oe(w,I);V=Math.sqrt(we/2)}else{let me=!1;te>Number.EPSILON?Q>Number.EPSILON&&(me=!0):te<-Number.EPSILON?Q<-Number.EPSILON&&(me=!0):Math.sign(H)===Math.sign(J)&&(me=!0),me?(w=-H,I=te,V=Math.sqrt(ne)):(w=te,I=H,V=Math.sqrt(ne/2))}return new oe(w/V,I/V)}let $=[];for(let O=0,L=F.length,N=L-1,w=O+1;O<L;O++,N++,w++)N===L&&(N=0),w===L&&(w=0),$[O]=Z(F[O],F[N],F[w]);let ue=[],_e,K=$.concat();for(let O=0,L=z.length;O<L;O++){let N=z[O];_e=[];for(let w=0,I=N.length,V=I-1,te=w+1;w<I;w++,V++,te++)V===I&&(V=0),te===I&&(te=0),_e[w]=Z(N[w],N[V],N[te]);ue.push(_e),K=K.concat(_e)}for(let O=0;O<f;O++){let L=O/f,N=p*Math.cos(L*Math.PI/2),w=m*Math.sin(L*Math.PI/2)+v;for(let I=0,V=F.length;I<V;I++){let te=U(F[I],$[I],w);ge(te.x,te.y,-N)}for(let I=0,V=z.length;I<V;I++){let te=z[I];_e=ue[I];for(let H=0,Q=te.length;H<Q;H++){let J=U(te[H],_e[H],w);ge(J.x,J.y,-N)}}}let ae=m+v;for(let O=0;O<X;O++){let L=u?U(B[O],K[O],ae):B[O];P?(S.copy(_.normals[0]).multiplyScalar(L.x),b.copy(_.binormals[0]).multiplyScalar(L.y),R.copy(x[0]).add(S).add(b),ge(R.x,R.y,R.z)):ge(L.x,L.y,0)}for(let O=1;O<=h;O++)for(let L=0;L<X;L++){let N=u?U(B[L],K[L],ae):B[L];P?(S.copy(_.normals[O]).multiplyScalar(N.x),b.copy(_.binormals[O]).multiplyScalar(N.y),R.copy(x[O]).add(S).add(b),ge(R.x,R.y,R.z)):ge(N.x,N.y,d/h*O)}for(let O=f-1;O>=0;O--){let L=O/f,N=p*Math.cos(L*Math.PI/2),w=m*Math.sin(L*Math.PI/2)+v;for(let I=0,V=F.length;I<V;I++){let te=U(F[I],$[I],w);ge(te.x,te.y,d+N)}for(let I=0,V=z.length;I<V;I++){let te=z[I];_e=ue[I];for(let H=0,Q=te.length;H<Q;H++){let J=U(te[H],_e[H],w);P?ge(J.x,J.y+x[h-1].y,x[h-1].x+N):ge(J.x,J.y,d+N)}}}function pe(O,L){let N=O.length;for(;--N>=0;){let w=N,I=N-1;I<0&&(I=O.length-1);for(let V=0,te=h+2*f;V<te;V++){let H=X*V,Q=X*(V+1);A(L+w+H,L+I+H,L+I+Q,L+w+Q)}}}function ge(O,L,N){l.push(O),l.push(L),l.push(N)}function ce(O,L,N){T(O),T(L),T(N);let w=n.length/3,I=y.generateTopUV(i,n,w-3,w-2,w-1);k(I[0]),k(I[1]),k(I[2])}function A(O,L,N,w){T(O),T(L),T(w),T(L),T(N),T(w);let I=n.length/3,V=y.generateSideWallUV(i,n,I-6,I-3,I-2,I-1);k(V[0]),k(V[1]),k(V[3]),k(V[1]),k(V[2]),k(V[3])}function T(O){n.push(l[3*O+0]),n.push(l[3*O+1]),n.push(l[3*O+2])}function k(O){r.push(O.x),r.push(O.y)}(function(){let O=n.length/3;if(u){let L=0,N=X*L;for(let w=0;w<j;w++){let I=D[w];ce(I[2]+N,I[1]+N,I[0]+N)}L=h+2*f,N=X*L;for(let w=0;w<j;w++){let I=D[w];ce(I[0]+N,I[1]+N,I[2]+N)}}else{for(let L=0;L<j;L++){let N=D[L];ce(N[2],N[1],N[0])}for(let L=0;L<j;L++){let N=D[L];ce(N[0]+X*h,N[1]+X*h,N[2]+X*h)}}i.addGroup(O,n.length/3-O,0)})(),function(){let O=n.length/3,L=0;pe(F,L),L+=F.length;for(let N=0,w=z.length;N<w;N++){let I=z[N];pe(I,L),L+=I.length}i.addGroup(O,n.length/3-O,1)}()}this.setAttribute("position",new Te(n,3)),this.setAttribute("uv",new Te(r,2)),this.computeVertexNormals()}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){let e=super.toJSON();return function(t,i,n){if(n.shapes=[],Array.isArray(t))for(let r=0,a=t.length;r<a;r++){let o=t[r];n.shapes.push(o.uuid)}else n.shapes.push(t.uuid);return n.options=Object.assign({},i),i.extrudePath!==void 0&&(n.options.extrudePath=i.extrudePath.toJSON()),n}(this.parameters.shapes,this.parameters.options,e)}static fromJSON(e,t){let i=[];for(let r=0,a=e.shapes.length;r<a;r++){let o=t[e.shapes[r]];i.push(o)}let n=e.options.extrudePath;return n!==void 0&&(e.options.extrudePath=new Ca[n.type]().fromJSON(n)),new s(i,e.options)}},Qm={generateTopUV:function(s,e,t,i,n){let r=e[3*t],a=e[3*t+1],o=e[3*i],l=e[3*i+1],c=e[3*n],h=e[3*n+1];return[new oe(r,a),new oe(o,l),new oe(c,h)]},generateSideWallUV:function(s,e,t,i,n,r){let a=e[3*t],o=e[3*t+1],l=e[3*t+2],c=e[3*i],h=e[3*i+1],d=e[3*i+2],u=e[3*n],p=e[3*n+1],m=e[3*n+2],v=e[3*r],f=e[3*r+1],g=e[3*r+2];return Math.abs(o-h)<Math.abs(a-c)?[new oe(a,1-l),new oe(c,1-d),new oe(u,1-m),new oe(v,1-g)]:[new oe(o,1-l),new oe(h,1-d),new oe(p,1-m),new oe(f,1-g)]}},ss=class s extends mn{constructor(e=1,t=0){let i=(1+Math.sqrt(5))/2;super([-1,i,0,1,i,0,-1,-i,0,1,-i,0,0,-1,i,0,1,i,0,-1,-i,0,1,-i,i,0,-1,i,0,1,-i,0,-1,-i,0,1],[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1],e,t),this.type="IcosahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new s(e.radius,e.detail)}},vc=class s extends mn{constructor(e=1,t=0){super([1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2],e,t),this.type="OctahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new s(e.radius,e.detail)}},rs=class s extends Ve{constructor(e=.5,t=1,i=32,n=1,r=0,a=2*Math.PI){super(),this.type="RingGeometry",this.parameters={innerRadius:e,outerRadius:t,thetaSegments:i,phiSegments:n,thetaStart:r,thetaLength:a},i=Math.max(3,i);let o=[],l=[],c=[],h=[],d=e,u=(t-e)/(n=Math.max(1,n)),p=new M,m=new oe;for(let v=0;v<=n;v++){for(let f=0;f<=i;f++){let g=r+f/i*a;p.x=d*Math.cos(g),p.y=d*Math.sin(g),l.push(p.x,p.y,p.z),c.push(0,0,1),m.x=(p.x/t+1)/2,m.y=(p.y/t+1)/2,h.push(m.x,m.y)}d+=u}for(let v=0;v<n;v++){let f=v*(i+1);for(let g=0;g<i;g++){let y=g+f,x=y,_=y+i+1,b=y+i+2,S=y+1;o.push(x,_,S),o.push(_,b,S)}}this.setIndex(o),this.setAttribute("position",new Te(l,3)),this.setAttribute("normal",new Te(c,3)),this.setAttribute("uv",new Te(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new s(e.innerRadius,e.outerRadius,e.thetaSegments,e.phiSegments,e.thetaStart,e.thetaLength)}},yc=class s extends Ve{constructor(e=new Pa([new oe(0,.5),new oe(-.5,-.5),new oe(.5,-.5)]),t=12){super(),this.type="ShapeGeometry",this.parameters={shapes:e,curveSegments:t};let i=[],n=[],r=[],a=[],o=0,l=0;if(Array.isArray(e)===!1)c(e);else for(let h=0;h<e.length;h++)c(e[h]),this.addGroup(o,l,h),o+=l,l=0;function c(h){let d=n.length/3,u=h.extractPoints(t),p=u.shape,m=u.holes;Hi.isClockWise(p)===!1&&(p=p.reverse());for(let f=0,g=m.length;f<g;f++){let y=m[f];Hi.isClockWise(y)===!0&&(m[f]=y.reverse())}let v=Hi.triangulateShape(p,m);for(let f=0,g=m.length;f<g;f++){let y=m[f];p=p.concat(y)}for(let f=0,g=p.length;f<g;f++){let y=p[f];n.push(y.x,y.y,0),r.push(0,0,1),a.push(y.x,y.y)}for(let f=0,g=v.length;f<g;f++){let y=v[f],x=y[0]+d,_=y[1]+d,b=y[2]+d;i.push(x,_,b),l+=3}}this.setIndex(i),this.setAttribute("position",new Te(n,3)),this.setAttribute("normal",new Te(r,3)),this.setAttribute("uv",new Te(a,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){let e=super.toJSON();return function(t,i){if(i.shapes=[],Array.isArray(t))for(let n=0,r=t.length;n<r;n++){let a=t[n];i.shapes.push(a.uuid)}else i.shapes.push(t.uuid);return i}(this.parameters.shapes,e)}static fromJSON(e,t){let i=[];for(let n=0,r=e.shapes.length;n<r;n++){let a=t[e.shapes[n]];i.push(a)}return new s(i,e.curveSegments)}},Ri=class s extends Ve{constructor(e=1,t=32,i=16,n=0,r=2*Math.PI,a=0,o=Math.PI){super(),this.type="SphereGeometry",this.parameters={radius:e,widthSegments:t,heightSegments:i,phiStart:n,phiLength:r,thetaStart:a,thetaLength:o},t=Math.max(3,Math.floor(t)),i=Math.max(2,Math.floor(i));let l=Math.min(a+o,Math.PI),c=0,h=[],d=new M,u=new M,p=[],m=[],v=[],f=[];for(let g=0;g<=i;g++){let y=[],x=g/i,_=0;g===0&&a===0?_=.5/t:g===i&&l===Math.PI&&(_=-.5/t);for(let b=0;b<=t;b++){let S=b/t;d.x=-e*Math.cos(n+S*r)*Math.sin(a+x*o),d.y=e*Math.cos(a+x*o),d.z=e*Math.sin(n+S*r)*Math.sin(a+x*o),m.push(d.x,d.y,d.z),u.copy(d).normalize(),v.push(u.x,u.y,u.z),f.push(S+_,1-x),y.push(c++)}h.push(y)}for(let g=0;g<i;g++)for(let y=0;y<t;y++){let x=h[g][y+1],_=h[g][y],b=h[g+1][y],S=h[g+1][y+1];(g!==0||a>0)&&p.push(x,_,S),(g!==i-1||l<Math.PI)&&p.push(_,b,S)}this.setIndex(p),this.setAttribute("position",new Te(m,3)),this.setAttribute("normal",new Te(v,3)),this.setAttribute("uv",new Te(f,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new s(e.radius,e.widthSegments,e.heightSegments,e.phiStart,e.phiLength,e.thetaStart,e.thetaLength)}},xc=class s extends mn{constructor(e=1,t=0){super([1,1,1,-1,-1,1,-1,1,-1,1,-1,-1],[2,1,0,0,3,2,1,3,0,2,3,1],e,t),this.type="TetrahedronGeometry",this.parameters={radius:e,detail:t}}static fromJSON(e){return new s(e.radius,e.detail)}},gn=class s extends Ve{constructor(e=1,t=.4,i=12,n=48,r=2*Math.PI){super(),this.type="TorusGeometry",this.parameters={radius:e,tube:t,radialSegments:i,tubularSegments:n,arc:r},i=Math.floor(i),n=Math.floor(n);let a=[],o=[],l=[],c=[],h=new M,d=new M,u=new M;for(let p=0;p<=i;p++)for(let m=0;m<=n;m++){let v=m/n*r,f=p/i*Math.PI*2;d.x=(e+t*Math.cos(f))*Math.cos(v),d.y=(e+t*Math.cos(f))*Math.sin(v),d.z=t*Math.sin(f),o.push(d.x,d.y,d.z),h.x=e*Math.cos(v),h.y=e*Math.sin(v),u.subVectors(d,h).normalize(),l.push(u.x,u.y,u.z),c.push(m/n),c.push(p/i)}for(let p=1;p<=i;p++)for(let m=1;m<=n;m++){let v=(n+1)*p+m-1,f=(n+1)*(p-1)+m-1,g=(n+1)*(p-1)+m,y=(n+1)*p+m;a.push(v,f,y),a.push(f,g,y)}this.setIndex(a),this.setAttribute("position",new Te(o,3)),this.setAttribute("normal",new Te(l,3)),this.setAttribute("uv",new Te(c,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new s(e.radius,e.tube,e.radialSegments,e.tubularSegments,e.arc)}},_c=class s extends Ve{constructor(e=1,t=.4,i=64,n=8,r=2,a=3){super(),this.type="TorusKnotGeometry",this.parameters={radius:e,tube:t,tubularSegments:i,radialSegments:n,p:r,q:a},i=Math.floor(i),n=Math.floor(n);let o=[],l=[],c=[],h=[],d=new M,u=new M,p=new M,m=new M,v=new M,f=new M,g=new M;for(let x=0;x<=i;++x){let _=x/i*r*Math.PI*2;y(_,r,a,e,p),y(_+.01,r,a,e,m),f.subVectors(m,p),g.addVectors(m,p),v.crossVectors(f,g),g.crossVectors(v,f),v.normalize(),g.normalize();for(let b=0;b<=n;++b){let S=b/n*Math.PI*2,R=-t*Math.cos(S),P=t*Math.sin(S);d.x=p.x+(R*g.x+P*v.x),d.y=p.y+(R*g.y+P*v.y),d.z=p.z+(R*g.z+P*v.z),l.push(d.x,d.y,d.z),u.subVectors(d,p).normalize(),c.push(u.x,u.y,u.z),h.push(x/i),h.push(b/n)}}for(let x=1;x<=i;x++)for(let _=1;_<=n;_++){let b=(n+1)*(x-1)+(_-1),S=(n+1)*x+(_-1),R=(n+1)*x+_,P=(n+1)*(x-1)+_;o.push(b,S,P),o.push(S,R,P)}function y(x,_,b,S,R){let P=Math.cos(x),C=Math.sin(x),B=b/_*x,z=Math.cos(B);R.x=S*(2+z)*.5*P,R.y=S*(2+z)*C*.5,R.z=S*Math.sin(B)*.5}this.setIndex(o),this.setAttribute("position",new Te(l,3)),this.setAttribute("normal",new Te(c,3)),this.setAttribute("uv",new Te(h,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}static fromJSON(e){return new s(e.radius,e.tube,e.tubularSegments,e.radialSegments,e.p,e.q)}},Mc=class s extends Ve{constructor(e=new Aa(new M(-1,-1,0),new M(-1,1,0),new M(1,1,0)),t=64,i=1,n=8,r=!1){super(),this.type="TubeGeometry",this.parameters={path:e,tubularSegments:t,radius:i,radialSegments:n,closed:r};let a=e.computeFrenetFrames(t,r);this.tangents=a.tangents,this.normals=a.normals,this.binormals=a.binormals;let o=new M,l=new M,c=new oe,h=new M,d=[],u=[],p=[],m=[];function v(f){h=e.getPointAt(f/t,h);let g=a.normals[f],y=a.binormals[f];for(let x=0;x<=n;x++){let _=x/n*Math.PI*2,b=Math.sin(_),S=-Math.cos(_);l.x=S*g.x+b*y.x,l.y=S*g.y+b*y.y,l.z=S*g.z+b*y.z,l.normalize(),u.push(l.x,l.y,l.z),o.x=h.x+i*l.x,o.y=h.y+i*l.y,o.z=h.z+i*l.z,d.push(o.x,o.y,o.z)}}(function(){for(let f=0;f<t;f++)v(f);v(r===!1?t:0),function(){for(let f=0;f<=t;f++)for(let g=0;g<=n;g++)c.x=f/t,c.y=g/n,p.push(c.x,c.y)}(),function(){for(let f=1;f<=t;f++)for(let g=1;g<=n;g++){let y=(n+1)*(f-1)+(g-1),x=(n+1)*f+(g-1),_=(n+1)*f+g,b=(n+1)*(f-1)+g;m.push(y,x,b),m.push(x,_,b)}}()})(),this.setIndex(m),this.setAttribute("position",new Te(d,3)),this.setAttribute("normal",new Te(u,3)),this.setAttribute("uv",new Te(p,2))}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}toJSON(){let e=super.toJSON();return e.path=this.parameters.path.toJSON(),e}static fromJSON(e){return new s(new Ca[e.path.type]().fromJSON(e.path),e.tubularSegments,e.radius,e.radialSegments,e.closed)}},bc=class extends Ve{constructor(e=null){if(super(),this.type="WireframeGeometry",this.parameters={geometry:e},e!==null){let t=[],i=new Set,n=new M,r=new M;if(e.index!==null){let a=e.attributes.position,o=e.index,l=e.groups;l.length===0&&(l=[{start:0,count:o.count,materialIndex:0}]);for(let c=0,h=l.length;c<h;++c){let d=l[c],u=d.start;for(let p=u,m=u+d.count;p<m;p+=3)for(let v=0;v<3;v++){let f=o.getX(p+v),g=o.getX(p+(v+1)%3);n.fromBufferAttribute(a,f),r.fromBufferAttribute(a,g),Du(n,r,i)===!0&&(t.push(n.x,n.y,n.z),t.push(r.x,r.y,r.z))}}}else{let a=e.attributes.position;for(let o=0,l=a.count/3;o<l;o++)for(let c=0;c<3;c++){let h=3*o+c,d=3*o+(c+1)%3;n.fromBufferAttribute(a,h),r.fromBufferAttribute(a,d),Du(n,r,i)===!0&&(t.push(n.x,n.y,n.z),t.push(r.x,r.y,r.z))}}this.setAttribute("position",new Te(t,3))}}copy(e){return super.copy(e),this.parameters=Object.assign({},e.parameters),this}};function Du(s,e,t){let i=`${s.x},${s.y},${s.z}-${e.x},${e.y},${e.z}`,n=`${e.x},${e.y},${e.z}-${s.x},${s.y},${s.z}`;return t.has(i)!==!0&&t.has(n)!==!0&&(t.add(i),t.add(n),!0)}var og=Object.freeze({__proto__:null,BoxGeometry:Ct,CapsuleGeometry:ns,CircleGeometry:$s,ConeGeometry:Xi,CylinderGeometry:li,DodecahedronGeometry:Zs,EdgesGeometry:pc,ExtrudeGeometry:gc,IcosahedronGeometry:ss,LatheGeometry:La,OctahedronGeometry:vc,PlaneGeometry:Gt,PolyhedronGeometry:mn,RingGeometry:rs,ShapeGeometry:yc,SphereGeometry:Ri,TetrahedronGeometry:xc,TorusGeometry:gn,TorusKnotGeometry:_c,TubeGeometry:Mc,WireframeGeometry:bc});var it=class extends gi{static get type(){return"MeshStandardMaterial"}constructor(e){super(),this.isMeshStandardMaterial=!0,this.defines={STANDARD:""},this.color=new ye(16777215),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new ye(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new oe(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new Et,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(e)}copy(e){return super.copy(e),this.defines={STANDARD:""},this.color.copy(e.color),this.roughness=e.roughness,this.metalness=e.metalness,this.map=e.map,this.lightMap=e.lightMap,this.lightMapIntensity=e.lightMapIntensity,this.aoMap=e.aoMap,this.aoMapIntensity=e.aoMapIntensity,this.emissive.copy(e.emissive),this.emissiveMap=e.emissiveMap,this.emissiveIntensity=e.emissiveIntensity,this.bumpMap=e.bumpMap,this.bumpScale=e.bumpScale,this.normalMap=e.normalMap,this.normalMapType=e.normalMapType,this.normalScale.copy(e.normalScale),this.displacementMap=e.displacementMap,this.displacementScale=e.displacementScale,this.displacementBias=e.displacementBias,this.roughnessMap=e.roughnessMap,this.metalnessMap=e.metalnessMap,this.alphaMap=e.alphaMap,this.envMap=e.envMap,this.envMapRotation.copy(e.envMapRotation),this.envMapIntensity=e.envMapIntensity,this.wireframe=e.wireframe,this.wireframeLinewidth=e.wireframeLinewidth,this.wireframeLinecap=e.wireframeLinecap,this.wireframeLinejoin=e.wireframeLinejoin,this.flatShading=e.flatShading,this.fog=e.fog,this}};function ta(s,e,t){return!s||!t&&s.constructor===e?s:typeof e.BYTES_PER_ELEMENT=="number"?new e(s):Array.prototype.slice.call(s)}function ef(s){return ArrayBuffer.isView(s)&&!(s instanceof DataView)}var as=class{constructor(e,t,i,n){this.parameterPositions=e,this._cachedIndex=0,this.resultBuffer=n!==void 0?n:new t.constructor(i),this.sampleValues=t,this.valueSize=i,this.settings=null,this.DefaultSettings_={}}evaluate(e){let t=this.parameterPositions,i=this._cachedIndex,n=t[i],r=t[i-1];t:{e:{let a;i:{n:if(!(e<n)){for(let o=i+2;;){if(n===void 0){if(e<r)break n;return i=t.length,this._cachedIndex=i,this.copySampleValue_(i-1)}if(i===o)break;if(r=n,n=t[++i],e<n)break e}a=t.length;break i}if(e>=r)break t;{let o=t[1];e<o&&(i=2,r=o);for(let l=i-2;;){if(r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(i===l)break;if(n=r,r=t[--i-1],e>=r)break e}a=i,i=0}}for(;i<a;){let o=i+a>>>1;e<t[o]?a=o:i=o+1}if(n=t[i],r=t[i-1],r===void 0)return this._cachedIndex=0,this.copySampleValue_(0);if(n===void 0)return i=t.length,this._cachedIndex=i,this.copySampleValue_(i-1)}this._cachedIndex=i,this.intervalChanged_(i,r,n)}return this.interpolate_(i,r,e,n)}getSettings_(){return this.settings||this.DefaultSettings_}copySampleValue_(e){let t=this.resultBuffer,i=this.sampleValues,n=this.valueSize,r=e*n;for(let a=0;a!==n;++a)t[a]=i[r+a];return t}interpolate_(){throw new Error("call to abstract method")}intervalChanged_(){}},Sc=class extends as{constructor(e,t,i,n){super(e,t,i,n),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:Sh,endingEnd:Sh}}intervalChanged_(e,t,i){let n=this.parameterPositions,r=e-2,a=e+1,o=n[r],l=n[a];if(o===void 0)switch(this.getSettings_().endingStart){case wh:r=e,o=2*t-i;break;case Eh:r=n.length-2,o=t+n[r]-n[r+1];break;default:r=e,o=i}if(l===void 0)switch(this.getSettings_().endingEnd){case wh:a=e,l=2*i-t;break;case Eh:a=1,l=i+n[1]-n[0];break;default:a=e-1,l=t}let c=.5*(i-t),h=this.valueSize;this._weightPrev=c/(t-o),this._weightNext=c/(l-i),this._offsetPrev=r*h,this._offsetNext=a*h}interpolate_(e,t,i,n){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=e*o,c=l-o,h=this._offsetPrev,d=this._offsetNext,u=this._weightPrev,p=this._weightNext,m=(i-t)/(n-t),v=m*m,f=v*m,g=-u*f+2*u*v-u*m,y=(1+u)*f+(-1.5-2*u)*v+(-.5+u)*m+1,x=(-1-p)*f+(1.5+p)*v+.5*m,_=p*f-p*v;for(let b=0;b!==o;++b)r[b]=g*a[h+b]+y*a[c+b]+x*a[l+b]+_*a[d+b];return r}},wc=class extends as{constructor(e,t,i,n){super(e,t,i,n)}interpolate_(e,t,i,n){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=e*o,c=l-o,h=(i-t)/(n-t),d=1-h;for(let u=0;u!==o;++u)r[u]=a[c+u]*d+a[l+u]*h;return r}},Ec=class extends as{constructor(e,t,i,n){super(e,t,i,n)}interpolate_(e){return this.copySampleValue_(e-1)}},ni=class{constructor(e,t,i,n){if(e===void 0)throw new Error("THREE.KeyframeTrack: track name is undefined");if(t===void 0||t.length===0)throw new Error("THREE.KeyframeTrack: no keyframes in track named "+e);this.name=e,this.times=ta(t,this.TimeBufferType),this.values=ta(i,this.ValueBufferType),this.setInterpolation(n||this.DefaultInterpolation)}static toJSON(e){let t=e.constructor,i;if(t.toJSON!==this.toJSON)i=t.toJSON(e);else{i={name:e.name,times:ta(e.times,Array),values:ta(e.values,Array)};let n=e.getInterpolation();n!==e.DefaultInterpolation&&(i.interpolation=n)}return i.type=e.ValueTypeName,i}InterpolantFactoryMethodDiscrete(e){return new Ec(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodLinear(e){return new wc(this.times,this.values,this.getValueSize(),e)}InterpolantFactoryMethodSmooth(e){return new Sc(this.times,this.values,this.getValueSize(),e)}setInterpolation(e){let t;switch(e){case oa:t=this.InterpolantFactoryMethodDiscrete;break;case kl:t=this.InterpolantFactoryMethodLinear;break;case Eo:t=this.InterpolantFactoryMethodSmooth}if(t===void 0){let i="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;if(this.createInterpolant===void 0){if(e===this.DefaultInterpolation)throw new Error(i);this.setInterpolation(this.DefaultInterpolation)}return console.warn("THREE.KeyframeTrack:",i),this}return this.createInterpolant=t,this}getInterpolation(){switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:return oa;case this.InterpolantFactoryMethodLinear:return kl;case this.InterpolantFactoryMethodSmooth:return Eo}}getValueSize(){return this.values.length/this.times.length}shift(e){if(e!==0){let t=this.times;for(let i=0,n=t.length;i!==n;++i)t[i]+=e}return this}scale(e){if(e!==1){let t=this.times;for(let i=0,n=t.length;i!==n;++i)t[i]*=e}return this}trim(e,t){let i=this.times,n=i.length,r=0,a=n-1;for(;r!==n&&i[r]<e;)++r;for(;a!==-1&&i[a]>t;)--a;if(++a,r!==0||a!==n){r>=a&&(a=Math.max(a,1),r=a-1);let o=this.getValueSize();this.times=i.slice(r,a),this.values=this.values.slice(r*o,a*o)}return this}validate(){let e=!0,t=this.getValueSize();t-Math.floor(t)!=0&&(console.error("THREE.KeyframeTrack: Invalid value size in track.",this),e=!1);let i=this.times,n=this.values,r=i.length;r===0&&(console.error("THREE.KeyframeTrack: Track is empty.",this),e=!1);let a=null;for(let o=0;o!==r;o++){let l=i[o];if(typeof l=="number"&&isNaN(l)){console.error("THREE.KeyframeTrack: Time is not a valid number.",this,o,l),e=!1;break}if(a!==null&&a>l){console.error("THREE.KeyframeTrack: Out of order keys.",this,o,l,a),e=!1;break}a=l}if(n!==void 0&&ef(n))for(let o=0,l=n.length;o!==l;++o){let c=n[o];if(isNaN(c)){console.error("THREE.KeyframeTrack: Value is not a valid number.",this,o,c),e=!1;break}}return e}optimize(){let e=this.times.slice(),t=this.values.slice(),i=this.getValueSize(),n=this.getInterpolation()===Eo,r=e.length-1,a=1;for(let o=1;o<r;++o){let l=!1,c=e[o];if(c!==e[o+1]&&(o!==1||c!==e[0]))if(n)l=!0;else{let h=o*i,d=h-i,u=h+i;for(let p=0;p!==i;++p){let m=t[h+p];if(m!==t[d+p]||m!==t[u+p]){l=!0;break}}}if(l){if(o!==a){e[a]=e[o];let h=o*i,d=a*i;for(let u=0;u!==i;++u)t[d+u]=t[h+u]}++a}}if(r>0){e[a]=e[r];for(let o=r*i,l=a*i,c=0;c!==i;++c)t[l+c]=t[o+c];++a}return a!==e.length?(this.times=e.slice(0,a),this.values=t.slice(0,a*i)):(this.times=e,this.values=t),this}clone(){let e=this.times.slice(),t=this.values.slice(),i=new this.constructor(this.name,e,t);return i.createInterpolant=this.createInterpolant,i}};ni.prototype.TimeBufferType=Float32Array,ni.prototype.ValueBufferType=Float32Array,ni.prototype.DefaultInterpolation=kl;var cn=class extends ni{constructor(e,t,i){super(e,t,i)}};cn.prototype.ValueTypeName="bool",cn.prototype.ValueBufferType=Array,cn.prototype.DefaultInterpolation=oa,cn.prototype.InterpolantFactoryMethodLinear=void 0,cn.prototype.InterpolantFactoryMethodSmooth=void 0;var Tc=class extends ni{};Tc.prototype.ValueTypeName="color";var Ac=class extends ni{};Ac.prototype.ValueTypeName="number";var Rc=class extends as{constructor(e,t,i,n){super(e,t,i,n)}interpolate_(e,t,i,n){let r=this.resultBuffer,a=this.sampleValues,o=this.valueSize,l=(i-t)/(n-t),c=e*o;for(let h=c+o;c!==h;c+=4)$e.slerpFlat(r,0,a,c-o,a,c,l);return r}},Ia=class extends ni{InterpolantFactoryMethodLinear(e){return new Rc(this.times,this.values,this.getValueSize(),e)}};Ia.prototype.ValueTypeName="quaternion",Ia.prototype.InterpolantFactoryMethodSmooth=void 0;var hn=class extends ni{constructor(e,t,i){super(e,t,i)}};hn.prototype.ValueTypeName="string",hn.prototype.ValueBufferType=Array,hn.prototype.DefaultInterpolation=oa,hn.prototype.InterpolantFactoryMethodLinear=void 0,hn.prototype.InterpolantFactoryMethodSmooth=void 0;var Cc=class extends ni{};Cc.prototype.ValueTypeName="vector";var Lc=class{constructor(e,t,i){let n=this,r,a=!1,o=0,l=0,c=[];this.onStart=void 0,this.onLoad=e,this.onProgress=t,this.onError=i,this.itemStart=function(h){l++,a===!1&&n.onStart!==void 0&&n.onStart(h,o,l),a=!0},this.itemEnd=function(h){o++,n.onProgress!==void 0&&n.onProgress(h,o,l),o===l&&(a=!1,n.onLoad!==void 0&&n.onLoad())},this.itemError=function(h){n.onError!==void 0&&n.onError(h)},this.resolveURL=function(h){return r?r(h):h},this.setURLModifier=function(h){return r=h,this},this.addHandler=function(h,d){return c.push(h,d),this},this.removeHandler=function(h){let d=c.indexOf(h);return d!==-1&&c.splice(d,2),this},this.getHandler=function(h){for(let d=0,u=c.length;d<u;d+=2){let p=c[d],m=c[d+1];if(p.global&&(p.lastIndex=0),p.test(h))return m}return null}}},tf=new Lc,Pc=class{constructor(e){this.manager=e!==void 0?e:tf,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={}}load(){}loadAsync(e,t){let i=this;return new Promise(function(n,r){i.load(e,n,t,r)})}parse(){}setCrossOrigin(e){return this.crossOrigin=e,this}setWithCredentials(e){return this.withCredentials=e,this}setPath(e){return this.path=e,this}setResourcePath(e){return this.resourcePath=e,this}setRequestHeader(e){return this.requestHeader=e,this}};Pc.DEFAULT_MATERIAL_NAME="__DEFAULT";var Da=class extends at{constructor(e,t=1){super(),this.isLight=!0,this.type="Light",this.color=new ye(e),this.intensity=t}dispose(){}copy(e,t){return super.copy(e,t),this.color.copy(e.color),this.intensity=e.intensity,this}toJSON(e){let t=super.toJSON(e);return t.object.color=this.color.getHex(),t.object.intensity=this.intensity,this.groundColor!==void 0&&(t.object.groundColor=this.groundColor.getHex()),this.distance!==void 0&&(t.object.distance=this.distance),this.angle!==void 0&&(t.object.angle=this.angle),this.decay!==void 0&&(t.object.decay=this.decay),this.penumbra!==void 0&&(t.object.penumbra=this.penumbra),this.shadow!==void 0&&(t.object.shadow=this.shadow.toJSON()),this.target!==void 0&&(t.object.target=this.target.uuid),t}},Ua=class extends Da{constructor(e,t,i){super(e,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(at.DEFAULT_UP),this.updateMatrix(),this.groundColor=new ye(t)}copy(e,t){return super.copy(e,t),this.groundColor.copy(e.groundColor),this}},sl=new Ee,Uu=new M,Nu=new M,Ic=class{constructor(e){this.camera=e,this.intensity=1,this.bias=0,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new oe(512,512),this.map=null,this.mapPass=null,this.matrix=new Ee,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new Kn,this._frameExtents=new oe(1,1),this._viewportCount=1,this._viewports=[new ct(0,0,1,1)]}getViewportCount(){return this._viewportCount}getFrustum(){return this._frustum}updateMatrices(e){let t=this.camera,i=this.matrix;Uu.setFromMatrixPosition(e.matrixWorld),t.position.copy(Uu),Nu.setFromMatrixPosition(e.target.matrixWorld),t.lookAt(Nu),t.updateMatrixWorld(),sl.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),this._frustum.setFromProjectionMatrix(sl),i.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),i.multiply(sl)}getViewport(e){return this._viewports[e]}getFrameExtents(){return this._frameExtents}dispose(){this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()}copy(e){return this.camera=e.camera.clone(),this.intensity=e.intensity,this.bias=e.bias,this.radius=e.radius,this.mapSize.copy(e.mapSize),this}clone(){return new this.constructor().copy(this)}toJSON(){let e={};return this.intensity!==1&&(e.intensity=this.intensity),this.bias!==0&&(e.bias=this.bias),this.normalBias!==0&&(e.normalBias=this.normalBias),this.radius!==1&&(e.radius=this.radius),this.mapSize.x===512&&this.mapSize.y===512||(e.mapSize=this.mapSize.toArray()),e.camera=this.camera.toJSON(!1).object,delete e.camera.matrix,e}};var lg=new Ee,cg=new M,hg=new M;var Dc=class extends Ic{constructor(){super(new Qn(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0}},Na=class extends Da{constructor(e,t){super(e,t),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(at.DEFAULT_UP),this.updateMatrix(),this.target=new at,this.shadow=new Dc}dispose(){this.shadow.dispose()}copy(e){return super.copy(e),this.target=e.target.clone(),this.shadow=e.shadow.clone(),this}};var ug=new Ee,dg=new Ee,pg=new Ee;var mg=new M,fg=new $e,gg=new M,vg=new M;var yg=new M,xg=new $e,_g=new M,Mg=new M;var qc="\\[\\]\\.:\\/",nf=new RegExp("["+qc+"]","g"),rl="[^"+qc+"]",sf="[^"+qc.replace("\\.","")+"]",rf=new RegExp("^"+/((?:WC+[\/:])*)/.source.replace("WC",rl)+/(WCOD+)?/.source.replace("WCOD",sf)+/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",rl)+/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",rl)+"$"),af=["material","materials","bones","map"],lt=class s{constructor(e,t,i){this.path=t,this.parsedPath=i||s.parseTrackName(t),this.node=s.findNode(e,this.parsedPath.nodeName),this.rootNode=e,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}static create(e,t,i){return e&&e.isAnimationObjectGroup?new s.Composite(e,t,i):new s(e,t,i)}static sanitizeNodeName(e){return e.replace(/\s/g,"_").replace(nf,"")}static parseTrackName(e){let t=rf.exec(e);if(t===null)throw new Error("PropertyBinding: Cannot parse trackName: "+e);let i={nodeName:t[2],objectName:t[3],objectIndex:t[4],propertyName:t[5],propertyIndex:t[6]},n=i.nodeName&&i.nodeName.lastIndexOf(".");if(n!==void 0&&n!==-1){let r=i.nodeName.substring(n+1);af.indexOf(r)!==-1&&(i.nodeName=i.nodeName.substring(0,n),i.objectName=r)}if(i.propertyName===null||i.propertyName.length===0)throw new Error("PropertyBinding: can not parse propertyName from trackName: "+e);return i}static findNode(e,t){if(t===void 0||t===""||t==="."||t===-1||t===e.name||t===e.uuid)return e;if(e.skeleton){let i=e.skeleton.getBoneByName(t);if(i!==void 0)return i}if(e.children){let i=function(r){for(let a=0;a<r.length;a++){let o=r[a];if(o.name===t||o.uuid===t)return o;let l=i(o.children);if(l)return l}return null},n=i(e.children);if(n)return n}return null}_getValue_unavailable(){}_setValue_unavailable(){}_getValue_direct(e,t){e[t]=this.targetObject[this.propertyName]}_getValue_array(e,t){let i=this.resolvedProperty;for(let n=0,r=i.length;n!==r;++n)e[t++]=i[n]}_getValue_arrayElement(e,t){e[t]=this.resolvedProperty[this.propertyIndex]}_getValue_toArray(e,t){this.resolvedProperty.toArray(e,t)}_setValue_direct(e,t){this.targetObject[this.propertyName]=e[t]}_setValue_direct_setNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.needsUpdate=!0}_setValue_direct_setMatrixWorldNeedsUpdate(e,t){this.targetObject[this.propertyName]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_array(e,t){let i=this.resolvedProperty;for(let n=0,r=i.length;n!==r;++n)i[n]=e[t++]}_setValue_array_setNeedsUpdate(e,t){let i=this.resolvedProperty;for(let n=0,r=i.length;n!==r;++n)i[n]=e[t++];this.targetObject.needsUpdate=!0}_setValue_array_setMatrixWorldNeedsUpdate(e,t){let i=this.resolvedProperty;for(let n=0,r=i.length;n!==r;++n)i[n]=e[t++];this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_arrayElement(e,t){this.resolvedProperty[this.propertyIndex]=e[t]}_setValue_arrayElement_setNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.needsUpdate=!0}_setValue_arrayElement_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty[this.propertyIndex]=e[t],this.targetObject.matrixWorldNeedsUpdate=!0}_setValue_fromArray(e,t){this.resolvedProperty.fromArray(e,t)}_setValue_fromArray_setNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.needsUpdate=!0}_setValue_fromArray_setMatrixWorldNeedsUpdate(e,t){this.resolvedProperty.fromArray(e,t),this.targetObject.matrixWorldNeedsUpdate=!0}_getValue_unbound(e,t){this.bind(),this.getValue(e,t)}_setValue_unbound(e,t){this.bind(),this.setValue(e,t)}bind(){let e=this.node,t=this.parsedPath,i=t.objectName,n=t.propertyName,r=t.propertyIndex;if(e||(e=s.findNode(this.rootNode,t.nodeName),this.node=e),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!e)return void console.warn("THREE.PropertyBinding: No target node found for track: "+this.path+".");if(i){let c=t.objectIndex;switch(i){case"materials":if(!e.material)return void console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);if(!e.material.materials)return void console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);e=e.material.materials;break;case"bones":if(!e.skeleton)return void console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);e=e.skeleton.bones;for(let h=0;h<e.length;h++)if(e[h].name===c){c=h;break}break;case"map":if("map"in e){e=e.map;break}if(!e.material)return void console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.",this);if(!e.material.map)return void console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);e=e.material.map;break;default:if(e[i]===void 0)return void console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.",this);e=e[i]}if(c!==void 0){if(e[c]===void 0)return void console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,e);e=e[c]}}let a=e[n];if(a===void 0){let c=t.nodeName;return void console.error("THREE.PropertyBinding: Trying to update property for track: "+c+"."+n+" but it wasn't found.",e)}let o=this.Versioning.None;this.targetObject=e,e.needsUpdate!==void 0?o=this.Versioning.NeedsUpdate:e.matrixWorldNeedsUpdate!==void 0&&(o=this.Versioning.MatrixWorldNeedsUpdate);let l=this.BindingType.Direct;if(r!==void 0){if(n==="morphTargetInfluences"){if(!e.geometry)return void console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);if(!e.geometry.morphAttributes)return void console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);e.morphTargetDictionary[r]!==void 0&&(r=e.morphTargetDictionary[r])}l=this.BindingType.ArrayElement,this.resolvedProperty=a,this.propertyIndex=r}else a.fromArray!==void 0&&a.toArray!==void 0?(l=this.BindingType.HasFromToArray,this.resolvedProperty=a):Array.isArray(a)?(l=this.BindingType.EntireArray,this.resolvedProperty=a):this.propertyName=n;this.getValue=this.GetterByBindingType[l],this.setValue=this.SetterByBindingTypeAndVersioning[l][o]}unbind(){this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound}};lt.Composite=class{constructor(s,e,t){let i=t||lt.parseTrackName(e);this._targetGroup=s,this._bindings=s.subscribe_(e,i)}getValue(s,e){this.bind();let t=this._targetGroup.nCachedObjects_,i=this._bindings[t];i!==void 0&&i.getValue(s,e)}setValue(s,e){let t=this._bindings;for(let i=this._targetGroup.nCachedObjects_,n=t.length;i!==n;++i)t[i].setValue(s,e)}bind(){let s=this._bindings;for(let e=this._targetGroup.nCachedObjects_,t=s.length;e!==t;++e)s[e].bind()}unbind(){let s=this._bindings;for(let e=this._targetGroup.nCachedObjects_,t=s.length;e!==t;++e)s[e].unbind()}},lt.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3},lt.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2},lt.prototype.GetterByBindingType=[lt.prototype._getValue_direct,lt.prototype._getValue_array,lt.prototype._getValue_arrayElement,lt.prototype._getValue_toArray],lt.prototype.SetterByBindingTypeAndVersioning=[[lt.prototype._setValue_direct,lt.prototype._setValue_direct_setNeedsUpdate,lt.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[lt.prototype._setValue_array,lt.prototype._setValue_array_setNeedsUpdate,lt.prototype._setValue_array_setMatrixWorldNeedsUpdate],[lt.prototype._setValue_arrayElement,lt.prototype._setValue_arrayElement_setNeedsUpdate,lt.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[lt.prototype._setValue_fromArray,lt.prototype._setValue_fromArray_setNeedsUpdate,lt.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];var bg=new Float32Array(1);var Sg=new Ee;var wg=new oe;var Eg=new M,Tg=new M;var Ag=new M;var Rg=new M,Cg=new Ee,Lg=new Ee;var Pg=new M,Ig=new ye,Dg=new ye;var Ug=new M,Ng=new M,Og=new M;var zg=new M,kg=new Ws;var Fg=new ri;var Bg=new M;typeof __THREE_DEVTOOLS__<"u"&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:al}})),typeof window<"u"&&(window.__THREE__?console.warn("WARNING: Multiple instances of Three.js being imported."):window.__THREE__=al);var cs=s=>s*s;function Ha(s){let e=xh(s.ctrl,15),t=new fr(e),i=t.total,{H0:n,landY:r}=s,a=s.drop0??170,o=h=>(h=de(h,0,i),n-a*Ye(0,380,h)-(n-a-r)*Math.pow(h/i,s.glideExp??1.05)),l=t.at(0),c=t.at(i);return{line:t,L:i,routeY:o,start:l,end:c,heading:Math.atan2(l.dx,l.dz)}}function Yc(s,e,t,i){let{line:n,L:r,routeY:a}=e,o={d:0,s:0},l=e.start.x,c=e.start.z,h=l-e.start.dx*25,d=c-e.start.dz*25,u=e.end.x,p=e.end.z,m=s.carve;return function(f,g){let y=i(f,g),x=s.cell||20,_=x+2,b=(f-l)*e.start.dx+(g-c)*e.start.dz,S=Math.abs((f-l)*e.start.dz-(g-c)*e.start.dx),R=Math.hypot(f-h,g-d),P=s.H0-(s.summitSlope??.55)*Math.max(0,R-45)-.004*cs(Math.max(0,R-45));y=Math.max(y,P+t.fbm(f/90,g/90,3)*6*Ye(45,80,R)),n.nearest(f,g,o);let C=o.s,B=o.d;if(B<1500){let F=Ye(_,_+.5,C);if(F>0){let U=1;if(m.narrows)for(let K of m.narrows)U-=K.k*Math.exp(-cs((C-K.s*r)/K.len));let X=m.clearance*(1-Ye(.76*r,r,C))+(s.startDrop??260)*(1-Ye(150,750,C)),j=a(C)-X+t.fbm(f/140,g/140,3)*m.floorNoise*(1-Ye(.8*r,r,C)),Z=m.w0*U,$=m.w*U,ue=m.wallH*Math.pow(Math.max(0,B-Z)/$,m.p),_e=j+ue+t.ridged(f/60,g/60,3)*m.wallNoise*Ye(Z,Z+$,B);y=fe(y,Math.min(y,_e),F)}}let z=Math.hypot(f-u,g-p),D=s.landR;return y=fe(y,s.landY,1-Ye(D,D*2,z)),b<=_&&b>-90&&(y=fe(y,s.H0,1-Ye(24,24+x*1.5,S))),s.extra&&(y=s.extra(f,g,y,o)),y}}function of(){let s=Ht(1101),e={id:"skyfall",name:"Skyfall Ridge",subtitle:"Alpine mountain range",size:3e3,H0:2050,landY:300,landR:85,ctrl:[[-200,2400],[-160,2150],[80,1750],[-90,1250],[180,760],[20,260],[-230,-260],[-120,-760],[140,-1180]],carve:{clearance:165,w0:70,w:300,p:1.6,wallH:950,floorNoise:25,wallNoise:90,narrows:[{s:.42,k:.55,len:170},{s:.63,k:.5,len:140}]}},t=Ha(e),i={x:t.end.x+330,z:t.end.z+220,r:260};e.extra=(r,a,o)=>{let l=Math.hypot(r-i.x,a-i.z),c=e.landY-45+cs(l/i.r)*120;return Math.min(o,fe(c,o,Ye(i.r*.9,i.r*1.5,l)))};let n=(r,a)=>{let o=r+s.fbm(r/2e3+7,a/2e3,3)*500,l=a+s.fbm(r/2e3,a/2e3+7,3)*500,c=s.ridged(o/3e3+3.1,l/3e3-1.7,6),h=s.fbm(r/1500,a/1500,4)*.5+.5;return 260+1900*Math.pow(c,1.5)*(.55+.6*h)+140*s.fbm(r/500,a/500,4)};return e.height=Yc(e,t,s,n),e.water={y:e.landY-14,kind:"lake"},e.color=(r,a,o,l,c)=>{let h=1500+c*200,d=.25,u=.33,p=.17,m=Ye(.16,.3,a),v=.36+c*.05,f=.32+c*.04,g=.27+c*.04;d=fe(d,v,m),u=fe(u,f,m),p=fe(p,g,m);let y=Ye(900,1300,r)*(1-m);d=fe(d,.38,y*.6),u=fe(u,.36,y*.6),p=fe(p,.3,y*.6);let x=Ye(h-60,h+60,r)*(1-Ye(.22,.38,a));return d=fe(d,.86,x),u=fe(u,.89,x),p=fe(p,.95,x),[d,u,p]},e.trees={kind:"pine",count:26e3,minH:e.landY-10,maxH:1250,maxSlope:.75,clearR:e.landR+40,scale:[.8,1.5]},e.rocks={count:900,minSlope:.3},e.particles="snow",e.ambient="mountain",e.defaultTime="midday",e.wind={dir:.6,speed:5},e.rain=!0,e.palette={tint:[1,1,1]},Va(e,t)}function lf(){let s=Ht(2202),e={id:"redstone",name:"Redstone Abyss",subtitle:"Desert canyon",size:2600,H0:1220,landY:140,landR:80,summitSlope:1.6,ctrl:[[-1400,1300],[-1150,1150],[-800,1150],[-500,900],[-450,550],[-150,300],[150,350],[380,120]],carve:{clearance:72,w0:28,w:76,p:3.2,wallH:900,floorNoise:8,wallNoise:30,narrows:[{s:.5,k:.35,len:120},{s:.8,k:.3,len:90}]}},t=Ha(e),i=(n,r)=>{let o=(s.fbm(n/1600,r/1600,4)*.5+.5)*5,c=420+560*((Math.floor(o)+Ye(.82,1,o-Math.floor(o)))/5),h=s.fbm(n/650+11,r/650-3,3),d=Ye(.32,.38,h)*(220+120*s.fbm(n/300,r/300,2));return c+d+s.fbm(n/120,r/120,3)*6};return e.extra=(n,r,a,o)=>{let l=Math.hypot(n-t.end.x,r-t.end.z),c=e.landY+cs(Math.max(0,l-160)/260)*300;return Math.min(a,c)},e.height=Yc(e,t,s,i),e.water=null,e.color=(n,r,a,o,l)=>{let c=Math.sin(n*.09+l*2.2)*.5+.5,h=fe(.62,.8,c),d=fe(.25,.38,c),u=fe(.12,.2,c),p=1-Ye(.06,.16,r);h=fe(h,.86+l*.04,p),d=fe(d,.58+l*.04,p),u=fe(u,.34,p);let m=1-Ye(e.landY+30,e.landY+200,n);return h=fe(h,.87,m*p),d=fe(d,.72,m*p),u=fe(u,.52,m*p),[h,d,u]},e.trees={kind:"bush",count:5e3,minH:0,maxH:2e3,maxSlope:.35,clearR:e.landR+20,scale:[.5,1.1]},e.rocks={count:1400,minSlope:.1},e.arches=[{s:.56,clearAbove:30,r:11},{s:.74,clearAbove:24,r:10}],e.particles="dust",e.ambient="desert",e.defaultTime="sunset",e.wind={dir:2.2,speed:4},e.rain=!1,Va(e,t)}function cf(){let s=Ht(3303),e={id:"tidal",name:"Tidal Edge",subtitle:"Coastal cliffs & ocean",size:2600,H0:820,landY:3,landR:70,summitSlope:.9,ctrl:[[240,2200],[120,1950],[-150,1650],[-250,1250],[-200,850],[20,620]],carve:{clearance:110,w0:50,w:220,p:2,wallH:500,floorNoise:0,wallNoise:20}},t=Ha(e),i=a=>60+90*Math.sin(a/500)+250*Math.exp(-cs((a-2150)/260))+s.fbm(.5,a/300,3)*50,n=[];for(let[a,o,l]of[[.3,48,50],[.38,-52,70],[.47,40,40],[.55,-38,60],[.62,55,20]]){let c=t.line.at(a*t.L);n.push({x:c.x-c.dz*o*1.25,z:c.z+c.dx*o*1.25,r:34,h:t.routeY(a*t.L)+l})}let r=(a,o)=>{let l=i(o),c=a-l,d=(330+260*(s.fbm(a/1100,o/1100,4)*.5+.5)+60*s.ridged(a/300,o/300,3))*Ye(-10,70,c)+Math.min(0,c)*.4,u=-38+s.fbm(a/400,o/400,3)*10,p=Ye(.42,.5,s.fbm(a/520+9,o/520,4))*(45+40*s.fbm(a/120,o/120,2));return u+=p*Ye(80,400,-c),c>-10?Math.max(d,u):u};return e.extra=(a,o,l)=>{for(let u of n){let p=Math.hypot(a-u.x,o-u.z);if(p<u.r*2.2){let m=u.h*(1-Ye(u.r*.8,u.r*1.1,p+s.n2(a/15,o/15)*4))+s.fbm(a/20,o/20,2)*6;l=Math.max(l,m-40*Ye(u.r,u.r*2.2,p))}}let c=Math.hypot(a-t.end.x,o-t.end.z),h=e.landY+Math.max(0,c-140)*.45,d=1-Ye(200,330,c);return l>h&&(l=fe(l,h,d)),l<-2&&c<150&&(l=fe(l,e.landY,1-Ye(90,150,c))),l},e.height=Yc(e,t,s,r),e.water={y:0,kind:"ocean"},e.color=(a,o,l,c,h)=>{let d=.27+h*.03,u=.4+h*.04,p=.18,m=Ye(.14,.28,o);d=fe(d,.26,m),u=fe(u,.25,m),p=fe(p,.26,m);let v=1-Ye(4,12,a);d=fe(d,.9,v),u=fe(u,.82,v),p=fe(p,.62,v);let f=1-Ye(-6,-1,a);return d=fe(d,.78,f),u=fe(u,.74,f),p=fe(p,.58,f),[d,u,p]},e.trees={kind:"pine",count:9e3,minH:10,maxH:900,maxSlope:.55,clearR:e.landR+60,scale:[.6,1.2],palms:!0},e.rocks={count:600,minSlope:.4},e.arches=[{s:.8,clearAbove:26,r:10,sea:!0}],e.particles="mist",e.ambient="coast",e.defaultTime="morning",e.wind={dir:-1,speed:5},e.rain=!0,Va(e,t)}function hf(){let s=Ht(4404),e={id:"metro",name:"Vertical Metropolis",subtitle:"Modern urban skyline",size:2400,H0:880,landY:2,landR:70,city:!0,ctrl:[[0,1392],[0,1100],[0,760],[0,600],[120,450],[300,450],[450,330],[450,0],[450,-230]]},t=Ha(e);e.height=(u,p)=>{let m=Math.hypot(u,p-300);return 2+Ye(1700,2400,m)*(s.fbm(u/500,p/500,3)*.5+.5)*120},e.water=null,e.color=()=>[.3,.3,.3];let i=(()=>{let u=99;return()=>(u=u*16807%2147483647,u/2147483647)})(),n=[],r=150,a=30,o=27,l={d:0,s:0},c={x:t.end.x,z:t.end.z-20,r:170};e.park=c;let h={x:675,z:75,w:64,d:64,h:128};e.helipad=h;let d=u=>{let p=1e9;for(let m=0;m<=4;m++)for(let v=0;v<=4;v++){if(m>0&&m<4&&v>0&&v<4)continue;let f=fe(u.x0,u.x1,m/4),g=fe(u.z0,u.z1,v/4);t.line.nearest(f,g,l),l.d<p&&(p=l.d)}return t.line.nearest((u.x0+u.x1)/2,(u.z0+u.z1)/2,l),Math.min(p,l.d)};for(let u=-16;u<16;u++)for(let p=-16;p<16;p++){let m=u*r+a/2,v=p*r+a/2,f=r-a,g=m+f/2,y=v+f/2,x=Math.hypot(g,y-650);if(Math.hypot(g,y)>2300||Math.hypot(g-c.x,y-c.z)<c.r+40||i()<.04)continue;let b=i()<.5?2:i()<.5?3:1,S=f/b;for(let R=0;R<b;R++)for(let P=0;P<b;P++){let C={x0:m+R*S+3,x1:m+(R+1)*S-3,z0:v+P*S+3,z1:v+(P+1)*S-3};if(Math.abs((C.x0+C.x1)/2-h.x)<70&&Math.abs((C.z0+C.z1)/2-h.z)<70)continue;let B=Math.exp(-cs(x/850)),z=25+60*i()+B*(120+380*Math.pow(i(),1.4));i()<.08&&(z*=1.5);let D=!0;for(let F=0;F<4;F++){let U=d(C);if(U>=o)break;t.line.nearest((C.x0+C.x1)/2,(C.z0+C.z1)/2,l);let X=t.line.at(l.s),j=(C.x0+C.x1)/2-X.x,Z=(C.z0+C.z1)/2-X.z,$=o-U+2;if(Math.abs(j)>Math.abs(Z)?j>0?C.x0+=$:C.x1-=$:Z>0?C.z0+=$:C.z1-=$,C.x1-C.x0<12||C.z1-C.z0<12){D=!1;break}}if(!(!D||d(C)<o-1)&&!(Math.abs((C.x0+C.x1)/2)<110&&Math.abs((C.z0+C.z1)/2-1420)<110)&&(n.push({...C,y0:0,y1:z,kind:"building",tone:i()}),z>300&&i()<.3)){let F=(C.x0+C.x1)/2,U=(C.z0+C.z1)/2,X=20+i()*45;n.push({x0:F-.8,x1:F+.8,z0:U-.8,z1:U+.8,y0:z,y1:z+X,kind:"antenna"})}}}n.push({x0:-30,x1:30,z0:1380,z1:1450,y0:0,y1:e.H0,kind:"tower",tone:.5}),n.push({x0:-1.5,x1:1.5,z0:1430,z1:1433,y0:e.H0,y1:e.H0+70,kind:"antenna"}),n.push({x0:h.x-h.w/2,x1:h.x+h.w/2,z0:h.z-h.d/2,z1:h.z+h.d/2,y0:0,y1:h.h,kind:"building",tone:.2,helipad:!0}),e.bridgeSpecs=[{s:.2,above:28},{s:.33,above:-34},{s:.76,above:26},{s:.86,above:-30}];for(let u of e.bridgeSpecs){let p=t.line.at(u.s*t.L),m=t.routeY(u.s*t.L)+u.above,v=Math.abs(p.dx)>Math.abs(p.dz),f=60,g=v?{x0:p.x-5,x1:p.x+5,z0:p.z-f,z1:p.z+f}:{x0:p.x-f,x1:p.x+f,z0:p.z-5,z1:p.z+5};n.push({...g,y0:m-3,y1:m+3,kind:"bridge"});let y=f+10;for(let x of[-1,1]){let _=v?p.x:p.x+x*y,b=v?p.z+x*y:p.z;n.push({x0:_-16,x1:_+16,z0:b-16,z1:b+16,y0:0,y1:Math.max(m+40,120),kind:"building",tone:.7})}}return e.buildings=n,e.trees={kind:"broad",count:0,park:!0},e.particles="none",e.ambient="city",e.defaultTime="sunset",e.wind={dir:1.4,speed:4},e.rain=!0,Va(e,t)}function Va(s,e){return s.route=e,s.exit={x:e.start.x,z:e.start.z,y:s.H0,heading:e.heading},s.landing={x:e.end.x,z:e.end.z,y:s.landY,r:s.landR},s}var uf={skyfall:of,redstone:lf,tidal:cf,metro:hf},jc={};function Li(s){return jc[s]||(jc[s]=uf[s]()),jc[s]}var er=[{id:"skyfall",name:"Skyfall Ridge",subtitle:"Alpine mountain range",color:"#7fb4ff"},{id:"redstone",name:"Redstone Abyss",subtitle:"Desert canyon",color:"#ff8a4c"},{id:"tidal",name:"Tidal Edge",subtitle:"Coastal cliffs & ocean",color:"#38d6c4"},{id:"metro",name:"Vertical Metropolis",subtitle:"Modern urban skyline",color:"#c9a7ff"}];var tr=()=>new Promise(s=>setTimeout(s,0));function df(s=256,e=7){let t=Ht(e),i=document.createElement("canvas");i.width=i.height=s;let n=i.getContext("2d"),r=n.createImageData(s,s);for(let o=0;o<s;o++)for(let l=0;l<s;l++){let c=l/s*Math.PI*2,h=o/s*Math.PI*2,d=t.fbm(Math.cos(c)*1.6+5,Math.sin(c)*1.6+Math.cos(h)*1.6,5)*.5+t.n2(Math.sin(h)*9+Math.cos(c)*9,Math.cos(h)*9)*.25,u=de(128+d*140,0,255),p=(o*s+l)*4;r.data[p]=u,r.data[p+1]=de(128+t.n2(l*.21,o*.21)*90,0,255),r.data[p+2]=u,r.data[p+3]=255}n.putImageData(r,0,0);let a=new vi(i);return a.wrapS=a.wrapT=Fs,a.colorSpace=Bi,a.anisotropy=4,a}var ir=null;function Ga(s){let e=0,t=s.map(([l,c])=>{let h=l.index?l.toNonIndexed():l;return h.computeVertexNormals(),e+=h.attributes.position.count,[h,c]}),i=new Float32Array(e*3),n=new Float32Array(e*3),r=new Float32Array(e*3),a=0;for(let[l,c]of t){let h=l.attributes.position.array,d=l.attributes.normal.array;i.set(h,a*3),n.set(d,a*3);let u=new ye(c);for(let p=0;p<l.attributes.position.count;p++)r[(a+p)*3]=u.r,r[(a+p)*3+1]=u.g,r[(a+p)*3+2]=u.b;a+=l.attributes.position.count}let o=new Ve;return o.setAttribute("position",new We(i,3)),o.setAttribute("normal",new We(n,3)),o.setAttribute("color",new We(r,3)),o}function pf(s){if(s==="pine"){let i=new li(.03,.05,.3,5);i.translate(0,.15,0);let n=new Xi(.32,.6,7);n.translate(0,.45,0);let r=new Xi(.22,.45,7);return r.translate(0,.78,0),Ga([[i,4863014],[n,2837034],[r,3365424]])}if(s==="palm"){let i=new li(.025,.04,.9,5);i.translate(0,.45,0);let n=[[i,8020552]];for(let r=0;r<6;r++){let a=new Xi(.05,.42,3);a.rotateZ(Math.PI/2+.5),a.translate(.2,.88,0),a.rotateY(r/6*Math.PI*2),n.push([a,4156972])}return Ga(n)}if(s==="bush"){let i=new ss(.5,0);return i.scale(1,.6,1),i.translate(0,.25,0),Ga([[i,7039546]])}let e=new li(.035,.05,.45,5);e.translate(0,.22,0);let t=new ss(.33,0);return t.translate(0,.66,0),Ga([[e,5915440],[t,4025134]])}function mf(s){let e=s==="ocean",t=Gc.merge([he.fog,{uTime:{value:0},uSunDir:{value:new M(0,1,0)},uSunColor:{value:new ye(1,1,1)},uSky:{value:new ye(.6,.7,.9)},uDeep:{value:new ye(e?668501:1195080)},uShallow:{value:new ye(e?3130560:3836554)},uAmp:{value:e?.9:.15},uFoam:{value:e?.8:.15},uRipple:{value:e?.5:.22}}]);return new Tt({uniforms:t,transparent:!0,fog:!0,depthWrite:!0,vertexShader:`
      attribute float depth;
      uniform float uTime; uniform float uAmp;
      varying float vDepth; varying vec3 vWorld; varying vec3 vNormal2;
      #include <fog_pars_vertex>
      void main(){
        vec3 p = position;
        vec4 wp = modelMatrix * vec4(p,1.0);
        float k1 = 0.035, k2 = 0.06, k3 = 0.11;
        float a = uAmp * clamp(depth/6.0, 0.15, 1.0);
        float w = sin(wp.x*k1 + uTime*0.9) * a + sin((wp.x*0.6+wp.z*0.8)*k2 + uTime*1.3)*a*0.6 + sin((wp.z - wp.x*0.3)*k3 + uTime*1.9)*a*0.3;
        wp.y += w;
        float dx = cos(wp.x*k1 + uTime*0.9)*a*k1 + cos((wp.x*0.6+wp.z*0.8)*k2 + uTime*1.3)*a*0.6*k2*0.6 - cos((wp.z - wp.x*0.3)*k3 + uTime*1.9)*a*0.3*k3*0.3;
        float dz = cos((wp.x*0.6+wp.z*0.8)*k2 + uTime*1.3)*a*0.6*k2*0.8 + cos((wp.z - wp.x*0.3)*k3 + uTime*1.9)*a*0.3*k3;
        vNormal2 = normalize(vec3(-dx, 1.0, -dz));
        vDepth = depth; vWorld = wp.xyz;
        vec4 mvPosition = viewMatrix * wp;
        gl_Position = projectionMatrix * mvPosition;
        #include <fog_vertex>
      }`,fragmentShader:`
      uniform float uTime; uniform vec3 uSunDir; uniform vec3 uSunColor; uniform vec3 uSky; uniform vec3 uDeep; uniform vec3 uShallow; uniform float uFoam; uniform float uRipple;
      varying float vDepth; varying vec3 vWorld; varying vec3 vNormal2;
      #include <fog_pars_fragment>
      float h(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
      float vn(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);
        return mix(mix(h(i),h(i+vec2(1,0)),f.x), mix(h(i+vec2(0,1)),h(i+vec2(1,1)),f.x), f.y); }
      void main(){
        vec2 q = vWorld.xz*0.08;
        float r1 = vn(q + vec2(uTime*0.3, uTime*0.2)), r2 = vn(q*2.3 - vec2(uTime*0.25, -uTime*0.4));
        vec3 n = normalize(vNormal2 + vec3((r1-0.5)*0.35 + (r2-0.5)*0.2, 0.0, (r2-0.5)*0.35 - (r1-0.5)*0.15) * uRipple);
        vec3 v = normalize(cameraPosition - vWorld);
        float fres = 0.04 + 0.96*pow(1.0 - max(dot(n, v), 0.0), 5.0);
        vec3 base = mix(uShallow, uDeep, smoothstep(0.0, 28.0, vDepth));
        vec3 refl = uSky * 1.05;
        vec3 col = mix(base * (0.35 + 0.65*max(uSunDir.y,0.15)), refl, fres*0.85);
        vec3 hv = normalize(uSunDir + v);
        float spec = pow(max(dot(n, hv), 0.0), 220.0) * 1.2 + pow(max(dot(n, hv), 0.0), 40.0)*0.1;
        col += uSunColor * spec;
        float foam = (1.0 - smoothstep(0.0, 1.2, vDepth)) * (0.5 + 0.5*sin(uTime*1.5 + vWorld.x*0.08 + vWorld.z*0.05)) * uFoam;
        col = mix(col, vec3(0.95), clamp(foam,0.0,1.0)*0.8);
        float alpha = mix(0.55, 0.96, smoothstep(0.0, 7.0, vDepth));
        gl_FragColor = vec4(col, max(alpha, foam*0.9));
        #include <tonemapping_fragment>
        #include <colorspace_fragment>
        #include <fog_fragment>
      }`})}function ff(){let s=document.createElement("canvas");s.width=s.height=128;let e=s.getContext("2d"),t=Qi(42);for(let n=0;n<26;n++){let r=30+t()*68,a=40+t()*50,o=14+t()*26,l=e.createRadialGradient(r,a,0,r,a,o);l.addColorStop(0,"rgba(255,255,255,0.55)"),l.addColorStop(1,"rgba(255,255,255,0)"),e.fillStyle=l,e.beginPath(),e.arc(r,a,o,0,Math.PI*2),e.fill()}let i=new vi(s);return i.colorSpace=wt,i}function gf(){let s=document.createElement("canvas");s.width=4,s.height=128;let e=s.getContext("2d"),t=e.createLinearGradient(0,128,0,0);t.addColorStop(0,"rgba(255,170,60,0.75)"),t.addColorStop(.4,"rgba(255,150,50,0.25)"),t.addColorStop(1,"rgba(255,140,40,0)"),e.fillStyle=t,e.fillRect(0,0,4,128);let i=new vi(s);return i.colorSpace=wt,i}var Wa=class{constructor(e,t,i){this.scene=e,this.def=t,this.quality=i,this.group=new Qe,this.time=0,this.trees=[],this.treeGrid=new Map,this.boxGrid=new Map,this.boxes=[],this.arches=[],this.animated=[],e.add(this.group)}async build(e=()=>{}){let t=this.def,i={low:224,medium:320,high:448}[this.quality]||320,n=t.size;this.N=i,this.S=n,this.cell=2*n/i,t.cell=this.cell;let r=i+1,a=new Float32Array(r*r);for(let d=0;d<r;d++){let u=-n+d*this.cell;for(let p=0;p<r;p++)a[d*r+p]=t.height(-n+p*this.cell,u);d%24===0&&(e(.05+.5*d/r),await tr())}this.H=a;let o=128,l=n*4;this.FR=o,this.FS=l,this.fcell=2*l/o;let c=o+1,h=new Float32Array(c*c);for(let d=0;d<c;d++)for(let u=0;u<c;u++)h[d*c+u]=t.height(-l+u*this.fcell,-l+d*this.fcell)-20;this.FH=h,e(.6),await tr(),this.buildTerrainMesh(),e(.7),await tr(),t.water&&this.buildWater(),t.trees&&this.buildTrees(),e(.8),await tr(),t.rocks&&this.buildRocks(),t.arches&&this.buildArches(),t.buildings&&this.buildCity(),this.buildLandingMarker(),this.buildExitMarker(),this.buildClouds(),this.buildBirds(),e(.95),await tr()}terrainHeight(e,t){let i=this.S;if(e>-i&&e<i&&t>-i&&t<i)return this._sample(this.H,this.N,i,this.cell,e,t);let n=this.FS;return e>-n&&e<n&&t>-n&&t<n?this._sample(this.FH,this.FR,n,this.fcell,e,t):-100}_sample(e,t,i,n,r,a){let o=(r+i)/n,l=(a+i)/n,c=Math.floor(o),h=Math.floor(l);c>=t&&(c=t-1),h>=t&&(h=t-1);let d=o-c,u=l-h,p=t+1,m=e[h*p+c],v=e[h*p+c+1],f=e[(h+1)*p+c],g=e[(h+1)*p+c+1];return d+u<=1?m+(v-m)*d+(f-m)*u:g+(f-g)*(1-d)+(v-g)*(1-u)}ground(e,t,i={h:0,water:!1,roof:!1}){let n=this.terrainHeight(e,t);if(i.water=!1,i.roof=!1,this.def.water&&n<this.def.water.y&&(n=this.def.water.y,i.water=!0),this.boxes.length){let r=this.boxGrid.get(this._key(Math.floor(e/60),Math.floor(t/60)));if(r)for(let a of r)e>=a.x0&&e<=a.x1&&t>=a.z0&&t<=a.z1&&a.y0<5&&a.y1>n&&(n=a.y1,i.roof=!0,i.water=!1,i.box=a)}return i.h=n,i}_key(e,t){return e*92821+t*68917}collide(e,t){let i=this.terrainHeight(e.x,e.z);if(e.y-t<i)return{type:"terrain",h:i};if(this.def.water&&e.y-t*.5<this.def.water.y)return{type:"water",h:this.def.water.y};let n=Math.floor(e.x/40),r=Math.floor(e.z/40);for(let a=-1;a<=1;a++)for(let o=-1;o<=1;o++){let l=this.treeGrid.get(this._key(n+a,r+o));if(l)for(let c of l){if(e.y>c.y+c.h+t||e.y<c.y-t)continue;let h=Math.hypot(e.x-c.x,e.z-c.z),d=c.rad*(1-de((e.y-c.y)/c.h,0,1))+.4;if(h<d+t)return{type:"tree"}}}if(this.boxes.length){let a=this.boxGrid.get(this._key(Math.floor(e.x/60),Math.floor(e.z/60)));if(a)for(let o of a){let l=de(e.x,o.x0,o.x1),c=de(e.y,o.y0,o.y1),h=de(e.z,o.z0,o.z1),d=e.x-l,u=e.y-c,p=e.z-h;if(d*d+u*u+p*p<t*t)return{type:o.kind==="bridge"?"bridge":"building",box:o,top:o.y1}}}for(let a of this.arches){let o=e.x-a.c.x,l=e.y-a.c.y,c=e.z-a.c.z;if(l<0)continue;let h=o*a.rx+c*a.rz,d=o*a.fx+c*a.fz,u=Math.hypot(h,l)-a.R;if(Math.hypot(u,d)-a.r<t)return{type:"rock"}}return null}clearance(e,t){let i=e.y-this.ground(e.x,e.z).h,n=i,r=Math.hypot(t.x,t.y,t.z)||1,a=t.x/r,o=t.y/r,l=t.z/r,c=-l,h=a,d=Math.hypot(c,h)||1;c/=d,h/=d;let u=[[a,o,l],[c,0,h],[-c,0,-h],[a*.7+c*.7,o*.7,l*.7+h*.7],[a*.7-c*.7,o*.7,l*.7-h*.7]],p={x:0,y:0,z:0};for(let m of u)for(let v=3;v<Math.min(n,45);v+=3)if(p.x=e.x+m[0]*v,p.y=e.y+m[1]*v,p.z=e.z+m[2]*v,this.collide(p,.5)){n=Math.min(n,v);break}return{agl:i,clr:Math.max(0,n)}}buildTerrainMesh(){let e=this.def,t=this.N,i=this.S,n=t+1,r=this.H,a=this.cell,o=new Float32Array(n*n*3),l=new Float32Array(n*n*3),c=new Float32Array(n*n*3),h=new Float32Array(n*n*2),d=Ht(77);for(let D=0;D<n;D++)for(let F=0;F<n;F++){let U=D*n+F,X=-i+F*a,j=-i+D*a,Z=r[U];o[U*3]=X,o[U*3+1]=Z,o[U*3+2]=j;let $=r[D*n+Math.max(0,F-1)],ue=r[D*n+Math.min(t,F+1)],_e=r[Math.max(0,D-1)*n+F],K=r[Math.min(t,D+1)*n+F],ae=$-ue,pe=_e-K,ge=2*a,ce=Math.hypot(ae,ge,pe);c[U*3]=ae/ce,c[U*3+1]=ge/ce,c[U*3+2]=pe/ce;let A=1-ge/ce,T=e.color(Z,A,X,j,d.fbm(X/160,j/160,3));l[U*3]=T[0],l[U*3+1]=T[1],l[U*3+2]=T[2],h[U*2]=X/24,h[U*2+1]=j/24}this.slopeAt=(D,F)=>{let U=de(Math.round((D+i)/a),0,t),X=de(Math.round((F+i)/a),0,t);return 1-c[(X*n+U)*3+1]};let u=new Uint32Array(t*t*6),p=0;for(let D=0;D<t;D++)for(let F=0;F<t;F++){let U=D*n+F,X=U+1,j=U+n,Z=j+1;u[p++]=U,u[p++]=j,u[p++]=X,u[p++]=X,u[p++]=j,u[p++]=Z}let m=new Ve;m.setAttribute("position",new We(o,3)),m.setAttribute("normal",new We(c,3)),m.setAttribute("color",new We(l,3)),m.setAttribute("uv",new We(h,2)),m.setIndex(new We(u,1)),m.computeBoundingSphere(),ir||(ir=df());let v=new it({vertexColors:!0,roughness:.96,metalness:0,map:ir});this._terrainShader(v,!!e.city);let f=new Ce(m,v);f.receiveShadow=!0,f.castShadow=!1,this.group.add(f),this.terrainMat=v;let g=this.FR,y=this.FS,x=g+1,_=this.FH,b=this.fcell,S=new Float32Array(x*x*3),R=new Float32Array(x*x*3),P=new Float32Array(x*x*2);for(let D=0;D<x;D++)for(let F=0;F<x;F++){let U=D*x+F,X=-y+F*b,j=-y+D*b,Z=_[U];S[U*3]=X,S[U*3+1]=Z,S[U*3+2]=j;let $=e.color(Z+20,.2,X,j,d.fbm(X/160,j/160,3));R[U*3]=$[0],R[U*3+1]=$[1],R[U*3+2]=$[2],P[U*2]=X/24,P[U*2+1]=j/24}let C=[];for(let D=0;D<g;D++)for(let F=0;F<g;F++){let U=-y+F*b,X=-y+D*b;if(U>=-i&&U+b<=i&&X>=-i&&X+b<=i)continue;let j=D*x+F,Z=j+1,$=j+x,ue=$+1;C.push(j,$,Z,Z,$,ue)}let B=new Ve;B.setAttribute("position",new We(S,3)),B.setAttribute("color",new We(R,3)),B.setAttribute("uv",new We(P,2)),B.setIndex(C),B.computeVertexNormals();let z=new Ce(B,v);this.group.add(z)}_terrainShader(e,t){let i=this.def.park||{x:1e6,z:1e6,r:0};e.onBeforeCompile=n=>{n.uniforms.uPark={value:new M(i.x,i.z,i.r)},n.vertexShader=n.vertexShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;`).replace("#include <worldpos_vertex>",`#include <worldpos_vertex>
vWPos = (modelMatrix * vec4(transformed,1.0)).xyz;`);let r=n.fragmentShader.replace("#include <common>",`#include <common>
varying vec3 vWPos;
uniform vec3 uPark;`);r=r.replace("#include <map_fragment>",`
        #ifdef USE_MAP
          vec4 t1 = texture2D(map, vMapUv);
          vec4 t2 = texture2D(map, vMapUv * 0.113);
          vec4 t3 = texture2D(map, vMapUv * 4.1);
          float det = (t1.r - 0.5) * 0.5 + (t2.g - 0.5) * 0.6 + (t3.r - 0.5) * 0.25;
          diffuseColor.rgb *= clamp(1.0 + det, 0.55, 1.5);
        #endif
        ${t?`
          float sx = abs(vWPos.x - floor(vWPos.x/150.0+0.5)*150.0);
          float sz = abs(vWPos.z - floor(vWPos.z/150.0+0.5)*150.0);
          float road = 1.0 - step(15.0, min(sx, sz));
          float walk = (1.0 - step(18.5, min(sx, sz))) * (1.0 - road);
          vec3 lot = vec3(0.42,0.42,0.43);
          float pk = 1.0 - smoothstep(uPark.z, uPark.z + 6.0, length(vWPos.xz - uPark.xy));
          lot = mix(lot, vec3(0.20,0.36,0.14), pk);
          vec3 c = mix(lot, vec3(0.62,0.62,0.6), walk);
          float lane = (1.0 - step(0.35, min(sx, sz))) * step(0.5, fract((sx < sz ? vWPos.z : vWPos.x) / 12.0));
          vec3 asphalt = vec3(0.16,0.16,0.17) + lane * vec3(0.7,0.65,0.4);
          float cross = step(min(sx,sz), 15.0) * step(max(sx,sz), 15.0);
          asphalt = mix(asphalt, vec3(0.17), cross);
          c = mix(c, asphalt, road * (1.0 - pk));
          diffuseColor.rgb = c * clamp(1.0 + det*0.6, 0.6, 1.4);
        `:""}
      `),n.fragmentShader=r}}buildWater(){let e=this.def,t=e.water.y,i=e.water.kind==="ocean"?this.FS:this.S,n=e.water.kind==="ocean"?200:220,r=new Gt(i*2,i*2,n,n);r.rotateX(-Math.PI/2);let a=r.attributes.position.array,o=new Float32Array(a.length/3);for(let u=0;u<o.length;u++)o[u]=Math.max(0,t-this.terrainHeight(a[u*3],a[u*3+2]));r.setAttribute("depth",new We(o,1));let l=r.index.array,c=[];for(let u=0;u<l.length;u+=3)(o[l[u]]>0||o[l[u+1]]>0||o[l[u+2]]>0)&&c.push(l[u],l[u+1],l[u+2]);r.setIndex(c),r.translate(0,t,0);let h=mf(e.water.kind),d=new Ce(r,h);d.renderOrder=1,this.group.add(d),this.waterMat=h}buildTrees(){var f;let e=this.def,t=e.trees,i=Qi(555),n={low:.3,medium:.6,high:1}[this.quality]||.6,r=Ht(909),a=[],o=e.landing,l=e.exit,c=(g,y,x,_)=>{let b=this.terrainHeight(g,y);a.push({x:g,y:b,z:y,s:x,kind:_,h:x,rad:x*(_==="pine"?.3:_==="bush"?.5:.36)})};if(t.park&&e.park){let g=e.park;for(let y=0;y<260;y++){let x=i()*Math.PI*2,_=g.r*Math.sqrt(i()),b=g.x+Math.cos(x)*_,S=g.z+Math.sin(x)*_;Math.hypot(b-o.x,S-o.z)<o.r+25||c(b,S,10+i()*8,"broad")}}else{let g=Math.floor(t.count*n),y=0;for(;a.length<g&&y<g*8;){y++;let x=(i()*2-1)*this.S*.98,_=(i()*2-1)*this.S*.98,b=this.terrainHeight(x,_);if(b<t.minH||b>t.maxH+r.n2(x/300,_/300)*120||e.water&&b<e.water.y+2||this.slopeAt(x,_)>t.maxSlope*.35||Math.hypot(x-o.x,_-o.z)<t.clearR||Math.hypot(x-l.x,_-l.z)<60||r.fbm(x/500,_/500,3)<(t.kind==="bush"?0:-.15))continue;let S=t.kind;t.palms&&b<25&&(S="palm");let R=(t.kind==="bush"?3:14)*(t.scale[0]+i()*(t.scale[1]-t.scale[0]))*(S==="palm"?1.1:1);c(x,_,R,S)}if(t.kind==="pine"&&!t.palms)for(let x=0;x<140;x++){let _=i()*Math.PI*2,b=o.r*(1.35+i()*.9);c(o.x+Math.cos(_)*b,o.z+Math.sin(_)*b,12+i()*10,"pine")}}let h={};for(let g of a)(h[f=g.kind]||(h[f]=[])).push(g);let d=new Ee,u=new $e,p=new M,m=new M,v=new M(0,1,0);for(let g in h){let y=h[g],x=pf(g),_=new it({vertexColors:!0,roughness:.9,flatShading:!0});this._swayShader(_);let b=new dn(x,_,y.length),S=new ye;y.forEach((R,P)=>{u.setFromAxisAngle(v,i()*Math.PI*2),p.set(R.s*(.85+i()*.3),R.s,R.s*(.85+i()*.3)),m.set(R.x,R.y-.3,R.z),d.compose(m,u,p),b.setMatrixAt(P,d);let C=.75+i()*.45;S.setRGB(C*(.9+i()*.2),C,C*(.85+i()*.2)),b.setColorAt(P,S)}),b.castShadow=this.quality!=="low",b.receiveShadow=!1,b.frustumCulled=!1,this.group.add(b)}for(let g of a){let y=this._key(Math.floor(g.x/40),Math.floor(g.z/40)),x=this.treeGrid.get(y);x||(x=[],this.treeGrid.set(y,x)),x.push(g)}this.trees=a}_swayShader(e){let t=this;e.onBeforeCompile=i=>{i.uniforms.uTime={get value(){return t.time}},i.vertexShader=i.vertexShader.replace("#include <common>",`#include <common>
uniform float uTime;`).replace("#include <begin_vertex>",`#include <begin_vertex>
          #ifdef USE_INSTANCING
          float ph = instanceMatrix[3].x*0.05 + instanceMatrix[3].z*0.07;
          float sw = (sin(uTime*1.4 + ph) + 0.5*sin(uTime*2.7 + ph*1.7)) * 0.035 * max(position.y, 0.0);
          transformed.x += sw; transformed.z += sw*0.6;
          #endif`)}}buildRocks(){let e=this.def.rocks,t=Qi(31),i=Math.floor(e.count*({low:.4,medium:.7,high:1}[this.quality]||.7)),n=new Zs(1,0),r=new it({color:this.def.id==="redstone"?10115642:7828336,roughness:1,flatShading:!0}),a=new dn(n,r,i),o=new Ee,l=new $e,c=new M,h=new M,d=new Et,u=0;for(let p=0;p<i*5&&u<i;p++){let m=(t()*2-1)*this.S,v=(t()*2-1)*this.S;if(this.slopeAt(m,v)<e.minSlope*.2)continue;let f=this.terrainHeight(m,v);if(this.def.water&&f<this.def.water.y||Math.hypot(m-this.def.landing.x,v-this.def.landing.z)<this.def.landing.r+10)continue;let g=1+t()*t()*5;d.set(t()*3,t()*3,t()*3),l.setFromEuler(d),c.set(g*(.8+t()*.6),g*(.5+t()*.5),g*(.8+t()*.6)),h.set(m,f+g*.2,v),o.compose(h,l,c),a.setMatrixAt(u++,o)}a.count=u,a.castShadow=this.quality==="high",a.receiveShadow=!0,this.group.add(a)}buildArches(){let e=this.def,t=e.route,i=Ht(4242);for(let n of e.arches){let r=n.s*t.L,a=t.line.at(r),o=t.routeY(r),l=n.sea?-6:o-e.carve.clearance*(1-Ye(.76*t.L,t.L,r)),c=o+n.clearAbove-l+n.r,h=new gn(c,n.r,12,56,Math.PI),d=h.attributes.position;for(let y=0;y<d.count;y++){let x=d.getX(y),_=d.getY(y),b=d.getZ(y),S=i.fbm(x/18,_/18+b/18,3)*3,R=Math.hypot(x,_)||1;d.setXYZ(y,x+x/R*S,_+_/R*S*.6,b*(1.25+i.n2(x/30,_/30)*.25))}h.computeVertexNormals();let u=e.id==="redstone"?11558970:4868166,p=new it({color:u,roughness:.95,flatShading:!0,map:ir}),m=new Ce(h,p),v=Math.atan2(a.dx,a.dz);m.rotation.y=v,m.position.set(a.x,l,a.z),m.castShadow=!0,m.receiveShadow=!0,this.group.add(m);let f=a.dx,g=a.dz;this.arches.push({c:new M(a.x,l,a.z),R:c,r:n.r*1.05,rx:Math.cos(v),rz:-Math.sin(v),fx:f,fz:g})}}buildCity(){let e=this.def.buildings;this.boxes=e;for(let m of e){let v=Math.floor(m.x0/60),f=Math.floor(m.x1/60),g=Math.floor(m.z0/60),y=Math.floor(m.z1/60);for(let x=v;x<=f;x++)for(let _=g;_<=y;_++){let b=this._key(x,_),S=this.boxGrid.get(b);S||(S=[],this.boxGrid.set(b,S)),S.push(m)}}let t=new Ct(1,1,1);t.translate(0,.5,0);let i={building:[],tower:[],antenna:[],bridge:[]};for(let m of e)i[m.kind].push(m);let n=this,r=new it({color:16777215,roughness:.6,metalness:.2});r.onBeforeCompile=m=>{m.uniforms.uNight={get value(){return n.night||0}},m.vertexShader=m.vertexShader.replace("#include <common>",`#include <common>
varying vec3 vWPos; varying vec3 vWNor;`).replace("#include <worldpos_vertex>",`#include <worldpos_vertex>
          vec4 wpp = vec4(transformed,1.0);
          #ifdef USE_INSTANCING
          wpp = instanceMatrix * wpp;
          #endif
          vWPos = (modelMatrix * wpp).xyz;
          vWNor = normalize(mat3(modelMatrix) * objectNormal);`),m.fragmentShader=m.fragmentShader.replace("#include <common>",`#include <common>
varying vec3 vWPos; varying vec3 vWNor; uniform float uNight;
float hh(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);}`).replace("#include <map_fragment>",`
          float isWall = step(abs(vWNor.y), 0.5);
          float u = abs(vWNor.x) > 0.5 ? vWPos.z : vWPos.x;
          vec2 cellId = vec2(floor(u/3.2), floor(vWPos.y/3.8));
          float wx = fract(u/3.2), wy = fract(vWPos.y/3.8);
          float win = isWall * step(0.1, wx) * step(wx, 0.9) * step(0.18, wy) * step(wy, 0.86) * step(4.0, vWPos.y);
          vec3 glass = vec3(0.10,0.14,0.20);
          diffuseColor.rgb = mix(diffuseColor.rgb * vec3(0.75), glass, win);
          float lit = step(0.8, hh(cellId + floor(vWPos.xz/40.0))) * win * uNight;
        `).replace("#include <roughnessmap_fragment>",`#include <roughnessmap_fragment>
roughnessFactor = mix(roughnessFactor, 0.06, win);`).replace("#include <metalnessmap_fragment>",`#include <metalnessmap_fragment>
metalnessFactor = mix(metalnessFactor, 0.9, win);`).replace("#include <emissivemap_fragment>",`#include <emissivemap_fragment>
totalEmissiveRadiance += vec3(1.0,0.75,0.45) * lit * 0.55;`)};let a=new Ee,o=new $e,l=new M,c=new M,h=new ye,d=(m,v,f)=>{if(!m.length)return;let g=new dn(t,v,m.length);m.forEach((y,x)=>{c.set((y.x0+y.x1)/2,y.y0,(y.z0+y.z1)/2),l.set(y.x1-y.x0,y.y1-y.y0,y.z1-y.z0),a.compose(c,o,l),g.setMatrixAt(x,a),f&&g.setColorAt(x,f(y,h))}),g.castShadow=!0,g.receiveShadow=!0,g.frustumCulled=!1,this.group.add(g)},u=[13223098,9213603,14209732,7305862,11773327,10465471,8223608];d([...i.building,...i.tower],r,(m,v)=>v.set(u[Math.floor((m.tone||0)*u.length)%u.length])),d(i.antenna,new it({color:9080726,roughness:.5,metalness:.7})),d(i.bridge,new it({color:10139856,roughness:.15,metalness:.7}));let p=this.def.helipad;if(p){let m=new Ce(new rs(10,12,32),new oi({color:16765503}));m.rotation.x=-Math.PI/2,m.position.set(p.x,p.h+.15,p.z),this.group.add(m)}}buildLandingMarker(){let e=this.def.landing;this.addTarget(e.x,e.y,e.z,e.r)}addTarget(e,t,i,n){let r=new Qe,a=new Qe,o=(d,u,p,m)=>{let v=new Ce(new rs(d,u,48),new oi({color:p,transparent:!0,opacity:m,depthWrite:!1,polygonOffset:!0,polygonOffsetFactor:-4}));v.rotation.x=-Math.PI/2,a.add(v)};o(n*.94,n,16777215,.8),o(n*.62,n*.68,16747050,.85),o(n*.28,n*.34,16777215,.85),o(0,n*.08,16734746,.95),a.position.set(e,t+.25,i),r.add(a);let l=new Ce(new li(Math.max(3,n*.12),Math.max(3,n*.12),600,12,1,!0),new oi({map:gf(),transparent:!0,depthWrite:!1,blending:Oa,side:Xt,fog:!1}));l.position.set(e,t+300,i),r.add(l);let c=new Ce(new li(.08,.08,6,6),new it({color:14540253}));c.position.set(e+n*1.1,t+3,i),r.add(c);let h=new Ce(new Xi(.5,2.5,10,1,!0),new it({color:16738842,side:Xt}));return h.geometry.rotateX(-Math.PI/2),h.geometry.translate(0,0,1.25),h.position.set(e+n*1.1,t+5.6,i),r.add(h),this.socks=this.socks||[],this.socks.push(h),this.group.add(r),r}buildExitMarker(){let e=this.def.exit,t=new Qe,i=new Ce(new li(.05,.05,3,6),new it({color:12303291,metalness:.6}));i.position.y=1.5,t.add(i);let n=new Ce(new Gt(1.2,.7),new it({color:16742938,side:Xt}));n.position.set(.6,2.6,0),t.add(n),this.flag=n;let r=e.x+Math.cos(e.heading)*4-Math.sin(e.heading)*4,a=e.z-Math.sin(e.heading)*4-Math.cos(e.heading)*4;t.position.set(r,this.ground(r,a).h,a),this.group.add(t)}buildClouds(){let e=this.def,t=ff();this.cloudMat=new Xs({map:t,transparent:!0,depthWrite:!1,fog:!0,opacity:.9});let i=Qi(77);this.clouds=new Qe;let n={low:40,medium:80,high:130}[this.quality]||80,r=e.H0+500;for(let a=0;a<n;a++){let o=new _a(this.cloudMat),l=250+i()*650;o.scale.set(l,l*.45,1);let c=i()<.35;o.position.set((i()*2-1)*this.S*1.6,c?e.H0*(.45+i()*.3):r+i()*600,(i()*2-1)*this.S*1.6),c&&e.route.line.nearest(o.position.x,o.position.z).d<400&&(o.position.y=r+i()*400),this.clouds.add(o)}this.group.add(this.clouds)}buildBirds(){let e=new Ve;e.setAttribute("position",new Te([0,0,.3,-1,.2,-.2,0,0,-.3,0,0,.3,1,.2,-.2,0,0,-.3],3)),e.computeVertexNormals();let t=new oi({color:2236962,side:Xt,fog:!0}),i=24,n=new dn(e,t,i);n.frustumCulled=!1;let r=Qi(12),a=this.def.route,o=a.line.at(a.L*.35);this.birds={mesh:n,n:i,data:[],center:new M(o.x+250,a.routeY(a.L*.35)+60,o.z)};for(let l=0;l<i;l++)this.birds.data.push({r:30+r()*70,a:r()*6.28,sp:.15+r()*.1,y:r()*30,ph:r()*6,s:1.2+r()*.6});this.group.add(n)}update(e,t){if(this.time+=e,this.waterMat&&(this.waterMat.uniforms.uTime.value=this.time),this.clouds)for(let i of this.clouds.children){i.position.x+=t.x*e*2,i.position.z+=t.z*e*2;let n=this.S*1.6;i.position.x>n&&(i.position.x-=n*2),i.position.x<-n&&(i.position.x+=n*2),i.position.z>n&&(i.position.z-=n*2),i.position.z<-n&&(i.position.z+=n*2)}if(this.birds){let i=this.birds,n=new Ee,r=new $e,a=new Et,o=new M,l=new M;i.data.forEach((c,h)=>{c.a+=c.sp*e,l.set(i.center.x+Math.cos(c.a)*c.r,i.center.y+c.y+Math.sin(this.time*.5+c.ph)*4,i.center.z+Math.sin(c.a)*c.r),a.set(0,-c.a,Math.sin(this.time*.4+c.ph)*.3),r.setFromEuler(a);let d=.4+Math.abs(Math.sin(this.time*8+c.ph))*.8;o.set(c.s,c.s*d,c.s),n.compose(l,r,o),i.mesh.setMatrixAt(h,n)}),i.mesh.instanceMatrix.needsUpdate=!0}if(this.socks)for(let i of this.socks)i.rotation.y=Math.atan2(t.x,t.z)+Math.sin(this.time*3)*.08;this.flag&&(this.flag.rotation.y=Math.sin(this.time*4)*.25)}setLighting(e){this.waterMat&&(this.waterMat.uniforms.uSunDir.value.copy(e.sunDir),this.waterMat.uniforms.uSunColor.value.copy(e.sunColor),this.waterMat.uniforms.uSky.value.copy(e.horizon).lerp(e.zenith,.35)),this.night=e.night,this.cloudMat&&this.cloudMat.color.copy(e.cloudColor)}dispose(){this.scene.remove(this.group),this.group.traverse(e=>{e.geometry&&e.geometry.dispose(),e.material&&(Array.isArray(e.material)?e.material:[e.material]).forEach(i=>{i.map&&i.map!==ir&&i.map.dispose(),i.dispose()})})}};var hs={morning:{label:"Morning",elev:11,az:95,sun:[1,.82,.66],sunI:2,hemiSky:[.5,.62,.9],hemiGr:[.22,.22,.26],hemiI:1,zenith:[.22,.42,.78],horizon:[.78,.8,.86],fog:1,exposure:1,night:0},midday:{label:"Midday",elev:62,az:160,sun:[1,.97,.92],sunI:2.3,hemiSky:[.6,.7,.88],hemiGr:[.3,.27,.22],hemiI:.8,zenith:[.16,.38,.82],horizon:[.68,.79,.93],fog:.85,exposure:.9,night:0},sunset:{label:"Sunset",elev:5,az:255,sun:[1,.52,.22],sunI:2.3,hemiSky:[.5,.42,.58],hemiGr:[.28,.18,.14],hemiI:.8,zenith:[.17,.2,.45],horizon:[1,.58,.32],fog:1.1,exposure:1.05,night:.6},overcast:{label:"Overcast",elev:38,az:140,sun:[.85,.87,.9],sunI:.75,hemiSky:[.66,.69,.74],hemiGr:[.3,.3,.3],hemiI:1.7,zenith:[.46,.49,.54],horizon:[.64,.66,.69],fog:1.7,exposure:1,night:.2,cloud:.9}},ci={clear:{label:"Clear",fog:1,wind:1,gust:.6,cloud:.25},lightfog:{label:"Light Fog",fog:3.2,wind:.7,gust:.4,cloud:.4},heavyfog:{label:"Heavy Fog",fog:7.5,wind:.5,gust:.3,cloud:.6},windy:{label:"Wind Gusts",fog:1.2,wind:1.5,gust:2,cloud:.45},clouds:{label:"Cloud Layers",fog:1.6,wind:1.2,gust:1,cloud:.85},rain:{label:"Light Rain",fog:3,wind:1.4,gust:1.3,cloud:.95,rain:!0}},nr=s=>new ye(s[0],s[1],s[2]),Xa=class{constructor(e,t,i){this.scene=e,this.renderer=t,this.quality=i,this.sunDir=new M(0,1,0),this.sunColor=new ye,this.zenith=new ye,this.horizon=new ye,this.cloudColor=new ye,this.uniforms={uZenith:{value:this.zenith},uHorizon:{value:this.horizon},uSunDir:{value:this.sunDir},uSunColor:{value:this.sunColor},uCloud:{value:.3},uTime:{value:0},uGround:{value:new ye(.3,.3,.32)}};let n=new Tt({uniforms:this.uniforms,side:Uc,depthWrite:!1,fog:!1,vertexShader:"varying vec3 vDir; void main(){ vDir = position; vec4 p = projectionMatrix * modelViewMatrix * vec4(position,1.0); gl_Position = p.xyww; }",fragmentShader:`
        uniform vec3 uZenith, uHorizon, uSunDir, uSunColor, uGround; uniform float uCloud, uTime;
        varying vec3 vDir;
        float h(vec2 p){ return fract(sin(dot(p, vec2(127.1,311.7)))*43758.5453); }
        float vn(vec2 p){ vec2 i=floor(p), f=fract(p); f=f*f*(3.0-2.0*f);
          return mix(mix(h(i),h(i+vec2(1,0)),f.x), mix(h(i+vec2(0,1)),h(i+vec2(1,1)),f.x), f.y); }
        float fbm(vec2 p){ float s=0.0,a=0.5; for(int i=0;i<5;i++){ s+=a*vn(p); p*=2.03; a*=0.5; } return s; }
        void main(){
          vec3 d = normalize(vDir);
          float y = d.y;
          vec3 col = mix(uHorizon, uZenith, pow(clamp(y,0.0,1.0), 0.55));
          col = mix(col, uHorizon*0.92, smoothstep(0.0,-0.25,y));
          float sd = max(dot(d, uSunDir), 0.0);
          col += uSunColor * (pow(sd, 8.0)*0.25 + pow(sd, 64.0)*0.45) * (1.0 - uCloud*0.6);
          col += uSunColor * smoothstep(0.9993, 0.9997, sd) * 6.0 * (1.0 - uCloud*0.85);
          // horizon glow from low sun
          col += uSunColor * pow(1.0-abs(y), 6.0) * pow(sd, 2.0) * 0.25 * clamp(1.0-uSunDir.y*2.0,0.0,1.0);
          if (y > 0.0) {
            vec2 uv = d.xz / (y + 0.12) * 1.4 + vec2(uTime*0.004, uTime*0.0025);
            float c = fbm(uv);
            float cov = smoothstep(1.0-uCloud*0.95, 1.25-uCloud*0.7, c + 0.15);
            vec3 cc = mix(uHorizon*1.05, vec3(1.0), 0.5) * (0.75 + 0.35*pow(sd,4.0)) + uSunColor*0.15;
            cc = mix(cc, cc*0.65, uCloud*0.6);
            col = mix(col, cc, cov * smoothstep(0.0, 0.18, y) * 0.92);
          }
          gl_FragColor = vec4(col, 1.0);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }`});this.dome=new Ce(new Ri(2e4,32,16),n),this.dome.renderOrder=-10,this.dome.frustumCulled=!1,e.add(this.dome),this.sun=new Na(16777215,3),this.sun.castShadow=i!=="low";let r=i==="high"?2048:1024;this.sun.shadow.mapSize.set(r,r);let a=this.sun.shadow.camera;a.left=-90,a.right=90,a.top=90,a.bottom=-90,a.near=10,a.far=1600,this.sun.shadow.bias=-4e-4,this.sun.shadow.normalBias=.6,e.add(this.sun),e.add(this.sun.target),this.hemi=new Ua(16777215,4473924,1),e.add(this.hemi),e.fog=new ya(11189196,2e-4),this.weather=ci.clear,this.envRT=null}apply(e,t,i){let n=hs[e]||hs.midday,r=ci[t]||ci.clear;this.time=n,this.weather=r,this.timeKey=e,this.weatherKey=t;let a=Vc.degToRad(n.elev),o=Vc.degToRad(n.az);this.sunDir.set(Math.cos(a)*Math.sin(o),Math.sin(a),Math.cos(a)*Math.cos(o)).normalize();let l=de(Math.max(n.cloud||0,r.cloud)-.6,0,.4)/.4;this.sunColor.copy(nr(n.sun)),this.zenith.copy(nr(n.zenith)).lerp(new ye(.5,.52,.56),l*.7),this.horizon.copy(nr(n.horizon)).lerp(new ye(.66,.68,.7),l*.6),i&&i.id==="redstone"&&this.horizon.lerp(new ye(.95,.75,.55),.25),i&&i.id==="metro"&&this.horizon.lerp(new ye(.75,.72,.7),.15),this.uniforms.uCloud.value=Math.max(n.cloud||0,r.cloud),this.sun.color.copy(this.sunColor),this.sun.intensity=n.sunI*(1-l*.65),this.hemi.color.copy(nr(n.hemiSky)),this.hemi.groundColor.copy(nr(n.hemiGr)),this.hemi.intensity=n.hemiI*(1+l*.4);let c=13e-5*n.fog*r.fog;this.scene.fog.density=c,this.scene.fog.color.copy(this.horizon).lerp(this.zenith,.12),this.cloudColor.copy(this.horizon).lerp(new ye(1,1,1),.55).lerp(this.sunColor,.15),this.night=n.night,this.exposure=n.exposure,this.renderer.toneMappingExposure=n.exposure,this.updateEnv()}updateEnv(){let e=new es(this.renderer),t=new Wi,i=this.dome.clone();i.material=this.dome.material,i.scale.setScalar(.004),i.position.set(0,0,0),t.add(i),this.envRT&&this.envRT.dispose(),this.envRT=e.fromScene(t,0,.1,200),this.scene.environment=this.envRT.texture,this.scene.environmentIntensity=.8,e.dispose()}update(e,t,i){this.uniforms.uTime.value+=e,this.dome.position.copy(t.position),this.sun.position.copy(i).addScaledVector(this.sunDir,800),this.sun.target.position.copy(i)}},qa=class{constructor(e){this.scene=e;let t=1400;this.n=t;let i=new Float32Array(t*6),n=new Ve;n.setAttribute("position",new We(i,3)),this.seg=new ts(n,new pn({color:16777215,transparent:!0,opacity:.5,depthWrite:!1,fog:!1})),this.seg.frustumCulled=!1,e.add(this.seg),this.pts=new Float32Array(t*3),this.box=60;for(let r=0;r<t;r++)this.pts[r*3]=(Math.random()*2-1)*this.box,this.pts[r*3+1]=(Math.random()*2-1)*this.box,this.pts[r*3+2]=(Math.random()*2-1)*this.box;this.kind="none",this.rain=!1,this.center=new M,this.enabled=!0}configure(e,t){this.kind=e,this.rain=t;let i=this.seg.material;t?(i.color.set(12110040),i.opacity=.45):e==="snow"?(i.color.set(16777215),i.opacity=.8):e==="dust"?(i.color.set(15249536),i.opacity=.45):(i.color.set(16777215),i.opacity=.35)}update(e,t,i,n,r){let a=this.n,o=this.pts,l=this.box,c=this.seg.geometry.attributes.position.array,h=this.rain?9:this.kind==="snow"?1.6:this.kind==="dust"?.2:.3,d=n.x-i.x,u=-h-i.y,p=n.z-i.z,m=Math.hypot(d,u,p),v=this.enabled&&(this.rain||this.kind==="snow"||this.kind==="dust"||r&&m>20);if(this.seg.visible=v,!v)return;let f=this.rain?a:this.kind==="snow"?900:this.kind==="dust"?500:Math.min(a,Math.floor(m*4)),g=t.x-this.center.x,y=t.y-this.center.y,x=t.z-this.center.z;this.center.copy(t);let _=this.rain?.06:.025+Math.min(m,90)*6e-4;for(let b=0;b<a;b++){let S=o[b*3]+n.x*e-g,R=o[b*3+1]-h*e-y,P=o[b*3+2]+n.z*e-x;this.kind==="snow"&&(S+=Math.sin(b+R*.3)*e),S>l?S-=2*l:S<-l&&(S+=2*l),R>l?R-=2*l:R<-l&&(R+=2*l),P>l?P-=2*l:P<-l&&(P+=2*l),o[b*3]=S,o[b*3+1]=R,o[b*3+2]=P;let C=b*6;if(b<f){c[C]=t.x+S,c[C+1]=t.y+R,c[C+2]=t.z+P;let B=this.kind==="snow"&&m<15?.04:_;c[C+3]=c[C]-d*B,c[C+4]=c[C+1]-u*B,c[C+5]=c[C+2]-p*B}else c[C]=c[C+3]=0,c[C+1]=c[C+4]=-1e5,c[C+2]=c[C+5]=0}this.seg.geometry.attributes.position.needsUpdate=!0}},ja=class{constructor(e){let t=document.createElement("canvas");t.width=t.height=64;let i=t.getContext("2d"),n=i.createRadialGradient(32,32,0,32,32,32);n.addColorStop(0,"rgba(255,255,255,0.9)"),n.addColorStop(1,"rgba(255,255,255,0)"),i.fillStyle=n,i.fillRect(0,0,64,64),this.tex=new vi(t),this.max=400;let r=new Ve;this.pos=new Float32Array(this.max*3),this.col=new Float32Array(this.max*4),this.size=new Float32Array(this.max),r.setAttribute("position",new We(this.pos,3)),r.setAttribute("color",new We(this.col,4)),r.setAttribute("size",new We(this.size,1));let a=new Tt({uniforms:{map:{value:this.tex},scale:{value:600}},transparent:!0,depthWrite:!1,vertexShader:`attribute float size; attribute vec4 color; varying vec4 vC; uniform float scale;
        void main(){ vC = color; vec4 mv = modelViewMatrix * vec4(position,1.0); gl_PointSize = size * scale / max(-mv.z, 0.5); gl_Position = projectionMatrix * mv; }`,fragmentShader:"uniform sampler2D map; varying vec4 vC; void main(){ vec4 t = texture2D(map, gl_PointCoord); gl_FragColor = vec4(vC.rgb, vC.a * t.a); }"});this.points=new is(r,a),this.points.frustumCulled=!1,e.add(this.points),this.parts=[]}emit(e,t,i,n,r,a=1){this.parts.length>=this.max&&this.parts.shift(),this.parts.push({x:e.x,y:e.y,z:e.z,vx:t.x,vy:t.y,vz:t.z,c:i,s:n,life:r,t:0,grow:a})}burst(e,t,i,n,r){for(let a=0;a<i;a++){let o=Math.random()*6.28,l=Math.random()*1.4;this.emit(e,{x:Math.cos(o)*Math.cos(l)*n*Math.random(),y:Math.sin(l)*n*Math.random(),z:Math.sin(o)*Math.cos(l)*n*Math.random()},t,r*(.6+Math.random()*.8),1.2+Math.random()*1.2,2.5)}}clear(){this.parts.length=0}update(e){let t=this.parts;for(let n=t.length-1;n>=0;n--){let r=t[n];if(r.t+=e,r.t>r.life){t.splice(n,1);continue}r.x+=r.vx*e,r.y+=r.vy*e,r.z+=r.vz*e;let a=Math.exp(-1.5*e);r.vx*=a,r.vy=r.vy*a-1*e,r.vz*=a}for(let n=0;n<this.max;n++){let r=t[n];if(r){let a=r.t/r.life;this.pos[n*3]=r.x,this.pos[n*3+1]=r.y,this.pos[n*3+2]=r.z,this.col[n*4]=r.c[0],this.col[n*4+1]=r.c[1],this.col[n*4+2]=r.c[2],this.col[n*4+3]=(1-a)*(r.c[3]??.8),this.size[n]=r.s*(1+a*r.grow)}else this.size[n]=0,this.col[n*4+3]=0}let i=this.points.geometry;i.attributes.position.needsUpdate=!0,i.attributes.color.needsUpdate=!0,i.attributes.size.needsUpdate=!0}};var $c=["armAbdL","armAbdR","armSwL","armSwR","elbL","elbR","legAbdL","legAbdR","legSwL","legSwR","kneeL","kneeR","head","spine"];function Ya(s,e,t,i){let n=new ns((e+t)/2,s-(e+t),4,8);n.rotateX(Math.PI/2),n.translate(0,0,-s/2);let r=new Ce(n,i);return r.castShadow=!0,r}var $a=class{constructor(e,t){this.scene=e,this.root=new Qe,this.body=new Qe,this.root.add(this.body),e.add(this.root),this.mats={suit:new it({color:13777450,roughness:.65}),suit2:new it({color:1908516,roughness:.7}),wing:new it({color:13777450,roughness:.7,side:Xt}),wing2:new it({color:1908516,roughness:.7,side:Xt}),glove:new it({color:1381914,roughness:.8}),boot:new it({color:2434602,roughness:.7}),helmet:new it({color:15921906,roughness:.25,metalness:.2}),visor:new it({color:2238513,roughness:.03,metalness:1}),rig:new it({color:2829619,roughness:.8})};let i=this.mats,n=new Ce(new ns(.15,.36,4,10),i.suit);n.rotation.x=Math.PI/2,n.position.z=.26,n.scale.set(1.25,1,.8),n.castShadow=!0,this.spine=new Qe,this.body.add(this.spine),this.spine.add(n);let r=new Ce(new Ct(.3,.12,.42),i.rig);r.position.set(0,.16,.24),r.castShadow=!0,this.spine.add(r);let a=new Ce(new Ct(.32,.02,.06),i.suit2);a.position.set(0,.11,.42),this.spine.add(a),this.neck=new Qe,this.neck.position.z=.6,this.spine.add(this.neck),this.head=new Qe,this.neck.add(this.head);let o=new Ce(new Ri(.135,20,14),i.helmet);o.position.z=.1,o.scale.set(1,1.05,1.12),o.castShadow=!0,this.head.add(o);let l=new Ce(new Ri(.138,20,10,-Math.PI*.42,Math.PI*.84,Math.PI*.38,Math.PI*.3),i.visor);l.rotation.x=-Math.PI/2,l.position.z=.1,l.scale.set(1.02,1.12,1.07),this.head.add(l),this.helmetMesh=o,this.visorMesh=l,this.arm={};for(let c of["L","R"]){let h=c==="L"?1:-1,d=new Qe;d.position.set(.2*h,0,.5),this.spine.add(d);let u=new Qe;d.add(u),u.add(Ya(.3,.06,.05,i.suit));let p=new Qe;p.position.z=-.3,u.add(p),p.add(Ya(.27,.05,.04,i.suit));let m=new Ce(new Ri(.05,8,6),i.glove);m.position.z=-.3,m.scale.set(.8,.5,1.3),p.add(m);let v=new at;v.position.z=-.27,p.add(v),this.arm[c]={sh:d,sw:u,el:p,wr:v,hand:m}}this.leg={};for(let c of["L","R"]){let h=c==="L"?1:-1,d=new Qe;d.position.set(.1*h,0,0),this.body.add(d);let u=new Qe;d.add(u),u.add(Ya(.45,.08,.06,i.suit2));let p=new Qe;p.position.z=-.45,u.add(p),p.add(Ya(.44,.06,.05,i.suit2));let m=new Qe;m.position.z=-.44,p.add(m);let v=new Ce(new Ct(.1,.24,.08),i.boot);v.position.set(0,-.08,-.03),v.castShadow=!0,m.add(v),this.leg[c]={hp:d,sw:u,kn:p,an:m}}this.wingL=this._membrane(6,4,i.wing),this.wingR=this._membrane(6,4,i.wing),this.tail=this._membrane(6,5,i.wing2),this.body.add(this.wingL.mesh,this.wingR.mesh,this.tail.mesh),this.armpit={L:new at,R:new at},this.armpit.L.position.set(.16,0,.42),this.armpit.R.position.set(-.16,0,.42),this.hipSide={L:new at,R:new at},this.hipSide.L.position.set(.14,0,-.08),this.hipSide.R.position.set(-.14,0,-.08),this.crotch=new at,this.crotch.position.set(0,0,-.05);for(let c of[this.armpit.L,this.armpit.R,this.hipSide.L,this.hipSide.R])this.spine.add(c);this.body.add(this.crotch),this.pose={};for(let c of $c)this.pose[c]=0;this.target={...this.pose},this.t=0,this.flutter=0,this.tension=0,this.buildCanopy(),this.trailColor=null,t&&this.setLook(t)}_membrane(e,t,i){let n=new Ve,r=new Float32Array(e*t*3);n.setAttribute("position",new We(r,3));let a=[];for(let l=0;l<e-1;l++)for(let c=0;c<t-1;c++){let h=l*t+c,d=h+1,u=h+t,p=u+1;a.push(h,u,d,d,u,p)}n.setIndex(a);let o=new Ce(n,i);return o.castShadow=!0,o.frustumCulled=!1,{mesh:o,nu:e,nv:t,pos:r}}buildCanopy(){let n=new Ct(8.2,.45,3,18,1,4),r=n.attributes.position,a=new Float32Array(r.count*3);for(let c=0;c<r.count;c++){let h=r.getX(c),d=r.getY(c),u=r.getZ(c),p=h/8.2*1.25,m=6.5,v=Math.sin(p)*(m+d),f=Math.cos(p)*(m+d)-m,g=1+.6*Math.max(0,u/3);r.setXYZ(c,v,f*g+(u>0?.05:0),u),a[c*3]=a[c*3+1]=a[c*3+2]=1}n.setAttribute("color",new We(a,3)),n.computeVertexNormals(),this.canopyMat=new it({vertexColors:!0,roughness:.6,side:Xt}),this.canopy=new Ce(n,this.canopyMat),this.canopy.castShadow=!0,this.canopyGroup=new Qe,this.canopyGroup.add(this.canopy),this.canopy.position.y=5.2;let o=[];for(let c=0;c<=6;c++){let h=(c/6-.5)*1.25*1,d=Math.sin(h)*6.5,u=5.2+Math.cos(h)*6.5-6.5-.2;for(let p of[1.2,-1.2])o.push(d,u,p,Math.sign(d||.001)*.22,.55,0)}let l=new Ve;l.setAttribute("position",new Te(o,3)),this.lines=new ts(l,new pn({color:4473924,transparent:!0,opacity:.7})),this.canopyGroup.add(this.lines),this.canopyGroup.visible=!1,this.canopyGroup.rotation.x=Math.PI/2,this.root.add(this.canopyGroup),this.canopyOpen=0}setLook(e){let t=this.mats;t.suit.color.set(e.suit[0]),t.wing.color.set(e.suit[0]),t.suit2.color.set(e.suit[1]),t.wing2.color.set(e.suit[1]),t.glove.color.set(e.suit[2]||1381914),t.helmet.color.set(e.helmet[0]),t.helmet.metalness=e.helmet[2]??.2,t.helmet.roughness=e.helmet[3]??.25,t.visor.color.set(e.helmet[1]);let i=e.chute.map(o=>new ye(o)),n=this.canopy.geometry,r=n.attributes.position,a=n.attributes.color;for(let o=0;o<r.count;o++){let l=Math.floor((Math.atan2(r.getX(o),r.getY(o)+6.5)/1.25+.5)*9),c=i[(l%i.length+i.length)%i.length];a.setXYZ(o,c.r,c.g,c.b)}a.needsUpdate=!0,this.trailColor=e.trail||null}_targetPose(e){let t=this.target,i=this.t;for(let n of $c)t[n]=0;switch(e.state){case"idle":{let n=Math.sin(i*1.6)*.03;t.armAbdL=t.armAbdR=.12+n,t.elbL=t.elbR=.25,t.legAbdL=t.legAbdR=.06,t.head=Math.sin(i*.4)*.2,t.armSwL=t.armSwR=.05;break}case"run":{let n=e.runPhase||0,r=e.runSpeed||1,a=Math.sin(n)*.7*r;t.armSwL=-a,t.armSwR=a,t.elbL=t.elbR=1.1,t.armAbdL=t.armAbdR=.15,t.legSwL=a,t.legSwR=-a,t.kneeL=.3+Math.max(0,-Math.sin(n))*1.2*r,t.kneeR=.3+Math.max(0,Math.sin(n))*1.2*r,t.spine=.15*r;break}case"jump":{t.armAbdL=t.armAbdR=1.2,t.armSwL=t.armSwR=.6,t.elbL=t.elbR=.4,t.legSwL=.4,t.legSwR=-.2,t.kneeL=.6,t.kneeR=.4;break}case"flight":{let n=e.wing,r=e.posture||0,a=fe(1.2,1.38+r*.16,n)-Math.max(0,e.pitchIn)*.35*n;t.armAbdL=a+e.bankIn*.12,t.armAbdR=a-e.bankIn*.12,t.elbL=t.elbR=fe(1.2,.12,n)+(r<0?-r*.1:0),t.armSwL=fe(.3,-.12,n)-e.bankIn*.35*n+Math.min(0,e.pitchIn)*-.2,t.armSwR=fe(.3,-.12,n)+e.bankIn*.35*n+Math.min(0,e.pitchIn)*-.2;let o=fe(.35,.36+r*.12,n)-Math.max(0,e.pitchIn)*.12;t.legAbdL=o,t.legAbdR=o,t.kneeL=t.kneeR=fe(1,.05,n),t.legSwL=t.legSwR=fe(-.25,0,n),t.head=fe(.6,.85,n)+e.pitchIn*-.2,t.spine=-.1*n;break}case"canopy":{let n=e.brakeL||0,r=e.brakeR||0;t.armAbdL=2.6-n*1.1,t.armAbdR=2.6-r*1.1,t.elbL=.3+n*.8,t.elbR=.3+r*.8,t.armSwL=t.armSwR=-.1,t.legSwL=.35+Math.sin(i*.9)*.05,t.legSwR=.25+Math.sin(i*.9+1)*.05,t.kneeL=t.kneeR=.35,t.legAbdL=t.legAbdR=.08,t.head=.1;break}case"flare":{t.armAbdL=t.armAbdR=.6,t.elbL=t.elbR=.5,t.armSwL=t.armSwR=-.3,t.legSwL=t.legSwR=.7,t.kneeL=t.kneeR=.4;break}case"landed":{t.armAbdL=t.armAbdR=.5+Math.sin(i*2)*.05,t.elbL=t.elbR=.6,t.legAbdL=t.legAbdR=.1,t.kneeL=t.kneeR=.15,e.celebrate&&(t.armAbdL=t.armAbdR=2.7,t.elbL=t.elbR=.2);break}case"crash":{let n=e.crashT||0;t.armAbdL=1.4+Math.sin(n*7)*.8,t.armAbdR=.9+Math.cos(n*6)*.8,t.elbL=1.2,t.elbR=.4,t.legSwL=Math.sin(n*5)*.8,t.legSwR=Math.cos(n*5)*.8,t.kneeL=1,t.kneeR=.6,t.spine=.3;break}}}animate(e,t){this.t+=e,this._targetPose(t);let i=t.state==="run"?22:t.state==="crash"?14:7;for(let l of $c)this.pose[l]=Je(this.pose[l],this.target[l],i,e);let n=this.pose,r=this.arm,a=this.leg;r.L.sh.rotation.set(0,-n.armAbdL,0),r.R.sh.rotation.set(0,n.armAbdR,0),r.L.sw.rotation.x=-n.armSwL,r.R.sw.rotation.x=-n.armSwR,r.L.el.rotation.x=-n.elbL,r.R.el.rotation.x=-n.elbR,a.L.hp.rotation.set(0,-n.legAbdL,0),a.R.hp.rotation.set(0,n.legAbdR,0),a.L.sw.rotation.x=-n.legSwL,a.R.sw.rotation.x=-n.legSwR,a.L.kn.rotation.x=n.kneeL,a.R.kn.rotation.x=n.kneeR,a.L.an.rotation.x=-.2-n.kneeL*.2,a.R.an.rotation.x=-.2-n.kneeR*.2,this.neck.rotation.x=-n.head,this.spine.rotation.x=-n.spine;let o=t.airspeed||0;if(this.tension=Je(this.tension,(t.state==="flight"?t.wing:0)*de(o/40,0,1),4,e),this.flutter+=e*(8+o*.5),this.body.updateMatrixWorld(!0),this._updateMembranes(o,t),this.canopyGroup.visible=this.canopyOpen>.01,this.canopyGroup.visible){let l=this.canopyOpen;this.canopy.scale.set(fe(.15,1,l),fe(.3,1,l),fe(.25,1,Math.min(1,l*1.3))),this.canopy.position.y=fe(2.5,5.2,l),this.canopy.rotation.z=Math.sin(this.t*13)*.08*(1-l)+(t.canopyBank||0)*.3,this.canopy.rotation.x=-(t.brake||0)*.12,this.lines.visible=l>.4}}_local(e,t){return e.getWorldPosition(t),this.body.worldToLocal(t)}_updateMembranes(e,t){let i=new M,n=f=>f.map(g=>this._local(g,new M)),r=.03+this.tension*.07,a=.006+.01*de(e/60,0,1.5),o=(f,g,y,x)=>{let{nu:_,nv:b,pos:S}=f;for(let R=0;R<_;R++){let P=R/(_-1),C=rd(g,P),B=rd(y,P);for(let z=0;z<b;z++){let D=z/(b-1);i.copy(C).lerp(B,D);let F=Math.sin(Math.PI*D)*Math.sin(Math.PI*Math.min(1,P*1.2+.1))*r,U=Math.sin(this.flutter+R*1.3+z*.7)*a*P;i.y+=F+U;let X=(R*b+z)*3;S[X]=i.x,S[X+1]=i.y,S[X+2]=i.z}}f.mesh.geometry.attributes.position.needsUpdate=!0,f.mesh.geometry.computeVertexNormals()},l=this.arm,c=this.leg,h=n([l.L.sh,l.L.el,l.L.wr]),d=n([l.R.sh,l.R.el,l.R.wr]),u=n([this.armpit.L,this.hipSide.L,c.L.kn]),p=n([this.armpit.R,this.hipSide.R,c.R.kn]);o(this.wingL,h,u),o(this.wingR,d,p);let m=n([c.L.hp,c.L.kn,c.L.an]),v=n([c.R.hp,c.R.kn,c.R.an]);m[0]=this._local(this.crotch,new M).add(new M(.02,0,0)),v[0]=m[0].clone().add(new M(-.04,0,0)),o(this.tail,m,v)}setHeadVisible(e){this.helmetMesh.visible=e,this.visorMesh.visible=e}};function rd(s,e){let t=s.length-1,i=de(e*t,0,t-1e-6),n=Math.floor(i);return s[n].clone().lerp(s[n+1],i-n)}var Za=new Ee,ad=new M,sr=new M,rr=new M;function Pi(s,e,t){let i=Math.sin(s),n=Math.cos(s);return rr.set(i*Math.sin(e),Math.cos(e),n*Math.sin(e)).normalize(),sr.set(-i,0,-n),sr.addScaledVector(rr,-sr.dot(rr)).normalize(),ad.crossVectors(sr,rr),Za.makeBasis(ad,sr,rr),t.setFromRotationMatrix(Za)}function ar(s,e,t,i){return Za.makeBasis(s,e,t),i.setFromRotationMatrix(Za)}var od=9.81,ld=85,vf=1.225,Mt=new M,qt=new M,bt=new M,qi=new M,us=new M,Ja=new M,ds=new $e,yf=new M(0,1,0),ps=new M,or=new M,ms=new M,fs=new M,lr=new M,se={READY:0,RUN:1,FREEFALL:2,WINGSUIT:3,DEPLOY:4,CANOPY:5,LANDED:6,CRASHED:7},Ka=class{constructor(){this.pos=new M,this.vel=new M,this.q=new $e,this.reset({x:0,y:0,z:0,heading:0})}reset(e,t="ready"){this.state=se.READY,this.heading=e.heading,this.pos.set(e.x,e.y,e.z),this.vel.set(0,0,0),Pi(this.heading,0,this.q),this.wing=0,this.wingTarget=0,this.alpha=.22,this.alphaV=0,this.bank=0,this.bankV=0,this.posture=0,this.stability=100,this.instab=0,this.wobA=0,this.wobB=0,this.time=0,this.stateTime=0,this.runDist=0,this.runPhase=0,this.deployT=0,this.canopyOpen=0,this.cHeading=e.heading,this.cBank=0,this.brake=0,this.brakeL=0,this.brakeR=0,this.flareT=0,this.brakeHold=0,this.hardOpening=!1,this.airspeed=0,this.aoa=0,this.lastIn={pitch:0,turn:0,roll:0},this.autoSpreadAt=1.8,this.gust=new M,t==="canopy"&&(this.state=se.CANOPY,this.canopyOpen=1,this.vel.set(Math.sin(this.heading)*10,-4.5,Math.cos(this.heading)*10),Pi(this.heading,0,this.q))}setState(e){this.state=e,this.stateTime=0}startRun(){this.state===se.READY&&this.setState(se.RUN)}spreadWings(){this.state===se.FREEFALL&&(this.wingTarget=1,this.setState(se.WINGSUIT))}deploy(){if(this.state===se.WINGSUIT||this.state===se.FREEFALL){this.hardOpening=this.vel.length()>62,this.setState(se.DEPLOY),this.deployT=0;let e=qi.set(this.vel.x,0,this.vel.z);return this.cHeading=e.lengthSq()>1?Math.atan2(e.x,e.z):this.heading,!0}return!1}step(e,t,i,n){switch(this.time+=e,this.stateTime+=e,this.state){case se.READY:return null;case se.RUN:return this._run(e,n);case se.FREEFALL:case se.WINGSUIT:return this._fly(e,t,i,n);case se.DEPLOY:case se.CANOPY:return this._canopy(e,t,i,n);default:return null}}_run(e,t){let i=de(1.5+this.stateTime*4.5,0,6.5);this.runPhase+=i*e*2.2;let n=Math.sin(this.heading)*i*e,r=Math.cos(this.heading)*i*e;this.pos.x+=n,this.pos.z+=r,this.runDist+=i*e;let a=t.ground(this.pos.x,this.pos.z).h;return a<this.pos.y-1.2||this.runDist>40?(this.vel.set(Math.sin(this.heading)*(i+1),2.6,Math.cos(this.heading)*(i+1)),this.pos.y+=.3,this.setState(se.FREEFALL),"exit"):(this.pos.y=a+.95,Pi(this.heading,.18*i/6.5,this.q),null)}_fly(e,t,i,n){this.state===se.FREEFALL&&this.stateTime>this.autoSpreadAt&&this.spreadWings(),this.wing=Je(this.wing,this.wingTarget,3.2,e);let r=this.wing;ps.copy(this.vel).sub(i);let a=Math.max(ps.length(),.01);this.airspeed=a,Mt.copy(ps).divideScalar(a);let o=t.tuck?-1:t.spread?1:0;this.posture=Je(this.posture,o,3,e);let l=t.stab?1:0,c=t.pitch,h=t.turn,d=t.roll,u=.22-(c>0?c*.19:c*.24),p=h*.72+d*.7;l&&(p*=.6,Math.abs(h)+Math.abs(d)<.1&&(p=0),u=fe(u,.22,.4));let m=1-this.stability/100;this.wobA+=((Math.random()-.5)*2*m-this.wobA*2)*e*3,this.wobB+=((Math.random()-.5)*2*m-this.wobB*2)*e*3,u+=this.wobA*.12+this.gust.y*.004,p+=this.wobB*.25;let v=26,f=9+l*3,g=Math.abs(d)>.1?30:18,y=7.5+l*4;this.alphaV+=(v*(u-this.alpha)-f*this.alphaV)*e,this.alpha+=this.alphaV*e,this.bankV+=(g*(p-this.bank)-y*this.bankV)*e,this.bank+=this.bankV*e,this.bank=de(this.bank,-1.45,1.45),qt.crossVectors(Mt,yf),qt.lengthSq()<.0025&&qt.set(1,0,0).applyQuaternion(this.q).negate(),qt.normalize(),bt.crossVectors(qt,Mt).normalize();let x=Math.cos(this.bank),_=Math.sin(this.bank),b=bt.x*x+qt.x*_,S=bt.y*x+qt.y*_,R=bt.z*x+qt.z*_,P=qt.x*x-bt.x*_,C=qt.y*x-bt.y*_,B=qt.z*x-bt.z*_;bt.set(b,S,R),qt.set(P,C,B);let z=this.alpha,D,F;if(this.state===se.FREEFALL||r<.5){let ce=Math.sin(this.heading),A=Math.cos(this.heading),T=1-de(r*2,0,1);qi.set(ce,-.35,A).normalize(),us.set(0,1,0).addScaledVector(qi,-qi.y).normalize();let k=Mt.x*Math.cos(z)+bt.x*Math.sin(z),O=Mt.y*Math.cos(z)+bt.y*Math.sin(z),L=Mt.z*Math.cos(z)+bt.z*Math.sin(z);ms.set(k,O,L).lerp(qi,T).normalize(),fs.copy(bt).lerp(us,T),fs.addScaledVector(ms,-fs.dot(ms)).normalize(),D=ms,F=fs,this.heading-=(h+d*.5)*e*1.3}else{let ce=Math.cos(z),A=Math.sin(z);ms.set(Mt.x*ce+bt.x*A,Mt.y*ce+bt.y*A,Mt.z*ce+bt.z*A),fs.set(bt.x*ce-Mt.x*A,bt.y*ce-Mt.y*A,bt.z*ce-Mt.z*A),D=ms,F=fs,this.heading=Math.atan2(this.vel.x,this.vel.z)}lr.crossVectors(F,D).normalize(),ar(lr,F,D,ds);let U=fe(2.5,9+l*3,r);this.q.slerp(ds,1-Math.exp(-U*e)),qi.set(0,0,1).applyQuaternion(this.q),us.set(0,1,0).applyQuaternion(this.q);let X=Math.atan2(-Mt.dot(us),Mt.dot(qi));this.aoa=X;let j=vf*Math.exp(-this.pos.y/8500),Z=fe(.62,1.8*(1+.16*this.posture),r),$=X,ue;$<.48?ue=1.5*$:ue=Math.max(.12,.72-($-.48)*1.1),ue=ue*r+.12*Math.sin(2*$)*(1-r);let _e=.055-.015*Math.min(0,this.posture)+.02*Math.max(0,this.posture)+1.2*$*$;$>.6&&(_e=.055+1.2*.36+($-.6)*.9),_e=_e*r+(.95+.25*Math.sin($)**2)*(1-r);let K=.5*j*a*a*Z;Ja.copy(us).addScaledVector(Mt,-us.dot(Mt)),Ja.lengthSq()>1e-6&&Ja.normalize(),or.set(0,-od*ld,0),or.addScaledVector(Ja,K*ue),or.addScaledVector(Mt,-K*_e),lr.set(1,0,0).applyQuaternion(this.q),or.addScaledVector(lr,-Mt.dot(lr)*K*.25),this.vel.addScaledVector(or,e/ld),this.pos.addScaledVector(this.vel,e);let ae=Math.abs(c-this.lastIn.pitch)+Math.abs(h-this.lastIn.turn)+Math.abs(d-this.lastIn.roll);this.lastIn.pitch=c,this.lastIn.turn=h,this.lastIn.roll=d;let pe=ae*6+Math.max(0,Math.abs(this.bank)-.95)*1.6+Math.max(0,$-.46)*4*r*r+Math.abs(this.bankV)*.22*r+this.gust.length()*.05+Math.abs(d)*.25;this.instab=Je(this.instab,pe,3,e);let ge=l?55:22;return this.stability=de(this.stability+(ge*(1-de(this.instab,0,1))-this.instab*70)*e,0,100),this._checkCollision(n)}_canopy(e,t,i,n){if(this.state===se.DEPLOY){this.deployT+=e,this.canopyOpen=de((this.deployT-.4)/1.6,0,1);let m=this.canopyOpen;ps.copy(this.vel).sub(i);let v=ps.length(),f=(.6+9*m*m)*v*.02;return this.vel.addScaledVector(ps,-f*e),this.vel.y-=od*e*(1-m*.8),Pi(this.cHeading,fe(-1.2,.05,m),ds),this.q.slerp(ds,1-Math.exp(-4*e)),this.pos.addScaledVector(this.vel,e),this.deployT>=2&&(this.setState(se.CANOPY),this.hardOpening&&(this.stability=Math.max(20,this.stability-35))),this.airspeed=v,this._checkCollision(n)}let r=t.turn+t.roll*.6;this.brakeL=Je(this.brakeL,de(-r,0,1)+(t.pitch<0?-t.pitch:0),6,e),this.brakeR=Je(this.brakeR,de(r,0,1)+(t.pitch<0?-t.pitch:0),6,e);let a=de(Math.min(this.brakeL,this.brakeR),0,1),o=this.brake;this.brake=a,a-o>.02&&(this.flareT=Math.min(1.6,this.flareT+(a-o)*3.5)),this.flareT=Math.max(0,this.flareT-e),this.brakeHold=a>.85?this.brakeHold+e:Math.max(0,this.brakeHold-e*2);let l=Math.max(0,t.pitch),c=(this.brakeR-this.brakeL)*.95*(1+l*.5);this.cHeading-=c*e,this.cBank=Je(this.cBank,-c*.35,3,e);let h=fe(11,5.5,a)+l*4.5,d=fe(4.6,2.6,a)+l*2.4+Math.abs(c)*2.2;this.flareT>0&&(d-=Math.min(3.2,this.flareT*3)),this.brakeHold>3&&(d+=4),t.stab&&(this.cBank=Je(this.cBank,0,4,e));let u=Math.sin(this.cHeading)*h+i.x,p=Math.cos(this.cHeading)*h+i.z;return this.vel.x=Je(this.vel.x,u,1.4,e),this.vel.z=Je(this.vel.z,p,1.4,e),this.vel.y=Je(this.vel.y,-d+this.gust.y*.3,1.8,e),this.pos.addScaledVector(this.vel,e),Pi(this.cHeading,.05-a*.15,ds),this.q.slerp(ds,1-Math.exp(-5*e)),this.airspeed=Math.hypot(h,d),this.stability=de(this.stability+20*e,0,100),this._checkCollision(n)}_checkCollision(e){let t=this.state===se.CANOPY||this.state===se.DEPLOY,i=t?.5:.75,n=t?qi.copy(this.pos).setY(this.pos.y-.6):this.pos,r=e.collide(n,i);if(!r)return null;let a=e.ground(this.pos.x,this.pos.z);if(this.state===se.CANOPY&&(r.type==="terrain"||r.type==="water"||r.type==="building"&&this.pos.y>r.top-.5)){let l=-this.vel.y,c=Math.hypot(this.vel.x,this.vel.z),h=r.type==="building";this.pos.y=(h?r.top:a.h)+.95;let d={type:"land",vs:l,hs:c,water:r.type==="water"||a.water,roof:h,surface:r.type};return d.hard=l>4.2||c>9,d.crash=l>7.5||c>15,this.vel.set(0,0,0),this.setState(d.crash||d.water?se.CRASHED:se.LANDED),d}let o=this.vel.length();return this.setState(se.CRASHED),{type:"crash",what:r.type,speed:o}}};var Zc=new M,yn=new M,xf=new M,Qa=new $e,i0=new Ee,n0=new Et,Jc=["chase","pilot","cinema"],to={chase:"Chase View",pilot:"Pilot View",cinema:"Cinema View",orbit:"Orbit"},eo=class{constructor(e){this.cam=e,this.view="chase",this.lookYaw=0,this.lookPitch=0,this.pos=new M,this.target=new M,this.dist=7,this.fov=70,this.shakeT=0,this.roll=0,this.cine={shot:0,t:0,anchor:new M,kind:"orbit"},this.orbit={yaw:0,pitch:.25,dist:14},this.settings={shake:1,fov:70},this.impulse=0,this.lastInput=0}setView(e){this.view=e,this.cine.t=99}cycle(){let e=Jc.indexOf(this.view);return this.setView(Jc[(e+1)%Jc.length]),this.view}look(e,t){this.lookYaw=de(this.lookYaw-e,-Math.PI,Math.PI),this.lookPitch=de(this.lookPitch-t,-1.2,1.2),this.lastInput=0}kick(e){this.impulse=Math.max(this.impulse,e)}update(e,t,i,n){this.lastInput+=e,this.lastInput>1.2&&n!=="orbit"&&(this.lookYaw=Je(this.lookYaw,0,2.5,e),this.lookPitch=Je(this.lookPitch,0,2.5,e));let r=t.vel.length(),a=n==="orbit"?"orbit":this.view,o=this.settings.fov+de((r-25)/60,0,1)*10,l=this.cam,c=Zc.copy(t.vel);if(c.lengthSq()<1&&c.set(Math.sin(t.heading),0,Math.cos(t.heading)),c.normalize(),a==="orbit"){let u=this.orbit;u.yaw+=e*.06*(this.lastInput>2?1:0);let p=(t.heading||0)+Math.PI+u.yaw+this.lookYaw,m=de(u.pitch+this.lookPitch*.5,-.2,1.3),v=yn.copy(t.pos);v.y+=.6,this.target.lerp(v,1-Math.exp(-6*e)),l.position.set(this.target.x+Math.sin(p)*Math.cos(m)*u.dist,this.target.y+Math.sin(m)*u.dist,this.target.z+Math.cos(p)*Math.cos(m)*u.dist);let f=i.ground(l.position.x,l.position.z).h;l.position.y<f+1.5&&(l.position.y=f+1.5),l.up.set(0,1,0),l.lookAt(this.target),o=this.settings.fov}else if(a==="chase"){let u=t.canopy,p=u?13:fe(4.6,6.2,de((r-20)/50,0,1)),m=u?2.5:1.1,v=Math.atan2(c.x,c.z)+this.lookYaw,f=de(Math.asin(de(c.y,-1,1))*.75-this.lookPitch*.8,-1.25,.9),g=Math.sin(v)*Math.cos(f),y=Math.sin(f),x=Math.cos(v)*Math.cos(f),_=yn.set(t.pos.x-g*p,t.pos.y-y*p+m,t.pos.z-x*p),b=i.ground(_.x,_.z).h;_.y<b+2&&(_.y=b+2);let S=1-Math.exp(-(u?3:7)*e);this.pos.distanceToSquared(_)>2500?this.pos.copy(_):this.pos.lerp(_,S),l.position.copy(this.pos);let R=xf.copy(t.pos).addScaledVector(c,u?2:8);R.y+=u?2.5:.8,this.target.distanceToSquared(R)>900?this.target.copy(R):this.target.lerp(R,1-Math.exp(-12*e)),this.roll=Je(this.roll,(t.bank||0)*.35,3,e),l.up.set(0,1,0),l.lookAt(this.target),l.rotateZ(-this.roll)}else if(a==="pilot"){let u=yn.set(0,.08,.72).applyQuaternion(t.q).add(t.pos);l.position.copy(u);let p=Zc.set(0,1,0).applyQuaternion(t.q),m;t.canopy||t.standing?(m=new M(Math.sin(t.heading),-.25,Math.cos(t.heading)).normalize(),p.set(0,1,0)):m=new M(0,0,1).applyQuaternion(t.q).lerp(new M().copy(t.vel).normalize(),.6).normalize(),Qa.setFromAxisAngle(p,this.lookYaw),m.applyQuaternion(Qa);let v=new M().crossVectors(m,p).normalize();Qa.setFromAxisAngle(v,this.lookPitch),m.applyQuaternion(Qa),l.up.copy(p),l.lookAt(Zc.copy(u).add(m)),o+=6}else if(a==="cinema"){let u=this.cine;if(u.t+=e,u.t>5||u.force){if(u.force=!1,u.t=0,u.shot=(u.shot+1)%4,u.kind=["side","tripod","orbit","high"][u.shot],u.kind==="tripod"){let v=new M(-c.z,0,c.x).normalize();u.anchor.copy(t.pos).addScaledVector(t.vel,3.2).addScaledVector(v,18*(Math.random()<.5?-1:1)),u.anchor.y+=6;let f=i.ground(u.anchor.x,u.anchor.z).h;u.anchor.y<f+3&&(u.anchor.y=f+3)}u.seed=Math.random()<.5?-1:1}let p;if(u.kind==="side"){let v=new M(-c.z,0,c.x).normalize().multiplyScalar(9*u.seed);p=yn.copy(t.pos).add(v).addScaledVector(c,2-u.t*.6),p.y+=1.5}else if(u.kind==="tripod")p=yn.copy(u.anchor);else if(u.kind==="orbit"){let v=u.t*.5*u.seed;p=yn.set(t.pos.x+Math.sin(v)*11,t.pos.y+3,t.pos.z+Math.cos(v)*11)}else p=yn.copy(t.pos).addScaledVector(c,-30).add(new M(0,22,0));let m=i.ground(p.x,p.z).h;p.y<m+2&&(p.y=m+2),u.t<.05?this.pos.copy(p):this.pos.lerp(p,1-Math.exp(-5*e)),l.position.copy(this.pos),this.target.distanceToSquared(t.pos)>900?this.target.copy(t.pos):this.target.lerp(t.pos,1-Math.exp(-10*e)),l.up.set(0,1,0),l.lookAt(this.target),o=u.kind==="tripod"?40+de(this.pos.distanceTo(t.pos)/4,0,30):60}let h=this.settings.shake*(de((r-35)/50,0,1)*.006+(t.turbulence||0)*.004+this.impulse*.05);this.impulse=Je(this.impulse,0,4,e),h>0&&a!=="orbit"&&(this.shakeT+=e*30,l.rotateX(Math.sin(this.shakeT*1.3)*h+Math.sin(this.shakeT*2.9)*h*.5),l.rotateY(Math.sin(this.shakeT*1.7+1)*h)),this.fov=Je(this.fov,o,3,e),Math.abs(l.fov-this.fov)>.05&&(l.fov=this.fov,l.updateProjectionMatrix());let d=a==="pilot"?.12:.8;l.near!==d&&(l.near=d,l.updateProjectionMatrix())}flyover(e,t,i){let n=t.route,r=e*n.L,a=n.line.at(r),o=n.routeY(r)+60+Math.sin(e*Math.PI)*120,l=80;this.cam.position.set(a.x-a.dz*l,o,a.z+a.dx*l);let c=i.ground(this.cam.position.x,this.cam.position.z).h;this.cam.position.y<c+20&&(this.cam.position.y=c+20);let h=n.line.at(r+220);this.cam.up.set(0,1,0),this.cam.lookAt(h.x,n.routeY(r+220),h.z),this.cam.near!==.8&&(this.cam.near=.8,this.cam.updateProjectionMatrix())}};var io=class{constructor(){this.ctx=null,this.ready=!1,this.vol={master:.8,music:.5,sfx:.8},this.muteReasons=new Set,this.amb=null,this.mapKind=null,this.music={intensity:0,next:0,step:0,chord:0,on:!0},this.flight={speed:0,tension:0,active:!1,near:0};let e=()=>this.unlock();["pointerdown","keydown","touchend","click"].forEach(t=>window.addEventListener(t,e,{passive:!0}))}unlock(){try{this.ctx||this._init(),this.ctx&&this.ctx.state!=="running"&&this.ctx.resume()}catch{}}_init(){let e=window.AudioContext||window.webkitAudioContext;if(!e)return;let t=this.ctx=new e;this.master=t.createGain(),this.master.connect(t.destination),this.musicBus=t.createGain(),this.musicBus.connect(this.master),this.sfxBus=t.createGain(),this.sfxBus.connect(this.master),this.ambBus=t.createGain(),this.ambBus.connect(this.master);let i=t.sampleRate*2;this.white=t.createBuffer(1,i,t.sampleRate),this.brown=t.createBuffer(1,i,t.sampleRate);let n=this.white.getChannelData(0),r=this.brown.getChannelData(0),a=0;for(let o=0;o<i;o++)n[o]=Math.random()*2-1,a=(a+.02*n[o])/1.02,r[o]=a*3.5;this.wind={body:this._noiseChain("white","bandpass",400,.7),whistle:this._noiseChain("white","bandpass",2200,9),rumble:this._noiseChain("brown","lowpass",160,.7),flutter:this._noiseChain("white","bandpass",900,1.5)},this.flutLfo=t.createOscillator(),this.flutLfoGain=t.createGain(),this.flutLfo.frequency.value=14,this.flutLfoGain.gain.value=0,this.flutLfo.connect(this.flutLfoGain),this.flutLfoGain.connect(this.wind.flutter.gain.gain),this.flutLfo.start();for(let o in this.wind)this.wind[o].gain.connect(this.sfxBus);this.musicFilter=t.createBiquadFilter(),this.musicFilter.type="lowpass",this.musicFilter.frequency.value=900,this.musicFilter.connect(this.musicBus),this.delay=t.createDelay(1),this.delay.delayTime.value=.42,this.fb=t.createGain(),this.fb.gain.value=.35,this.delay.connect(this.fb),this.fb.connect(this.delay),this.delay.connect(this.musicBus),this.ready=!0,this.applyVolumes(),this.mapKind&&this.setAmbient(this.mapKind)}_noiseChain(e,t,i,n){let r=this.ctx,a=r.createBufferSource();a.buffer=e==="brown"?this.brown:this.white,a.loop=!0,a.playbackRate.value=.9+Math.random()*.2;let o=r.createBiquadFilter();o.type=t,o.frequency.value=i,o.Q.value=n;let l=r.createGain();return l.gain.value=0,a.connect(o),o.connect(l),a.start(0,Math.random()*1.5),{src:a,filter:o,gain:l}}setVolumes(e){Object.assign(this.vol,e),this.applyVolumes()}mute(e,t){t?this.muteReasons.add(e):this.muteReasons.delete(e),this.applyVolumes()}applyVolumes(){if(!this.ready)return;let e=this.ctx.currentTime,t=this.muteReasons.size?0:this.vol.master;this.master.gain.setTargetAtTime(t,e,.05),this.musicBus.gain.setTargetAtTime(this.vol.music*.5,e,.1),this.sfxBus.gain.setTargetAtTime(this.vol.sfx,e,.1),this.ambBus.gain.setTargetAtTime(this.vol.sfx*.7,e,.1)}setAmbient(e){if(this.mapKind=e,!this.ready)return;if(this.amb)for(let n of this.amb.nodes)try{n.gain.gain.setTargetAtTime(0,this.ctx.currentTime,.3),setTimeout(()=>n.src.stop(),1500)}catch{}let t=[],i=(n,r,a,o,l)=>{let c=this._noiseChain(n,r,a,o);return c.gain.connect(this.ambBus),c.gain.gain.setTargetAtTime(l,this.ctx.currentTime,1),c.base=l,t.push(c),c};if(e==="mountain"&&(i("brown","lowpass",380,.5,.25),i("white","bandpass",5200,.6,.012)),e==="desert"&&(i("brown","lowpass",300,.6,.2),i("white","bandpass",700,.4,.02)),e==="coast"){let n=i("brown","lowpass",700,.5,.25),r=this.ctx.createOscillator(),a=this.ctx.createGain();r.frequency.value=.11,a.gain.value=.18,r.connect(a),a.connect(n.gain.gain),r.start(),i("white","highpass",3e3,.5,.01)}if(e==="city"){i("brown","lowpass",190,.7,.35),i("white","bandpass",1100,.6,.012);let n=this.ctx.createOscillator();n.type="sawtooth",n.frequency.value=58;let r=this.ctx.createBiquadFilter();r.type="lowpass",r.frequency.value=140;let a=this.ctx.createGain();a.gain.value=.02,n.connect(r),r.connect(a),a.connect(this.ambBus),n.start(),t.push({src:n,gain:a,base:.02})}this.amb={kind:e,nodes:t,nextEvent:this.ctx.currentTime+3}}_ambEvent(){let e=this.ctx,t=e.currentTime,i=this.amb.kind,n=(r,a,o,l,c="sine",h=0)=>{let d=e.createOscillator(),u=e.createGain();if(d.type=c,d.frequency.setValueAtTime(r,t),d.frequency.exponentialRampToValueAtTime(a,t+o),h){let m=e.createOscillator(),v=e.createGain();m.frequency.value=h,v.gain.value=r*.04,m.connect(v),v.connect(d.frequency),m.start(t),m.stop(t+o)}u.gain.setValueAtTime(0,t),u.gain.linearRampToValueAtTime(l,t+.02),u.gain.exponentialRampToValueAtTime(1e-4,t+o);let p=e.createStereoPanner?e.createStereoPanner():null;p?(p.pan.value=Math.random()*1.6-.8,d.connect(u),u.connect(p),p.connect(this.ambBus)):(d.connect(u),u.connect(this.ambBus)),d.start(t),d.stop(t+o+.05)};if(i==="mountain")for(let r=0;r<3;r++)setTimeout(()=>this.ready&&n(2600+Math.random()*900,3400,.09,.03),r*140);i==="desert"&&n(2e3,1300,1.1,.025,"sine",18),i==="coast"&&n(1500,1050,.45,.03,"triangle",9),i==="city"&&(Math.random()<.4?[392,494].forEach(r=>{let a=e.createOscillator(),o=e.createGain();a.type="square",a.frequency.value=r,o.gain.setValueAtTime(.008,t),o.gain.setTargetAtTime(0,t+.35,.05),a.connect(o),o.connect(this.ambBus),a.start(t),a.stop(t+.6)}):this.noiseHit(.9,400,1400,.03,this.ambBus))}update(e,t){if(!this.ready)return;let i=this.ctx.currentTime,n=t.flying?t.speed:0,r=de(n/85,0,1.3),a=this.wind;a.body.gain.gain.setTargetAtTime(t.flying?.04+r*r*.55:.02,i,.08),a.body.filter.frequency.setTargetAtTime(250+r*1300,i,.1),a.whistle.gain.gain.setTargetAtTime(t.flying?Math.max(0,r-.35)*.12:0,i,.1),a.whistle.filter.frequency.setTargetAtTime(1600+r*2400+(t.turb||0)*300,i,.1),a.rumble.gain.gain.setTargetAtTime(t.flying?r*.5:0,i,.1);let o=t.flying?(t.tension||0)*.08:0;if(a.flutter.gain.gain.setTargetAtTime(o*.4,i,.1),this.flutLfoGain.gain.setTargetAtTime(o*.5,i,.1),this.flutLfo.frequency.setTargetAtTime(9+r*26,i,.2),this.amb){let l=de(1-(t.agl||0)/400,.15,1);for(let c of this.amb.nodes)c.gain.gain.setTargetAtTime(c.base*l*(t.flying&&r>.5?.6:1),i,.5);i>this.amb.nextEvent&&(this.amb.nextEvent=i+4+Math.random()*9,l>.3&&this._ambEvent())}this._music(t.intensity||0)}_music(e){let t=this.music,i=this.ctx;if(t.intensity=fe(t.intensity,e,.02),this.musicFilter.frequency.setTargetAtTime(500+t.intensity*2600,i.currentTime,.5),!t.on)return;let n=[[57,60,64,69],[53,57,60,65],[48,55,60,64],[55,59,62,67]],r=i.currentTime;if(r+.15<t.next)return;let a=Math.max(r+.05,t.next),o=4.8,l=n[t.chord%n.length];t.chord++,t.next=a+o;let c=u=>440*Math.pow(2,(u-69)/12);for(let u of l)for(let p of[-6,6]){let m=i.createOscillator(),v=i.createGain();m.type="sawtooth",m.frequency.value=c(u-12),m.detune.value=p,v.gain.setValueAtTime(0,a),v.gain.linearRampToValueAtTime(.018,a+1.6),v.gain.linearRampToValueAtTime(.014,a+o-.6),v.gain.linearRampToValueAtTime(0,a+o+.4),m.connect(v),v.connect(this.musicFilter),m.start(a),m.stop(a+o+.5)}let h=i.createOscillator(),d=i.createGain();if(h.type="triangle",h.frequency.value=c(l[0]-24),d.gain.setValueAtTime(0,a),d.gain.linearRampToValueAtTime(.05+t.intensity*.04,a+.3),d.gain.linearRampToValueAtTime(0,a+o),h.connect(d),d.connect(this.musicFilter),h.start(a),h.stop(a+o+.1),t.intensity>.35){let p=o/16;for(let m=0;m<16;m++){let v=l[m*3%l.length]+(m%8>=4?12:0),f=i.createOscillator(),g=i.createGain();f.type="square",f.frequency.value=c(v);let y=a+m*p;g.gain.setValueAtTime(0,y),g.gain.linearRampToValueAtTime(.012*t.intensity,y+.01),g.gain.exponentialRampToValueAtTime(1e-4,y+p*.9),f.connect(g),g.connect(this.musicFilter),g.connect(this.delay),f.start(y),f.stop(y+p)}}if(t.intensity>.6)for(let u=0;u<8;u++){let p=a+u*o/8,m=i.createOscillator(),v=i.createGain();m.frequency.setValueAtTime(110,p),m.frequency.exponentialRampToValueAtTime(40,p+.15),v.gain.setValueAtTime(.09*t.intensity,p),v.gain.exponentialRampToValueAtTime(1e-4,p+.2),m.connect(v),v.connect(this.musicBus),m.start(p),m.stop(p+.25)}}tone(e,t,i=.2,n="sine",r=0,a=null){if(!this.ready)return;let o=this.ctx,l=o.currentTime+r,c=o.createOscillator(),h=o.createGain();c.type=n,c.frequency.setValueAtTime(e,l),a&&c.frequency.exponentialRampToValueAtTime(a,l+t),h.gain.setValueAtTime(0,l),h.gain.linearRampToValueAtTime(i,l+.01),h.gain.exponentialRampToValueAtTime(1e-4,l+t),c.connect(h),h.connect(this.sfxBus),c.start(l),c.stop(l+t+.05)}noiseHit(e,t,i,n,r){if(!this.ready)return;let a=this.ctx,o=a.currentTime,l=a.createBufferSource();l.buffer=this.white;let c=a.createBiquadFilter();c.type="bandpass",c.Q.value=1.2,c.frequency.setValueAtTime(t,o),c.frequency.exponentialRampToValueAtTime(i,o+e);let h=a.createGain();h.gain.setValueAtTime(n,o),h.gain.exponentialRampToValueAtTime(1e-4,o+e),l.connect(c),c.connect(h),h.connect(r||this.sfxBus),l.start(o,Math.random()),l.stop(o+e+.05)}play(e){switch(e){case"click":this.tone(1200,.05,.06,"triangle");break;case"gate":this.tone(880,.18,.15,"triangle"),this.tone(1320,.3,.13,"triangle",.08);break;case"gatePerfect":this.tone(880,.15,.15,"triangle"),this.tone(1320,.15,.13,"triangle",.07),this.tone(1760,.4,.12,"triangle",.14);break;case"miss":this.tone(220,.35,.15,"sawtooth",0,140);break;case"warn":this.tone(880,.08,.07,"square");break;case"warnHigh":this.tone(1200,.06,.09,"square"),this.tone(1200,.06,.09,"square",.1);break;case"wings":this.noiseHit(.5,300,2500,.25);break;case"jump":this.noiseHit(.25,600,200,.15);break;case"deploy":this.noiseHit(.4,3e3,500,.3),setTimeout(()=>{this.noiseHit(.6,200,80,.6),this.tone(90,.3,.3,"sine",0,45)},900);break;case"land":this.tone(110,.3,.35,"sine",0,45),this.noiseHit(.3,500,150,.2);break;case"crash":this.noiseHit(1.2,1200,60,.7),this.tone(70,.8,.5,"sine",0,30);break;case"splash":this.noiseHit(1.4,2500,300,.6);break;case"finish":[523,659,784,1046].forEach((t,i)=>this.tone(t,.5,.12,"triangle",i*.12));break;case"fail":[392,330,262].forEach((t,i)=>this.tone(t,.45,.12,"triangle",i*.16));break;case"coin":this.tone(1320,.08,.1,"square"),this.tone(1760,.2,.1,"square",.07);break}}};var no=class{constructor(e){this.renderer=e,this.enabled=!0,this.rt=new si(4,4,{samples:4,type:vn}),this.scene=new Wi,this.cam=new Qn(-1,1,1,-1,0,1),this.uniforms={tDiffuse:{value:this.rt.texture},uBlur:{value:0},uDanger:{value:0},uDistort:{value:.03},uFade:{value:0}};let t=new Tt({uniforms:this.uniforms,depthTest:!1,depthWrite:!1,vertexShader:"varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }",fragmentShader:`
        uniform sampler2D tDiffuse; uniform float uBlur, uDanger, uDistort, uFade; varying vec2 vUv;
        void main(){
          vec2 c = vUv - 0.5;
          float r2 = dot(c,c);
          vec2 uv = 0.5 + c * (1.0 - uDistort * r2);
          vec3 col = texture2D(tDiffuse, uv).rgb;
          if (uBlur > 0.001) {
            vec3 acc = col; float w = 1.0;
            for (int i = 1; i <= 6; i++) {
              float k = float(i) / 6.0;
              vec2 o = (uv - 0.5) * (1.0 - uBlur * k * 0.06 * smoothstep(0.02, 0.25, r2));
              acc += texture2D(tDiffuse, 0.5 + o).rgb; w += 1.0;
            }
            col = acc / w;
          }
          float vig = smoothstep(0.85, 0.2, length(c * vec2(1.0, 0.85)));
          col *= mix(0.72, 1.0, vig);
          col = mix(col, vec3(0.9, 0.05, 0.02), uDanger * (1.0 - vig) * 0.55);
          col = mix(col, vec3(0.0), uFade);
          gl_FragColor = vec4(col, 1.0);
          #include <tonemapping_fragment>
          #include <colorspace_fragment>
        }`}),i=new Ce(new Gt(2,2),t);i.frustumCulled=!1,this.scene.add(i)}setSize(e,t){this.rt.setSize(e,t)}render(e,t){let i=this.renderer;if(!this.enabled){i.setRenderTarget(null),i.render(e,t);return}i.setRenderTarget(this.rt),i.render(e,t),i.setRenderTarget(null),i.render(this.scene,this.cam)}};var _f=[{id:"ember",name:"Ember",suit:["#d23a2a","#1d1f24","#15161a"],price:0},{id:"glacier",name:"Glacier",suit:["#e8f1f8","#2a6fb0","#1b2533"],price:150},{id:"fox",name:"Desert Fox",suit:["#d98b3a","#4a3020","#2b1d14"],price:250},{id:"neon",name:"Neon Volt",suit:["#c6ff2e","#141414","#141414"],price:400},{id:"ocean",name:"Deep Ocean",suit:["#1f9fc0","#0d2b45","#0d1b25"],price:600},{id:"stealth",name:"Stealth",suit:["#34373e","#111214","#0a0a0a"],price:800},{id:"tiger",name:"Tiger Stripe",suit:["#ff8c1a","#141414","#141414"],req:{rank:"gold",count:3}},{id:"aurora",name:"Aurora",suit:["#7a3cff","#1fe0c0","#101018"],req:{rank:"platinum",count:3}}],Mf=[{id:"white",name:"Classic White",helmet:["#f2f2f2","#222831",.2,.25],price:0},{id:"carbon",name:"Carbon",helmet:["#2a2a2e","#4a3a18",.5,.35],price:120},{id:"flame",name:"Flame Orange",helmet:["#ff5a1a","#30200a",.3,.2],price:220},{id:"sky",name:"Sky Blue",helmet:["#5ab4ff","#101a2a",.3,.2],price:300},{id:"chrome",name:"Chrome",helmet:["#e6eaf0","#1a1f2a",1,.06],price:500},{id:"gold",name:"Gold Visor",helmet:["#d4a437","#7a5a10",1,.12],req:{rank:"perfect",count:1}}],bf=[{id:"sunset",name:"Sunset",chute:["#ff6a1a","#ffd23f","#ff6a1a","#ffffff"],price:0},{id:"ice",name:"Ice",chute:["#ffffff","#5ab4ff","#ffffff","#1d4f8a"],price:100},{id:"jungle",name:"Jungle",chute:["#2e8b3a","#d9e05a","#1d4a22"],price:200},{id:"royal",name:"Royal",chute:["#5a2ea6","#ffd23f","#5a2ea6","#ffffff"],price:350},{id:"mono",name:"Monochrome",chute:["#111111","#ffffff"],price:450},{id:"rainbow",name:"Rainbow",chute:["#ff3b3b","#ff9f1a","#ffe23f","#3bd65a","#3b8bff","#8a3bff"],req:{missions:9}}],Sf=[{id:"none",name:"No Trail",trail:null,price:0},{id:"white",name:"White Smoke",trail:[.95,.95,.95,.55],price:200},{id:"crimson",name:"Crimson Smoke",trail:[.9,.15,.15,.6],price:300},{id:"azure",name:"Azure Smoke",trail:[.2,.55,1,.6],price:300},{id:"gold",name:"Golden Sparks",trail:[1,.8,.3,.8],req:{rank:"platinum",count:1}},{id:"rainbow",name:"Prism",trail:"rainbow",req:{missions:12}}],hr={suit:_f,helmet:Mf,chute:bf,trail:Sf},Kc=[{id:"perfect",name:"Perfect",min:950,color:"#7af0ff"},{id:"platinum",name:"Platinum",min:800,color:"#d9e4f0"},{id:"gold",name:"Gold",min:600,color:"#ffc93c"},{id:"silver",name:"Silver",min:400,color:"#c0c6cf"},{id:"bronze",name:"Bronze",min:0,color:"#d08a4a"}],Qc=["bronze","silver","gold","platinum","perfect"],ud=s=>Kc.find(e=>s>=e.min),jt={free:{id:"free",name:"Free Flight",desc:"Explore freely. No gates, no timer. Practice maneuvers and canopy landings."},mission:{id:"mission",name:"Flight Missions",desc:"Structured challenges with gates, time limits and score targets."},speed:{id:"speed",name:"Speed Run",desc:"Fly the route through every gate as fast as possible. Timer stops at the finish gate."},precision:{id:"precision",name:"Precision Flight",desc:"Thread small gates dead-center with smooth, stable flight."},landing:{id:"landing",name:"Landing Trials",desc:"Start under an open canopy and land inside the target zone."}},Ot=[{id:"m1",name:"First Exit",map:"skyfall",mode:"mission",time:"midday",weather:"clear",gates:{n:4,r:22,shapes:["ring"]},limit:220,maxMiss:2,tutorial:!0,desc:"Your first BASE jump. Spread the wings, fly through big gates and land in the clearing."},{id:"m2",name:"Valley Run",map:"skyfall",mode:"speed",time:"morning",weather:"clear",gates:{n:6,r:18,shapes:["ring","rect"]},limit:200,maxMiss:1,par:1,desc:"Race down the valley. Dive to build speed but keep enough height to reach the finish."},{id:"m3",name:"Needle's Eye",map:"skyfall",mode:"precision",time:"morning",weather:"lightfog",gates:{n:8,r:10,shapes:["ring","slot","ring"]},limit:240,maxMiss:2,desc:"Narrow gates through the mountain gaps in light fog."},{id:"m4",name:"Canyon Gate",map:"redstone",mode:"mission",time:"midday",weather:"clear",gates:{n:6,r:16,shapes:["ring","rect"]},limit:220,maxMiss:1,desc:"Drop off the butte and follow the winding red canyon."},{id:"m5",name:"Arch Hunter",map:"redstone",mode:"precision",time:"sunset",weather:"clear",gates:{n:7,r:11,shapes:["rect","ring"]},limit:220,maxMiss:1,desc:"Fly beneath both natural arches without touching stone."},{id:"m6",name:"Red Line",map:"redstone",mode:"speed",time:"sunset",weather:"windy",gates:{n:8,r:17,shapes:["ring"]},limit:200,maxMiss:1,desc:"Gusty speed run through the narrows."},{id:"m7",name:"Sea Stacks",map:"tidal",mode:"mission",time:"morning",weather:"clear",gates:{n:6,r:15,shapes:["ring","slot"]},limit:220,maxMiss:1,desc:"Weave between the sea stacks and land on the beach."},{id:"m8",name:"Low Tide",map:"tidal",mode:"speed",time:"midday",weather:"clouds",gates:{n:7,r:16,shapes:["ring","rect"]},limit:200,maxMiss:1,desc:"Skim the waves at full speed along the coastline."},{id:"m9",name:"Beach Drop",map:"tidal",mode:"landing",time:"sunset",weather:"windy",limit:180,desc:"Gusty sea breeze. Put the canopy down on the beach target."},{id:"m10",name:"Rooftop Exit",map:"metro",mode:"mission",time:"midday",weather:"clear",gates:{n:6,r:14,shapes:["ring","rect"]},limit:220,maxMiss:1,desc:"Leap from the Spire and carve down the avenues to the park."},{id:"m11",name:"Avenue Rush",map:"metro",mode:"speed",time:"sunset",weather:"clear",gates:{n:8,r:15,shapes:["ring"]},limit:200,maxMiss:1,desc:"Sunset speed run between the glass towers."},{id:"m12",name:"Skybridge",map:"metro",mode:"precision",time:"overcast",weather:"rain",gates:{n:8,r:10,shapes:["rect","slot","ring"]},limit:240,maxMiss:1,desc:"Rain, wind and skybridges. Precision under pressure."}],ur={skyfall:0,redstone:2,tidal:5,metro:8};function eh(s){return s==="speed"?{n:7,r:17,shapes:["ring"]}:s==="precision"?{n:8,r:10,shapes:["ring","slot","rect"]}:{n:6,r:16,shapes:["ring","rect"]}}function oo(s,e){let t=s.helipad?{x:s.helipad.x,y:s.helipad.h,z:s.helipad.z,r:22}:{x:s.landing.x,y:s.landing.y,z:s.landing.z,r:s.landing.r*.6},i=t.y+(s.helipad?330:380),n=s.helipad?480:520,r=s.wind.dir+Math.PI,a=null;for(let o=0;o<16;o++){let l=r+(o%2?1:-1)*Math.ceil(o/2)*(Math.PI/8),c=t.x+Math.sin(l)*n,h=t.z+Math.cos(l)*n,d=!0;if(e)for(let u=.15;u<=1;u+=.05){let p=t.x+(c-t.x)*u,m=t.z+(h-t.z)*u,v=t.y+(i-t.y)*u*.55;if(e.ground(p,m).h>v-25){d=!1;break}}if(d){a={sx:c,sz:h};break}}return a||(a={sx:t.x+Math.sin(r)*n,sz:t.z+Math.cos(r)*n}),{start:{x:a.sx,y:i,z:a.sz,heading:Math.atan2(t.x-a.sx,t.z-a.sz)},target:t}}var cr=class{constructor(e,t,i,n,r){if(this.scene=e,this.group=new Qe,e.add(this.group),this.list=[],this.next=0,this.mode=r,!n)return;let a=i.route,o=n.n,l=.11,c=r==="speed"?.74:.7,h=[];if(i.arches)for(let d of i.arches)h.push(d.s);if(i.bridgeSpecs)for(let d of i.bridgeSpecs)h.push(d.s);for(let d=0;d<o;d++){let u=fe(l,c,o===1?.5:d/(o-1));for(let z of h)Math.abs(z-u)<.5/o&&(u=z);let p=u*a.L,m=a.line.at(p),v=a.routeY(p),f=(a.routeY(p+20)-a.routeY(p-20))/40,g=new M(m.dx,f,m.dz).normalize(),y=new M().crossVectors(g,new M(0,1,0)).normalize(),x=0;r==="precision"&&!h.some(z=>Math.abs(z-u)<.01)&&(x=(d%2?1:-1)*9);let _=n.shapes[d%n.shapes.length],b=_==="slot"?{w:n.r*.7,h:n.r*2.4}:_==="rect"?{w:n.r*2.2,h:n.r*1.3}:{r:n.r},S=new M(m.x,v,m.z).addScaledVector(y,x),R=b.r||b.h/2,P=t.ground(S.x,S.z).h;S.y-R<P+6&&(S.y=P+R+6);let C=new M().crossVectors(y,g).normalize(),B={c:S,dir:g,right:y,up:C,shape:_,size:b,s:p,state:"pending",acc:0};B.mesh=this._mesh(B),this.group.add(B.mesh),this.list.push(B)}this.finishIndex=this.list.length-1,this.prev=new M,this.t=0}_mesh(e){let t=new it({color:16747034,emissive:16738816,emissiveIntensity:1.2,roughness:.4,transparent:!0,opacity:.95}),i;if(e.shape==="ring")i=new Ce(new gn(e.size.r,Math.max(.45,e.size.r*.045),10,48),t);else{let a=e.size.w,o=e.size.h,l=Math.max(.5,Math.min(a,o)*.05);i=new Qe;let c=new Ct(a+l*2,l,l),h=new Ct(l,o,l),d=new Ce(c,t);d.position.y=o/2+l/2;let u=new Ce(c,t);u.position.y=-o/2-l/2;let p=new Ce(h,t);p.position.x=-a/2-l/2;let m=new Ce(h,t);m.position.x=a/2+l/2,i.add(d,u,p,m)}let n=new Ee().makeBasis(e.right.clone().negate(),e.up,e.dir);i.quaternion.setFromRotationMatrix(n),i.position.copy(e.c),i.userData.mat=t;let r=new Ce(e.shape==="ring"?new $s(e.size.r,32):new Gt(e.size.w,e.size.h),new oi({color:16756800,transparent:!0,opacity:.08,depthWrite:!1,side:Xt,blending:Oa}));return i.add(r),i.userData.disc=r,i}get total(){return this.list.length}get passed(){return this.list.filter(e=>e.state==="passed").length}get missed(){return this.list.filter(e=>e.state==="missed").length}reset(){for(let e of this.list)e.state="pending",e.acc=0;this.next=0}check(e,t){let i=[];for(let n=this.next;n<Math.min(this.list.length,this.next+3);n++){let r=this.list[n],a=cd.copy(e).sub(r.c).dot(r.dir),o=cd.copy(t).sub(r.c).dot(r.dir);if(a<0&&o>=0){let l=a/(a-o),c=wf.copy(e).lerp(t,l).sub(r.c),h=c.dot(r.right),d=c.dot(r.up),u,p;if(r.shape==="ring"){let v=Math.hypot(h,d);u=v<r.size.r,p=1-v/r.size.r}else{let v=Math.abs(h)/(r.size.w/2),f=Math.abs(d)/(r.size.h/2);u=v<1&&f<1,p=1-Math.max(v,f)}let m=(r.size.r||Math.max(r.size.w,r.size.h))*5;if(Math.hypot(h,d)>m)continue;for(let v=this.next;v<n;v++)this.list[v].state==="pending"&&(this.list[v].state="missed",i.push({type:"miss",index:v}));r.state=u?"passed":"missed",r.acc=u?de(p,0,1):0,i.push({type:u?"pass":"miss",index:n,acc:r.acc,finish:n===this.finishIndex}),this.next=n+1;break}}return i}checkBehind(e){let t=[];for(;this.next<this.list.length&&e>this.list[this.next].s+160;)this.list[this.next].state="missed",t.push({type:"miss",index:this.next}),this.next++;return t}nextGate(){return this.list[this.next]||null}update(e){this.t+=e,this.list.forEach((t,i)=>{let n=t.mesh.userData.mat;if((t.state!=="pending"||i!==this.next)&&(t.mesh.userData.disc.visible=i===this.next),t.state==="passed")n.color.setHex(4063114),n.emissive.setHex(1097808),n.opacity=Math.max(.15,n.opacity-e*.5);else if(t.state==="missed")n.color.setHex(16724016),n.emissive.setHex(10485760),n.opacity=Math.max(.2,n.opacity-e*.5);else if(i===this.next){let r=1+Math.sin(this.t*6)*.4;n.emissiveIntensity=1.4*r,n.color.setHex(16752672),n.emissive.setHex(16742912),t.mesh.userData.disc.material.opacity=.12}else n.emissiveIntensity=.6,n.color.setHex(3852543),n.emissive.setHex(682656),t.mesh.userData.disc.material.opacity=0})}dispose(){this.scene.remove(this.group),this.group.traverse(e=>{e.geometry&&e.geometry.dispose(),e.material&&e.material.dispose()})}},cd=new M,wf=new M,hd={mission:{velocity:120,precision:220,proximity:120,stability:140,duration:80,landing:200,efficiency:120},speed:{velocity:280,precision:130,proximity:80,stability:60,duration:200,landing:120,efficiency:130},precision:{velocity:60,precision:400,proximity:60,stability:200,duration:40,landing:140,efficiency:100},landing:{velocity:0,precision:0,proximity:0,stability:200,duration:100,landing:600,efficiency:100},free:{velocity:200,precision:0,proximity:260,stability:140,duration:150,landing:150,efficiency:100}},dd={velocity:"Velocity",precision:"Precision",proximity:"Proximity",stability:"Stability",duration:"Duration",landing:"Landing",efficiency:"Efficiency"},so=class{constructor(){this.reset()}reset(){Object.assign(this,{flightTime:0,totalTime:0,maxSpeed:0,speedSum:0,speedT:0,stabSum:0,stabT:0,prox:0,path:0,startAlt:0,minClr:1e9,landDist:null,landQuality:0,gatesPassed:0,gatesTotal:0,accSum:0,finishTime:null,crashed:!1,crashWhat:"",water:!1,hardOpening:!1,exitPos:null,landPos:null})}sampleFlight(e,t,i,n,r){this.flightTime+=e,t>this.maxSpeed&&(this.maxSpeed=t),this.speedSum+=t*e,this.speedT+=e,this.stabSum+=i*e,this.stabT+=e,n<30&&t>100&&(this.prox+=(1-n/30)*e*(t/180)),n<this.minClr&&(this.minClr=n),this.path+=r}get avgSpeed(){return this.speedT>0?this.speedSum/this.speedT:0}get avgStab(){return this.stabT>0?this.stabSum/this.stabT:100}};function pd(s,e,t){let i=hd[s]||hd.mission,n={};n.velocity=de(.5*(e.maxSpeed-140)/150+.5*(e.avgSpeed-90)/110,0,1),n.precision=e.gatesTotal?de(e.gatesPassed/e.gatesTotal*(.45+.55*(e.gatesPassed?e.accSum/e.gatesPassed:0)),0,1):0,n.proximity=de(e.prox/Math.max(8,e.flightTime*.22),0,1),n.stability=de(Math.pow(e.avgStab/100,1.5),0,1),s==="speed"&&e.finishTime!=null?n.duration=de(1-(e.finishTime-t.par)/(t.par*.8),0,1):s==="speed"?n.duration=0:n.duration=de(e.totalTime/t.targetTime,0,1),e.crashed||e.landDist==null?n.landing=0:n.landing=de(1-e.landDist/(t.landR*2.2),0,1)*e.landQuality,s==="landing"?n.efficiency=de(t.directDist/Math.max(1,e.path),0,1):s==="free"?n.efficiency=de(t.glideRatio/2.6,0,1):n.efficiency=de(Math.pow(t.routeLen/Math.max(t.routeLen,e.path),2),0,1);let r={},a=0;for(let l in i)r[l]=Math.round(n[l]*i[l]),a+=r[l];let o=0;for(let l in i)o+=i[l];return a=Math.round(a*1e3/o),e.crashed&&(a=Math.round(a*.35)),{total:de(a,0,1e3),parts:r,weights:i,norm:n}}var ro=class{constructor(){this.frames=[],this.acc=0,this.rate=1/12}reset(){this.frames=[],this.acc=0,this.t=0}sample(e,t,i,n=!1){if(this.t=(this.t||0)+e,this.acc+=e,this.acc<this.rate&&!n)return;this.acc=0;let r=t.q;this.frames.push([Math.round(this.t*100),Math.round(t.pos.x*10),Math.round(t.pos.y*10),Math.round(t.pos.z*10),Math.round(r.x*1e3),Math.round(r.y*1e3),Math.round(r.z*1e3),Math.round(r.w*1e3),t.state,Math.round(t.wing*100),Math.round(t.posture*100),Math.round(i.pitch*100),Math.round(i.turn*100),Math.round(t.canopyOpen*100),Math.round(t.brakeL*100),Math.round(t.brakeR*100),Math.round(t.vel.length()*10),Math.round(t.runPhase%6.283*100),Math.round(t.cBank*100),Math.round(t.stability)])}},ao=class{constructor(e){this.data=e,this.f=e.frames,this.duration=this.f.length?this.f[this.f.length-1][0]/100:0}sample(e,t){let i=this.f;if(!i.length)return null;let n=e*100,r=0,a=i.length-1;for(;a-r>1;){let u=r+a>>1;i[u][0]<=n?r=u:a=u}let o=i[r],l=i[a],c=l[0]===o[0]?0:de((n-o[0])/(l[0]-o[0]),0,1),h=(u,p)=>fe(o[u],l[u],c)/p;t.pos.set(h(1,10),h(2,10),h(3,10)),t.q.set(o[4]/1e3,o[5]/1e3,o[6]/1e3,o[7]/1e3).normalize();let d=Ef.set(l[4]/1e3,l[5]/1e3,l[6]/1e3,l[7]/1e3).normalize();return t.q.slerp(d,c),t.state=c<.5?o[8]:l[8],t.wing=h(9,100),t.posture=h(10,100),t.pitch=h(11,100),t.turn=h(12,100),t.canopyOpen=h(13,100),t.brakeL=h(14,100),t.brakeR=h(15,100),t.speed=h(16,10),t.runPhase=o[17]/100+c*.3,t.cBank=h(18,100),t.stability=h(19,1),t}},Ef=new $e;var re=s=>document.getElementById(s),ji=s=>String(s).replace(/[&<>"]/g,e=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"})[e]),Yi=s=>Kc.find(e=>e.id===s),md=["loading","menu","modes","worlds","missions","garage","records","archive","settings","prep"],yi=new M,lo=class{constructor(e){this.g=e,this.cur="loading",this.sel={mode:"free",map:"skyfall",time:"midday",weather:"clear"},this.garageTab="suit",this.setTab="graphics",this.hudT=0,this.isTouch=matchMedia("(pointer: coarse)").matches||"ontouchstart"in window,this.wire(),this.initTouch(),qe.onUser=()=>this.updateTopbar()}wire(){document.querySelectorAll("#ui [data-act]").forEach(e=>e.addEventListener("click",t=>{t.stopPropagation(),this.g.audio.play("click"),this.act(e.dataset.act)})),re("flyBtn").addEventListener("click",()=>{this.g.audio.play("click"),this.g.startSession({map:this.sel.map,mode:this.sel.mode,time:this.sel.time,weather:this.sel.weather})}),re("hintSkip").addEventListener("click",()=>{this.g.tutorial=!1,He.data.tutorialDone=!0,He.write(),re("hint").classList.add("hidden")}),re("pauseBtn").addEventListener("click",()=>this.g.pause()),document.querySelectorAll("[data-rp]").forEach(e=>{let t=e.dataset.rp;if(t==="rew"){let i=()=>{this.g.replay&&(this.g.replay.rew=!0)},n=()=>{this.g.replay&&(this.g.replay.rew=!1)};e.addEventListener("pointerdown",i),e.addEventListener("pointerup",n),e.addEventListener("pointerleave",n),e.addEventListener("pointercancel",n)}else e.addEventListener("click",()=>{if(t==="play"&&this.replayToggle(),t==="speed"){let i=this.g.replay,n=[.25,.5,1,2];i.speed=n[(n.indexOf(i.speed)+1)%n.length],re("rpSpeed").textContent=i.speed+"\xD7"}t==="cam"&&this.replayCam(),t==="exit"&&this.g.exitReplay()})}),re("rpSlider").addEventListener("input",e=>{let t=this.g.replay;t&&(t.t=e.target.value/1e3*t.player.duration)})}act(e){let t=this.g;switch(e){case"start":this.show("modes");break;case"worlds":this.sel.mode=this.cur==="modes"?this.sel.mode:"free",this.cur==="results"||t.mode==="results"?(this.hideModal(),t.showMenu().then(()=>this.show("worlds"))):this.show("worlds");break;case"garage":t.showGarage();break;case"missions":this.show("missions");break;case"records":this.show("records");break;case"archive":this.show("archive");break;case"settings":this.settingsFrom=t.mode==="paused"?"pause":this.cur,t.mode==="paused"&&this.hideModal(),this.show("settings");break;case"back":this.back();break;case"menu":this.hideModal(),t.showMenu();break;case"jump":t.jump();break;case"preview":t.preview={t:0};break;case"cam":t.cycleCam();break;case"resume":t.resume();break;case"restart":t.restart();break;case"retry":this.hideModal(),t.restart();break;case"next":this.hideModal(),t.nextMission();break;case"watch":this.hideModal(),t.startReplay(t.lastReplay);break;case"saveReplay":t.saveReplay();break;case"double":t.doubleCoins();break}}back(){let e=this.g;if(this.cur==="settings"&&this.settingsFrom==="pause"){this.show(e.pausedFrom==="prep"?"prep":"hud"),this.showModal("pause");return}if(this.cur==="worlds"&&this.worldsFrom==="modes"){this.show("modes");return}if(this.cur==="garage"){e.showMenu();return}this.show("menu")}show(e){let t=this.cur;this.cur=e;for(let n of md)re(n).classList.toggle("show",n===e);re("hud").classList.toggle("hidden",e!=="hud"),re("replay").classList.toggle("hidden",e!=="replay"),re("topbar").classList.toggle("hidden",!["menu","modes","worlds","missions","garage","records","archive","settings"].includes(e)),re("touch").classList.toggle("hidden",!(this.isTouch&&e==="hud")),e!=="hud"&&(re("hint").classList.add("hidden"),this.warn("","")),e==="worlds"&&(this.worldsFrom=t);let i={menu:()=>this.buildMenu(),modes:()=>this.buildModes(),worlds:()=>this.buildWorlds(),missions:()=>this.buildMissions(),garage:()=>this.buildGarage(),records:()=>this.buildRecords(),archive:()=>this.buildArchive(),settings:()=>this.buildSettings()}[e];i&&i(),this.updateTopbar(),this.g.input.lastDevice==="pad"&&setTimeout(()=>this.focusFirst(),30)}showModal(e){for(let t of["pause","results"])re(t).classList.toggle("show",t===e);this.modal=e,e==="pause"&&this.buildPauseKeys(),this.g.input.lastDevice==="pad"&&setTimeout(()=>this.focusFirst(),30)}hideModal(){re("pause").classList.remove("show"),re("results").classList.remove("show"),this.modal=null}adLock(e){re("adlock").classList.toggle("hidden",!e)}loading(e,t,i){e?(re("loading").classList.add("show"),t&&(re("loadText").textContent=t),i!=null&&(re("loadBar").style.width=`${Math.round(i*100)}%`)):re("loading").classList.remove("show")}toast(e){let t=re("toast");t.textContent=e,t.classList.add("show"),clearTimeout(this._tt),this._tt=setTimeout(()=>t.classList.remove("show"),2400)}flash(e,t){let i=re("flash");i.textContent=e,i.style.color=t,i.style.opacity=1,clearTimeout(this._ft),this._ft=setTimeout(()=>{i.style.opacity=0},1100)}camLabel(e){let t=re("camLabel");t.textContent=e,t.style.opacity=1,clearTimeout(this._ct),this._ct=setTimeout(()=>{t.style.opacity=0},1300),this.cur==="prep"&&this.toast(e)}warn(e,t){let i=re("warn");i.textContent!==e&&(i.textContent=e),i.className!==t&&(i.className=t)}keyName(e){let t=this.g.input;if(this.isTouch&&t.lastDevice!=="pad"&&t.lastDevice!=="kbreal"){let i={stab:"STAB",chute:"CHUTE",pitchUp:"stick \u2193",pitchDown:"stick \u2191",left:"stick \u2190",right:"stick \u2192",camera:"CAM",tuck:"TUCK",spread:"SPREAD"};if(i[e]&&!this.kbUsed)return i[e]}return t.lastDevice==="pad"?yr[t.pad[e]]||(e==="pitchUp"?"L-stick \u2193":e==="pitchDown"?"L-stick \u2191":e==="left"||e==="right"?"L-stick":"?"):t.keyLabel(e)}kbd(e){return`<kbd>${ji(this.keyName(e))}</kbd>`}updateTopbar(){re("coinVal").textContent=He.data.coins;let e=qe.user,t=re("userBox");e&&e.username?t.innerHTML=`${e.profilePictureUrl?`<img src="${ji(e.profilePictureUrl)}" alt="">`:""}<span>${ji(e.username)}</span>`:qe.userAvailable?(t.innerHTML='<button id="loginBtn">Log in</button>',re("loginBtn").onclick=()=>qe.showAuthPrompt()):t.innerHTML=""}buildMenu(){let e=He.data;re("menuFoot").textContent=`Flights: ${e.flights} \xB7 Missions: ${Object.keys(e.missions).length}/${Ot.length} \xB7 Top speed: ${Math.round(e.stats.maxSpeed)} km/h`}buildModes(){let e=re("modeList");e.innerHTML="";for(let t of["mission","free","speed","precision","landing"]){let i=jt[t],n=document.createElement("button");n.className="card",n.innerHTML=`<div class="stripe" style="background:${t==="mission"?"var(--acc)":"var(--acc2)"}"></div><h3>${i.name}</h3><div class="muted small">${i.desc}</div>`,n.onclick=()=>{this.g.audio.play("click"),t==="mission"?this.show("missions"):(this.sel.mode=t,this.show("worlds"),this.worldsFrom="modes")},e.appendChild(n)}}buildWorlds(){let e=this.g;re("worldsTitle").textContent=`World Select \xB7 ${jt[this.sel.mode].name}`,e.mapUnlocked(this.sel.map)||(this.sel.map="skyfall");let t=re("worldList");t.innerHTML="";for(let n of er){let r=e.mapUnlocked(n.id),a=He.data.records[`${n.id}_${this.sel.mode}`],o=document.createElement("button");o.className=`card${this.sel.map===n.id?" sel":""}${r?"":" locked"}`,o.innerHTML=`<div class="stripe" style="background:${n.color}"></div><h3>${n.name}</h3><div class="muted small">${n.subtitle}</div>
        ${r?a&&a.score?`<div class="small">Best: <b>${a.score}</b> <span class="badge" style="color:${Yi(a.rank).color}">${Yi(a.rank).name}</span></div>`:'<div class="small muted">No record yet</div>':`<div class="lock">\u{1F512} Complete ${ur[n.id]} missions</div>`}`,o.onclick=()=>{if(!r){this.toast(`Complete ${ur[n.id]} missions to unlock ${n.name}`);return}this.sel.map=n.id;let l=Li(n.id);this.sel.time=l.defaultTime,!l.rain&&this.sel.weather==="rain"&&(this.sel.weather="clear"),this.buildWorlds()},t.appendChild(o)}let i=(n,r,a)=>{n.innerHTML="";for(let[o,l]of Object.entries(r)){if(a==="weather"&&o==="rain"&&!Li(this.sel.map).rain)continue;let c=document.createElement("button");c.textContent=l.label,this.sel[a]===o&&(c.className="sel"),c.onclick=()=>{this.sel[a]=o,i(n,r,a)},n.appendChild(c)}};i(re("timeSel"),hs,"time"),i(re("weatherSel"),ci,"weather")}buildMissions(){let e=re("missionList");e.innerHTML="";let t=Object.keys(He.data.missions).length;re("missionProg").textContent=`${t}/${Ot.length} complete`,Ot.forEach((i,n)=>{let r=this.g.missionUnlocked(i),a=He.data.missions[i.id],o=er.find(c=>c.id===i.map),l=document.createElement("button");l.className=`mission${r?"":" locked"}`,l.innerHTML=`<div class="num">${String(n+1).padStart(2,"0")}</div><div class="info"><b>${ji(i.name)}</b><span>${o.name} \xB7 ${jt[i.mode].name} \xB7 ${hs[i.time].label}${i.weather!=="clear"?" \xB7 "+ci[i.weather].label:""}</span><span style="display:block">${ji(i.desc)}</span></div>
        ${a?`<span class="badge" style="color:${Yi(a.rank).color}">${Yi(a.rank).name} ${a.best}</span>`:r?'<span class="badge" style="color:var(--acc)">NEW</span>':"<span>\u{1F512}</span>"}`,l.onclick=()=>{if(!r){this.toast("Complete the previous mission first");return}this.g.audio.play("click"),this.g.startSession({missionId:i.id})},e.appendChild(l)})}buildGarage(){let e=re("garageTabs");e.innerHTML="";let t={suit:"Wingsuit",helmet:"Helmet",chute:"Parachute",trail:"Effects"};for(let r of Object.keys(hr)){let a=document.createElement("button");a.textContent=t[r],r===this.garageTab&&(a.className="sel"),a.onclick=()=>{this.garageTab=r,this.buildGarage()},e.appendChild(a)}let i=re("garageList");i.innerHTML="";let n=He.data;for(let r of hr[this.garageTab]){let a=n.owned[this.garageTab].includes(r.id),o=n.equip[this.garageTab]===r.id,l=this.reqMet(r.req),c=r.suit||r.helmet&&r.helmet.slice(0,2)||r.chute||(Array.isArray(r.trail)?[`rgb(${r.trail.slice(0,3).map(u=>Math.round(u*255)).join(",")})`]:r.trail==="rainbow"?["#f33","#fa3","#ff3","#3d5","#38f","#93f"]:["#333"]),h=document.createElement("button");h.className=`item${o?" sel":""}`;let d;o?d='<span style="color:var(--ok)">Equipped</span>':a?d="Owned \xB7 tap to equip":r.req?d=l?"Unlocked \xB7 tap to claim":`\u{1F512} ${this.reqText(r.req)}`:d=`<span class="coin-ico"></span> ${r.price}`,h.innerHTML=`<div class="sw">${c.map(u=>`<i style="background:${u}"></i>`).join("")}</div><b>${ji(r.name)}</b><span class="price">${d}</span>`,h.onclick=()=>{if(!o){if(!a){if(r.req){if(!l){this.toast(this.reqText(r.req));return}}else{if(n.coins<r.price){this.toast("Not enough coins. Fly missions to earn more!");return}n.coins-=r.price,this.g.audio.play("coin")}n.owned[this.garageTab].push(r.id)}n.equip[this.garageTab]=r.id,He.write(),this.g.pilot.setLook(this.g.currentLook()),this.buildGarage(),this.updateTopbar()}},i.appendChild(h)}re("garageInfo").textContent="Cosmetic only \u2014 gear never changes flight physics."}reqMet(e){return e?e.missions?Object.keys(He.data.missions).length>=e.missions:e.rank?this.g.rankCount(e.rank)>=e.count:!1:!0}reqText(e){return e.missions?`Complete ${e.missions} missions`:`Earn ${Yi(e.rank).name} or better on ${e.count} mission${e.count>1?"s":""}`}buildRecords(){let e=He.data,t="";for(let n of er){t+=`<h3 style="margin:0.8em 0 0.3em">${n.name}</h3><table class="rec"><tr><th>Mode</th><th>Best score</th><th>Rank</th><th>Best time</th><th>Top speed</th><th>Flights</th></tr>`;for(let r of["mission","speed","precision","landing","free"]){let a=e.records[`${n.id}_${r}`];t+=`<tr><td>${jt[r].name}</td><td>${a&&a.score?a.score:"\u2014"}</td><td>${a&&a.rank?`<span style="color:${Yi(a.rank).color}">${Yi(a.rank).name}</span>`:"\u2014"}</td><td>${a&&a.time?zt(a.time):"\u2014"}</td><td>${a&&a.maxSpeed?Math.round(a.maxSpeed)+" km/h":"\u2014"}</td><td>${a&&a.flights||0}</td></tr>`}t+="</table>"}let i=e.stats;t+=`<h3 style="margin:0.8em 0 0.3em">Career</h3><table class="rec"><tr><th>Flights</th><th>Air time</th><th>Landings</th><th>Crashes</th><th>Gates</th><th>Top speed</th></tr><tr><td>${e.flights}</td><td>${zt(i.flightTime)}</td><td>${i.landings}</td><td>${i.crashes}</td><td>${i.gates}</td><td>${Math.round(i.maxSpeed)} km/h</td></tr></table>`,re("recordList").innerHTML=t}buildArchive(){let e=re("archiveList");e.innerHTML="";let t=[];if(this.g.lastReplay&&t.push({r:this.g.lastReplay,last:!0}),He.data.archive.forEach((i,n)=>t.push({r:i,i:n})),!t.length){e.innerHTML='<div class="muted">No flights recorded yet. Complete a flight and press "Save Replay" on the results screen.</div>';return}for(let i of t){let n=i.r.meta,r=er.find(c=>c.id===n.map),a=document.createElement("div");a.className="mission";let o=n.rank?Yi(n.rank):null;a.innerHTML=`<div class="info"><b>${i.last?"Last flight \xB7 ":""}${r.name} \u2014 ${jt[n.mode].name}</b><span>${new Date(n.date).toLocaleString()} \xB7 ${zt(n.duration||0)} \xB7 ${n.maxSpeed||0} km/h \xB7 Score ${n.score}${o?` \xB7 <span style="color:${o.color}">${o.name}</span>`:" \xB7 Failed"}</span></div>`;let l=document.createElement("button");if(l.className="mbtn",l.textContent="Watch",l.onclick=()=>{this.g.session=null,this.g.lastResult=null,this.g.startReplay(i.r)},a.appendChild(l),!i.last){let c=document.createElement("button");c.className="mbtn",c.textContent="Delete",c.onclick=()=>{He.data.archive.splice(i.i,1),He.write(),this.buildArchive()},a.appendChild(c)}e.appendChild(a)}}buildSettings(){let e=re("setTabs");e.innerHTML="";let t={graphics:"Graphics",camera:"Camera",audio:"Audio",controls:"Controls",gameplay:"Gameplay"};for(let[h,d]of Object.entries(t)){let u=document.createElement("button");u.textContent=d,h===this.setTab&&(u.className="sel"),u.onclick=()=>{this.setTab=h,this.buildSettings()},e.appendChild(u)}let i=re("setBody");i.innerHTML="";let n=this.g.settings,r=()=>{He.write(),this.g.applySettings()},a=(h,d)=>{let u=document.createElement("div");u.className="set-row";let p=document.createElement("span");return p.innerHTML=h,u.append(p,d),i.appendChild(u),u},o=(h,d,u)=>{let p=document.createElement("button");p.className="kb";let m=()=>{p.textContent=d()?"ON":"OFF"};m(),p.onclick=()=>{u(!d()),m(),r()},a(h,p)},l=(h,d,u,p,m,v,f=g=>g)=>{let g=document.createElement("span"),y=document.createElement("input");y.type="range",y.min=d,y.max=u,y.step=p,y.value=m();let x=document.createElement("span");x.style.minWidth="3.5em",x.style.display="inline-block",x.style.textAlign="right",x.textContent=f(m()),y.oninput=()=>{v(parseFloat(y.value)),x.textContent=f(parseFloat(y.value)),r()},g.append(y,x),a(h,g)},c=(h,d,u,p)=>{let m=document.createElement("div");m.className="seg";for(let[v,f]of Object.entries(d)){let g=document.createElement("button");g.textContent=f,u()===v&&(g.className="sel"),g.onclick=()=>{p(v),r(),this.buildSettings()},m.appendChild(g)}a(h,m)};if(this.setTab==="graphics")c('Quality <span class="muted small">(applies to next world load)</span>',{auto:"Auto",low:"Low",medium:"Medium",high:"High"},()=>n.quality,h=>{n.quality=h,this.g.pendingQuality=!0,this.g.quality=h==="auto"?this.g.quality:h,this.g.resize()}),o("Shadows",()=>n.shadows,h=>{n.shadows=h}),o("Motion blur & lens effects",()=>n.motionBlur,h=>{n.motionBlur=h}),o("Speed effects (streaks, blur strength)",()=>n.speedFx,h=>{n.speedFx=h}),o("Show flight route",()=>n.hudRoute,h=>{n.hudRoute=h,this.g.routeDots&&(this.g.routeDots.visible=h)});else if(this.setTab==="camera")c("Default view",{chase:"Chase",pilot:"Pilot",cinema:"Cinema"},()=>n.view,h=>{n.view=h}),l("Field of view",55,95,1,()=>n.fov,h=>{n.fov=h},h=>`${h}\xB0`),l("Camera shake & turbulence",0,1.5,.1,()=>n.shake,h=>{n.shake=h},h=>`${Math.round(h*100)}%`);else if(this.setTab==="audio")l("Master volume",0,1,.05,()=>n.master,h=>{n.master=h},h=>`${Math.round(h*100)}%`),l("Music",0,1,.05,()=>n.music,h=>{n.music=h},h=>`${Math.round(h*100)}%`),l("Effects & wind",0,1,.05,()=>n.sfx,h=>{n.sfx=h},h=>`${Math.round(h*100)}%`);else if(this.setTab==="controls"){let h=document.createElement("div");h.className="muted small",h.textContent="Click a key box, then press the new key. Gamepad: click to cycle buttons. Arrow keys always work for pitch/turn.",i.appendChild(h);for(let[u,p]of _h){let m=document.createElement("span");m.style.display="flex",m.style.gap="6px";let v=document.createElement("button");v.className="kb",v.textContent=bo(n.keys[u]),v.onclick=()=>{v.classList.add("wait"),v.textContent="press key\u2026",this.g.input.onAnyKey=g=>{if(this.g.input.onAnyKey=null,Mh.has(g))this.toast("That key is reserved by the browser");else{for(let y in n.keys)n.keys[y]===g&&(n.keys[y]=n.keys[u]);n.keys[u]=g,r()}this.buildSettings()}};let f=document.createElement("button");f.className="kb",f.textContent=yr[n.pad[u]]||"\u2014",f.onclick=()=>{n.pad[u]=n.pad[u]==null?0:(n.pad[u]+1)%12,r(),f.textContent=yr[n.pad[u]]},m.append(v,f),a(p,m)}o("Invert pitch",()=>n.invert,u=>{n.invert=u}),l("Input smoothing",.3,2,.1,()=>n.smoothing,u=>{n.smoothing=u},u=>u.toFixed(1));let d=document.createElement("button");d.className="kb",d.textContent="Reset",d.onclick=()=>{n.keys={..._s},n.pad={...Ms},r(),this.buildSettings()},a("Restore default controls",d)}else if(this.setTab==="gameplay"){o("Auto-spread wings after exit",()=>n.autoSpread,u=>{n.autoSpread=u}),l("Proximity warning (subtle)",15,60,1,()=>n.warn.subtle,u=>{n.warn.subtle=u},u=>`${u} m`),l("Proximity warning (strong)",5,30,1,()=>n.warn.strong,u=>{n.warn.strong=u},u=>`${u} m`),l("Proximity warning (critical)",1,15,1,()=>n.warn.critical,u=>{n.warn.critical=u},u=>`${u} m`);let h=document.createElement("button");h.className="kb",h.textContent="Reset progress",h.onclick=()=>{h.dataset.c?(He.reset(),this.g.pilot.setLook(this.g.currentLook()),this.toast("Progress reset"),this.buildSettings()):(h.dataset.c=1,h.textContent="Click again to confirm")},a("Reset all progress (keeps settings)",h);let d=document.createElement("button");d.className="kb",d.textContent="Defaults",d.onclick=()=>{let u={keys:n.keys,pad:n.pad};Object.assign(n,JSON.parse(JSON.stringify(So)),u),r(),this.buildSettings()},a("Restore default settings",d)}}buildPauseKeys(){let e=[["pitchDown","Dive"],["pitchUp","Pull up"],["left","Turn L"],["right","Turn R"],["rollL","Roll L"],["rollR","Roll R"],["stab","Stabilize"],["tuck","Tuck"],["spread","Spread"],["chute","Parachute"],["camera","Camera"],["restart","Restart"]];re("pauseKeys").innerHTML=e.map(([t,i])=>`<span>${i}</span><span><b>${ji(this.keyName(t))}</b></span>`).join("")+"<span>Look around</span><span><b>Drag mouse / right stick</b></span>"}prep(e){let t=Li(e.map);re("prepMap").textContent=e.mission?`${e.mission.name}`:t.name;let i="";e.mission?i+=`<b>${t.name} \xB7 ${jt[e.mode].name}</b><br>${ji(e.mission.desc)}<br>`:i+=`<b>${jt[e.mode].name}</b> \xB7 ${t.subtitle}<br>`,e.gatesCfg&&(i+=`Gates: <b>${e.gatesCfg.n}</b>${e.mission?` (max ${e.mission.maxMiss} missed)`:""} \xB7 `),e.limit&&(i+=`Time limit: <b>${zt(e.limit)}</b> \xB7 `),i+=`Landing zone: <b>${Math.round(Math.hypot(e.start.x-e.target.x,e.start.z-e.target.z))} m</b> away, ${Math.round(e.start.y-e.target.y)} m below`,i+=`<br><span class="muted small">${hs[e.time].label} \xB7 ${ci[e.weather].label}</span>`,i+=`<br><span class="small">${this.kbd("stab")} jump \xB7 ${this.kbd("pitchDown")}${this.kbd("pitchUp")} pitch \xB7 ${this.kbd("left")}${this.kbd("right")} turn \xB7 ${this.kbd("chute")} parachute \xB7 ${this.kbd("camera")} camera</span>`,re("prepObj").innerHTML=i,re("jumpBtn").textContent=e.mode==="landing"?"Start":"Jump",re("prepHint").textContent=this.isTouch?"Drag to look around":"Drag the mouse to look around"}tutorial(e){let t=re("hint");if(!e){t.classList.add("hidden");return}if(e==="prep"){re("prepHint").innerHTML=`Press ${this.kbd("stab")} or tap <b>JUMP</b> to run off the edge`;return}let i={spread:`Press ${this.kbd("stab")} to spread your wings!`,pitch:`${this.kbd("pitchDown")} dive for speed \xB7 ${this.kbd("pitchUp")} pull up to flatten your glide`,turn:`${this.kbd("left")} / ${this.kbd("right")} turn \xB7 ${this.kbd("rollL")} / ${this.kbd("rollR")} roll harder`,gates:"Fly through the glowing orange gate \u2014 follow the arrow and keep the green flight-path ring on it",deploy:`Time to land! Press ${this.kbd("chute")} to deploy your parachute`,canopy:`Steer with ${this.kbd("left")} / ${this.kbd("right")} toward the orange beacon`,flare:`Hold ${this.kbd("pitchUp")} now to flare and land softly!`}[e];this._tutPhase!==e&&(re("hintTxt").innerHTML=i,this._tutPhase=e),t.classList.remove("hidden")}hud(e){let t=this.g,i=t.flight,n=t.session,r=t.camera,a=window.innerWidth,o=window.innerHeight,l=i.state===se.WINGSUIT||i.state===se.FREEFALL,c=re("fpv");l&&t.rig.view!=="cinema"&&i.vel.lengthSq()>25?(yi.copy(t.renderPos).addScaledVector(i.vel,2).project(r),yi.z<1&&Math.abs(yi.x)<1.1&&Math.abs(yi.y)<1.1?(c.style.display="block",c.style.left=`${(yi.x+1)/2*a}px`,c.style.top=`${(1-yi.y)/2*o}px`):c.style.display="none"):c.style.display="none";let h=t.gates&&t.gates.nextGate(),d=h&&i.state<=se.WINGSUIT?h.c:yi.set(n.target.x,n.target.y+2,n.target.z).clone(),u=t.renderPos.distanceTo(d),p=d.clone().project(r),m=re("gateMark"),v=re("edgeArrow"),f=p.z<1&&Math.abs(p.x)<.92&&Math.abs(p.y)<.9;if(i.state===se.LANDED||i.state===se.CRASHED)m.style.display=v.style.display="none";else if(f)m.style.display="block",v.style.display="none",m.style.left=`${(p.x+1)/2*a}px`,m.style.top=`${(1-p.y)/2*o}px`,m.dataset.d=`${h&&i.state<=se.WINGSUIT?"GATE ":"LZ "}${Math.round(u)} m`,m.style.borderColor=h&&i.state<=se.WINGSUIT?"var(--acc)":"var(--ok)";else{m.style.display="none",v.style.display="block";let X=p.x,j=p.y;p.z>1&&(X=-X,j=-j);let Z=Math.atan2(-j,X),$=Math.min(a,o)*.42;v.style.left=`${a/2+Math.cos(Z)*$}px`,v.style.top=`${o/2+Math.sin(Z)*$}px`,v.style.transform=`rotate(${Z}rad)`}if(this.hudT-=e,this.hudT>0)return;this.hudT=1/15;let g=i.vel.length()*3.6;re("hSpeed").textContent=Math.round(g),re("hMax").textContent=Math.round(t.stats.maxSpeed),re("hTime").textContent=zt(t.stats.totalTime);let y=Math.max(0,Math.round(t.clr.agl)),x=re("hAlt");x.textContent=y,x.parentElement.style.color=y<30&&l?"#ff4a3a":y<120&&l?"#ffd23f":"",re("hAsl").textContent=Math.round(i.pos.y);let _=Math.hypot(i.pos.x-n.target.x,i.pos.z-n.target.z);re("hDist").textContent=Math.round(_),re("hLandDist").textContent=Math.round(_);let b="";t.gates.list.length&&i.state<=se.WINGSUIT?b=`Gate ${Math.min(t.gates.next+1,t.gates.total)}/${t.gates.total} \xB7 \u2713 ${t.stats.gatesPassed}`:n.mode==="landing"||i.state>=se.DEPLOY?b="Land on the target":n.mode==="free"?b="Free flight":b="Deploy & land in the zone",n.limit&&(b+=` \xB7 ${zt(Math.max(0,n.limit-t.stats.totalTime))} left`),n.mode==="speed"&&t.stats.finishTime!=null&&(b=`Finish ${zt(t.stats.finishTime)} \xB7 Land now`),re("hObj").textContent=b;let S=i.stability,R=re("hStab");R.style.width=`${S}%`,R.style.background=S>65?"var(--ok)":S>35?"#ffd23f":"var(--bad)",r.getWorldDirection(yi);let P=Math.atan2(yi.x,yi.z),C=Math.atan2(t.wind.x,t.wind.z),B=P-C;re("hWindArrow").style.transform=`rotate(${-Math.PI/2+B}rad)`,re("hWind").textContent=`${Math.round(Math.hypot(t.wind.x,t.wind.z)*3.6)} km/h wind`;let z=Math.atan2(n.target.x-i.pos.x,n.target.z-i.pos.z);re("hLandArrow").style.transform=`rotate(${P-z}rad)`;let D=re("hChute"),F="chute",U;i.state===se.DEPLOY?(F+=" open",U="DEPLOYING\u2026"):i.state===se.CANOPY?(F+=" open",U="CANOPY OPEN"):i.state===se.LANDED?(F+=" open",U="LANDED"):i.state===se.CRASHED?U="IMPACT":(F+=" ready",U="PARACHUTE READY",t.deployWindowShown&&i.state===se.WINGSUIT&&(F+=" window")),D.className=F,re("hChuteTxt").textContent=U,re("hChuteKey").innerHTML=i.state<=se.WINGSUIT&&i.state>=se.FREEFALL?`Deploy: ${this.kbd("chute")}`:i.state===se.CANOPY?`Flare: ${this.kbd("pitchUp")}`:""}results(e,t){let i=this.g;for(let d of md)re(d).classList.remove("show");for(let d of["hud","replay","touch","topbar"])re(d).classList.add("hidden");this.cur="results";let n=e.success?t.mission?"Mission Complete":"Landed Safely":e.ok?"Challenge Failed":"Flight Failed";re("resTitle").textContent=n,re("resTitle").style.color=e.success?"var(--ok)":"var(--bad)",re("resSub").textContent=`${Li(t.map).name} \xB7 ${t.mission?t.mission.name:jt[t.mode].name}${e.reasons.length?" \u2014 "+e.reasons.join(" \xB7 "):""}`,re("resScore").textContent=e.sc.total;let r=re("resRank");e.rank?(r.textContent=e.rank.name,r.style.color=e.rank.color):(r.textContent="No rank",r.style.color="var(--mut)"),re("resRec").textContent=e.newRecord?"New personal record!":e.firstClear?"First clear bonus +50":"";let a=re("resBars");a.innerHTML="";for(let d in e.sc.weights){if(!e.sc.weights[d])continue;let u=document.createElement("div");u.className="rb",u.innerHTML=`<span>${dd[d]}</span><span class="t"><i></i></span><span class="v">${e.sc.parts[d]}/${e.sc.weights[d]}</span>`,a.appendChild(u),setTimeout(()=>{u.querySelector("i").style.width=`${Math.round(e.sc.norm[d]*100)}%`},50)}let o=e.st,l=[["Max speed",`${Math.round(o.maxSpeed)} km/h`],["Avg speed",`${Math.round(o.avgSpeed)} km/h`],["Flight time",zt(o.totalTime)],["Distance",`${(o.path/1e3).toFixed(2)} km`],["Stability",`${Math.round(o.avgStab)}%`],["Closest pass",o.minClr<1e8?`${o.minClr.toFixed(1)} m`:"\u2014"]];o.gatesTotal&&l.push(["Gates",`${o.gatesPassed}/${o.gatesTotal}`]),o.finishTime!=null&&l.push(["Route time",zt(o.finishTime)]),l.push(["Landing",o.landDist!=null?`${o.landDist.toFixed(1)} m from center${o.landQuality<1?" (hard)":""}`:"\u2014"]),l.push(["Glide ratio",`${e.ctx.glideRatio.toFixed(2)} : 1`]),re("resStats").innerHTML=l.map(([d,u])=>`<div><span class="muted">${d}</span><b>${u}</b></div>`).join(""),re("resCoins").textContent=e.coins*(e.doubled?2:1),re("resReward").textContent=e.doubled?"(doubled!)":"",re("coinVal").textContent=He.data.coins;let c=t.mission?Ot.findIndex(d=>d.id===t.mission.id):-1,h=c>=0?Ot[c+1]:null;re("resNext").style.display=h&&i.missionUnlocked(h)?"":"none",re("resAd").style.display=qe.rewardedAvailable&&!e.doubled&&e.coins>0?"":"none",this.showModal("results")}replayInit(e){let t=e.meta;re("rpTitle").textContent=`Replay \xB7 ${Li(t.map).name} \xB7 ${jt[t.mode].name} \xB7 Score ${t.score}`,re("rpSpeed").textContent="1\xD7",re("rpCam").textContent="Chase",re("rpPlay").textContent="\u275A\u275A"}replayUpdate(e,t){re("rpSlider").value=Math.round(e.t/Math.max(.01,e.player.duration)*1e3),re("rpTime").textContent=zt(e.t),re("rpStats").textContent=`${Math.round(t.speed*3.6)} km/h \xB7 ${Math.round(t.pos.y)} m ASL \xB7 stability ${Math.round(t.stability)}%`,re("rpPlay").textContent=e.playing?"\u275A\u275A":"\u25B6"}replayToggle(){let e=this.g.replay;e&&(e.t>=e.player.duration-.01&&(e.t=0),e.playing=!e.playing)}replayCam(){let e=this.g.rig,t=["chase","cinema","pilot","orbit"],i=t[(t.indexOf(e.view)+1)%t.length];e.view=i,e.cine.t=99,re("rpCam").textContent=i==="orbit"?"Orbit":to[i].replace(" View","")}initTouch(){let e=re("stickZone"),t=re("stickBase"),i=re("stickKnob"),n=this.g.input.touch,r=null,a=0,o=0,l=55;e.addEventListener("pointerdown",f=>{r=f.pointerId;let g=t.getBoundingClientRect();a=g.left+g.width/2,o=g.top+g.height/2,e.setPointerCapture(r),c(f),n.active=!0});let c=f=>{if(f.pointerId!==r)return;let g=f.clientX-a,y=f.clientY-o,x=Math.hypot(g,y);x>l&&(g*=l/x,y*=l/x),i.style.transform=`translate(${g}px, ${y}px)`,n.x=g/l,n.y=y/l},h=f=>{f.pointerId===r&&(r=null,n.active=!1,n.x=n.y=0,i.style.transform="")};e.addEventListener("pointermove",c),e.addEventListener("pointerup",h),e.addEventListener("pointercancel",h);let d=this.g.canvas,u=null,p=0,m=0;d.addEventListener("pointerdown",f=>{f.pointerType==="touch"&&(u=f.pointerId,p=f.clientX,m=f.clientY)}),d.addEventListener("pointermove",f=>{f.pointerId===u&&(this.g.input.lookDX+=(f.clientX-p)*.008,this.g.input.lookDY+=(f.clientY-m)*.008,p=f.clientX,m=f.clientY)});let v=f=>{f.pointerId===u&&(u=null)};d.addEventListener("pointerup",v),d.addEventListener("pointercancel",v),document.querySelectorAll("#tbtns .tb").forEach(f=>{let g=f.dataset.t,y=["stab","tuck","spread","rollL","rollR"].includes(g);f.addEventListener("pointerdown",_=>{_.preventDefault(),this.g.input.lastDevice="touch",y&&(n.btn[g]=!0,f.classList.add("on")),this.g.input.queue.push(g)});let x=()=>{y&&(n.btn[g]=!1,f.classList.remove("on"))};f.addEventListener("pointerup",x),f.addEventListener("pointercancel",x),f.addEventListener("pointerleave",x)}),window.addEventListener("keydown",()=>{this.kbUsed=!0},{once:!0})}focusables(){let e=this.modal?re(this.modal):["hud","replay"].includes(this.cur)?re(this.cur):re(this.cur);return e?Array.from(e.querySelectorAll("button, input[type=range]")).filter(t=>t.offsetParent!==null&&!t.disabled):[]}focusFirst(){let e=this.focusables();e.length&&!e.includes(document.activeElement)&&e[0].focus()}padNav(e){let t=this.g;if(t.mode==="flight"||t.mode==="prep"&&!this.modal)return;let i=parseInt(e.slice(4),10),n=this.focusables();if(!n.length)return;let r=document.activeElement;if(!n.includes(r)){n[0].focus();return}if(i===0){r.click();return}if(i===1){this.modal==="pause"?t.resume():!this.modal&&this.cur!=="menu"&&this.back();return}let a={12:[0,-1],13:[0,1],14:[-1,0],15:[1,0]}[i];if(!a)return;let o=r.getBoundingClientRect(),l=[o.left+o.width/2,o.top+o.height/2],c=null,h=1e9;for(let d of n){if(d===r)continue;let u=d.getBoundingClientRect(),p=[u.left+u.width/2,u.top+u.height/2],m=p[0]-l[0],v=p[1]-l[1],f=m*a[0]+v*a[1];if(f<=4)continue;let g=Math.abs(m*a[1]-v*a[0]),y=f+g*2.5;y<h&&(h=y,c=d)}c&&(c.focus(),c.scrollIntoView({block:"nearest"}))}};var co=1/120,xn=new M,th=new M,ho=new $e;function Tf(s){let e=new URLSearchParams(location.search).get("quality");if(e)return e;if(s&&s!=="auto")return s;let t=matchMedia("(pointer: coarse)").matches,i=navigator.hardwareConcurrency||4,n=navigator.deviceMemory||4;return t||i<=4||n<=4?"low":"medium"}var uo=class{constructor(e){this.canvas=e;let t=He.data.settings;this.settings=t,this.quality=Tf(t.quality);let i=this.renderer=new va({canvas:e,antialias:this.quality==="low",powerPreference:"high-performance",stencil:!1});i.outputColorSpace=wt,i.toneMapping=zu,i.shadowMap.enabled=this.quality!=="low"&&t.shadows,i.shadowMap.type=Ou,this.scene=new Wi,this.camera=new Ut(70,16/9,.8,26e3),this.post=new no(i),this.sky=new Xa(this.scene,i,this.quality),this.particles=new qa(this.scene),this.puffs=new ja(this.scene),this.audio=new io,this.input=new vr(e),this.pilot=new $a(this.scene,this.currentLook()),this.flight=new Ka,this.rig=new eo(this.camera),this.stats=new so,this.rec=new ro,this.noise=Ht(99),this.wind=new M,this.gust=new M,this.baseWind=new M,this.prevPos=new M,this.prevQ=new $e,this.renderPos=new M,this.renderQ=new $e,this.mode="loading",this.world=null,this.def=null,this.gates=null,this.acc=0,this.time=0,this.clr={agl:999,clr:999},this.clrT=0,this.routeNear={d:0,s:0},this.ui=new lo(this),this.applySettings(),window.addEventListener("resize",()=>this.resize()),document.addEventListener("visibilitychange",()=>{document.hidden&&this.mode==="flight"&&this.pause()}),qe.onMute=n=>this.audio.mute("sdk",n),qe.onPause=n=>{n?(this.audio.mute("ad",!0),this.mode==="flight"&&this.pause()):this.audio.mute("ad",!1)},this.resize()}currentLook(){let e=He.data.equip,t=hr,i=(n,r)=>n.find(a=>a.id===r)||n[0];return{suit:i(t.suit,e.suit).suit,helmet:i(t.helmet,e.helmet).helmet,chute:i(t.chute,e.chute).chute,trail:i(t.trail,e.trail).trail}}applySettings(){let e=this.settings;this.audio.setVolumes({master:e.master,music:e.music,sfx:e.sfx}),this.input.bind={...e.keys},this.input.pad={...e.pad},this.input.invert=e.invert,this.input.smoothing=e.smoothing,this.rig.settings.shake=e.shake,this.rig.settings.fov=e.fov,this.post.enabled=e.motionBlur&&this.quality!=="low",this.particles.enabled=!0,this.renderer.shadowMap.enabled=this.quality!=="low"&&e.shadows,this.sky.sun.castShadow=this.renderer.shadowMap.enabled,this.rig.view=e.view||"chase"}resize(){let e=window.innerWidth,t=window.innerHeight,i=window.devicePixelRatio||1,n=this.quality==="high"?Math.min(i,2):this.quality==="medium"?Math.min(i,1.25):Math.min(i,1)*.85;this.renderer.setPixelRatio(n),this.renderer.setSize(e,t,!1),this.post.setSize(Math.floor(e*n),Math.floor(t*n)),this.camera.aspect=e/t,this.camera.updateProjectionMatrix()}async loadWorld(e,t,i){if(!(this.world&&this.def&&this.def.id===e&&this.world.quality===this.quality)){this.ui.loading(!0,`Building ${Li(e).name}\u2026`,0),qe.loadingStart(),await new Promise(h=>setTimeout(h,30)),this.world&&(this.world.dispose(),this.world=null),this.def=Li(e);let c=new Wa(this.scene,this.def,this.quality);await c.build(h=>this.ui.loading(!0,null,h)),this.world=c,this.audio.setAmbient(this.def.ambient),qe.loadingStop(),this.ui.loading(!1)}let r=t||this.def.defaultTime,a=i||"clear";a==="rain"&&!this.def.rain&&(a="clouds"),this.sky.apply(r,a,this.def),this.world.setLighting(this.sky),this.particles.configure(this.def.particles,!!ci[a].rain);let o=this.def.wind,l=ci[a].wind;this.baseWind.set(Math.sin(o.dir)*o.speed*l,0,Math.cos(o.dir)*o.speed*l),this.gustMul=ci[a].gust,this.timeKey=r,this.weatherKey=a}async showMenu(){qe.gameplayStop(),this.mode="loading",this.clearSession(),this.world||await this.loadWorld("skyfall","sunset","clear"),this.mode="menu",this.menuS=this.def.route.L*.12,this.rig.cine.t=99,this.rig.cine.shot=0,this.pilot.canopyOpen=0,this.ui.show("menu"),this.audio.music.on=!0}async showGarage(){this.world||await this.loadWorld("skyfall","sunset","clear"),this.mode="garage",this.garageT=0,this.ui.show("garage")}clearSession(){this.gates&&(this.gates.dispose(),this.gates=null),this.extraTarget&&(this.world&&this.world.group.remove(this.extraTarget),this.extraTarget=null),this.routeDots&&(this.scene.remove(this.routeDots),this.routeDots.geometry.dispose(),this.routeDots=null),this.session=null,this.replay=null,this.ending=null,this.puffs.clear()}async startSession(e){let t=e.missionId?Ot.find(o=>o.id===e.missionId):null,i=t?t.map:e.map,n=t?t.mode:e.mode;this.mode="loading",qe.gameplayStop(),this.clearSession(),await this.loadWorld(i,t?t.time:e.time,t?t.weather:e.weather);let r=this.def,a={map:i,mode:n,mission:t,opts:{...e},time:this.timeKey,weather:this.weatherKey};if(a.gatesCfg=n==="free"||n==="landing"?null:t&&t.gates||eh(n),a.limit=t?t.limit:null,n==="landing"){let o=oo(r,this.world);a.start=o.start,a.target=o.target,a.directDist=Math.hypot(o.start.x-o.target.x,o.start.z-o.target.z),a.targetTime=60}else{let o=r.exit,l=Math.sin(o.heading),c=Math.cos(o.heading),h=4;for(let p=-20;p<90;p+=.5)if(this.world.ground(o.x+l*p,o.z+c*p).h<o.y-1){h=p;break}let d=o.x+l*(h-9),u=o.z+c*(h-9);a.start={x:d,y:this.world.ground(d,u).h+.95,z:u,heading:o.heading},a.target={...r.landing},a.targetTime=r.route.L/38}if(a.routeLen=r.route.L,this.session=a,this.gates=new cr(this.scene,this.world,r,a.gatesCfg,n),this.gates.list.length){let o=this.gates.list[this.gates.finishIndex];a.par=o.s/57}else a.par=60;this.tutorial=!!(t&&t.tutorial&&!He.data.tutorialDone),this.tutStep=0,this.resetFlight(),qe.setContext({map:r.name,mode:jt[n].name,mission:t?t.name:""}),this.ui.prep(a)}buildRouteDots(){let e=this.def.route,t=[];for(let n=40;n<e.L*.92;n+=35){let r=e.line.at(n);t.push(r.x,e.routeY(n),r.z)}let i=new Ve;if(i.setAttribute("position",new Te(t,3)),!this.dotTex){let n=document.createElement("canvas");n.width=n.height=32;let r=n.getContext("2d"),a=r.createRadialGradient(16,16,0,16,16,16);a.addColorStop(0,"rgba(255,255,255,1)"),a.addColorStop(.45,"rgba(255,255,255,0.8)"),a.addColorStop(1,"rgba(255,255,255,0)"),r.fillStyle=a,r.fillRect(0,0,32,32),this.dotTex=new vi(n)}this.routeDots=new is(i,new qs({color:10479871,map:this.dotTex,size:3,sizeAttenuation:!0,transparent:!0,opacity:.6,depthWrite:!1})),this.routeDots.visible=this.settings.hudRoute&&this.session.mode!=="landing",this.scene.add(this.routeDots)}resetFlight(){let e=this.session;if(this.routeDots||this.buildRouteDots(),e.mode==="landing"&&!this.extraTarget){let t=oo(this.def,this.world);(t.target.x!==this.def.landing.x||t.target.z!==this.def.landing.z)&&(this.extraTarget=this.world.addTarget(t.target.x,t.target.y,t.target.z,t.target.r))}this.flight.reset(e.start,e.mode==="landing"?"canopy":"ready"),this.flight.autoSpreadAt=this.settings.autoSpread||this.tutorial?1.8:99,this.stats.reset(),this.rec.reset(),this.gates.reset(),this.ending=null,this.acc=0,this.started=!1,this.paused=!1,this.prevPos.copy(this.flight.pos),this.prevQ.copy(this.flight.q),this.renderPos.copy(this.flight.pos),this.renderQ.copy(this.flight.q),this.pilot.canopyOpen=e.mode==="landing"?1:0,this.rig.orbit.yaw=0,this.rig.orbit.dist=e.mode==="landing"?18:11,this.rig.orbit.pitch=.42,this.rig.lookYaw=0,this.rig.lookPitch=0,this.rig.target.copy(this.flight.pos),this.rig.pos.copy(this.flight.pos),this.puffs.clear(),this.warnLevel=0,this.mode="prep",this.preview=null,this.trailT=0,this.lastGateEv=null,this.timeOver=!1,this.deployWindowShown=!1,qe.gameplayStart(),this.ui.show("prep"),this.ui.prep(this.session)}jump(){this.mode==="prep"&&(this.preview=null,this.mode="flight",this.started=!0,this.session.mode!=="landing"&&this.flight.startRun(),this.stats.startAlt=this.flight.pos.y,this.stats.exitPos=this.flight.pos.clone(),this.ui.show("hud"),this.audio.play("click"),qe.gameplayStart())}restart(){this.session&&(this.ui.hideModal(),this.resetFlight())}pause(){this.mode!=="flight"&&this.mode!=="prep"||(this.pausedFrom=this.mode,this.mode="paused",qe.gameplayStop(),this.ui.showModal("pause"))}resume(){this.mode==="paused"&&(this.mode=this.pausedFrom||"flight",this.ui.hideModal(),qe.gameplayStart())}physicsStep(e){let t=this.flight;this.prevPos.copy(t.pos),this.prevQ.copy(t.q);let i=t.state,n=this.inp;t.gust.copy(this.gust);let r=t.step(e,n,this.wind,this.world);if(t.state!==i&&this.onStateChange(i,t.state),t.state!==se.READY&&this.rec.sample(e,t,n),t.state>=se.FREEFALL&&t.state<=se.CANOPY){this.stats.totalTime+=e;let o=t.vel.length()*3.6;if(this.stats.sampleFlight(e,o,t.stability,this.clr.clr,this.prevPos.distanceTo(t.pos)),this.gates.list.length&&t.state<=se.WINGSUIT)for(let h of this.gates.check(this.prevPos,t.pos))this.onGate(h);let l=this.session;l.limit&&this.stats.totalTime>l.limit&&!this.timeOver&&(this.timeOver=!0,this.ui.flash("TIME LIMIT EXCEEDED","#ff4a3a"));let c=this.def.size*1.5;if(Math.abs(t.pos.x)>c||Math.abs(t.pos.z)>c){t.setState(se.CRASHED),this.endFlight({type:"crash",what:"bounds"});return}}r&&(r==="exit"?(this.audio.play("jump"),this.stats.exitPos=t.pos.clone()):this.endFlight(r))}onStateChange(e,t){t===se.WINGSUIT&&(this.audio.play("wings"),this.rig.kick(.3)),t===se.DEPLOY&&this.audio.play("deploy"),t===se.CANOPY&&(this.rig.kick(.8),this.flight.hardOpening&&(this.stats.hardOpening=!0,this.ui.flash("HARD OPENING","#ffd23f")))}onGate(e){let t=this.gates.list[e.index];if(e.type==="pass"){this.stats.gatesPassed++,this.stats.accSum+=e.acc;let i=e.acc>.75;this.audio.play(i?"gatePerfect":"gate"),this.ui.flash(i?"PERFECT GATE":"GATE",i?"#7af0ff":"#3dff8a"),e.finish&&this.session.mode==="speed"&&(this.stats.finishTime=this.stats.totalTime,this.ui.flash(`FINISH ${zt(this.stats.finishTime)}`,"#ffd23f")),this.puffs.burst(t.c,[1,.8,.4,.6],14,12,3)}else this.audio.play("miss"),this.ui.flash("GATE MISSED","#ff4a3a"),e.finish&&this.session.mode==="speed"&&(this.stats.finishTime=this.stats.totalTime+15)}endFlight(e){if(this.ending)return;let t=this.flight,i=this.stats,n=this.session;if(this.rec.sample(0,t,this.inp,!0),this.gates.list.length)for(let a=this.gates.next;a<this.gates.list.length;a++)this.gates.list[a].state==="pending"&&(this.gates.list[a].state="missed");i.gatesTotal=this.gates.list.length,i.landPos=t.pos.clone();let r=t.vel.clone();if(e.type==="land"&&!e.crash&&!e.water){let a=Math.hypot(t.pos.x-n.target.x,t.pos.z-n.target.z);i.landDist=a,i.landQuality=e.hard?.6:1,n.mode==="landing"&&e.roof!==(n.target.y>5&&this.def.city)&&(i.landDist=a+50),this.audio.play("land"),this.puffs.burst(t.pos.clone().setY(t.pos.y-.9),this.dustColor(),10,4,2),this.ending={t:0,ok:!0,res:e}}else{i.crashed=!0,i.crashWhat=e.water?"water":e.what||(e.type==="land"?"hard landing":"terrain");let a=e.water||e.what==="water";this.audio.play(a?"splash":"crash"),this.rig.kick(1.5),this.puffs.burst(t.pos,a?[.85,.95,1,.9]:this.dustColor(),40,14,5),this.ending={t:0,ok:!1,res:e,vel:r.multiplyScalar(a?.05:.18),spin:new M(Math.random()*8-4,Math.random()*8-4,Math.random()*8-4)}}qe.gameplayStop()}dustColor(){let e=this.def.id;return e==="skyfall"?this.flight.pos.y>1300?[.95,.97,1,.8]:[.6,.55,.45,.7]:e==="redstone"?[.85,.55,.35,.8]:e==="tidal"?[.85,.8,.65,.7]:[.6,.6,.6,.7]}async finishFlight(){let e=this.session,t=this.stats,i=this.flight,n=this.ending.ok,r=this.def,a=t.exitPos||i.pos,o=Math.hypot((t.landPos||i.pos).x-a.x,(t.landPos||i.pos).z-a.z),l=Math.max(1,a.y-(t.landPos||i.pos).y),c={par:e.par,targetTime:e.targetTime,landR:e.target.r,routeLen:e.routeLen*.95,directDist:e.directDist||1,glideRatio:o/l},h=pd(e.mode,t,c),d=[];n||d.push(t.crashWhat==="bounds"?"Left the flight area":t.crashWhat==="water"?"Water landing":t.crashWhat==="hard landing"?"Landing too hard":`Collision (${t.crashWhat})`);let u=e.mission?e.mission.maxMiss??1:99,p=t.gatesTotal-t.gatesPassed;n&&t.gatesTotal&&p>u&&e.mode!=="free"&&d.push(`Missed ${p} gates (max ${u})`),n&&this.timeOver&&d.push("Time limit exceeded"),n&&e.mode==="landing"&&t.landDist>e.target.r&&d.push("Landed outside the target"),n&&e.mission&&e.mode!=="landing"&&t.landDist>e.target.r*3&&d.push("Landed too far from the landing zone");let m=d.length===0,v=m?ud(h.total):null,f=He.data,g=Math.floor(m?h.total/20:h.total/60),y=!1,x=!1;if(e.mission&&m){let S=f.missions[e.mission.id];S||(y=!0,g+=50),(!S||h.total>S.best)&&(f.missions[e.mission.id]={best:h.total,rank:v.id})}let _=`${e.map}_${e.mode}`,b=f.records[_]||{};m&&(!b.score||h.total>b.score)&&(b.score=h.total,b.rank=v.id,x=!!f.records[_]),e.mode==="speed"&&m&&t.finishTime!=null&&(!b.time||t.finishTime<b.time)&&(b.time=t.finishTime,x=!0),(!b.maxSpeed||t.maxSpeed>b.maxSpeed)&&(b.maxSpeed=t.maxSpeed),b.flights=(b.flights||0)+1,f.records[_]=b,f.coins+=g,f.flights++,f.stats.flightTime+=t.totalTime,f.stats.maxSpeed=Math.max(f.stats.maxSpeed,t.maxSpeed),n?f.stats.landings++:f.stats.crashes++,f.stats.gates+=t.gatesPassed,this.tutorial&&(f.tutorialDone=!0),this.tutorial=!1,He.write(),(x&&m||v&&v.id==="perfect")&&qe.happytime(),qe.progress(Object.keys(f.missions).length/Ot.length*100),this.lastReplay={meta:{map:e.map,mode:e.mode,mission:e.mission?e.mission.id:null,time:e.time,weather:e.weather,score:h.total,rank:v?v.id:null,ok:m,date:Date.now(),look:this.currentLook(),maxSpeed:Math.round(t.maxSpeed),duration:t.totalTime},frames:this.rec.frames.slice()},this.lastResult={sc:h,rank:v,success:m,reasons:d,coins:g,firstClear:y,newRecord:x,st:t,ctx:c,ok:n},this.mode="results",qe.adsEnabled&&(this.ui.adLock(!0),await qe.midgame({started:()=>this.audio.mute("ad",!0)}),this.audio.mute("ad",!1),this.ui.adLock(!1)),this.audio.play(m?"finish":"fail"),this.ui.results(this.lastResult,e)}async doubleCoins(){let e=this.lastResult;if(!e||e.doubled||!qe.rewardedAvailable)return;this.ui.adLock(!0);let t=await qe.rewarded({started:()=>this.audio.mute("ad",!0)});this.audio.mute("ad",!1),this.ui.adLock(!1),t?(e.doubled=!0,He.data.coins+=e.coins,He.write(),this.audio.play("coin"),this.ui.toast(`Reward: +${e.coins} coins!`),this.ui.results(e,this.session)):this.ui.toast("No ad available right now. Please try again later.")}saveReplay(){if(!this.lastReplay)return;let e=He.data.archive;if(e.some(t=>t.meta.date===this.lastReplay.meta.date)){this.ui.toast("Already saved");return}for(e.unshift(this.lastReplay);e.length>4;)e.pop();He.write(),this.ui.toast("Replay saved to the Flight Archive")}nextMission(){let e=this.session;if(!e.mission)return;let t=Ot.findIndex(n=>n.id===e.mission.id),i=Ot[t+1];i&&this.missionUnlocked(i)&&this.startSession({missionId:i.id})}missionUnlocked(e){let t=Ot.indexOf(e);return t<=0?!0:!!He.data.missions[Ot[t-1].id]&&this.mapUnlocked(e.map)}mapUnlocked(e){return Object.keys(He.data.missions).length>=ur[e]}rankCount(e){let t=Qc.indexOf(e);return Object.values(He.data.missions).filter(i=>Qc.indexOf(i.rank)>=t).length}async startReplay(e){if(!e||!e.frames.length)return;let t=e.meta;this.mode="loading";let i=this.session;this.clearSession(),this.session=i,await this.loadWorld(t.map,t.time,t.weather);let n=t.mission?Ot.find(a=>a.id===t.mission):null,r=t.mode==="free"||t.mode==="landing"?null:n&&n.gates||eh(t.mode);if(this.gates=new cr(this.scene,this.world,this.def,r,t.mode),t.mode==="landing"){let a=oo(this.def,this.world);(a.target.x!==this.def.landing.x||a.target.z!==this.def.landing.z)&&(this.extraTarget=this.world.addTarget(a.target.x,a.target.y,a.target.z,a.target.r))}this.pilot.setLook(t.look||this.currentLook()),this.replay={player:new ao(e),t:0,speed:1,playing:!0,rew:!1,meta:t,sample:{pos:new M,q:new $e},lastT:0,prevPos:new M},this.mode="replay",qe.gameplayStop(),this.rig.setView("chase"),this.ui.show("replay"),this.ui.replayInit(this.replay)}exitReplay(){this.pilot.setLook(this.currentLook());let e=this.session;this.replay=null,this.lastResult&&e?(this.mode="results",this.ui.results(this.lastResult,e)):this.showMenu()}updateReplay(e){let t=this.replay,i=t.player.duration;t.playing&&(t.t+=e*t.speed*(t.rew?-3:1)),t.rew&&!t.playing&&(t.t-=e*3),t.t=de(t.t,0,i),t.t>=i&&(t.playing=!1);let n=t.player.sample(t.t,t.sample);if(!n)return;if(this.gates.list.length){t.t<t.lastT&&(this.gates.reset(),t.prevPos.copy(t.player.sample(0,{pos:new M,q:new $e}).pos),t.lastT=0);let u={pos:new M,q:new $e};for(let p=t.lastT;p<=t.t;p+=.05)t.player.sample(p,u),u.state<=se.WINGSUIT&&u.state>=se.FREEFALL&&this.gates.check(t.prevPos,u.pos),t.prevPos.copy(u.pos)}t.lastT=t.t,this.renderPos.copy(n.pos),this.renderQ.copy(n.q);let r=xn.set(0,0,0),a=t.player.sample(Math.min(i,t.t+.1),{pos:new M,q:new $e});a&&r.copy(a.pos).sub(n.pos).multiplyScalar(10),r.lengthSq()<.01&&r.set(0,0,.1),this.replayVel=r.clone(),this.pilot.canopyOpen=n.canopyOpen;let o=n.state,l=o===se.READY?"idle":o===se.RUN?"run":o===se.CANOPY?"canopy":o===se.DEPLOY?n.canopyOpen>.5?"canopy":"flight":o===se.LANDED?"landed":o===se.CRASHED?"crash":"flight";this.pilot.animate(e*Math.abs(t.speed),{state:l,wing:n.wing,posture:n.posture,pitchIn:n.pitch,bankIn:n.turn,airspeed:n.speed,brakeL:n.brakeL,brakeR:n.brakeR,brake:Math.min(n.brakeL,n.brakeR),canopyBank:n.cBank,runPhase:n.runPhase,runSpeed:1,crashT:t.t,celebrate:t.meta.ok});let c=o===se.CANOPY||o===se.DEPLOY&&n.canopyOpen>.3,h=th.set(0,0,1).applyQuaternion(n.q),d={pos:n.pos,vel:r,q:n.q,heading:Math.atan2(r.x,r.z),canopy:c,standing:o<=se.RUN||o>=se.LANDED,bank:0,turbulence:0};this.rig.update(e,d,this.world,this.rig.view==="orbit"||o>=se.LANDED||o<=se.RUN?"orbit":"flight"),this.pilot.setHeadVisible(this.rig.view!=="pilot"),this.ui.replayUpdate(t,n),this.lastFocus=d}frame(e){this.time+=e,this.input.poll(e);let t=this.input.consume();this.handleActions(t);let[i,n]=this.input.takeLook();(i||n)&&this.rig.look(i,n),this.inp=this.input.state();let r=this.time,a=this.gustMul||.5;if(this.gust.set(this.noise.n2(r*.25,1.3)*3.5*a,this.noise.n2(r*.4,7.7)*1.5*a,this.noise.n2(r*.25,4.1)*3.5*a),this.wind.copy(this.baseWind).add(this.gust),this.mode==="menu"||this.mode==="garage"?this.updateMenuScene(e):this.mode==="prep"?this.updatePrep(e):this.mode==="flight"?this.updateFlight(e):this.mode==="replay"?this.updateReplay(e):(this.mode==="results"||this.mode==="paused")&&this.updateIdleScene(e),this.world){this.world.update(e,this.baseWind);let h=this.renderPos;this.sky.update(e,this.camera,h);let d=this.mode==="flight"?this.flight.vel:this.mode==="replay"&&this.replayVel?this.replayVel:xn.set(0,0,0);this.particles.update(e,this.camera.position,d,this.wind,this.settings.speedFx&&(this.mode==="flight"||this.mode==="replay")),this.gates&&this.gates.update(e)}this.puffs.update(e);let o=this.mode==="flight"?this.flight.vel.length():this.mode==="replay"&&this.replayVel?this.replayVel.length():0;this.post.uniforms.uBlur.value=this.settings.speedFx?de((o-40)/50,0,1.4):0,this.post.uniforms.uDanger.value=Je(this.post.uniforms.uDanger.value,this.mode==="flight"?this.warnLevel>=3?1:this.warnLevel===2?.45:0:0,6,e),this.post.uniforms.uFade.value=Je(this.post.uniforms.uFade.value,this.ending&&!this.ending.ok&&this.ending.t>.8?.55:0,3,e);let l=this.mode==="flight"&&this.flight.state>=se.FREEFALL&&this.flight.state<=se.CANOPY||this.mode==="replay"&&this.replay&&this.replay.playing,c=this.mode==="flight"?de((o-30)/50,0,1)*.6+(this.clr.clr<40?.4:0):this.mode==="menu"?.15:.05;this.audio.update(e,{flying:l,speed:o,tension:this.pilot.tension,agl:this.clr.agl,turb:this.gust.length()*.2,intensity:c}),this.post.render(this.scene,this.camera)}handleActions(e){for(let t of e){if(t.startsWith("pad:")){this.ui.padNav(t);continue}switch(this.mode){case"prep":t==="stab"?this.preview?this.preview=null:this.jump():t==="camera"?this.cycleCam():t==="pause"&&this.pause();break;case"flight":t==="stab"&&this.flight.state===se.FREEFALL?this.flight.spreadWings():t==="chute"?this.flight.deploy()&&(this.stats.deployAlt=this.clr.agl):t==="camera"?this.cycleCam():t==="restart"?this.restart():t==="pause"&&this.pause();break;case"paused":t==="pause"?this.resume():t==="restart"&&this.restart();break;case"results":t==="restart"&&(this.ui.hideModal(),this.restart());break;case"replay":t==="pause"||t==="stab"?this.ui.replayToggle():t==="camera"?this.ui.replayCam():t==="restart"&&(this.replay.t=0,this.replay.playing=!0);break}}}cycleCam(){let e=this.rig.cycle();this.settings.view=e,He.write(),this.ui.camLabel(to[e])}updatePrep(e){let t=this.flight;this.renderPos.copy(t.pos),this.renderQ.copy(t.q);let i=this.session.mode==="landing";this.pilot.animate(e,{state:i?"canopy":"idle",wing:0,airspeed:0}),this.pilot.root.position.copy(t.pos),this.pilot.root.quaternion.copy(t.q),this.pilot.setHeadVisible(!0);let n={pos:t.pos,vel:xn.set(Math.sin(t.heading)*.01,0,Math.cos(t.heading)*.01),q:t.q,heading:t.heading,canopy:i,standing:!0};if(this.preview){this.preview.t+=e;let r=this.preview.t/9;r>=1?this.preview=null:this.rig.flyover(r,this.def,this.world)}else this.rig.update(e,n,this.world,"orbit");this.clr.agl=0,this.tutorial&&this.ui.tutorial("prep")}updateFlight(e){let t=this.flight;if(this.ending)this.updateEnding(e);else{this.acc+=e;let c=0;for(;this.acc>=co&&c<10&&(this.physicsStep(co),this.acc-=co,c++,!this.ending););c>=10&&(this.acc=0);let h=this.ending?1:this.acc/co;this.renderPos.copy(this.prevPos).lerp(t.pos,h),this.renderQ.copy(this.prevQ).slerp(t.q,h)}if(this.clrT-=e,this.clrT<=0&&!this.ending&&(this.clrT=1/15,this.clr=this.world.clearance(t.pos,t.vel.lengthSq()>1?t.vel:xn.set(0,-1,0)),this.gates.list.length&&t.state<=se.WINGSUIT&&(this.def.route.line.nearest(t.pos.x,t.pos.z,this.routeNear),this.routeNear.d<600)))for(let c of this.gates.checkBehind(this.routeNear.s))this.onGate(c);let i=t.state,n=i===se.READY?"idle":i===se.RUN?"run":i===se.FREEFALL&&t.stateTime<.5?"jump":i===se.DEPLOY?t.canopyOpen>.5?"canopy":"flight":i===se.CANOPY?t.brake>.7&&this.clr.agl<8?"flare":"canopy":i===se.LANDED?"landed":i===se.CRASHED?"crash":"flight";this.pilot.canopyOpen=this.ending&&this.ending.ok?Math.max(0,this.pilot.canopyOpen-e*.8):t.canopyOpen,this.pilot.animate(e,{state:n,wing:i===se.DEPLOY?Math.max(0,t.wing-t.deployT):t.wing,posture:t.posture,pitchIn:this.inp.pitch,bankIn:this.inp.turn+this.inp.roll,airspeed:t.airspeed,brakeL:t.brakeL,brakeR:t.brakeR,brake:t.brake,canopyBank:t.cBank,runPhase:t.runPhase,runSpeed:1,crashT:this.ending?this.ending.t:0,celebrate:this.ending&&this.ending.ok&&this.ending.t>.6}),this.pilot.root.position.copy(this.renderPos),this.pilot.root.quaternion.copy(this.renderQ),this.pilot.setHeadVisible(this.rig.view!=="pilot"||!!this.ending);let r=this.pilot.trailColor;if(r&&i===se.WINGSUIT&&(this.trailT-=e,this.trailT<=0)){this.trailT=.025;let c=r==="rainbow"?Af(this.time*.3%1):r,h=th.set(0,0,-.9).applyQuaternion(t.q).add(t.pos);this.puffs.emit(h,xn.copy(t.vel).multiplyScalar(.05),c,1.2,2.2,3)}let a=i===se.CANOPY||i===se.DEPLOY&&t.canopyOpen>.3,o={pos:this.renderPos,vel:t.vel,q:this.renderQ,heading:i===se.CANOPY?t.cHeading:t.heading,canopy:a,standing:i<=se.RUN,bank:t.bank*(i===se.WINGSUIT?1:0),turbulence:1-t.stability/100+this.gust.length()*.05},l=this.ending||i<=se.RUN&&this.rig.view!=="pilot"?"orbit":"flight";this.ending&&!this.ending.camSet&&(this.ending.camSet=!0,this.rig.orbit.dist=10,this.rig.orbit.pitch=.35,this.rig.orbit.yaw=.6,this.rig.target.copy(this.renderPos)),this.rig.update(e,o,this.world,l),this.lastFocus=o,this.computeWarnings(e),this.ui.hud(e),this.tutorial&&this.ui.tutorial(this.tutorialPhase())}updateEnding(e){let t=this.ending,i=this.flight;if(t.t+=e,!t.ok&&t.vel){i.pos.addScaledVector(t.vel,e),t.vel.multiplyScalar(Math.exp(-2.5*e)),t.vel.y-=9.8*e;let n=this.world.ground(i.pos.x,i.pos.z);i.pos.y<n.h+.4&&(i.pos.y=n.h+(n.water?-.3:.4),t.vel.y=Math.abs(t.vel.y)*.25,t.vel.x*=.6,t.vel.z*=.6,t.spin.multiplyScalar(.7)),ho.setFromEuler(new Et(t.spin.x*e,t.spin.y*e,t.spin.z*e)),i.q.multiply(ho),t.spin.multiplyScalar(Math.exp(-1.5*e))}else t.ok&&(Pi(i.cHeading,0,ho),i.q.slerp(ho,1-Math.exp(-6*e)));this.renderPos.copy(i.pos),this.renderQ.copy(i.q),t.t>(t.ok?2.4:2)&&!t.done&&(t.done=!0,this.finishFlight())}tutorialPhase(){let e=this.flight;return e.state===se.RUN?null:e.state===se.FREEFALL?"spread":e.state===se.WINGSUIT?e.stateTime<5?"pitch":this.deployWindowShown?"deploy":e.stateTime<11?"turn":"gates":e.state===se.CANOPY?this.clr.agl<25?"flare":"canopy":null}computeWarnings(e=1/60){let t=this.flight,i=this.settings.warn,n=this.session,r=0,a="",o="";if(this.ending){this.warnLevel=0,this.ui.warn("","");return}let l=t.state===se.WINGSUIT||t.state===se.FREEFALL,c=this.clr.clr,h=this.clr.agl;if(l){c<i.critical?(r=3,a=h<=c+1?"PULL UP":"OBSTACLE"):c<i.strong?(r=2,a=h<=c+1?"TERRAIN":"OBSTACLE"):c<i.subtle&&(r=1,a="TERRAIN PROXIMITY");let d=Math.hypot(t.pos.x-n.target.x,t.pos.z-n.target.z),u=t.pos.y-n.target.y;!r&&t.state===se.WINGSUIT&&(h<160&&u<260?(r=2,a="DEPLOY NOW"):(d<900&&u<480||h<260&&u<420)&&(a="DEPLOYMENT WINDOW",o="info",this.deployWindowShown=!0)),!r&&t.stability<35&&(r=1,a="UNSTABLE \u2014 HOLD "+this.ui.keyName("stab"))}else t.state===se.CANOPY&&h<12&&h>1.5&&-t.vel.y>3&&(a="FLARE \u2014 "+this.ui.keyName("pitchUp"),o="info");r&&r!==this.warnLevel&&this.audio.play(r>=2?"warnHigh":"warn"),r>=2&&(this.warnBeep=(this.warnBeep||0)-e,this.warnBeep<=0&&(this.warnBeep=r===3?.25:.6,this.audio.play("warn"))),this.warnLevel=r,this.ui.warn(a,o||(r?"l"+r:""))}updateMenuScene(e){let t=this.def,i=t.route;if(this.mode==="garage"){this.garageT+=e;let B=i.line.at(i.L*.3),z=xn.set(B.x,i.routeY(i.L*.3)+40,B.z),D=this.ui.garageTab==="chute";this.pilot.canopyOpen=Je(this.pilot.canopyOpen,D?1:0,4,e);let F=new $e;D?Pi(this.garageT*.3,0,F):ar(new M(Math.cos(this.garageT*.3),0,-Math.sin(this.garageT*.3)),new M(0,1,0),new M(Math.sin(this.garageT*.3),0,Math.cos(this.garageT*.3)),F),this.pilot.animate(e,{state:D?"canopy":"flight",wing:1,posture:0,pitchIn:0,bankIn:Math.sin(this.garageT)*.3,airspeed:45}),this.pilot.root.position.copy(z),this.pilot.root.quaternion.copy(F),this.pilot.setHeadVisible(!0),this.renderPos.copy(z);let U=-.6,X=D?16:4.2;this.camera.position.set(z.x+Math.sin(U)*X,z.y+(D?4:1.4),z.z+Math.cos(U)*X),this.camera.up.set(0,1,0),this.camera.lookAt(z.x+0,z.y+(D?3:0),z.z),this.camera.fov!==50&&(this.camera.fov=50,this.camera.near=.3,this.camera.updateProjectionMatrix());return}this.menuS+=e*48,this.menuS>i.L*.78&&(this.menuS=i.L*.1);let n=this.menuS,r=i.line.at(n),a=i.line.at(n+30),o=i.routeY(n)+25,l=i.routeY(n+30)+25,c=xn.set(r.x,o,r.z),h=th.set(a.x-r.x,l-o,a.z-r.z).normalize().multiplyScalar(48),d=i.line.at(n-30),u=Math.atan2(a.x-r.x,a.z-r.z)-Math.atan2(r.x-d.x,r.z-d.z),p=de(-u*6,-.8,.8);this.menuBank=Je(this.menuBank||0,p,2,e);let m=h.clone().normalize(),v=new M().crossVectors(m,new M(0,1,0)).normalize(),f=new M().crossVectors(v,m).normalize(),g=Math.cos(this.menuBank),y=Math.sin(this.menuBank),x=f.clone().multiplyScalar(g).addScaledVector(v,y),_=.2,b=m.clone().multiplyScalar(Math.cos(_)).addScaledVector(x,Math.sin(_)),S=x.clone().multiplyScalar(Math.cos(_)).addScaledVector(m,-Math.sin(_)),R=new M().crossVectors(S,b).normalize(),P=ar(R,S,b,new $e);this.pilot.canopyOpen=0,this.pilot.animate(e,{state:"flight",wing:1,posture:0,pitchIn:0,bankIn:this.menuBank,airspeed:48}),this.pilot.root.position.copy(c),this.pilot.root.quaternion.copy(P),this.pilot.setHeadVisible(!0),this.renderPos.copy(c);let C=this.rig.view;this.rig.view="cinema",this.rig.update(e,{pos:c,vel:h,q:P,heading:Math.atan2(h.x,h.z),bank:this.menuBank},this.world,"flight"),this.rig.view=C}updateIdleScene(e){let t=this.flight;this.ending&&this.mode!=="paused"&&this.updateEnding(e);let i=t.state,n=i===se.LANDED?"landed":i===se.CRASHED?"crash":i===se.CANOPY?"canopy":i===se.READY?"idle":"flight";this.pilot.animate(this.mode==="paused"?0:e,{state:n,wing:t.wing,airspeed:this.mode==="paused"?0:t.airspeed,celebrate:this.ending&&this.ending.ok,crashT:this.ending?this.ending.t:0,brakeL:t.brakeL,brakeR:t.brakeR}),this.pilot.root.position.copy(this.renderPos),this.pilot.root.quaternion.copy(this.renderQ),this.mode==="results"&&this.lastFocus&&this.rig.update(e,{...this.lastFocus,pos:this.renderPos},this.world,"orbit")}};function Af(s){let e=new ye().setHSL(s,.9,.6);return[e.r,e.g,e.b,.7]}async function Rf(){let s=document.getElementById("loadBar");s.style.width="5%",await qe.init(),qe.loadingStart(),He.load();let e=new uo(document.getElementById("c"));window.__game=e;let t=performance.now(),i=n=>{let r=Math.min(.1,Math.max(0,(n-t)/1e3));t=n;try{e.frame(r)}catch(a){console.error(a)}requestAnimationFrame(i)};requestAnimationFrame(i),qe.loadingStop(),He.isNew||!He.data.tutorialDone?await e.startSession({missionId:"m1"}):await e.showMenu()}Rf().catch(s=>{console.error(s);let e=document.getElementById("loadText");e&&(e.textContent="Sorry, your browser could not start the game (WebGL required).")});})();
